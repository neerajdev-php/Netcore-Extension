/**
 * Data Transfer module
 * - Screens live under partials/sections/data-transfer-screens/
 * - Each screen is loaded on demand the first time it is shown
 * - Event binding runs once per screen after load
 * - Tab navigation initializes here; landing content loads only when the tab is opened
 */
jQuery(function ($) {
	var SCREEN_FOLDER = 'partials/sections/data-transfer-screens/';
	var CONTAINER_SELECTOR = '#section-data-transfer';
	var SETUP_FORM_SELECTOR = '#dt-setup-form';
	var CONNECTIONS_ENTITY = 'netcore0__Connections';
	var DATA_TRANSFER_ENTITY = 'netcore0__Data_Transfer';

	/**
	 * After a successful INSERT, Zoho returns the new record id.
	 * We keep it here so the next SAVE updates that same record
	 * instead of creating another duplicate.
	 *
	 * null  → Insert / Create mode (no record yet)
	 * "id"  → View / Edit mode (record already exists in CRM)
	 */
	var currentRecordId = null;

	/**
	 * Setup form field contract (used by get/set helpers + Save API payload).
	 * Keys map 1:1 to name / data-dt-field attributes in dt-event-screen.html.
	 */
	var SETUP_FIELDS = {
		transferName: 'transferName',
		connectionId: 'connectionId',
		sourceObject: 'sourceObject',
		targetObject: 'targetObject',
		triggerSync: 'triggerSync'
	};

	/** UI field key → Zoho CRM field API name (reference map; payload uses these names directly) */
	var SETUP_ZOHO_FIELD_MAP = {
		connectionId: 'netcore0__Connection',
		sourceObject: 'netcore0__Which_Zoho_object',
		targetObject: 'netcore0__Netcore_Object',
		triggerSync: 'netcore0__Trigger_Type'
	};

	var SETUP_FIELD_MESSAGES = {
		connectionId: 'Connection is required.',
		sourceObject: 'Zoho data is required.',
		targetObject: 'Netcore CE data is required.',
		triggerSync: 'Please select a trigger for real-time transfer.'
	};

	var SETUP_NEXT_STEP_ALERT_MESSAGE = 'Fill all required detail to proceed to next step.';
	var DATA_CONFIG_TEST_ALERT_MESSAGE =
		'Please fill all the fields to test your configuration.';
	var DATA_CONFIG_START_EXPORT_ALERT_MESSAGE =
		'Please fill all the required fields to start the export.';
	var START_EXPORT_FUNCTION = 'netcore0__create_data_transfer_workflow';
	var START_EXPORT_MISSING_ID_MESSAGE =
		'Save this data transfer before starting the export.';
	var START_EXPORT_UNAVAILABLE_MESSAGE =
		'Unable to start the export right now. Please try again.';
	var DUPLICATE_DATA_TRANSFER_NAME_MESSAGE =
		'A data transfer with this name already exists. Please use a different name.';
	var DATA_TRANSFER_NAME_CHECK_FAILED_MESSAGE =
		'Unable to validate data transfer name. Please try again.';
	var DUPLICATE_TRANSFER_TOAST_MESSAGE = 'Data transfer duplicated successfully.';

	/**
	 * RUN TEST success gate for START EXPORT.
	 * Fingerprint invalidates a prior success when Setup / Data Config changes
	 * (avoids exporting with a stale "tested" configuration).
	 */
	var runTestGate = {
		isTestRunSuccessful: false,
		fingerprint: ''
	};
	var ZOHO_OBJECT_CHANGED_ALERT_MESSAGE = 'Netcore entity changed. Please review the updated field mappings before continuing.';
	var NETCORE_ENTITY_CHANGED_ALERT_MESSAGE = 'Netcore entity changed. Please review the updated field mappings before continuing.';

	/** Exact inline messages for Data Configuration → Test validation. */
	var DATA_CONFIG_TEST_MESSAGES = {
		sourceFields: 'Field is required.',
		eventSelect: 'Field is required.',
		zohoIdentifier: 'Zoho identifier is required.',
		sfIdentifier: 'Netcore CE identifier is required.',
		customParams: 'Custom parameters are required.',
		sourceIdentifier: 'Source identifier is required.',
		destinationIdentifier: 'Destination identifier is required.',
		mappingSourceField: 'Source field is required.',
		destinationAttribute: 'Destination attribute is required.',
		filterField: 'Field is required.',
		filterOperator: 'Field is required.',
		filterValue: 'Field is required.',
		addToList: 'Field is required.',
		removeFromList: 'Field is required.'
	};

	var CONNECTION_PLACEHOLDERS = {
		default: 'Select connection',
		loading: 'Loading connections...',
		empty: 'No connections available',
		error: 'Unable to load connections'
	};

	/** Zoho Function that returns Netcore event names for the Entity dropdown. */
	var EVENT_LISTING_FUNCTION = 'netcore0__NetCore_Event_Listing';
	var EVENT_SELECT_EMPTY_MESSAGE = 'No Netcore entities available';

	/** Tracks Netcore Entity (#eventSelect) selection + in-flight load. */
	var eventSelectUi = {
		selectedValue: '',
		loadingConnectionId: null
	};

	/** Zoho Function that returns Netcore CE identifier config for #sfIdentifier. */
	var NETCORE_IDENTIFIER_FUNCTION = 'netcore0__netcore_identifier';
	/** Always offered in both identifier dropdowns (Event + Contacts). */
	var NETCORE_CE_BASE_IDENTIFIERS = ['EMAIL', 'MOBILE'];
	var SF_IDENTIFIER_EMPTY_MESSAGE = 'No Netcore CE identifiers available';
	var SF_IDENTIFIER_PLACEHOLDER = 'for ex: Email';
	var DESTINATION_IDENTIFIER_DD_ID = 'destination-identifier-dropdown';
	var SECONDARY_SOURCE_IDENTIFIER_DD_ID = 'secondary-source-identifier-dropdown';
	var SECONDARY_DESTINATION_IDENTIFIER_DD_ID = 'secondary-destination-identifier-dropdown';
	var CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE = 'MOBILE';

	/** Zoho Function that returns audience/list options for Contacts "add to list". */
	var AUDIENCE_LISTING_FUNCTION = 'netcore0__get_all_audience';
	var CONTACTS_ADD_LIST_EMPTY_MESSAGE = 'No lists available';
	var CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE = 'Select a connection first.';

	/** Zoho Function that returns attribute options for Field mapping → Destination attribute. */
	var ATTRIBUTE_LISTING_FUNCTION = 'netcore0__get_all_attribute_listing';
	var CREATE_ATTRIBUTE_FUNCTION = 'netcore0__create_new_attributes';
	var ATTRIBUTE_BASED_STATUS_FUNCTION = 'netcore0__data_t_status_attribute_based';
	var MAPPING_DEST_ATTRIBUTE_EMPTY_MESSAGE = 'No attributes available';
	var MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE = 'Select a connection first.';
	var CREATE_ATTR_SUCCESS_MESSAGE = 'Attribute creation started successfully.';
	var CREATE_ATTR_ERROR_MESSAGE = 'Attribute creation failed. Please try again.';

	/** CRM module that logs every approved attribute request against its Data Transfer. */
	var ATTRIBUTE_REQUEST_ENTITY = 'netcore0__Data_Transfer_Attribute';
	var ATTRIBUTE_REQUEST_PENDING_STATUS = 'Pending';

	/** Sync status while Netcore has an attribute request pending — drives the listing badge. */
	var CREATING_ATTRIBUTES_STATUS = 'Creating Attributes';

	/** Netcore entity label wording — Accounts gets its own question. */
	var ACCOUNTS_SOURCE_OBJECT = 'Accounts';
	var EVENT_SELECT_LABEL_DEFAULT = 'Select which Netcore entity should receive data from Zoho';
	var EVENT_SELECT_LABEL_ACCOUNTS = 'Which event would you like to transfer the account data to?';

	/** New attributes requested for the open transfer; START EXPORT writes both status and count. */
	var pendingAttributeRequestCount = 0;
	var CREATE_ATTR_REQUIRED_MESSAGE = 'Field is required.';

	/** Shared attribute list from netcore0__get_all_attribute_listing — all mapping rows. */
	var mappingDestAttributeUi = {
		attributesCache: [],
		loadingConnectionId: null
	};

	/** Create attribute panel (#createAttributePanel) UI state. */
	var createAttributeUi = {
		saving: false,
		targetDestAttributeDd: null
	};

	/** Zoho Function invoked by RUN TEST in the Test configurations panel. */
	var RUN_TEST_FUNCTION = 'netcore0__task_event_data_transfer_runtest';
	var CONTACTS_RUN_TEST_FUNCTION = 'netcore0__create_contact_data_runtest';

	/** Event vs Contacts — separate function names; shared RUN TEST handler. */
	var eventRunTestApiConfig = {
		functionName: RUN_TEST_FUNCTION,
		buildPayload: null
	};
	var contactsRunTestApiConfig = {
		functionName: CONTACTS_RUN_TEST_FUNCTION,
		buildPayload: null
	};
	var RUN_TEST_VALIDATION_MESSAGE =
		'Please fill all the fields to test your configuration.';
	var RUN_TEST_SUCCESS_MESSAGE =
		'The test configuration is successful and is working as expected.';
	var RUN_TEST_ERROR_MESSAGE =
		'The test configuration failed. Please check your values and try again.';
	var RUN_TEST_UNAVAILABLE_MESSAGE =
		'Unable to run the test right now. Please try again.';

	/** Contacts RUN TEST → #statusErrorContactTest gateway JSON copy buffer. */
	var contactsTestErrorUi = {
		lastGatewayJson: '',
		copyToastTimer: null,
		lastRunTestPayload: null,
		lastRunTestReqData: null
	};

	/** Tracks Netcore CE identifier (#sfIdentifier) selection + in-flight load. */
	var sfIdentifierUi = {
		selectedValue: '',
		/** foreignkey.value from netcore0__netcore_identifier (the Primary key option). */
		primaryValue: '',
		loadingConnectionId: null
	};

	/**
	 * Netcore CE import options.
	 * Task / Call / Meeting → Event only.
	 * All other Zoho objects → Event + Contacts.
	 */
	var NETCORE_IMPORT_EVENT = { value: 'Event', label: 'Event' };
	var NETCORE_IMPORT_CONTACTS = { value: 'Contacts', label: 'Contacts' };

	/** Wizard step indices — Setup (divided from Data configuration / Field mapping). */
	var WIZARD_STEP = {
		SETUP: 0,
		DATA_CONFIG: 1,
		FIELD_MAPPING: 2
	};

	/** Zoho objects that can only sync as Event (by data-value or data-label). */
	var EVENT_ONLY_SOURCE_OBJECTS = {
		Tasks: true,
		Calls: true,
		Meetings: true,
		// Legacy data-value / saved netcore0__Source before Meeting → Meetings rename.
		Events: true,
		Task: true,
		Call: true,
		Meeting: true
	};

	/**
	 * Dropdown data-value → Zoho CRM META Entity when they differ.
	 * Meeting option stores "Meetings"; Zoho CRM module API name remains "Events".
	 */
	var SOURCE_OBJECT_META_ENTITY_MAP = {
		Meetings: 'Events'
	};

	/** Older saved Source / Which_Zoho_object values → current dropdown data-value. */
	var SOURCE_OBJECT_LEGACY_VALUE_ALIASES = {
		Events: 'Meetings'
	};

	var screens = {
		landing: {
			key: 'landing',
			rootSelector: '#data-transfer',
			url: SCREEN_FOLDER + 'dt-landing-screen.html',
			bind: bindLandingScreenEvents
		},
		event: {
			key: 'event',
			rootSelector: '#data-transfer-setup',
			url: SCREEN_FOLDER + 'dt-event-screen.html',
			bind: bindEventScreenEvents
		}
	};

	var state = {
		loaded: {},
		bound: {},
		currentScreen: null,
		opening: false,
		connections: [],
		connectionsLoaded: false,
		connectionsLoading: false,
		saving: false,
		toastHideTimer: null,
		nextAlertHideTimer: null,
		zohoObjectAlertHideTimer: null,
		fieldMappingAlertHideTimer: null
	};

	/* ------------------------------------------------------------------ */
	/* Current record id (Insert mode vs View/Edit mode)                  */
	/* ------------------------------------------------------------------ */

	/** True when we already have a CRM record id (edit / update mode). */
	function isDataTransferEditMode() {
		return !!getCurrentRecordId();
	}

	/** Read the stored record id (JS variable first, then DOM fallback). */
	function getCurrentRecordId() {
		if (currentRecordId) {
			return String(currentRecordId);
		}

		var fromDom = $.trim($(SETUP_FORM_SELECTOR).attr('data-record-id') || '');
		if (fromDom) {
			currentRecordId = fromDom;
			return fromDom;
		}

		return '';
	}

	/**
	 * Store the CRM record id in a JS variable + on the form container.
	 * After this runs, SAVE will use updateRecord instead of insertRecord.
	 * Form field values are NOT cleared — user stays on the same filled screen.
	 */
	function setCurrentRecordId(recordId) {
		var id = $.trim(recordId == null ? '' : String(recordId));
		var previousId = currentRecordId || null;
		var nextId = id || null;

		// Different transfer (or leaving edit) → drop any prior RUN TEST success,
		// and the attribute request belongs to the transfer we are leaving.
		if (previousId !== nextId) {
			resetTestRunSuccessfulFlag();
			pendingAttributeRequestCount = 0;
		}

		currentRecordId = nextId;

		var $form = $(SETUP_FORM_SELECTOR);
		if (!$form.length) {
			return;
		}

		if (id) {
			$form.attr('data-record-id', id);
			$form.attr('data-dt-mode', 'edit');
		} else {
			$form.removeAttr('data-record-id');
			$form.attr('data-dt-mode', 'create');
		}
	}

	/** Back to Insert/Create mode (e.g. user opens a brand-new transfer). */
	function clearCurrentRecordId() {
		setCurrentRecordId(null);
	}

	/**
	 * Wipe every piece of editor state that survives between screen visits.
	 *
	 * The event screen markup is loaded once and reused, so without this the
	 * previous Edit (or Create) session leaks into the next one until a full
	 * page reload. Covers: record id / mode, RUN TEST gate, unsaved-changes
	 * baseline, Setup fields, Data Configuration selections, filters and the
	 * Test panel.
	 */
	function resetDataTransferEditor() {
		setCurrentRecordId(null);
		resetTestRunSuccessfulFlag();
		clearEditorFormBaseline();

		hideSetupToasts();
		hideSetupNextStepAlert();
		hideSetupInfoAlert();
		clearDuplicateDataTransferNameError();
		clearSetupFormErrors();
		clearDataConfigTestErrors();

		// ----- Setup -----
		var $form = getSetupFormRoot();
		if ($form.length) {
			$('#datatrsf-title').val('');
			[
				SETUP_FIELDS.connectionId,
				SETUP_FIELDS.sourceObject
			].forEach(function (fieldKey) {
				setCddValue($form.find('[data-field-key="' + fieldKey + '"]'), '', '');
			});
			// No Zoho object → clears + disables Netcore import and the trigger radios.
			syncImportTargetForSourceObject('');
			clearTriggerSyncSelection();
			updateSetupDependentFieldVisibility();
		}
		ensureDefaultTransferName();

		// ----- Data Configuration: Netcore side -----
		clearEventSelectDropdown();
		clearNetcoreCeIdentifierDropdown();
		clearContactsAddListDropdown(CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE);
		clearContactsRemoveListDropdown(CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE);
		clearMappingDestAttributeCache(MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE);
		eventSelectUi.loadingConnectionId = null;
		sfIdentifierUi.loadingConnectionId = null;
		if (contactsListUi && contactsListUi.addLists) {
			contactsListUi.addLists.loadingConnectionId = null;
		}

		// ----- Data Configuration: Zoho side -----
		sourceFieldsUi.loadedModule = null;
		sourceFieldsUi.fieldsCache = [];
		sourceFieldsUi.selected = {};
		customParamsUi.selected = {};
		customParamsUi.labels = {};
		// No Zoho object selected → repaints Source data, Zoho identifier,
		// Custom parameters and filter field lists with the empty-state hint.
		refreshSourceDataSection({ forceReload: true });

		// ----- Filters -----
		setFiltersToggleState(false);
		resetFilterRowsToSingleEmpty();

		// ----- Test panel -----
		$('#dt-test-config-rows').empty();
		testConfigSearchUi.searchStates = {};
		clearTestConfigSelectedRecords();
		hideTestConfigStatusBoxes();
		hideContactsTestErrorStatus();

		resetContactsDestinationFields();
		resetContactsSecondaryIdentity();
		resetMappingRowsToDefault();

		showDataTransferWizardStep(0);
	}

	/**
	 * ------------------------------------------------------------------
	 * Unsaved-changes gate for the Data Transfer close button
	 * (same pattern as Connections → connection-close).
	 * ------------------------------------------------------------------
	 * Snapshot covers Setup + Data Configuration (reuse run-test fingerprint).
	 */

	function getEditorFormSnapshot() {
		return getRunTestGateFingerprint();
	}

	function setEditorFormBaseline() {
		var $form = getSetupFormRoot();
		if (!$form.length) {
			return;
		}
		$form.data('editor-baseline', getEditorFormSnapshot());
	}

	function clearEditorFormBaseline() {
		getSetupFormRoot().removeData('editor-baseline');
	}

	function hasEditorFormChanges() {
		var baseline = getSetupFormRoot().data('editor-baseline');
		if (!baseline) {
			return false;
		}
		try {
			return baseline !== getEditorFormSnapshot();
		} catch (error) {
			console.error('hasEditorFormChanges error:', error);
			return false;
		}
	}

	function showDataTransferCloseModal() {
		var el = document.getElementById('data-transfer-close');
		if (!el || typeof bootstrap === 'undefined' || !bootstrap.Modal) {
			console.error('data-transfer-close modal is unavailable.');
			return;
		}
		bootstrap.Modal.getOrCreateInstance(el).show();
	}

	function hideDataTransferCloseModal() {
		var el = document.getElementById('data-transfer-close');
		if (!el || typeof bootstrap === 'undefined' || !bootstrap.Modal) {
			return;
		}
		try {
			bootstrap.Modal.getOrCreateInstance(el).hide();
		} catch (error) {
			console.error('hideDataTransferCloseModal error:', error);
		}
	}

	/** Navigate away from the editor (listing if records exist, else landing). */
	function exitDataTransferEditor() {
		clearEditorFormBaseline();
		clearCurrentRecordId();
		clearDuplicateDataTransferNameError();

		if (window.DataTransferListing && typeof window.DataTransferListing.openAfterEditorClose === 'function') {
			window.DataTransferListing.openAfterEditorClose({ animate: true });
			return;
		}

		showScreen('landing', { animate: true });
	}

	function handleDataTransferDiscardAndExit() {
		hideDataTransferCloseModal();
		exitDataTransferEditor();
	}

	/** How long the SAVE & EXIT toast stays on screen before the editor closes. */
	var SAVE_EXIT_TOAST_DELAY = 1600;

	/** Toasts and the bottom alert both sit at the panel's bottom edge — bring it into view. */
	function scrollToSetupPanelBottom() {
		try {
			// stop(true): a field-level scroll issued right after must win, not queue.
			$('html, body').stop(true).animate({ scrollTop: $(document).height() }, 250);
		} catch (panelScrollError) {
			console.error('Setup panel scroll failed:', panelScrollError);
		}
	}

	/**
	 * SAVE & EXIT on the close confirm: same save as #dt-setup-save-btn, then leave.
	 * The save waits for this modal to finish hiding — common-loader-popup is a modal
	 * too, and opening it mid-transition leaves a stuck Bootstrap backdrop.
	 * A failed save keeps the user in the editor with the error toast already shown.
	 */
	function handleDataTransferSaveAndExit() {
		var el = document.getElementById('data-transfer-close');

		function runSaveThenExit() {
			persistDataTransferRecord({
				showSuccessToast: true,
				showCommonLoader: true
			}).then(function () {
				scrollToSetupPanelBottom();
				setTimeout(exitDataTransferEditor, SAVE_EXIT_TOAST_DELAY);
			}).catch(function () {
				// Error toast already shown inside persistDataTransferRecord.
				scrollToSetupPanelBottom();
			});
		}

		if (!el) {
			runSaveThenExit();
			return;
		}

		$(el).one('hidden.bs.modal', runSaveThenExit);
		hideDataTransferCloseModal();
	}

	/**
	 * Close (×) on the DT editor:
	 *  - unsaved changes → data-transfer-close confirm
	 *  - clean → leave immediately
	 */
	function handleDataTransferCloseClick(event) {
		if (event) {
			event.preventDefault();
			event.stopPropagation();
		}

		if (hasEditorFormChanges()) {
			showDataTransferCloseModal();
			return;
		}

		exitDataTransferEditor();
	}

	/**
	 * ------------------------------------------------------------------
	 * Edit from Listing — fetch record + hydrate Setup / Data Config
	 * (same getRecord + populate pattern as Connections view/edit).
	 * ------------------------------------------------------------------
	 */

	function extractConnectionIdFromRecord(record) {
		if (!record) {
			return '';
		}
		var conn = record.netcore0__Connection;
		if (!conn) {
			return '';
		}
		if (typeof conn === 'string') {
			return $.trim(conn);
		}
		return $.trim(String(conn.id || ''));
	}

	/**
	 * Resolve a stored Zoho object (label or value) to the dropdown data-value
	 * (CRM module key used in Setup / netcore0__Source).
	 *
	 * Create stores data-value in the form; save writes the display label to
	 * netcore0__Which_Zoho_object (e.g. "Opportunities" / "Meeting") and the
	 * API/data-value to netcore0__Source (e.g. "Deals" / "Meetings").
	 * Edit hydrates with data-value so Source fields / Zoho identifier / Custom
	 * params load against the correct module (META may remap Meetings → Events).
	 */
	function resolveSourceObjectModuleApiName(stored) {
		var key = $.trim(String(stored || ''));
		if (!key) {
			return '';
		}

		// Meeting option used to save "Events" — map to current data-value.
		if (SOURCE_OBJECT_LEGACY_VALUE_ALIASES[key]) {
			key = SOURCE_OBJECT_LEGACY_VALUE_ALIASES[key];
		}

		var $options = getSetupFormRoot()
			.find('[data-field-key="' + SETUP_FIELDS.sourceObject + '"] [data-cdd-option]');

		if (!$options.length) {
			return key;
		}

		var $byValue = $options.filter(function () {
			return String($(this).attr('data-value') || '') === key;
		}).first();
		if ($byValue.length) {
			return String($byValue.attr('data-value'));
		}

		var $byLabel = $options.filter(function () {
			return String($(this).attr('data-label') || '') === key
				|| $.trim($(this).text()) === key;
		}).first();
		if ($byLabel.length) {
			return String($byLabel.attr('data-value'));
		}

		return key;
	}

	/** Entity name for ZOHO.CRM.META.getFields (may differ from Setup data-value). */
	function resolveCrmModuleEntityForMeta(moduleApiName) {
		var key = String(moduleApiName || '').trim();
		return SOURCE_OBJECT_META_ENTITY_MAP[key] || key;
	}

	function mapRecordToSetupValues(record) {
		// Prefer Source (module API / data-value); fall back to Which_Zoho_object
		// (may be the display label) and normalize either to data-value.
		var rawZohoObject = $.trim(
			record.netcore0__Source
			|| record.netcore0__Which_Zoho_object
			|| ''
		);

		return {
			transferName: $.trim(record.Name || ''),
			connectionId: extractConnectionIdFromRecord(record),
			sourceObject: resolveSourceObjectModuleApiName(rawZohoObject),
			targetObject: $.trim(record.netcore0__Netcore_Object || ''),
			triggerSync: $.trim(record.netcore0__Trigger_Type || '')
		};
	}

	function parseCsvApiNames(raw) {
		return String(raw || '')
			.split(',')
			.map(function (part) {
				return $.trim(part);
			})
			.filter(function (part) {
				return !!part;
			});
	}

	function parseSavedFilterRows(raw) {
		if ($.isArray(raw)) {
			return raw;
		}
		try {
			var parsed = JSON.parse($.trim(raw || '') || '[]');
			return $.isArray(parsed) ? parsed : [];
		} catch (error) {
			console.warn('Bad Filter_Data while hydrating editor:', raw, error);
			return [];
		}
	}

	function fetchDataTransferRecord(recordId) {
		var id = $.trim(recordId == null ? '' : String(recordId));
		if (!id) {
			return Promise.reject({ message: 'Invalid data transfer selected.' });
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.API
			|| typeof ZOHO.CRM.API.getRecord !== 'function'
		) {
			return Promise.reject({ message: 'Zoho CRM API is unavailable.' });
		}

		return Promise.resolve(ZOHO.CRM.API.getRecord({
			Entity: DATA_TRANSFER_ENTITY,
			RecordID: id
		})).then(function (response) {
			var record = response && response.data && response.data[0];
			if (!record) {
				return Promise.reject({ message: 'Data transfer record not found.' });
			}
			return record;
		});
	}

	function selectEventByValue(eventName) {
		var name = $.trim(eventName || '');
		var list = document.getElementById('eventSelectList');
		var valueEl = document.getElementById('eventSelectValue');
		if (!name || !list) {
			return;
		}

		var found = null;
		Array.prototype.forEach.call(list.querySelectorAll('.sdd-item'), function (item) {
			item.classList.remove('selected');
			if ($.trim(item.getAttribute('data-value') || '') === name) {
				found = item;
			}
		});

		if (!found) {
			found = document.createElement('div');
			found.className = 'sdd-item';
			found.setAttribute('data-value', name);
			found.textContent = name;
			list.appendChild(found);
		}

		found.classList.add('selected');
		eventSelectUi.selectedValue = name;
		if (valueEl) {
			valueEl.textContent = name;
			valueEl.classList.remove('placeholder');
			valueEl.classList.remove('is-placeholder');
		}
	}

	function selectSfIdentifierByValue(value, optionalLabel) {
		var selected = $.trim(value || '');
		if (!selected) {
			return;
		}

		var label = $.trim(optionalLabel || '');
		if (!label) {
			['sfIdentifierList', 'destinationIdentifierList'].forEach(function (listId) {
				var list = document.getElementById(listId);
				if (!list || label) {
					return;
				}
				Array.prototype.forEach.call(list.querySelectorAll('.dd-simple-item'), function (item) {
					var itemValue = $.trim(item.getAttribute('data-value') || '');
					if (
						itemValue === selected
						|| itemValue.toLowerCase() === selected.toLowerCase()
					) {
						label = item.getAttribute('data-label') || selected;
					}
				});
			});
		}
		if (!label) {
			label = selected;
		}

		sfIdentifierUi.selectedValue = selected;
		syncNetcoreCeIdentifierListSelection(selected);
		renderNetcoreCeIdentifierDisplay(label);

		if ($.trim(sfIdentifierUi.selectedValue || '')) {
			clearDataConfigFieldError('sfIdentifier');
			clearDataConfigFieldError('destinationIdentifier');
		}

		updateContactsSecondaryIdentityVisibility();
	}

	function applySourceFieldSelections(csv) {
		var apiNames = parseCsvApiNames(csv);
		var list = document.getElementById('datatrsf-event-export-list-lead');
		sourceFieldsUi.selected = {};

		if (!list) {
			return;
		}

		Array.prototype.forEach.call(list.querySelectorAll('.datatrsf-mdd-item'), function (item) {
			item.classList.remove('selected');
		});

		apiNames.forEach(function (apiName) {
			var item = null;
			Array.prototype.forEach.call(list.querySelectorAll('.datatrsf-mdd-item'), function (el) {
				if (el.getAttribute('data-value') === apiName) {
					item = el;
				}
			});
			if (!item) {
				return;
			}
			item.classList.add('selected');
			sourceFieldsUi.selected[apiName] = item.getAttribute('data-label') || apiName;
		});

		if (typeof sourceFieldsUi.renderTags === 'function') {
			sourceFieldsUi.renderTags();
		}
	}

	function applyCustomParamSelections(csv) {
		var apiNames = parseCsvApiNames(csv);
		var list = document.getElementById('customParamsList');
		customParamsUi.selected = {};

		if (list) {
			Array.prototype.forEach.call(list.querySelectorAll('.dd-check-item'), function (item) {
				item.classList.remove('selected');
			});
		}

		apiNames.forEach(function (apiName) {
			customParamsUi.selected[apiName] = true;
			if (!list) {
				return;
			}
			Array.prototype.forEach.call(list.querySelectorAll('.dd-check-item'), function (item) {
				if (item.getAttribute('data-value') === apiName) {
					item.classList.add('selected');
				}
			});
		});

		if (typeof renderCustomParamsTags === 'function') {
			renderCustomParamsTags();
		}
	}

	function normalizeContactsDestActionValue(value) {
		var normalized = $.trim(String(value || '')).toLowerCase();
		if (normalized === 'remove') {
			return 'remove';
		}
		if (normalized === 'add') {
			return 'add';
		}
		return normalized;
	}

	function normalizeContactsRemoveFromValue(value) {
		var normalized = $.trim(String(value || '')).toLowerCase();
		if (normalized === 'list') {
			return 'list';
		}
		if (normalized === 'contactmaster' || normalized === 'contact master') {
			return 'contactmaster';
		}
		return normalized;
	}

	function parseSavedBooleanValue(raw) {
		return raw === true
			|| String(raw || '').toLowerCase() === 'true'
			|| String(raw || '').toLowerCase() === 'yes';
	}

	function applyContactsListSelections(listElementId, selectedStore, csv, labelsCsv) {
		var list = document.getElementById(listElementId);
		var values = parseCsvApiNames(csv);
		var labels = parseCsvApiNames(labelsCsv);

		if (!selectedStore) {
			return;
		}

		selectedStore.selected = {};
		if (list) {
			Array.prototype.forEach.call(list.querySelectorAll('.datatrsf-mdd-item'), function (item) {
				item.classList.remove('selected');
			});
		}

		values.forEach(function (value, index) {
			var fallbackLabel = $.trim(labels[index] || '');
			var item = null;
			if (list) {
				Array.prototype.forEach.call(list.querySelectorAll('.datatrsf-mdd-item'), function (el) {
					var elValue = $.trim(el.getAttribute('data-value') || '');
					var elLabel = $.trim(el.getAttribute('data-label') || '');
					if (
						elValue === value
						|| elLabel === value
						|| String(elValue) === String(value)
					) {
						item = el;
					}
				});
			}

			if (item) {
				item.classList.add('selected');
				var selectedValue = $.trim(item.getAttribute('data-value') || value);
				selectedStore.selected[selectedValue] = item.getAttribute('data-label') || fallbackLabel || selectedValue;
			} else {
				selectedStore.selected[value] = fallbackLabel || value;
			}
		});

		if (typeof selectedStore.renderTags === 'function') {
			selectedStore.renderTags();
		}
		if (typeof selectedStore.syncItemStates === 'function') {
			selectedStore.syncItemStates();
		}
	}

	/** Restore Destination data (Contacts) fields when editing a saved record. */
	function applyContactsDestinationFromRecord(record) {
		var $panel = getContactsDestinationPanel();
		if (!$panel.length) {
			return;
		}

		record = record || {};
		var action = normalizeContactsDestActionValue(record.netcore0__What_Do_With_Contacts);
		var removeFrom = normalizeContactsRemoveFromValue(record.netcore0__Remove_Contacts_From);
		var addToListChecked = parseSavedBooleanValue(record.netcore0__Add_To_List);
		var listCsv = record.netcore0__List_Contacts_To;
		var listLabelsCsv = record.netcore0__List_Contacts_From_Name;

		$panel.find('input[name="datatrsf-dest-action"]').prop('checked', false);
		if (action) {
			$panel.find('input[name="datatrsf-dest-action"]').each(function () {
				this.checked = normalizeContactsDestActionValue(this.value) === action;
			});
		} else {
			$panel.find('input[name="datatrsf-dest-action"][value="add"]').prop('checked', true);
		}

		$panel.find('input[name="datatrsf-dest-remove-from"]').prop('checked', false);
		if (removeFrom) {
			$panel.find('input[name="datatrsf-dest-remove-from"]').each(function () {
				this.checked = normalizeContactsRemoveFromValue(this.value) === removeFrom;
			});
		}

		$panel.find('#addToListToggle').prop('checked', addToListChecked);

		if (contactsListUi && contactsListUi.addLists) {
			contactsListUi.addLists.selected = {};
			if (typeof contactsListUi.addLists.renderTags === 'function') {
				contactsListUi.addLists.renderTags();
			}
			if (typeof contactsListUi.addLists.syncItemStates === 'function') {
				contactsListUi.addLists.syncItemStates();
			}
		}
		if (contactsListUi && contactsListUi.removeLists) {
			contactsListUi.removeLists.selected = {};
			if (typeof contactsListUi.removeLists.renderTags === 'function') {
				contactsListUi.removeLists.renderTags();
			}
			if (typeof contactsListUi.removeLists.syncItemStates === 'function') {
				contactsListUi.removeLists.syncItemStates();
			}
		}

		if (action === 'remove' && removeFrom === 'list') {
			applyContactsListSelections(
				'datatrsf-mdd-remove-list',
				contactsListUi.removeLists,
				listCsv,
				listLabelsCsv
			);
		} else if (addToListChecked) {
			applyContactsListSelections(
				'datatrsf-mdd-list',
				contactsListUi.addLists,
				listCsv,
				listLabelsCsv
			);
		}

		updateContactsDestinationFieldsVisibility();
	}

	/** Restore Contacts secondary identity when editing a saved record (CUST_ID only). */
	function applyContactsSecondaryIdentityFromRecord(record) {
		record = record || {};

		if (!isContactsSecondaryIdentityRequired()) {
			contactsSecondaryIdentityUi.sourceValue = '';
			contactsSecondaryIdentityUi.sourceLabel = '';
			renderSecondarySourceIdentifierDisplay();
			syncSecondarySourceIdentifierListSelection('');
			ensureSecondaryDestinationIdentifierSelected();
			return;
		}

		var sourceApi = $.trim(record.netcore0__Second_SourceIdentifier || '');
		if (sourceApi) {
			selectSecondarySourceIdentifierValue(
				sourceApi,
				(zohoIdentifierUi.labels && zohoIdentifierUi.labels[sourceApi]) || ''
			);
		} else {
			contactsSecondaryIdentityUi.sourceValue = '';
			contactsSecondaryIdentityUi.sourceLabel = '';
			renderSecondarySourceIdentifierDisplay();
			syncSecondarySourceIdentifierListSelection('');
		}

		ensureSecondaryDestinationIdentifierSelected();
		updateContactsSecondaryIdentityVisibility();
	}

	function setFiltersToggleState(isOn) {
		var $input = $('#datatrsf-toggle-input');
		if (!$input.length) {
			return;
		}
		$input.prop('checked', !!isOn).trigger('change');
	}

	// A Bootstrap tooltip lives outside its trigger, so removing the trigger with
	// the tooltip open strands the popup at the page corner — dispose first.
	function disposeTooltipsIn($scope) {
		if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip || !$scope || !$scope.length) {
			return;
		}

		$scope
			.find('[data-bs-toggle="tooltip"]')
			.addBack('[data-bs-toggle="tooltip"]')
			.each(function () {
				var instance = bootstrap.Tooltip.getInstance(this);
				if (instance) {
					instance.dispose();
				}
			});
	}

	function resetFilterRowsToSingleEmpty() {
		var $wrap = $('#datatrsf-rows-wrap');
		if (!$wrap.length) {
			return;
		}

		var $extraRows = $wrap.find('.datatrsf-filter-row').slice(1);
		disposeTooltipsIn($extraRows);
		$extraRows.remove();

		var $first = $wrap.find('.datatrsf-filter-row').first();
		if (!$first.length) {
			return;
		}

		fillOneFilterFieldDropdown(
			$first.find('[data-filter-field-cdd="true"]').first(),
			sourceFieldsUi.fieldsCache || []
		);
		clearFilterOperatorDropdown(
			$first.find('[data-filter-op-cdd="true"]').first()
		);
		$first.find('.form-control').val('');
		updateFilterValueField($first, '');

		// One row again — drop its Delete button and reopen ADD.
		if (typeof window.datatrsf_refreshRowControls === 'function') {
			window.datatrsf_refreshRowControls();
		}
	}

	function applyOneSavedFilterRow($row, rowData) {
		if (!$row || !$row.length || !rowData) {
			return;
		}

		var fieldKey = $.trim(rowData.field || '');
		var operator = $.trim(rowData.operator || '');
		var value = rowData.value == null ? '' : String(rowData.value);

		var $fieldCdd = $row.find('[data-filter-field-cdd="true"]').first();
		if ($fieldCdd.length && fieldKey && typeof window.datatrsf_selectItem === 'function') {
			var $fieldItem = $fieldCdd.find('.datatrsf-cdd-item').filter(function () {
				var $item = $(this);
				return $item.attr('data-value') === fieldKey
					|| $item.attr('data-label') === fieldKey;
			}).first();

			if ($fieldItem.length) {
				window.datatrsf_selectItem($fieldItem[0], $fieldCdd.attr('id'));
			}
		}

		var $opCdd = $row.find('[data-filter-op-cdd="true"]').first();
		if ($opCdd.length && operator && typeof window.datatrsf_selectItem === 'function') {
			var $opItem = $opCdd.find('.datatrsf-cdd-item').filter(function () {
				return $(this).attr('data-value') === operator
					|| $.trim($(this).text()) === operator;
			}).first();

			if ($opItem.length) {
				window.datatrsf_selectItem($opItem[0], $opCdd.attr('id'));
			}
		}

		var $valueInput = $row.find('[data-filter-value-input="true"]').first();
		if ($valueInput.length) {
			$valueInput.val(value);
			if (typeof syncFilterDatetimeEmptyState === 'function') {
				syncFilterDatetimeEmptyState($valueInput[0]);
			}
		}
	}

	function applySavedFilters(record) {
		var filterOn = record.netcore0__Is_Filter_On === true
			|| String(record.netcore0__Is_Filter_On || '').toLowerCase() === 'true';
		var rows = parseSavedFilterRows(record.netcore0__Filter_Data);

		setFiltersToggleState(filterOn);
		resetFilterRowsToSingleEmpty();

		if (!filterOn || !rows.length) {
			return;
		}

		rows.forEach(function (rowData, index) {
			if (index > 0 && typeof window.datatrsf_addRow === 'function') {
				window.datatrsf_addRow();
			}
			var $row = $('#datatrsf-rows-wrap .datatrsf-filter-row').eq(index);
			applyOneSavedFilterRow($row, rowData);
		});
	}

	/**
	 * Hydrate Setup + Data Configuration from a CRM Data Transfer record.
	 * options.asDuplicate:
	 *   false (default) → edit mode (currentRecordId set → SAVE uses updateRecord)
	 *   true            → create mode (no id; name prefixed with "Copy:")
	 */
	function populateDataTransferEditor(record, options) {
		options = options || {};
		var asDuplicate = options.asDuplicate === true;

		if (!record || (!asDuplicate && !record.id)) {
			return Promise.reject({ message: 'Invalid data transfer record.' });
		}

		if (asDuplicate) {
			// Fresh insert on SAVE — never keep the parent record id.
			setCurrentRecordId(null);
		} else {
			setCurrentRecordId(record.id);
		}

		var setupValues = mapRecordToSetupValues(record);
		if (asDuplicate) {
			setupValues.transferName = buildDuplicateTransferName(setupValues.transferName);
		}

		setSetupFormValues(setupValues);
		$('#datatrsf-title').val(setupValues.transferName || '');
		updateSetupDependentFieldVisibility();
		showDataTransferWizardStep(0);

		var connectionId = setupValues.connectionId;
		// Always use the form's data-value (module API name), never a stale label.
		var sourceObject = getSelectedZohoObjectValue()
			|| resolveSourceObjectModuleApiName(setupValues.sourceObject);
		var listElement = document.getElementById('datatrsf-event-export-list-lead');

		return Promise.all([
			loadNetcoreEventEntities(connectionId).then(function () {
				selectEventByValue(record.netcore0__Event_Name);
			}),
			loadNetcoreCeIdentifiers(connectionId),
			loadContactsAudienceLists(connectionId),
			loadMappingDestAttributes(connectionId),
			loadSourceModuleFields(listElement, sourceObject)
		]).then(function () {
			if (isContactsImportTargetSelected()) {
				applyDataConfigSourceFieldsFromRecord(record);
				applySavedFilters(record);
				applyContactsFieldMappingFromRecord(
					getContactsFieldMappingRawFromRecord(record)
				);
				selectZohoIdentifierValue(
					$.trim(record.netcore0__Destination_Zoho_Identifier || ''),
					(zohoIdentifierUi.labels
						&& zohoIdentifierUi.labels[record.netcore0__Destination_Zoho_Identifier])
						|| ''
				);
				selectSfIdentifierByValue(record.netcore0__Destination_Netcore_CE_identifier);
				applyContactsSecondaryIdentityFromRecord(record);
				applyContactsDestinationFromRecord(record);
				return;
			}

			applySourceFieldSelections(record.netcore0__Source_Fields);
			applyCustomParamSelections(record.netcore0__Destination_Custom_parameters);
			selectZohoIdentifierValue(
				$.trim(record.netcore0__Destination_Zoho_Identifier || ''),
				(zohoIdentifierUi.labels
					&& zohoIdentifierUi.labels[record.netcore0__Destination_Zoho_Identifier])
					|| ''
			);
			selectSfIdentifierByValue(record.netcore0__Destination_Netcore_CE_identifier);
			applySavedFilters(record);
			applyContactsDestinationFromRecord(record);
		});
	}

	/** Parent name → "Copy:<name>" — always prepend, even if already prefixed. */
	function buildDuplicateTransferName(name) {
		var base = $.trim(String(name || ''));
		if (!base) {
			return 'Copy:' + buildDefaultTransferName();
		}
		return 'Copy:' + base;
	}

	/**
	 * Listing Edit → fetch by id → open event screen in edit mode.
	 */
	function openDataTransferForEdit(recordId) {
		var id = $.trim(recordId == null ? '' : String(recordId));
		if (!id) {
			return Promise.reject({ message: 'Invalid data transfer selected.' });
		}

		if (window.DataTransferListing && typeof window.DataTransferListing.showLoader === 'function') {
			window.DataTransferListing.showLoader();
		}

		return fetchDataTransferRecord(id)
			.then(function (record) {
				return showScreen('event', {
					animate: true,
					editRecord: record
				});
			})
			.finally(function () {
				if (window.DataTransferListing && typeof window.DataTransferListing.hideLoader === 'function') {
					window.DataTransferListing.hideLoader();
				}
			});
	}

	/**
	 * Listing Duplicate → fetch by id → open event screen in create mode
	 * with fields copied from the parent (name prefixed "Copy:").
	 */
	function openDataTransferForDuplicate(recordId) {
		var id = $.trim(recordId == null ? '' : String(recordId));
		if (!id) {
			return Promise.reject({ message: 'Invalid data transfer selected.' });
		}

		if (window.DataTransferListing && typeof window.DataTransferListing.showLoader === 'function') {
			window.DataTransferListing.showLoader();
		}

		return fetchDataTransferRecord(id)
			.then(function (record) {
				return showScreen('event', {
					animate: true,
					duplicateRecord: record
				});
			})
			.then(function () {
				// Duplicate only — a failed toast must not fail the duplicate itself.
				try {
					showSuccessToast(DUPLICATE_TRANSFER_TOAST_MESSAGE);
					// The toast lives at the panel's bottom edge — bring it into view.
					scrollToSetupPanelBottom();
				} catch (duplicateToastError) {
					console.error('Duplicate toast failed:', duplicateToastError);
				}
			})
			.finally(function () {
				if (window.DataTransferListing && typeof window.DataTransferListing.hideLoader === 'function') {
					window.DataTransferListing.hideLoader();
				}
			});
	}

	/**
	 * Pull details.id out of a Zoho insert/update response.
	 * Sample insert success shape:
	 * { data: [ { code: "SUCCESS", details: { id: "..." }, status: "success" } ] }
	 */
	function extractSavedRecordId(response) {
		if (!response) {
			return '';
		}

		var rows = response.data;
		if ($.isArray(rows) && rows.length && rows[0] && rows[0].details) {
			return $.trim(String(rows[0].details.id || ''));
		}

		if (rows && rows.details && rows.details.id) {
			return $.trim(String(rows.details.id));
		}

		if (response.details && response.details.id) {
			return $.trim(String(response.details.id));
		}

		return '';
	}

	function getContainer() {
		return $(CONTAINER_SELECTOR);
	}

	function hideOtherWidgetSections() {
		if (typeof window.hideAllMainWidgetSections === 'function') {
			window.hideAllMainWidgetSections();
			return;
		}

		$('#nav-netcore, #nav-connections, #nav-connections-list, #connections-view-edit, #data-transfer, #data-transfer-setup, #data-transfer-listing')
			.removeClass('active')
			.hide();
	}

	function setDataTransferTabActive() {
		$('.main-tabs .nav-link').removeClass('active');
		$('#nav-data-transfer-tab').addClass('active');
		if (typeof window.saveActiveMainTab === 'function') {
			window.saveActiveMainTab('data-transfer');
		}
	}

	function hideAllDataTransferScreens() {
		Object.keys(screens).forEach(function (key) {
			var screen = screens[key];
			$(screen.rootSelector).removeClass('active').hide();
		});
	}

	function loadScreenMarkup(screen) {
		if (state.loaded[screen.key]) {
			return $.Deferred().resolve().promise();
		}

		return $.get(screen.url).then(function (html) {
			var $container = getContainer();
			if (!$container.length) {
				return $.Deferred().reject('Data Transfer container not found.').promise();
			}

			$container.append(html);
			state.loaded[screen.key] = true;
		});
	}

	function ensureScreenEvents(screen) {
		if (state.bound[screen.key] || typeof screen.bind !== 'function') {
			return;
		}

		screen.bind();
		state.bound[screen.key] = true;
	}

	function showScreen(screenKey, options) {
		var settings = $.extend({ animate: false }, options);
		var screen = screens[screenKey];

		if (!screen) {
			console.error('Unknown Data Transfer screen:', screenKey);
			return $.Deferred().reject('Unknown screen').promise();
		}

		// A popup torn down by hand can stay "open" for Bootstrap, keeping its
		// focus trap on the document. Every screen change is a safe point to put
		// that back in sync, so the next popup here does not fight a dead one.
		if (window.DataTransferListing && typeof window.DataTransferListing.syncOverlays === 'function') {
			window.DataTransferListing.syncOverlays();
		}

		return loadScreenMarkup(screen).then(function () {
			ensureScreenEvents(screen);
			hideAllDataTransferScreens();

			var $screen = $(screen.rootSelector);
			if (!$screen.length) {
				return $.Deferred().reject('Screen root not found: ' + screen.rootSelector).promise();
			}

			if (settings.animate) {
				$screen.addClass('active').hide().fadeIn(200);
			} else {
				$screen.addClass('active').show();
			}

			state.currentScreen = screenKey;
			getContainer().show();

			 // Listing rows come from CRM — repaint on every visit, not just the first *******.
			 if (
                (screenKey === 'listing' || screenKey === 'listing-filtered') &&
                window.DataTransferListing
            ) {
                window.DataTransferListing.render(screenKey);
            }

			if (screenKey === 'event') {
				initEventScreenChrome();

				var editRecord = settings.editRecord || null;
				var duplicateRecord = settings.duplicateRecord || null;
				var seedRecord = editRecord || duplicateRecord;

				// The editor DOM is reused across visits — start every session
				// (create, edit, or duplicate) from a clean slate, then hydrate.
				resetDataTransferEditor();

				var selectedConnectionId = seedRecord
					? extractConnectionIdFromRecord(seedRecord)
					: (settings.selectedConnectionId || null);

				return Promise.resolve(loadConnectionOptions({
					selectedId: selectedConnectionId || null,
					forceReload: true,
					// Seed populate loads events/IDs itself so selections are not wiped by a race.
					skipDependentLoads: !!seedRecord
				})).then(function () {
					if (editRecord) {
						return populateDataTransferEditor(editRecord);
					}

					if (duplicateRecord) {
						return populateDataTransferEditor(duplicateRecord, { asDuplicate: true });
					}

					syncImportTargetForSourceObject(
						$.trim($('#dt-setup-source-object-value').val() || '')
					);
					updateSetupDependentFieldVisibility();
				}).then(function () {
					setEditorFormBaseline();
				}).catch(function (error) {
					console.error('Failed to prepare Data Transfer editor:', error);
					setEditorFormBaseline();
				});
			}
		}).fail(function (error) {
			console.error('Failed to show Data Transfer screen "' + screenKey + '":', error);
		});
	}

	/**
	 * data-transfer-listing.js publishes itself at the end of its own ready
	 * callback, so an early open (restoring the saved tab on page load) can
	 * arrive before it exists. Wait for it instead of reading the absence as
	 * "no records" and dropping the user on the create screen.
	 */
	function whenDataTransferListingReady(maxWaitMs) {
		var limit = typeof maxWaitMs === 'number' ? maxWaitMs : 3000;

		function isReady() {
			return !!(window.DataTransferListing
				&& typeof window.DataTransferListing.hasRecords === 'function');
		}

		if (isReady()) {
			return Promise.resolve(window.DataTransferListing);
		}

		return new Promise(function (resolve, reject) {
			var startedAt = Date.now();
			var timer = setInterval(function () {
				if (isReady()) {
					clearInterval(timer);
					resolve(window.DataTransferListing);
					return;
				}
				if (Date.now() - startedAt >= limit) {
					clearInterval(timer);
					reject({ message: 'DataTransferListing is not ready.' });
				}
			}, 50);
		});
	}

	/** Records from the last successful listing fetch — only used as a fallback. */
	function getLastKnownRecordCount() {
		var listing = window.DataTransferListing;
		if (!listing || typeof listing.getLastRecords !== 'function') {
			return 0;
		}

		try {
			return (listing.getLastRecords() || []).length;
		} catch (error) {
			console.error('getLastKnownRecordCount error:', error);
			return 0;
		}
	}

	/**
	 * Open the Data Transfer tab.
	 *
	 * If options.screen is set → open that screen directly.
	 * If not set → ask listing helper:
	 *   records exist → listing
	 *   no records    → empty landing (first-time / create)
	 *
	 * Requires at least one Connection record; otherwise redirects to Connections.
	 */
	function openDataTransferTab(options) {
		var settings = $.extend({
			screen: null,
			animate: false
		}, options);

		if (state.opening) {
			return $.Deferred().resolve().promise();
		}

		function proceedOpen() {
			state.opening = true;
			hideOtherWidgetSections();
			setDataTransferTabActive();
			getContainer().show();

			function finishOpening() {
				state.opening = false;
			}

			// Caller forced a specific screen (e.g. open create form).
			if (settings.screen) {
				return showScreen(settings.screen, { animate: settings.animate }).always(finishOpening);
			}

			// Auto-decide: listing vs empty landing. Nothing is rendered until
			// the records call has settled — showing the create screen while
			// the answer is still unknown is what made this flaky.
			return whenDataTransferListingReady()
				.then(function (listing) {
					return listing.hasRecords();
				})
				.catch(function (error) {
					// Never read a failed lookup as "no records": fall back to
					// whatever the listing last loaded successfully.
					console.error('Data Transfer open decide error:', error);
					return getLastKnownRecordCount() > 0;
				})
				.then(function (hasRecords) {
					var screenKey = hasRecords ? 'listing' : 'landing';
					return showScreen(screenKey, { animate: settings.animate });
				})
				.then(finishOpening, finishOpening);
		}

		function ensureConnectionsExist() {
			if (typeof window.syncDataTransferTabVisibility === 'function') {
				return Promise.resolve(window.syncDataTransferTabVisibility());
			}

			return fetchConnectionRecords()
				.then(function (records) {
					return (records || []).length > 0;
				})
				.catch(function () {
					return false;
				});
		}

		return Promise.resolve(ensureConnectionsExist()).then(function (hasConnections) {
			if (!hasConnections) {
				if (typeof window.redirectToConnectionsRequireConnection === 'function') {
					return window.redirectToConnectionsRequireConnection(
						'Please create a Connection first.'
					);
				}
				return $.Deferred().resolve().promise();
			}
			return proceedOpen();
		});
	}

	function bindLandingScreenEvents() {
		$('body').on('click', '#export-btn', function (event) {
			event.preventDefault();
			// Opening from landing = start a new Data Transfer (Insert mode).
			resetDataTransferEditor();
			showScreen('event', { animate: true });
		});
	}

	function bindEventScreenEvents() {
		$('body').on('click', '#dt-setup-close-btn, #data-transfer-setup .datatrsf-btn-close', function (event) {
			handleDataTransferCloseClick(event);
		});

		$('body').on('click', '#dt-discard-exit-btn', function (event) {
			event.preventDefault();
			event.stopPropagation();
			handleDataTransferDiscardAndExit();
		});

		$('body').on('click', '#dt-save-exit-btn', function (event) {
			event.preventDefault();
			event.stopPropagation();
			handleDataTransferSaveAndExit();
		});

		$('body').on('click', '#dt-setup-save-btn', function (event) {
			event.preventDefault();
			handleSetupSaveClick();
		});

		// If the user clears transferName and leaves the field, regenerate a default name.
		$('body').on('blur', '#datatrsf-title', function () {
			ensureDefaultTransferName();
		});

		// Clear duplicate-name error styling once the user edits the title.
		$('body').on('input', '#datatrsf-title', function () {
			clearDuplicateDataTransferNameError({ keepAlert: true });
			hideSetupNextStepAlert();
		});

		bindSetupSectionInteractions();
		// Keep legacy config-section CDD helpers available for static data-configuration markup.
		ensureLegacyCddGlobals();
		// Designer UI: NEXT, filter toggle, etc. (delegated — safe before HTML loads).
		bindDataConfigurationEvents();
	}

	function initEventScreenChrome() {
		$('#data-transfer-setup [data-bs-toggle="tooltip"]').each(function () {
			if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
				return;
			}

			// transferName Rename tip lives on the wrapper (.datatrsf-title), same as Connections.
			if ($(this).is('.datatrsf-title[data-rename-tooltip], [data-rename-tooltip]')) {
				if (typeof window.bindRenameTooltipHideOnEdit === 'function') {
					// Bind against the input so focus/typing still hides the host tip.
					var $titleInput = $(this).is('input')
						? $(this)
						: $(this).find('#datatrsf-title');
					window.bindRenameTooltipHideOnEdit($titleInput.length ? $titleInput : $(this));
				} else {
					bootstrap.Tooltip.getOrCreateInstance(this, {
						trigger: 'hover',
						placement: 'bottom',
						container: 'body'
					});
				}
				return;
			}

			bootstrap.Tooltip.getOrCreateInstance(this);
		});

		hideSetupToasts();
		// Keep DOM mode attribute in sync with the JS variable
		// (create until first successful insert, then edit).
		setCurrentRecordId(getCurrentRecordId() || null);
		// Designer UI that needs real DOM nodes (multi-select, event select, .dd).
		initDataConfigurationUi();
		updateDataConfigurationDestinationPanel();
		updateContactsDestinationFieldsVisibility();

		// Set the generated name as the real input value (not a placeholder).
		ensureDefaultTransferName();
		// Initial baseline; refreshed again after connection options load in showScreen.
		setEditorFormBaseline();
	}

	/**
	 * Keep transferName filled:
	 * - Trim whitespace
	 * - If empty after trim → set buildDefaultTransferName()
	 * Used on screen load, blur, and before SAVE.
	 */
	function ensureDefaultTransferName() {
		var $title = $('#datatrsf-title');
		if (!$title.length) {
			return;
		}

		var trimmed = $.trim($title.val() || '');
		if (trimmed) {
			// Keep the user's name (normalized).
			$title.val(trimmed);
			return;
		}

		// Empty / whitespace only → generate a fresh default name.
		$title.val(buildDefaultTransferName());
	}

	/** Example: Datatransfer_20251208160348 */
	function buildDefaultTransferName() {
		var now = new Date();
		var pad = function (n) {
			var value = String(n);
			return value.length < 2 ? '0' + value : value;
		};

		return 'Datatransfer_' +
			now.getFullYear() +
			pad(now.getMonth() + 1) +
			pad(now.getDate()) +
			pad(now.getHours()) +
			pad(now.getMinutes()) +
			pad(now.getSeconds());
	}

	/* ------------------------------------------------------------------ */
	/* Setup form helpers — ready for load / validate / save in next phase */
	/* ------------------------------------------------------------------ */

	function getSetupFormRoot() {
		return $(SETUP_FORM_SELECTOR);
	}

	function getCddRoot($from) {
		return $($from).closest('.datatrsf-cdd');
	}

	/**
	 * Flip an anchored dropdown panel up/down based on viewport space.
	 * Same idea as positionCustomParamsMoreTooltip() — keeps panel aligned to trigger.
	 */
	function resetDropdownPanelPosition(config) {
		config = config || {};
		var rootEl = config.rootEl;
		var panelEl = config.panelEl;
		var scrollableEl = config.scrollableEl;
		var upClass = config.upClass || 'open-up';

		if (rootEl && rootEl.classList) {
			rootEl.classList.remove(upClass);
		}
		if (panelEl) {
			panelEl.style.maxHeight = '';
		}
		if (scrollableEl) {
			scrollableEl.style.maxHeight = '';
		}
	}

	function positionDropdownPanel(config) {
		config = config || {};
		var rootEl = config.rootEl;
		var panelEl = config.panelEl;
		var triggerEl = config.triggerEl;
		var gap = config.gap != null ? config.gap : 6;
		var viewportPadding = config.viewportPadding != null ? config.viewportPadding : 8;
		var maxPanelHeight = config.maxPanelHeight || 320;
		var upClass = config.upClass || 'open-up';
		var scrollableEl = config.scrollableEl || null;
		var fixedHeaderEl = config.fixedHeaderEl || null;

		if (!panelEl) {
			return;
		}

		resetDropdownPanelPosition({
			rootEl: rootEl,
			panelEl: panelEl,
			scrollableEl: scrollableEl,
			upClass: upClass
		});

		var anchorEl = triggerEl || rootEl;
		if (!anchorEl) {
			return;
		}

		var anchorRect = anchorEl.getBoundingClientRect();
		var panelHeight = panelEl.offsetHeight || panelEl.scrollHeight || maxPanelHeight;
		var spaceBelow = window.innerHeight - anchorRect.bottom - viewportPadding;
		var spaceAbove = anchorRect.top - viewportPadding;
		var openUp = panelHeight + gap > spaceBelow && spaceAbove > spaceBelow;

		function applyAvailableHeight(available) {
			var height = Math.max(120, Math.min(available, maxPanelHeight));
			panelEl.style.maxHeight = height + 'px';
			if (scrollableEl) {
				var headerHeight = fixedHeaderEl ? fixedHeaderEl.offsetHeight : 0;
				scrollableEl.style.maxHeight = Math.max(80, height - headerHeight) + 'px';
			}
		}

		if (openUp && rootEl && rootEl.classList) {
			rootEl.classList.add(upClass);
			applyAvailableHeight(spaceAbove - gap);
			return;
		}

		if (panelHeight + gap > spaceBelow) {
			applyAvailableHeight(spaceBelow - gap);
		}
	}

	function positionDatatrsfMddDropdown(root, trigger) {
		if (!root) {
			return;
		}

		var panel = root.querySelector('.datatrsf-mdd-panel');
		positionDropdownPanel({
			rootEl: root,
			panelEl: panel,
			triggerEl: trigger,
			gap: 5,
			scrollableEl: root.querySelector('.datatrsf-mdd-list'),
			fixedHeaderEl: panel ? panel.querySelector('.datatrsf-mdd-search') : null,
			maxPanelHeight: 320
		});
	}

	function resetDatatrsfMddDropdown(root) {
		if (!root) {
			return;
		}

		resetDropdownPanelPosition({
			rootEl: root,
			panelEl: root.querySelector('.datatrsf-mdd-panel'),
			scrollableEl: root.querySelector('.datatrsf-mdd-list')
		});
	}

	function positionDatatrsfCddDropdown($cdd) {
		if (!$cdd || !$cdd.length) {
			return;
		}

		var panel = $cdd.find('.datatrsf-cdd-panel').first()[0];
		positionDropdownPanel({
			rootEl: $cdd[0],
			panelEl: panel,
			triggerEl: $cdd.find('.datatrsf-cdd-trigger').first()[0],
			gap: 6,
			scrollableEl: $cdd.find('.datatrsf-cdd-list').first()[0] || null,
			fixedHeaderEl: panel ? panel.querySelector('.datatrsf-cdd-search-wrap') : null,
			maxPanelHeight: 280
		});
	}

	function resetDatatrsfCddDropdown($cdd) {
		if (!$cdd || !$cdd.length) {
			return;
		}

		resetDropdownPanelPosition({
			rootEl: $cdd[0],
			panelEl: $cdd.find('.datatrsf-cdd-panel').first()[0],
			scrollableEl: $cdd.find('.datatrsf-cdd-list').first()[0] || null
		});
	}

	function closeAllCdds($scope) {
		var $root = $scope && $scope.length ? $scope : $(document);
		$root.find('.datatrsf-cdd-panel.open').each(function () {
			resetDatatrsfCddDropdown($(this).closest('.datatrsf-cdd'));
		});
		$root.find('.datatrsf-cdd-panel.open').removeClass('open');
		$root.find('.datatrsf-cdd-trigger.open').removeClass('open').attr('aria-expanded', 'false');
	}

	function openCdd($cdd) {
		if ($cdd.attr('data-disabled') === 'true') {
			return;
		}

		var $trigger = $cdd.find('[data-cdd-toggle]').first();
		var $panel = $cdd.find('[data-cdd-panel]').first();
		var wasOpen = $panel.hasClass('open');

		closeAllCdds();
		if (wasOpen) {
			return;
		}

		$panel.addClass('open');
		$trigger.addClass('open').attr('aria-expanded', 'true');

		window.requestAnimationFrame(function () {
			positionDatatrsfCddDropdown($cdd);
		});

		var $search = $panel.find('[data-cdd-search]').first();
		if ($search.length) {
			$search.trigger('focus');
		}
	}

	function setCddValue($cdd, value, label) {
		if (!$cdd || !$cdd.length) {
			return;
		}

		var displayLabel = label != null ? String(label) : String(value || '');
		var nextValue = value == null ? '' : String(value);
		var $hidden = $cdd.find('input[data-dt-field]').first();
		var $display = $cdd.find('[data-cdd-display]').first();
		var $trigger = $cdd.find('[data-cdd-toggle]').first();
		var placeholder = $cdd.attr('data-placeholder') || '';

		$hidden.val(nextValue);
		$cdd.find('[data-cdd-option]').removeClass('datatrsf-selected');

		if (nextValue) {
			$cdd.find('[data-cdd-option]').filter(function () {
				return String($(this).data('value')) === nextValue;
			}).first().addClass('datatrsf-selected');
			$display.text(displayLabel || nextValue);
			$trigger.addClass('has-value');
		} else {
			$display.text(placeholder);
			$trigger.removeClass('has-value');
		}
	}

	function selectCddOption($option) {
		var $cdd = getCddRoot($option);
		if ($cdd.attr('data-disabled') === 'true') {
			return;
		}

		var value = $option.attr('data-value');
		var label = $option.attr('data-label') || $option.text();
		var fieldKey = $cdd.attr('data-field-key');

		// Remember previous value before we overwrite it (for change-only alerts).
		var previousValue = '';
		if (
			fieldKey === SETUP_FIELDS.sourceObject
			|| fieldKey === SETUP_FIELDS.targetObject
			|| fieldKey === SETUP_FIELDS.connectionId
		) {
			previousValue = $.trim($cdd.find('input[data-dt-field]').val() || '');
		}

		setCddValue($cdd, value, label);
		closeAllCdds($cdd);
		clearSetupFieldError(fieldKey);

		if (fieldKey === SETUP_FIELDS.connectionId) {
			// Connection changed → reload Netcore Entity + Netcore CE identifier + audience lists.
			if (String(previousValue) !== String(value || '')) {
				loadNetcoreEventEntities(value);
				loadNetcoreCeIdentifiers(value);
				loadContactsAudienceLists(value);
				loadMappingDestAttributes(value);

				// The old lists and attributes belong to the old connection.
				resetStepsAfterSetup();
			}
		}

		if (fieldKey === SETUP_FIELDS.sourceObject) {
			// Source changed → refresh Netcore options and reset later steps.
			syncImportTargetForSourceObject(value);
			clearSetupFieldError(SETUP_FIELDS.targetObject);
			// Keep Data Configuration "Source data (...)" + field list in sync with Setup.
			refreshSourceDataSection({ forceReload: true });

			// Info alert only when changing an existing selection (not the first pick).
			if (previousValue && String(previousValue) !== String(value || '')) {
				showZohoObjectChangedAlert();
			}

			// Filters, Destination and the mapping were built on the old Zoho object.
			if (String(previousValue) !== String(value || '')) {
				resetStepsAfterSetup();
			}
		}

		if (fieldKey === SETUP_FIELDS.targetObject) {
			// Keep Data Configuration "Destination data (...)" in sync with Setup.
			updateDestinationDataHeading(
				label || value || getSelectedImportTargetDisplayName()
			);
			updateDataConfigurationDestinationPanel();
			updateFieldMappingWizardVisibility();

			// Trigger visibility depends on import method for non–event-only objects.
			updateSetupDependentFieldVisibility();

			// Netcore entity changed (not first pick) → reset related defaults + info alert.
			if (previousValue && String(previousValue) !== String(value || '')) {
				setTriggerSyncSelection('Updated');
				showNetcoreEntityChangedAlert();
			}

			// A different Netcore entity means different lists, filters and attributes.
			if (String(previousValue) !== String(value || '')) {
				resetStepsAfterSetup();
			}
		}
	}

	function filterCddOptions($cdd, query) {
		var normalized = String(query || '').toLowerCase();
		$cdd.find('[data-cdd-option]').each(function () {
			var $item = $(this);
			var haystack = String($item.attr('data-label') || $item.attr('data-value') || $item.text() || '').toLowerCase();
			$item.toggle(!normalized || haystack.indexOf(normalized) !== -1);
		});
	}

	function syncTriggerRadioStyles() {
		$('#dt-setup-form input[name="triggerSync"]').each(function () {
			var $label = $(this).closest('.datatrsf-radio-label');
			if (this.checked) {
				$label.removeClass('datatrsf-inactive');
			} else {
				$label.addClass('datatrsf-inactive');
			}
		});
	}

	/**
	 * Reads current setup values into a plain object.
	 * Shape matches the Save API payload draft for the next phase.
	 */
	function getSetupFormValues() {
		var $form = getSetupFormRoot();
		return {
			transferName: $.trim($('#datatrsf-title').val() || ''),
			connectionId: $.trim($form.find('[name="connectionId"]').val() || ''),
			sourceObject: $.trim($form.find('[name="sourceObject"]').val() || ''),
			targetObject: $.trim($form.find('[name="targetObject"]').val() || ''),
			triggerSync: $form.find('input[name="triggerSync"]:checked').val() || ''
		};
	}

	/**
	 * Applies values from an object/API response onto the setup form.
	 * Options arrays can be injected later via setSetupFieldOptions().
	 */
	function setSetupFormValues(values) {
		var data = values || {};
		var $form = getSetupFormRoot();

		if (Object.prototype.hasOwnProperty.call(data, SETUP_FIELDS.transferName)) {
			$('#datatrsf-title').val(data.transferName || '');
		}

		[
			SETUP_FIELDS.connectionId,
			SETUP_FIELDS.sourceObject
		].forEach(function (fieldKey) {
			if (!Object.prototype.hasOwnProperty.call(data, fieldKey)) {
				return;
			}

			var $cdd = $form.find('[data-field-key="' + fieldKey + '"]');
			var value = data[fieldKey];

			// Match by data-value first; for sourceObject also accept a saved
			// display label so Edit hydrate still selects the correct option.
			var $match = $cdd.find('[data-cdd-option]').filter(function () {
				var $opt = $(this);
				var optValue = String($opt.attr('data-value') || $opt.data('value') || '');
				if (optValue === String(value || '')) {
					return true;
				}
				if (fieldKey !== SETUP_FIELDS.sourceObject) {
					return false;
				}
				return String($opt.attr('data-label') || '') === String(value || '')
					|| $.trim($opt.text()) === String(value || '');
			}).first();

			var resolvedValue = $match.length
				? String($match.attr('data-value') || value)
				: (fieldKey === SETUP_FIELDS.sourceObject
					? resolveSourceObjectModuleApiName(value)
					: value);
			var label = $match.length
				? ($match.attr('data-label') || $match.text())
				: resolvedValue;
			setCddValue($cdd, resolvedValue, label);
		});

		if (Object.prototype.hasOwnProperty.call(data, SETUP_FIELDS.triggerSync)) {
			var triggerValue = data.triggerSync;
			$form.find('input[name="triggerSync"]').each(function () {
				this.checked = String(this.value) === String(triggerValue);
			});
			syncTriggerRadioStyles();
		}

		// Target import options come from the Zoho source object.
		var sourceForTarget = Object.prototype.hasOwnProperty.call(data, SETUP_FIELDS.sourceObject)
			? data.sourceObject
			: $form.find('[name="sourceObject"]').val();

		syncImportTargetForSourceObject(sourceForTarget, {
			// When loading a saved record, restore the saved Netcore target (if any).
			selectedValue: Object.prototype.hasOwnProperty.call(data, SETUP_FIELDS.targetObject)
				? data.targetObject
				: null
		});
	}

	/**
	 * Replaces dropdown options for a setup field.
	 * options: [{ value, label }]
	 * Keeps current selected value when still present.
	 */
	function setSetupFieldOptions(fieldKey, options) {
		var $cdd = getSetupFormRoot().find('[data-field-key="' + fieldKey + '"]');
		if (!$cdd.length) {
			return;
		}

		var currentValue = $cdd.find('input[data-dt-field]').val();
		var $list = $cdd.find('[data-cdd-options]').first();
		var items = Array.isArray(options) ? options : [];

		$list.empty();
		items.forEach(function (option) {
			if (!option || option.value == null || option.value === '') {
				return;
			}

			var label = option.label != null ? String(option.label) : String(option.value);
			$list.append(
				$('<div/>', {
					'class': 'datatrsf-cdd-item',
					role: 'option',
					text: label
				}).attr({
					'data-value': option.value,
					'data-label': label,
					'data-cdd-option': ''
				})
			);
		});

		if (currentValue) {
			var stillExists = items.some(function (option) {
				return String(option.value) === String(currentValue);
			});
			if (stillExists) {
				var matched = items.filter(function (option) {
					return String(option.value) === String(currentValue);
				})[0];
				setCddValue($cdd, currentValue, matched && matched.label);
			} else {
				setCddValue($cdd, '', '');
			}
		} else {
			setCddValue($cdd, '', '');
		}
	}

	/* ------------------------------------------------------------------ */
	/* Connections API — populate Connection dropdown                     */
	/* ------------------------------------------------------------------ */

	function getConnectionField() {
		return getSetupFormRoot().find('[data-field-key="' + SETUP_FIELDS.connectionId + '"]');
	}

	function setConnectionFieldError(message) {
		var $error = getSetupFormRoot().find('[data-field-error="' + SETUP_FIELDS.connectionId + '"]');
		if (!$error.length) {
			return;
		}

		if (message) {
			$error.text(message).removeAttr('hidden').show();
		} else {
			$error.text('').attr('hidden', true).hide();
		}
	}

	function setConnectionFieldState(options) {
		var settings = $.extend({
			placeholder: CONNECTION_PLACEHOLDERS.default,
			disabled: false
		}, options);
		var $cdd = getConnectionField();
		if (!$cdd.length) {
			return;
		}

		$cdd.attr('data-placeholder', settings.placeholder);
		$cdd.attr('data-disabled', settings.disabled ? 'true' : 'false');
		$cdd.toggleClass('is-disabled', !!settings.disabled);
		$cdd.find('[data-cdd-toggle]')
			.attr('aria-disabled', settings.disabled ? 'true' : 'false')
			.attr('tabindex', settings.disabled ? '-1' : '0');

		if (!$cdd.find('input[data-dt-field]').val()) {
			$cdd.find('[data-cdd-display]').first().text(settings.placeholder);
			$cdd.find('[data-cdd-toggle]').removeClass('has-value');
		}
	}

	function mapConnectionRecordsToOptions(records) {
		return (records || []).map(function (record) {
			if (!record || !record.id) {
				return null;
			}

			return {
				value: String(record.id),
				label: String(record.Name || record.name || ('Connection ' + record.id)).trim()
			};
		}).filter(function (option) {
			return !!option;
		});
	}

	function fetchConnectionRecords() {
		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.getAllRecords !== 'function') {
			return $.Deferred().reject({
				message: 'Zoho CRM API is unavailable.'
			}).promise();
		}

		return ZOHO.CRM.API.getAllRecords({
			Entity: CONNECTIONS_ENTITY,
			sort_order: 'asc',
			per_page: 200,
			page: 1
		}).then(function (response) {
			return (response && response.data) || [];
		});
	}

	/**
	 * Loads connections into the Connection dropdown.
	 * Reusable from this screen and future Data Transfer screens.
	 *
	 * options.selectedId  — pre-select by record id (edit mode)
	 * options.forceReload — bypass cache and refetch from Zoho
	 * options.skipDependentLoads — set connection only; caller loads events/IDs
	 */
	function loadConnectionOptions(options) {
		var settings = $.extend({
			selectedId: null,
			forceReload: false,
			skipDependentLoads: false
		}, options);
		var $cdd = getConnectionField();

		if (!$cdd.length) {
			return $.Deferred().resolve([]).promise();
		}

		if (state.connectionsLoading) {
			return $.Deferred().resolve(mapConnectionRecordsToOptions(state.connections)).promise();
		}

		if (state.connectionsLoaded && !settings.forceReload) {
			var cachedOptions = mapConnectionRecordsToOptions(state.connections);
			applyConnectionOptions(cachedOptions, settings.selectedId, settings);
			return $.Deferred().resolve(cachedOptions).promise();
		}

		state.connectionsLoading = true;
		setConnectionFieldError('');
		setConnectionFieldState({
			placeholder: CONNECTION_PLACEHOLDERS.loading,
			disabled: true
		});
		setSetupFieldOptions(SETUP_FIELDS.connectionId, []);
		closeAllCdds($cdd);

		// Zoho promises support .then / .catch / .finally — not jQuery's .always().
		return fetchConnectionRecords().then(function (records) {
			state.connections = records || [];
			state.connectionsLoaded = true;

			var mapped = mapConnectionRecordsToOptions(state.connections);
			applyConnectionOptions(mapped, settings.selectedId, settings);
			return mapped;
		}).catch(function (error) {
			console.error('loadConnectionOptions error:', error);
			state.connections = [];
			state.connectionsLoaded = false;

			setSetupFieldOptions(SETUP_FIELDS.connectionId, []);
			setConnectionFieldState({
				placeholder: CONNECTION_PLACEHOLDERS.error,
				disabled: true
			});
			setConnectionFieldError(
				(error && (error.message || (error.details && error.details.message))) ||
				'Unable to load connections. Please try again.'
			);
			return [];
		}).finally(function () {
			state.connectionsLoading = false;
		});
	}

	function applyConnectionOptions(options, selectedId, settings) {
		settings = settings || {};
		var items = Array.isArray(options) ? options : [];

		setSetupFieldOptions(SETUP_FIELDS.connectionId, items);
		setConnectionFieldError('');

		if (!items.length) {
			setConnectionFieldState({
				placeholder: CONNECTION_PLACEHOLDERS.empty,
				disabled: true
			});
			setCddValue(getConnectionField(), '', '');
			clearEventSelectDropdown('Select a connection first.');
			clearNetcoreCeIdentifierDropdown('Select a connection first.');
			clearContactsAddListDropdown(CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE);
			clearMappingDestAttributeCache(MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE);
			return;
		}

		setConnectionFieldState({
			placeholder: CONNECTION_PLACEHOLDERS.default,
			disabled: false
		});

		if (selectedId) {
			setSetupFormValues({ connectionId: selectedId });
			if (!settings.skipDependentLoads) {
				loadNetcoreEventEntities(selectedId);
				loadNetcoreCeIdentifiers(selectedId);
				loadContactsAudienceLists(selectedId);
				loadMappingDestAttributes(selectedId);
			}
		} else {
			// Fresh load with no pre-selection — clear dependent Data Configuration options.
			var currentId = getSelectedConnectionId();
			if (currentId) {
				if (!settings.skipDependentLoads) {
					loadNetcoreEventEntities(currentId);
					loadNetcoreCeIdentifiers(currentId);
					loadContactsAudienceLists(currentId);
					loadMappingDestAttributes(currentId);
				}
			} else {
				clearEventSelectDropdown('Select a connection first.');
				clearNetcoreCeIdentifierDropdown('Select a connection first.');
				clearContactsAddListDropdown(CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE);
				clearMappingDestAttributeCache(MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE);
			}
		}
	}

	function reloadConnectionOptions(selectedId) {
		return loadConnectionOptions({
			selectedId: selectedId || getSelectedConnectionId(),
			forceReload: true
		});
	}

	function getSelectedConnectionId() {
		return $.trim(getSetupFormRoot().find('[name="connectionId"]').val() || '');
	}

	function getCachedConnections() {
		return state.connections.slice();
	}

	/** Find a full connection record (includes endpoint + API key) by id. */
	function getConnectionRecordById(connectionId) {
		var id = String(connectionId || '');
		if (!id) {
			return null;
		}

		var found = null;
		(state.connections || []).forEach(function (record) {
			if (record && String(record.id) === id) {
				found = record;
			}
		});
		return found;
	}

	/**
	 * Resolve Netcore credentials + Source + connection ID from a Connection record.
	 * Same record/fields used by netcore0__NetCore_Event_Listing
	 * (endpoint + API key); Source and connection ID are on that same Connection.
	 * @param {string} [connectionId] - defaults to Setup "Connection" selection
	 */
	function getConnectionNetcoreCredentials(connectionId) {
		var id = String(connectionId || getSelectedConnectionId() || '');
		var record = getConnectionRecordById(id);
		if (!record) {
			return {
				Netcore_end_point: '',
				Netcore_API_key: '',
				netcore0__Source: '',
				netcore0__Netcore_connection_ID: ''
			};
		}

		return {
			Netcore_end_point: $.trim(record.netcore0__Netcore_end_point || ''),
			Netcore_API_key: $.trim(record.netcore0__Netcore_API_key || ''),
			netcore0__Source: $.trim(record.netcore0__Source || ''),
			netcore0__Netcore_connection_ID: $.trim(
				record.netcore0__Netcore_connection_ID || ''
			)
		};
	}

	/**
	 * Parse ZOHO.CRM.FUNCTIONS.execute response (same idea as connections.js).
	 * Zoho usually returns: { details: { output: "<json string>" } }
	 */
	function parseEventListingOutput(data) {
		if (!data || !data.details || data.details.output == null) {
			return null;
		}

		var output = data.details.output;
		if (typeof output !== 'string') {
			return output;
		}

		try {
			return JSON.parse(output);
		} catch (error) {
			console.error('parseEventListingOutput error:', error);
			return null;
		}
	}

	/** Clear Netcore Entity options and reset the visible label. */
	function clearEventSelectDropdown(message) {
		var list = document.getElementById('eventSelectList');
		var valueEl = document.getElementById('eventSelectValue');

		if (list) {
			list.innerHTML = '';
			var empty = document.createElement('div');
			empty.className = 'sdd-empty';
			empty.textContent = message || EVENT_SELECT_EMPTY_MESSAGE;
			list.appendChild(empty);
		}

		if (valueEl) {
			valueEl.textContent = 'Select event';
			//valueEl.classList.add('placeholder');
			valueEl.classList.add('is-placeholder');
		}

		eventSelectUi.selectedValue = '';
	}

	/** Build .sdd-item rows from [{ event_name: "..." }, ...]. */
	function renderEventSelectOptions(events) {
		var list = document.getElementById('eventSelectList');
		var valueEl = document.getElementById('eventSelectValue');
		if (!list) {
			return;
		}

		list.innerHTML = '';

		(events || []).forEach(function (event) {
			var eventName = '';
			if (typeof event === 'string') {
				eventName = $.trim(event);
			} else if (event && event.event_name != null) {
				eventName = $.trim(String(event.event_name));
			}

			if (!eventName) {
				return;
			}

			var item = document.createElement('div');
			item.className = 'sdd-item';
			item.setAttribute('data-value', eventName);
			item.textContent = eventName;
			list.appendChild(item);
		});

		if (!list.querySelector('.sdd-item')) {
			clearEventSelectDropdown(EVENT_SELECT_EMPTY_MESSAGE);
			return;
		}

		if (valueEl) {
			valueEl.textContent = 'Select event';
			//valueEl.classList.add('placeholder');
			valueEl.classList.add('is-placeholder');
		}
		eventSelectUi.selectedValue = '';
	}

	/**
	 * Load Netcore Entity (event) options for Data Configuration.
	 * Uses the selected Connection's endpoint + API key, then calls:
	 *   ZOHO.CRM.FUNCTIONS.execute('netcore0__NetCore_Event_Listing', ...)
	 */
	function loadNetcoreEventEntities(connectionId) {
		var id = String(connectionId || '');
		if (!id) {
			clearEventSelectDropdown('Select a connection first.');
			eventSelectUi.loadingConnectionId = null;
			return Promise.resolve([]);
		}

		var record = getConnectionRecordById(id);
		if (!record) {
			clearEventSelectDropdown(EVENT_SELECT_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		var credentials = getConnectionNetcoreCredentials(id);
		var endpoint = credentials.Netcore_end_point;
		var apiKey = credentials.Netcore_API_key;

		if (!endpoint || !apiKey) {
			console.warn('Connection is missing Netcore endpoint or API key.', record);
			clearEventSelectDropdown(EVENT_SELECT_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			console.error('ZOHO.CRM.FUNCTIONS.execute is unavailable.');
			clearEventSelectDropdown(EVENT_SELECT_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		// Clear previous connection's options immediately (do not keep old list).
		clearEventSelectDropdown('Loading...');
		eventSelectUi.loadingConnectionId = id;

		var reqData = {
			arguments: JSON.stringify({
				//Netcore_end_point: endpoint,
				//Netcore_API_key: apiKey,
				connection_id: id
			})
		};

		return Promise.resolve(ZOHO.CRM.FUNCTIONS.execute(EVENT_LISTING_FUNCTION, reqData))
			.then(function (response) {
				// Ignore stale responses if the user switched connections mid-request.
				if (eventSelectUi.loadingConnectionId !== id) {
					return [];
				}

				var output = parseEventListingOutput(response);
				var events = (output && output.data) || [];
				var statusOk = !!(
					output
					&& String(output.status || '').toLowerCase() === 'success'
					&& Array.isArray(events)
					&& events.length > 0
				);

				if (!statusOk) {
					clearEventSelectDropdown(EVENT_SELECT_EMPTY_MESSAGE);
					return [];
				}

				renderEventSelectOptions(events);
				return events;
			})
			.catch(function (error) {
				console.error('loadNetcoreEventEntities error:', error);
				if (eventSelectUi.loadingConnectionId !== id) {
					return [];
				}
				clearEventSelectDropdown(EVENT_SELECT_EMPTY_MESSAGE);
				return [];
			});
	}

	/**
	 * Find one config row by item name, e.g. "foreignkey" or "target_anon_users".
	 */
	function findNetcoreConfigItem(configs, itemName) {
		var found = null;
		(configs || []).forEach(function (cfg) {
			if (cfg && String(cfg.item) === itemName) {
				found = cfg;
			}
		});
		return found;
	}

	/**
	 * Build Netcore CE identifier dropdown options from function output.
	 * Returns an array of { value, label }, or null when data is incomplete.
	 *
	 * Rules (driven by config item "foreignkey"):
	 * - EMAIL / MOBILE is the primary key → only EMAIL + MOBILE
	 * - anything else (CUST_ID, PANID, ...) → EMAIL + MOBILE + that value
	 * The primary key option keeps the "<VALUE> (Primary key)" label, which is
	 * what sfIdentifierUi.primaryValue and is_identifier_primary read.
	 */
	function buildNetcoreCeIdentifierOptions(output) {
		if (!output || String(output.status || '').toLowerCase() !== 'success') {
			return null;
		}

		var dataArr = output.data;
		if (!Array.isArray(dataArr) || !dataArr.length) {
			return null;
		}

		// API returns "config" (singular). Fall back to "configs" if present.
		var firstRow = dataArr[0] || {};
		var configList = firstRow.config || firstRow.configs;
		if (!Array.isArray(configList)) {
			return null;
		}

		var foreignKey = findNetcoreConfigItem(configList, 'foreignkey');

		if (!foreignKey || foreignKey.value == null || !$.trim(String(foreignKey.value))) {
			return null;
		}

		var primaryValue = $.trim(String(foreignKey.value));
		// API casing varies, so match the base options case-insensitively.
		var primaryUpper = primaryValue.toUpperCase();
		var options = [];

		NETCORE_CE_BASE_IDENTIFIERS.forEach(function (baseValue) {
			var isPrimary = primaryUpper === baseValue;
			options.push({
				value: baseValue,
				label: isPrimary ? baseValue + ' (Primary key)' : baseValue,
				isPrimary: isPrimary
			});
		});

		// A foreign key outside the base pair is offered as a third option.
		if (NETCORE_CE_BASE_IDENTIFIERS.indexOf(primaryUpper) === -1) {
			options.push({
				value: primaryValue,
				label: primaryValue + ' (Primary key)',
				isPrimary: true
			});
		}

		return options;
	}

	/** Clear Netcore CE identifier (#sfIdentifier) + Field mapping Destination identifier lists. */
	function clearOneNetcoreCeIdentifierList(list, message) {
		if (!list) {
			return;
		}

		list.innerHTML = '';
		var empty = document.createElement('div');
		empty.className = 'dd-empty';
		empty.textContent = message || SF_IDENTIFIER_EMPTY_MESSAGE;
		list.appendChild(empty);
	}

	function renderOneNetcoreCeIdentifierDisplay(valueSelector, label) {
		var valueEl = document.querySelector(valueSelector);
		if (!valueEl) {
			return;
		}

		if (!$.trim(label || '')) {
			valueEl.textContent = SF_IDENTIFIER_PLACEHOLDER;
			valueEl.classList.add('is-placeholder');
			return;
		}

		valueEl.textContent = label;
		valueEl.classList.remove('placeholder');
		valueEl.classList.remove('is-placeholder');
	}

	function renderNetcoreCeIdentifierDisplay(label) {
		var displayLabel = label;
		if (displayLabel == null) {
			displayLabel = getNetcoreCeIdentifierDisplayLabel();
		}

		renderOneNetcoreCeIdentifierDisplay('#sfIdentifierValue', displayLabel);
		renderOneNetcoreCeIdentifierDisplay('#sfIdentifier .dd-value', displayLabel);
		renderOneNetcoreCeIdentifierDisplay('#destinationIdentifierValue', displayLabel);
		renderOneNetcoreCeIdentifierDisplay('#destination-identifier-dropdown .dd-value', displayLabel);
	}

	function getNetcoreCeIdentifierDisplayLabel() {
		var displayLabel = '';
		if (sfIdentifierUi.selectedValue) {
			['sfIdentifierList', 'destinationIdentifierList'].some(function (listId) {
				var list = document.getElementById(listId);
				if (!list) {
					return false;
				}
				var matched = false;
				Array.prototype.forEach.call(list.querySelectorAll('.dd-simple-item.selected'), function (item) {
					displayLabel = item.getAttribute('data-label') || sfIdentifierUi.selectedValue;
					matched = true;
				});
				return matched;
			});
			if (!displayLabel) {
				displayLabel = sfIdentifierUi.selectedValue;
			}
		}
		return displayLabel;
	}

	function syncNetcoreCeIdentifierListSelection(selectedValue) {
		var normalized = $.trim(String(selectedValue || ''));
		var normalizedLower = normalized.toLowerCase();
		['sfIdentifierList', 'destinationIdentifierList'].forEach(function (listId) {
			var list = document.getElementById(listId);
			if (!list) {
				return;
			}
			Array.prototype.forEach.call(list.querySelectorAll('.dd-simple-item'), function (item) {
				var itemValue = $.trim(item.getAttribute('data-value') || '');
				if (
					itemValue === normalized
					|| itemValue.toLowerCase() === normalizedLower
				) {
					item.classList.add('selected');
				} else {
					item.classList.remove('selected');
				}
			});
		});
	}

	function populateNetcoreCeIdentifierList(list, options) {
		if (!list) {
			return false;
		}

		list.innerHTML = '';
		var hasItems = false;

		(options || []).forEach(function (opt) {
			if (!opt || !opt.value) {
				return;
			}

			var item = document.createElement('div');
			item.className = 'dd-simple-item';
			item.setAttribute('data-value', opt.value);
			item.setAttribute('data-label', opt.label || opt.value);
			if (opt.isPrimary) {
				item.setAttribute('data-is-primary', 'true');
				if (!sfIdentifierUi.primaryValue) {
					sfIdentifierUi.primaryValue = String(opt.value);
				}
			}
			item.textContent = opt.label || opt.value;
			list.appendChild(item);
			hasItems = true;
		});

		return hasItems;
	}

	function clearNetcoreCeIdentifierDropdown(message) {
		clearOneNetcoreCeIdentifierList(document.getElementById('sfIdentifierList'), message);
		clearOneNetcoreCeIdentifierList(document.getElementById('destinationIdentifierList'), message);

		sfIdentifierUi.selectedValue = '';
		sfIdentifierUi.primaryValue = '';
		renderNetcoreCeIdentifierDisplay('');
	}

	/** Render { value, label, isPrimary } rows into both Netcore CE identifier dropdowns. */
	function renderNetcoreCeIdentifierOptions(options) {
		var lists = [
			document.getElementById('sfIdentifierList'),
			document.getElementById('destinationIdentifierList')
		];

		var hasList = lists.some(function (list) {
			return !!list;
		});
		if (!hasList) {
			return;
		}

		var pendingValue = $.trim((sfIdentifierUi && sfIdentifierUi.selectedValue) || '');

		sfIdentifierUi.primaryValue = '';
		var hasAnyItems = false;

		lists.forEach(function (list) {
			if (!list) {
				return;
			}
			if (populateNetcoreCeIdentifierList(list, options)) {
				hasAnyItems = true;
			}
		});

		if (!hasAnyItems) {
			clearNetcoreCeIdentifierDropdown(SF_IDENTIFIER_EMPTY_MESSAGE);
			return;
		}

		// A refreshed list can drop the previous pick (e.g. CUST_ID → EMAIL/MOBILE);
		// keeping it would leave a selection no option matches.
		if (pendingValue && isNetcoreCeIdentifierOption(options, pendingValue)) {
			selectSfIdentifierByValue(pendingValue);
			return;
		}

		sfIdentifierUi.selectedValue = '';
		syncNetcoreCeIdentifierListSelection('');
		renderNetcoreCeIdentifierDisplay('');
		updateContactsSecondaryIdentityVisibility();
	}

	/** True when value is one of the rendered identifier options (case-insensitive). */
	function isNetcoreCeIdentifierOption(options, value) {
		var normalized = $.trim(String(value || '')).toLowerCase();
		if (!normalized) {
			return false;
		}

		return (options || []).some(function (opt) {
			return opt
				&& $.trim(String(opt.value || '')).toLowerCase() === normalized;
		});
	}

	/**
	 * True when the selected Netcore CE identifier is the Primary key option
	 * (foreignkey from netcore0__netcore_identifier).
	 */
	function isSelectedNetcoreCeIdentifierPrimary() {
		var selected = $.trim((sfIdentifierUi && sfIdentifierUi.selectedValue) || '');
		var primary = $.trim((sfIdentifierUi && sfIdentifierUi.primaryValue) || '');
		if (!selected || !primary) {
			return false;
		}
		return selected === primary;
	}

	/**
	 * Load Netcore CE identifier options for Data Configuration (#sfIdentifier).
	 * Uses the selected Connection's endpoint + API key, then calls:
	 *   ZOHO.CRM.FUNCTIONS.execute('netcore0__netcore_identifier', ...)
	 * Same pattern as loadNetcoreEventEntities().
	 */
	function loadNetcoreCeIdentifiers(connectionId) {
		var id = String(connectionId || '');
		if (!id) {
			clearNetcoreCeIdentifierDropdown('Select a connection first.');
			sfIdentifierUi.loadingConnectionId = null;
			return Promise.resolve([]);
		}

		var record = getConnectionRecordById(id);
		if (!record) {
			clearNetcoreCeIdentifierDropdown(SF_IDENTIFIER_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		var credentials = getConnectionNetcoreCredentials(id);
		var endpoint = credentials.Netcore_end_point;
		var apiKey = credentials.Netcore_API_key;

		if (!endpoint || !apiKey) {
			console.warn('Connection is missing Netcore endpoint or API key.', record);
			clearNetcoreCeIdentifierDropdown(SF_IDENTIFIER_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			console.error('ZOHO.CRM.FUNCTIONS.execute is unavailable.');
			clearNetcoreCeIdentifierDropdown(SF_IDENTIFIER_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		// Clear previous connection's options immediately (do not keep old list).
		clearNetcoreCeIdentifierDropdown('Loading...');
		sfIdentifierUi.loadingConnectionId = id;

		var reqData = {
			arguments: JSON.stringify({
				Netcore_end_point: endpoint,
				Netcore_API_key: apiKey
			})
		};

		return Promise.resolve(ZOHO.CRM.FUNCTIONS.execute(NETCORE_IDENTIFIER_FUNCTION, reqData))
			.then(function (response) {
				// Ignore stale responses if the user switched connections mid-request.
				if (sfIdentifierUi.loadingConnectionId !== id) {
					return [];
				}

				var output = parseEventListingOutput(response);
				var options = buildNetcoreCeIdentifierOptions(output);

				if (!options || !options.length) {
					clearNetcoreCeIdentifierDropdown(SF_IDENTIFIER_EMPTY_MESSAGE);
					return [];
				}

				renderNetcoreCeIdentifierOptions(options);
				return options;
			})
			.catch(function (error) {
				console.error('loadNetcoreCeIdentifiers error:', error);
				if (sfIdentifierUi.loadingConnectionId !== id) {
					return [];
				}
				clearNetcoreCeIdentifierDropdown(SF_IDENTIFIER_EMPTY_MESSAGE);
				return [];
			});
	}

	/**
	 * Extract audience rows from netcore0__get_all_audience output.
	 * Path: details.output → status + data.data[].
	 */
	function extractAudienceListFromOutput(output) {
		if (!output || String(output.status || '').toLowerCase() !== 'success') {
			return [];
		}

		var inner = output.data;
		var rows = (inner && Array.isArray(inner.data)) ? inner.data : [];
		var normalized = [];

		rows.forEach(function (row) {
			if (!row) {
				return;
			}

			var audienceName = $.trim(String(row.audience_name != null ? row.audience_name : ''));
			var audienceId = row.audience_id;

			if (!audienceName || audienceId == null || audienceId === '') {
				return;
			}

			normalized.push({
				audience_id: audienceId,
				audience_name: audienceName,
				description: row.description || ''
			});
		});

		return normalized;
	}

	/** Clear Contacts "add to list" options and reset the current selection. */
	function clearContactsAddListDropdown(message) {
		var list = document.getElementById('datatrsf-mdd-list');
		var store = contactsListUi && contactsListUi.addLists;

		if (store) {
			store.selected = {};
			if (typeof store.renderTags === 'function') {
				store.renderTags();
			}
			if (typeof store.syncItemStates === 'function') {
				store.syncItemStates();
			}
		}

		if (!list) {
			return;
		}

		list.innerHTML = '';
		var empty = document.createElement('div');
		empty.className = 'datatrsf-mdd-empty';
		empty.textContent = message || CONTACTS_ADD_LIST_EMPTY_MESSAGE;
		list.appendChild(empty);
	}

	/** Clear Contacts "remove from list" options and reset the current selection. */
	function clearContactsRemoveListDropdown(message) {
		var list = document.getElementById('datatrsf-mdd-remove-list');
		var store = contactsListUi && contactsListUi.removeLists;

		if (store) {
			store.selected = {};
			if (typeof store.renderTags === 'function') {
				store.renderTags();
			}
			if (typeof store.syncItemStates === 'function') {
				store.syncItemStates();
			}
		}

		if (!list) {
			return;
		}

		list.innerHTML = '';
		var empty = document.createElement('div');
		empty.className = 'datatrsf-mdd-empty';
		empty.textContent = message || CONTACTS_ADD_LIST_EMPTY_MESSAGE;
		list.appendChild(empty);
	}

	/** Build .datatrsf-mdd-item rows for Contacts "add to list" from audience API data. */
	function renderContactsAddListOptions(audiences) {
		var list = document.getElementById('datatrsf-mdd-list');
		var store = contactsListUi && contactsListUi.addLists;
		if (!list) {
			return;
		}

		list.innerHTML = '';

		(audiences || []).forEach(function (audience) {
			var audienceName = $.trim(String(audience && audience.audience_name != null ? audience.audience_name : ''));
			var audienceId = audience && audience.audience_id;
			if (!audienceName || audienceId == null || audienceId === '') {
				return;
			}

			var item = document.createElement('div');
			item.className = 'datatrsf-mdd-item';
			item.setAttribute('data-value', String(audienceId));
			item.setAttribute('data-label', audienceName);

			var chk = document.createElement('span');
			chk.className = 'datatrsf-mdd-chk';
			item.appendChild(chk);

			item.appendChild(document.createTextNode(audienceName));
			list.appendChild(item);
		});

		if (!list.querySelector('.datatrsf-mdd-item')) {
			clearContactsAddListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
			return;
		}

		ensureMddItemCheckboxMarkup(list);

		if (store) {
			store.selected = {};
			if (typeof store.renderTags === 'function') {
				store.renderTags();
			}
			if (typeof store.syncItemStates === 'function') {
				store.syncItemStates();
			}
		}
	}

	/** Build .datatrsf-mdd-item rows for Contacts "remove from list" from audience API data. */
	function renderContactsRemoveListOptions(audiences) {
		var list = document.getElementById('datatrsf-mdd-remove-list');
		var store = contactsListUi && contactsListUi.removeLists;
		if (!list) {
			return;
		}

		list.innerHTML = '';

		(audiences || []).forEach(function (audience) {
			var audienceName = $.trim(String(audience && audience.audience_name != null ? audience.audience_name : ''));
			var audienceId = audience && audience.audience_id;
			if (!audienceName || audienceId == null || audienceId === '') {
				return;
			}

			var item = document.createElement('div');
			item.className = 'datatrsf-mdd-item';
			item.setAttribute('data-value', String(audienceId));
			item.setAttribute('data-label', audienceName);

			var chk = document.createElement('span');
			chk.className = 'datatrsf-mdd-chk';
			item.appendChild(chk);

			item.appendChild(document.createTextNode(audienceName));
			list.appendChild(item);
		});

		if (!list.querySelector('.datatrsf-mdd-item')) {
			clearContactsRemoveListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
			return;
		}

		ensureMddItemCheckboxMarkup(list);

		if (store) {
			store.selected = {};
			if (typeof store.renderTags === 'function') {
				store.renderTags();
			}
			if (typeof store.syncItemStates === 'function') {
				store.syncItemStates();
			}
		}
	}

	/**
	 * Load audience/list options for Contacts → "Which list would you like to add the contacts to?"
	 * Uses the selected Connection's connection_id, then calls:
	 *   ZOHO.CRM.FUNCTIONS.execute('netcore0__get_all_audience', ...)
	 * Same response parsing pattern as loadNetcoreEventEntities().
	 */
	function loadContactsAudienceLists(connectionId) {
		var id = String(connectionId || '');
		if (!id) {
			clearContactsAddListDropdown(CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE);
			clearContactsRemoveListDropdown(CONTACTS_ADD_LIST_SELECT_CONNECTION_MESSAGE);
			if (contactsListUi && contactsListUi.addLists) {
				contactsListUi.addLists.loadingConnectionId = null;
			}
			return Promise.resolve([]);
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			console.error('ZOHO.CRM.FUNCTIONS.execute is unavailable.');
			clearContactsAddListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
			clearContactsRemoveListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		// Clear previous connection's options immediately (do not keep old list).
		clearContactsAddListDropdown('Loading...');
		clearContactsRemoveListDropdown('Loading...');
		if (contactsListUi && contactsListUi.addLists) {
			contactsListUi.addLists.loadingConnectionId = id;
		}

		var reqData = {
			arguments: JSON.stringify({
				connection_id: id
			})
		};

		return Promise.resolve(ZOHO.CRM.FUNCTIONS.execute(AUDIENCE_LISTING_FUNCTION, reqData))
			.then(function (response) {
				if (
					!contactsListUi
					|| !contactsListUi.addLists
					|| contactsListUi.addLists.loadingConnectionId !== id
				) {
					return [];
				}

				var output = parseEventListingOutput(response);
				var audiences = extractAudienceListFromOutput(output);

				if (!audiences.length) {
					clearContactsAddListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
					clearContactsRemoveListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
					return [];
				}

				renderContactsAddListOptions(audiences);
				renderContactsRemoveListOptions(audiences);
				return audiences;
			})
			.catch(function (error) {
				console.error('loadContactsAudienceLists error:', error);
				if (
					contactsListUi
					&& contactsListUi.addLists
					&& contactsListUi.addLists.loadingConnectionId === id
				) {
					clearContactsAddListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
					clearContactsRemoveListDropdown(CONTACTS_ADD_LIST_EMPTY_MESSAGE);
				}
				return [];
			});
	}

	/**
	 * Extract attribute rows from netcore0__get_all_attribute_listing output.
	 * Path: details.output → status + data.data[].
	 */
	function extractAttributeListFromOutput(output) {
		if (!output || String(output.status || '').toLowerCase() !== 'success') {
			return [];
		}

		var inner = output.data;
		var rows = (inner && Array.isArray(inner.data)) ? inner.data : [];
		var normalized = [];

		rows.forEach(function (row) {
			if (!row) {
				return;
			}

			var attributeName = $.trim(String(row.attribute_name != null ? row.attribute_name : ''));
			var attributeType = $.trim(String(row.attribute_type != null ? row.attribute_type : ''));
			var attributeId = row.id;
			var attributeCode = $.trim(String(row.attribute_code != null ? row.attribute_code : ''));

			if (!attributeName || !attributeType || attributeId == null || attributeId === '') {
				return;
			}

			normalized.push({
				id: attributeId,
				attribute_name: attributeName,
				attribute_type: attributeType,
				attribute_code: attributeCode
			});
		});

		return normalized;
	}

	/**
	 * Fill ONE Field mapping "Destination attribute" dropdown from the shared attributesCache.
	 * Does NOT call the Netcore API.
	 */
	function fillOneMappingDestAttributeDropdown($dd, attributes, options) {
		options = options || {};
		if (!$dd || !$dd.length) {
			return;
		}

		var $list = $dd.find('[data-mapping-dest-attribute-list="true"]').first();
		if (!$list.length) {
			$list = $dd.find('.dd-list').first();
		}
		if (!$list.length) {
			return;
		}

		var preservedSelection = null;
		if (options.preserveSelection) {
			var preservedValue = $.trim($dd.attr('data-selected-value') || '');
			var preservedLabel = $.trim($dd.attr('data-selected-label') || '');
			if (preservedValue || preservedLabel) {
				preservedSelection = {
					value: preservedValue,
					label: preservedLabel,
					dataType: $.trim($dd.attr('data-selected-type') || ''),
					id: $.trim($dd.attr('data-selected-id') || '')
				};
			}
		}

		$list.empty();

		if (options.message) {
			$list.append($('<div class="dd-empty"></div>').text(options.message));
		} else if (!attributes || !attributes.length) {
			$list.append($('<div class="dd-empty"></div>').text(MAPPING_DEST_ATTRIBUTE_EMPTY_MESSAGE));
		} else {
			attributes.forEach(function (attribute) {
				var attributeName = $.trim(String(attribute.attribute_name || ''));
				var attributeType = $.trim(String(attribute.attribute_type || ''));
				if (!attributeName || !attributeType) {
					return;
				}

				var $item = $('<div class="dd-simple-item"></div>');
				$item.attr('data-value', attributeName);
				$item.attr('data-label', attributeName);
				$item.attr('data-type', attributeType);
				$item.attr('data-attribute-id', String(attribute.id));
				// text-truncate: a long attribute name ellipsizes instead of breaking the row.
				$item.append($('<span class="item-name text-truncate"></span>').text(attributeName));
				$item.append($('<span class="item-type"></span>').text(attributeType));
				$list.append($item);
			});
		}

		if (preservedSelection) {
			applyMappingDestAttributeSelection(
				$dd,
				preservedSelection.value || preservedSelection.label,
				preservedSelection.dataType
			);
		} else {
			resetMappingDestAttributeDropdown($dd, options);
		}

		$dd.find('.dd-search-input').val('');
		filterMappingDestAttributeOptions($dd, '');
	}

	/** Apply the shared attributesCache to every Field mapping "Destination attribute" dropdown. */
	function refreshAllMappingDestAttributeDropdowns(options) {
		options = options || {};
		var attributes = mappingDestAttributeUi.attributesCache || [];
		var fillOptions = $.extend({}, options);

		if (options.message) {
			fillOptions.message = options.message;
			attributes = [];
		}

		$('#mappingRows [data-mapping-dest-attribute-dd="true"]').each(function () {
			fillOneMappingDestAttributeDropdown($(this), attributes, fillOptions);
		});
	}

	/** Clear shared Destination attribute cache and reset every mapping row dropdown. */
	function clearMappingDestAttributeCache(message) {
		mappingDestAttributeUi.attributesCache = [];
		mappingDestAttributeUi.loadingConnectionId = null;
		refreshAllMappingDestAttributeDropdowns({
			message: message || MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE
		});
	}

	/**
	 * Load Destination attribute options for Field mapping.
	 * Uses the selected Connection's connection_id, then calls:
	 *   ZOHO.CRM.FUNCTIONS.execute('netcore0__get_all_attribute_listing', ...)
	 */
	// options.preserveSelection keeps every row's pick — the create-attribute reload
	// is a refresh of the same connection, not a switch to a different one.
	function loadMappingDestAttributes(connectionId, options) {
		options = options || {};
		var id = String(connectionId || '');
		if (!id) {
			clearMappingDestAttributeCache(MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE);
			return Promise.resolve([]);
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			console.error('ZOHO.CRM.FUNCTIONS.execute is unavailable.');
			clearMappingDestAttributeCache(MAPPING_DEST_ATTRIBUTE_EMPTY_MESSAGE);
			return Promise.resolve([]);
		}

		// Clear previous connection's options immediately (do not keep old attributes).
		mappingDestAttributeUi.attributesCache = [];
		if (!options.preserveSelection) {
			refreshAllMappingDestAttributeDropdowns({ message: 'Loading...' });
		}
		mappingDestAttributeUi.loadingConnectionId = id;

		var reqData = {
			arguments: JSON.stringify({
				connection_id: id
			})
		};

		return Promise.resolve(ZOHO.CRM.FUNCTIONS.execute(ATTRIBUTE_LISTING_FUNCTION, reqData))
			.then(function (response) {
				if (mappingDestAttributeUi.loadingConnectionId !== id) {
					return [];
				}

				var output = parseEventListingOutput(response);
				var attributes = extractAttributeListFromOutput(output);

				if (!attributes.length) {
					mappingDestAttributeUi.attributesCache = [];
					refreshAllMappingDestAttributeDropdowns({ message: MAPPING_DEST_ATTRIBUTE_EMPTY_MESSAGE });
					return [];
				}

				mappingDestAttributeUi.attributesCache = attributes;
				refreshAllMappingDestAttributeDropdowns({
					preserveSelection: options.preserveSelection === true
				});
				return attributes;
			})
			.catch(function (error) {
				console.error('loadMappingDestAttributes error:', error);
				if (mappingDestAttributeUi.loadingConnectionId === id) {
					mappingDestAttributeUi.attributesCache = [];
					refreshAllMappingDestAttributeDropdowns({ message: MAPPING_DEST_ATTRIBUTE_EMPTY_MESSAGE });
				}
				return [];
			});
	}

	/* ------------------------------------------------------------------ */
	/* SAVE Data Transfer — beginner-friendly Insert / Update flow         */
	/*                                                                    */
	/* How a Zoho Widget save usually works:                              */
	/*  1. Read values from the HTML form                                 */
	/*  2. Setup fields are NOT validated on SAVE button (product rule)   */
	/*     NEXT / Data Configuration tab DOES validate Setup first        */
	/*  3. Build an object using Zoho field API names (the "payload")     */
	/*  4. If currentRecordId is empty → insertRecord (create)            */
	/*     If currentRecordId is set   → updateRecord (edit same row)     */
	/*  5. On successful insert, store details.id in currentRecordId      */
	/*  6. Show success or error feedback to the user                     */
	/*  7. Always reset the SAVE / NEXT buttons when done                 */
	/*                                                                    */
	/* First create can happen from:                                      */
	/*   - SAVE button, OR                                                */
	/*   - NEXT / Data Configuration tab (after Setup validation)         */
	/* Both use persistDataTransferRecord() → same Insert/Update logic.   */
	/* Form fields stay filled after save (no reset) — View/Edit mode.    */
	/* ------------------------------------------------------------------ */

	/**
	 * Validate Setup fields before going to Data Configuration.
	 * - Connection: always required
	 * - Zoho object: always required
	 * - Netcore import: required only when that field is visible
	 * - Trigger: not validated for navigation (defaults to Updated)
	 */
	function validateSetupForm() {
		var formValues = getSetupFormValues();
		var fieldErrors = {};

		if (!formValues.connectionId) {
			fieldErrors.connectionId = SETUP_FIELD_MESSAGES.connectionId;
		}
		if (!formValues.sourceObject) {
			fieldErrors.sourceObject = SETUP_FIELD_MESSAGES.sourceObject;
		}

		// Netcore CE import is conditional — only validate when shown.
		if (isSetupFieldVisible(SETUP_FIELDS.targetObject) && !formValues.targetObject) {
			fieldErrors.targetObject = SETUP_FIELD_MESSAGES.targetObject;
		}

		// Paint errors under each empty field (or clear them if valid).
		applySetupFormErrors(fieldErrors);

		return {
			isValid: Object.keys(fieldErrors).length === 0,
			formValues: formValues,
			// Keep "values" for any older callers that expect that key.
			values: formValues,
			errors: fieldErrors
		};
	}

	/** Clear all Data Configuration / Field mapping Test validation errors. */
	function clearDataConfigTestErrors() {
		var $root = $('#data-transfer-setup');
		if (!$root.length) {
			return;
		}

		$root.find('[data-dc-field]').removeClass('has-error');
		$root.find('[data-dc-error]').text('').attr('hidden', true).hide();

		$root.find('[data-dc-filter]').removeClass('has-error');
		$root.find('[data-dc-filter-error]').text('').attr('hidden', true).hide();

		$root.find('[data-dc-mapping-col]').removeClass('has-error');
		$root.find('[data-dc-mapping-error]').text('').attr('hidden', true).hide();
	}

	/** Show / hide one Data Configuration or Field mapping field error (non-filter). */
	function setDataConfigFieldError(fieldKey, message) {
		var $group = $('#data-transfer-setup [data-dc-field="' + fieldKey + '"]').first();
		var $error = $('#data-transfer-setup [data-dc-error="' + fieldKey + '"]').first();

		if (message) {
			$group.addClass('has-error');
			if ($error.length) {
				$error.text(message).removeAttr('hidden').show();
			}
		} else {
			$group.removeClass('has-error');
			if ($error.length) {
				$error.text('').attr('hidden', true).hide();
			}
		}
	}

	/** Clear one Data Configuration field error (TEST / START EXPORT live fix). */
	function clearDataConfigFieldError(fieldKey) {
		setDataConfigFieldError(fieldKey, '');
	}

	/** Show / hide one filter-column error inside a specific row. */
	function setFilterColError($row, filterKey, message) {
		if (!$row || !$row.length) {
			return;
		}

		var $col = $row.find('[data-dc-filter="' + filterKey + '"]').first();
		var $error = $col.find('[data-dc-filter-error="' + filterKey + '"]').first();

		if (message) {
			$col.addClass('has-error');
			if ($error.length) {
				$error.text(message).removeAttr('hidden').show();
			}
		} else {
			$col.removeClass('has-error');
			if ($error.length) {
				$error.text('').attr('hidden', true).hide();
			}
		}
	}

	/** Clear one filter-column error for a row (live fix after user selects/fills). */
	function clearFilterColError($row, filterKey) {
		setFilterColError($row, filterKey, '');
	}

	/** Show / hide one Field mapping row column error (Source field / Destination attribute). */
	function setMappingRowColError($row, colKey, message) {
		if (!$row || !$row.length) {
			return;
		}

		var $col = $row.find('[data-dc-mapping-col="' + colKey + '"]').first();
		var $error = $col.find('[data-dc-mapping-error="' + colKey + '"]').first();

		if (message) {
			$col.addClass('has-error');
			if ($error.length) {
				$error.text(message).removeAttr('hidden').show();
			}
		} else {
			$col.removeClass('has-error');
			if ($error.length) {
				$error.text('').attr('hidden', true).hide();
			}
		}
	}

	function clearMappingRowColError($row, colKey) {
		setMappingRowColError($row, colKey, '');
	}

	function isMappingSourceFieldSelected($sourceDd) {
		return !!$.trim(($sourceDd && $sourceDd.attr('data-selected-value')) || '');
	}

	function isMappingDestAttributeSelected($destDd) {
		return !!$.trim(($destDd && $destDd.attr('data-selected-value')) || '');
	}

	function isMappingRowBlank($row) {
		if (!$row || !$row.length) {
			return true;
		}

		var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
		var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();
		return !isMappingSourceFieldSelected($sourceDd) && !isMappingDestAttributeSelected($destDd);
	}

	/** Contacts Add flow only — Remove hides the mapping table and skips its validation. */
	function isContactsFieldMappingTableRequired() {
		return isContactsImportTargetSelected() && getContactsDestActionValue() !== 'remove';
	}

	/**
	 * Validate Data Configuration before opening the Test panel.
	 * Clears previous errors first, then paints only current failures.
	 */
	function validateDataConfigurationForTest() {
		clearDataConfigTestErrors();

		if (isContactsImportTargetSelected()) {
			return validateFieldMappingForTest();
		}

		var hasError = false;

		// 1) Which field updates should trigger event export…
		var sourceSelected = Object.keys((sourceFieldsUi && sourceFieldsUi.selected) || {});
		if (!sourceSelected.length) {
			setDataConfigFieldError('sourceFields', DATA_CONFIG_TEST_MESSAGES.sourceFields);
			hasError = true;
		}

		// 2) Filters — only when the Filters toggle is ON; every dynamic row.
		if (isFiltersToggleOn()) {
			$('#datatrsf-rows-wrap .datatrsf-filter-row').each(function () {
				var $row = $(this);
				var $fieldCdd = $row.find('[data-filter-field-cdd="true"]').first();
				var $opCdd = $row.find('[data-filter-op-cdd="true"]').first();
				var $valueInput = $row.find('[data-filter-value-input="true"]').first();

				var fieldApi = $.trim($fieldCdd.attr('data-selected-value') || '');
				var operator = $.trim($opCdd.attr('data-selected-value') || '');

				if (!fieldApi) {
					setFilterColError($row, 'field', DATA_CONFIG_TEST_MESSAGES.filterField);
					hasError = true;
				}
				if (!operator) {
					setFilterColError($row, 'operator', DATA_CONFIG_TEST_MESSAGES.filterOperator);
					hasError = true;
				}

				// Value only exists after Operator is chosen — skip if input not in DOM / not visible.
				var valueInputVisible = $valueInput.length
					&& $valueInput.is(':visible')
					&& !$valueInput.closest('.datatrsf-filter-value-wrap').hasClass('is-empty');
				if (valueInputVisible) {
					var value = $.trim($valueInput.val() || '');
					if (!value) {
						setFilterColError($row, 'value', DATA_CONFIG_TEST_MESSAGES.filterValue);
						hasError = true;
					}
				}
			});
		}

		// Event destination fields — skip when Contacts import is selected.
		if (!isContactsImportTargetSelected()) {
			// 3) Netcore entity
			if (!$.trim((eventSelectUi && eventSelectUi.selectedValue) || '')) {
				setDataConfigFieldError('eventSelect', DATA_CONFIG_TEST_MESSAGES.eventSelect);
				hasError = true;
			}

			// 4) Zoho identifier
			if (!$.trim((zohoIdentifierUi && zohoIdentifierUi.selectedValue) || '')) {
				setDataConfigFieldError('zohoIdentifier', DATA_CONFIG_TEST_MESSAGES.zohoIdentifier);
				hasError = true;
			}

			// 5) Netcore CE identifier
			if (!$.trim((sfIdentifierUi && sfIdentifierUi.selectedValue) || '')) {
				setDataConfigFieldError('sfIdentifier', DATA_CONFIG_TEST_MESSAGES.sfIdentifier);
				hasError = true;
			}

			// 6) Custom parameters — at least one
			var customSelected = Object.keys((customParamsUi && customParamsUi.selected) || {});
			if (!customSelected.length) {
				setDataConfigFieldError('customParams', DATA_CONFIG_TEST_MESSAGES.customParams);
				hasError = true;
			}
		}

		return { isValid: !hasError };
	}

	/**
	 * Contacts → Field mapping validation before TEST / START EXPORT.
	 * Identity fields + every dynamic mapping row (Source field + Destination attribute).
	 */
	function validateFieldMappingForTest() {
		var hasError = false;

		if (!$.trim((zohoIdentifierUi && zohoIdentifierUi.selectedValue) || '')) {
			setDataConfigFieldError('sourceIdentifier', DATA_CONFIG_TEST_MESSAGES.sourceIdentifier);
			hasError = true;
		}

		if (!$.trim((sfIdentifierUi && sfIdentifierUi.selectedValue) || '')) {
			setDataConfigFieldError('destinationIdentifier', DATA_CONFIG_TEST_MESSAGES.destinationIdentifier);
			hasError = true;
		}

		if (isContactsFieldMappingTableRequired()) {
			$('#mappingRows .mapping-row').each(function () {
				var $row = $(this);
				if (isMappingRowBlank($row)) {
					return;
				}

				var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
				var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();

				if (!isMappingSourceFieldSelected($sourceDd)) {
					setMappingRowColError($row, 'sourceField', DATA_CONFIG_TEST_MESSAGES.mappingSourceField);
					hasError = true;
				}

				if (!isMappingDestAttributeSelected($destDd)) {
					setMappingRowColError($row, 'destAttribute', DATA_CONFIG_TEST_MESSAGES.destinationAttribute);
					hasError = true;
				}
			});
		}

		if (isContactsSecondaryIdentityRequired()) {
			if (!$.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceValue) || '')) {
				setDataConfigFieldError('secondarySourceIdentifier', DATA_CONFIG_TEST_MESSAGES.sourceIdentifier);
				hasError = true;
			}

			if (!$.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.destValue) || '')) {
				setDataConfigFieldError('secondaryDestinationIdentifier', DATA_CONFIG_TEST_MESSAGES.destinationIdentifier);
				hasError = true;
			}
		}

		return { isValid: !hasError };
	}

	/** Open #testConfigPanel via Bootstrap Offcanvas (after validation passes). */
	function openTestConfigPanel() {
		var panel = document.getElementById('testConfigPanel');
		if (!panel || typeof bootstrap === 'undefined' || !bootstrap.Offcanvas) {
			console.error('Test config Offcanvas is unavailable.');
			return;
		}
		bootstrap.Offcanvas.getOrCreateInstance(panel).show();
	}

	/**
	 * Shared Data Configuration gate for TEST + START EXPORT.
	 * Validation rules stay in validateDataConfigurationForTest();
	 * each action passes its own failure banner message.
	 * @param {string} [failureMessage]
	 * @returns {boolean} true when validation passes
	 */
	function ensureDataConfigurationValidForAction(failureMessage) {
		var result = validateDataConfigurationForTest();
		if (!result.isValid) {
			showSetupErrorAlert(failureMessage || DATA_CONFIG_TEST_ALERT_MESSAGE);
			return false;
		}
		return true;
	}

	/** TEST button: validate Data Configuration first; open panel only if valid. */
	function handleTestConfigButtonClick(event) {
		if (event) {
			event.preventDefault();
			event.stopPropagation();
		}

		if (!ensureDataConfigurationValidForAction(DATA_CONFIG_TEST_ALERT_MESSAGE)) {
			return;
		}

		openTestConfigPanel();
	}

	/**
	 * Filters for START EXPORT — only rows that have a field selected.
	 * Shape matches the workflow function contract.
	 */
	function collectFiltersForStartExport() {
		var rows = [];

		$('#datatrsf-rows-wrap .datatrsf-filter-row').each(function () {
			var $row = $(this);
			var $fieldCdd = $row.find('[data-filter-field-cdd="true"]').first();
			var $opCdd = $row.find('[data-filter-op-cdd="true"]').first();
			var $valueInput = $row.find('[data-filter-value-input="true"]').first();

			var fieldApiName = $.trim($fieldCdd.attr('data-selected-value') || '');
			if (!fieldApiName) {
				return;
			}

			rows.push({
				fieldApiName: fieldApiName,
				operator: $.trim($opCdd.attr('data-selected-value') || ''),
				value: $valueInput.length ? $.trim($valueInput.val() || '') : ''
			});
		});

		return rows;
	}

	/**
	 * Build netcore0__create_data_transfer_workflow arguments.
	 * filters: populated only when the Filter toggle is ON; otherwise [].
	 */
	function buildStartExportPayload() {
		var setup = getSetupFormValues();
		var filterEnabled = isFiltersToggleOn();

		return {
			data_transfer_id: getCurrentRecordId() || '',
			// Zoho CRM Connection record id from Setup (create + edit).
			connection_id: $.trim(setup.connectionId || getSelectedConnectionId() || ''),
			transferName: $.trim(setup.transferName || '') || buildDefaultTransferName(),
			zoho_object: $.trim(setup.sourceObject || ''),
			import_method: $.trim(setup.targetObject || ''),
			// Setup "Trigger real-time transfer" radio: Updated | Both.
			trigger_realtime_transfer: $.trim(setup.triggerSync || ''),
			trigger_field_updates: getSelectedSourceFieldsForSave(),
			filter_enabled: filterEnabled,
			filters: filterEnabled ? collectFiltersForStartExport() : []
		};
	}

	function showStartingExportModal() {
		var el = document.getElementById('starting-export-modal');
		if (!el || typeof bootstrap === 'undefined' || !bootstrap.Modal) {
			return;
		}
		bootstrap.Modal.getOrCreateInstance(el, {
			backdrop: 'static',
			keyboard: false
		}).show();
	}

	function hideStartingExportModal() {
		var el = document.getElementById('starting-export-modal');
		if (!el) {
			return;
		}

		try {
			if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
				// getInstance() is often null on Zoho INVALID_DATA paths — always use getOrCreateInstance.
				var instance = bootstrap.Modal.getOrCreateInstance(el);
				instance.hide();

				// A fast export answer lands inside the show transition, where
				// Bootstrap drops hide(). Clearing the DOM below then leaves the
				// instance believing it is open, so its queued show repaints this
				// modal over the listing we are about to open and its backdrop
				// keeps swallowing clicks. Hide again once the show has settled.
				if (instance._isTransitioning) {
					$(el).one('shown.bs.modal', function () {
						instance.hide();
						clearStartingExportModalDom(el);
					});
				}
			}
		} catch (error) {
			console.error('hideStartingExportModal bootstrap error:', error);
		}

		clearStartingExportModalDom(el);
	}

	/** Force-clear stuck modal / backdrop if Bootstrap hide did not finish. */
	function clearStartingExportModalDom(el) {
		try {
			el.classList.remove('show');
			el.setAttribute('aria-hidden', 'true');
			el.removeAttribute('aria-modal');
			el.style.display = 'none';
			document.body.classList.remove('modal-open');
			document.body.style.removeProperty('overflow');
			document.body.style.removeProperty('padding-right');
			var backdrops = document.querySelectorAll('.modal-backdrop');
			for (var i = 0; i < backdrops.length; i++) {
				if (backdrops[i].parentNode) {
					backdrops[i].parentNode.removeChild(backdrops[i]);
				}
			}
		} catch (cleanupError) {
			console.error('hideStartingExportModal cleanup error:', cleanupError);
		}
	}

	/**
	 * True when START EXPORT / FUNCTIONS.execute response is a business failure.
	 * Same nested rule as RUN TEST: prefer details.output.data.status when present.
	 * Handles:
	 *  A) Wrapper error: { status:"error", code:"INVALID_DATA", message:"invalid data" }
	 *  B) Nested details.output: { status:"failed", description:"..." }
	 *  C) Nested details.output.data: { status:"failed", code:400, description:"..." }
	 *     (outer Zoho / output.status may still be "success")
	 */
	function isStartExportResponseFailed(response) {
		try {
			if (!response) {
				return true;
			}

			var status = String(response.status || '').toLowerCase();
			var code = String(response.code || '').toUpperCase();
			if (
				status === 'error'
				|| code === 'ERROR'
				|| code === 'INVALID_DATA'
				|| code === 'FAILURE'
			) {
				return true;
			}

			// HTTP-style status on the error object (some SDK paths).
			var httpStatus = Number(
				response.http_status
				|| response.statusCode
				|| (response.details && response.details.http_status)
			);
			if (!isNaN(httpStatus) && httpStatus >= 400) {
				return true;
			}

			// Shared with RUN TEST: details.output.data.status wins over outer status.
			return !isRunTestResponseSuccessful(response);
		} catch (error) {
			console.error('isStartExportResponseFailed parse error:', error, response);
			return true;
		}
	}

	/**
	 * User-facing error text for START EXPORT failures.
	 * Same nested preference as RUN TEST: details.output.data description / errors.
	 * Logs code + details.api_name for debugging only.
	 */
	function getStartExportErrorMessage(response, fallback) {
		var defaultMessage = fallback || START_EXPORT_UNAVAILABLE_MESSAGE;

		try {
			if (!response) {
				return defaultMessage;
			}

			// Debug-only: INVALID_DATA / wrapper errors often include api_name.
			if (response.code || (response.details && response.details.api_name)) {
				console.warn('Start Export failure details:', {
					code: response.code,
					api_name: response.details && response.details.api_name,
					status: response.status
				});
			}

			var output = parseEventListingOutput(response);
			if (output && typeof output === 'object') {
				var businessResult = getRunTestBusinessResult(output) || output;
				console.warn('Start Export output failure:', {
					code: businessResult.code || output.code,
					status_code: businessResult.status_code || businessResult.statusCode
						|| output.status_code || output.statusCode,
					status: businessResult.status || output.status,
					response: businessResult.response || output.response,
					api_name: businessResult.api_name
						|| output.api_name
						|| (output.details && output.details.api_name)
				});
			}

			// Reuse RUN TEST message extraction (nested data.description / errors first).
			return getRunTestErrorMessage(response, defaultMessage);
		} catch (error) {
			console.error('getStartExportErrorMessage parse error:', error, response);
			return defaultMessage;
		}
	}

	function showStartExportFailure(responseOrError) {
		hideStartingExportModal();
		showSetupErrorAlert(getStartExportErrorMessage(responseOrError));
	}

	/** Listing banner copy after a successful START EXPORT. */
	function buildStartExportSuccessMessage(transferName) {
		var name = $.trim(transferName || '') || buildDefaultTransferName();
		return name + ' started successfully.';
	}

	function showTestExportConfirmModal() {
		var el = document.getElementById('test-export-modal');
		if (!el || typeof bootstrap === 'undefined' || !bootstrap.Modal) {
			console.error('test-export-modal is unavailable.');
			return;
		}
		bootstrap.Modal.getOrCreateInstance(el).show();
	}

	function hideTestExportConfirmModal() {
		var el = document.getElementById('test-export-modal');
		if (!el || typeof bootstrap === 'undefined' || !bootstrap.Modal) {
			return;
		}
		try {
			bootstrap.Modal.getOrCreateInstance(el).hide();
		} catch (error) {
			console.error('hideTestExportConfirmModal error:', error);
		}
	}

	/**
	 * Snapshot of Setup + Data Configuration used to invalidate a prior RUN TEST success
	 * when the user changes anything relevant before START EXPORT.
	 */
	function getRunTestGateFingerprint() {
		var setup = getSetupFormValues();
		var filterOn = isFiltersToggleOn();
		return JSON.stringify({
			recordId: getCurrentRecordId() || '',
			transferName: setup.transferName || '',
			connectionId: setup.connectionId || '',
			sourceObject: setup.sourceObject || '',
			targetObject: setup.targetObject || '',
			triggerSync: setup.triggerSync || '',
			sourceFields: getSelectedSourceFieldsForSave(),
			contactsFieldMapping: isContactsImportTargetSelected()
				? getContactsFieldMappingForSave()
				: '',
			customParams: getSelectedCustomParamsForSave(),
			eventName: $.trim((eventSelectUi && eventSelectUi.selectedValue) || ''),
			zohoIdentifier: $.trim((zohoIdentifierUi && zohoIdentifierUi.selectedValue) || ''),
			sfIdentifier: $.trim((sfIdentifierUi && sfIdentifierUi.selectedValue) || ''),
			filterEnabled: filterOn,
			filters: filterOn ? collectFiltersForStartExport() : []
		});
	}

	function markTestRunSuccessful() {
		runTestGate.isTestRunSuccessful = true;
		runTestGate.fingerprint = getRunTestGateFingerprint();
	}

	function resetTestRunSuccessfulFlag() {
		runTestGate.isTestRunSuccessful = false;
		runTestGate.fingerprint = '';
	}

	/** True only if RUN TEST succeeded and config has not changed since then. */
	function isTestRunSuccessfulForCurrentConfig() {
		if (!runTestGate.isTestRunSuccessful || !runTestGate.fingerprint) {
			return false;
		}
		try {
			return runTestGate.fingerprint === getRunTestGateFingerprint();
		} catch (error) {
			console.error('isTestRunSuccessfulForCurrentConfig error:', error);
			return false;
		}
	}

	/**
	 * Core START EXPORT work (validations → API → SAVE → listing success).
	 * Called directly when RUN TEST already succeeded, or after "Start Export Anyway".
	 * On API success: reuse persistDataTransferRecord() (same as SAVE button),
	 * then navigate to listing only after save succeeds.
	 */
	function proceedWithStartExport() {
		if (!ensureDataConfigurationValidForAction(DATA_CONFIG_START_EXPORT_ALERT_MESSAGE)) {
			return;
		}

		var recordId = getCurrentRecordId();
		if (!recordId) {
			showSetupErrorAlert(START_EXPORT_MISSING_ID_MESSAGE);
			return;
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			showSetupErrorAlert(START_EXPORT_UNAVAILABLE_MESSAGE);
			return;
		}

		var payload;
		var reqData;
		try {
			payload = buildStartExportPayload();
			reqData = {
				arguments: stringifyRunTestArguments(payload)
			};
		} catch (buildError) {
			console.error('Start Export payload build error:', buildError);
			showSetupErrorAlert(START_EXPORT_UNAVAILABLE_MESSAGE);
			return;
		}

		showStartingExportModal();

		var exportPromise;
		try {
			exportPromise = ZOHO.CRM.FUNCTIONS.execute(START_EXPORT_FUNCTION, reqData);
		} catch (executeError) {
			console.error('Start Export execute threw:', executeError);
			showStartExportFailure(executeError);
			return;
		}

		Promise.resolve(exportPromise)
			.then(
				function (response) {
					// Always close loader first — INVALID_DATA must not leave it open.
					hideStartingExportModal();

					try {
						if (isStartExportResponseFailed(response)) {
							showStartExportFailure(response);
							return;
						}

						// START EXPORT succeeded → save config without touching status
						// (export API already set Running; do not write DRAFT over it).
						return persistDataTransferRecord({
							showSuccessToast: false,
							skipNameCheck: true,
							skipStatusUpdate: true
						})
							.then(applyAttributeRequestToDataTransfer)
							.then(function () {
								var successMessage = buildStartExportSuccessMessage(
									getSetupFormValues().transferName
								);

								var openListing = window.DataTransferListing
									&& typeof window.DataTransferListing.open === 'function'
									? window.DataTransferListing.open({ animate: true })
									: showScreen('listing', { animate: true });

								return Promise.resolve(openListing).then(function () {
									if (
										window.DataTransferListing
										&& typeof window.DataTransferListing.showSuccessAlert === 'function'
									) {
										window.DataTransferListing.showSuccessAlert(successMessage);
									}
								});
							})
							.catch(function (saveError) {
								// Stay on editor — save / duplicate-name errors already shown
								// by persistDataTransferRecord (same as SAVE button).
								console.error('Start Export: save after export failed:', saveError);
							});
					} catch (handleError) {
						console.error('Start Export success-handler error:', handleError, response);
						showStartExportFailure(response);
					}
				},
				function (error) {
					// Zoho SDK often rejects INVALID_DATA here instead of resolving.
					console.error('Start Export rejected:', error);
					hideStartingExportModal();
					showStartExportFailure(error);
				}
			)
			.catch(function (error) {
				console.error('Start Export error:', error);
				hideStartingExportModal();
				try {
					showStartExportFailure(error);
				} catch (alertError) {
					console.error('Start Export alert error:', alertError);
					hideStartingExportModal();
					showSetupErrorAlert(START_EXPORT_UNAVAILABLE_MESSAGE);
				}
			});
	}

	/**
	 * START EXPORT button:
	 *  1. Always validate Data Configuration first (same rules as TEST)
	 *  2. If valid and RUN TEST already succeeded → export API
	 *  3. If valid but not tested → open test-export-modal
	 */
	// The Field mapping card's own bottom banner — only START EXPORT uses it.
	function toggleFieldMappingErrorAlert(show) {
		try {
			var $fieldMappingAlert = $('#data-transfer-setup .field-mapping-sec .alert-msg.absolutemsg');
			if (!$fieldMappingAlert.length) {
				return;
			}

			if (state.fieldMappingAlertHideTimer) {
				clearTimeout(state.fieldMappingAlertHideTimer);
				state.fieldMappingAlertHideTimer = null;
			}

			$fieldMappingAlert.toggle(!!show);
			if (!show) {
				return;
			}

			// This banner sits inside the mapping card, so scrollIntoView is what
			// finds the ancestor that actually scrolls and lands right on it.
			var fieldMappingAlertEl = $fieldMappingAlert[0];
			if (fieldMappingAlertEl && typeof fieldMappingAlertEl.scrollIntoView === 'function') {
				fieldMappingAlertEl.scrollIntoView({ behavior: 'smooth', block: 'end' });
			}

			// Same 2s auto-hide the Setup bottom alert already uses.
			state.fieldMappingAlertHideTimer = setTimeout(function () {
				$fieldMappingAlert.hide();
				state.fieldMappingAlertHideTimer = null;
			}, 2000);
		} catch (fieldMappingAlertError) {
			console.error('Field mapping: error alert toggle failed:', fieldMappingAlertError);
		}
	}

	// Contacts only: a type mismatch is already flagged on the row by
	// refreshMappingRowTypeMismatch, and it must also stop the export.
	function hasFieldMappingTypeMismatch() {
		if (!isContactsFieldMappingTableRequired()) {
			return false;
		}

		return $('#mappingRows .mapping-row .col-dest .dd.warn').length > 0;
	}

	function handleStartExportClick(event) {
		if (event) {
			event.preventDefault();
			event.stopPropagation();
		}

		// Block while SAVE / Setup→Data Config persist is in progress.
		if (state.saving) {
			return;
		}

		// Every click decides afresh whether the banner belongs on screen.
		toggleFieldMappingErrorAlert(false);

		// STEP 1 — validations must run on every click, before the test-run gate.
		if (!ensureDataConfigurationValidForAction(DATA_CONFIG_START_EXPORT_ALERT_MESSAGE)) {
			return;
		}

		// STEP 1b — export only; RUN TEST's validator is left untouched.
		if (hasFieldMappingTypeMismatch()) {
			toggleFieldMappingErrorAlert(true);
			return;
		}

		// STEP 2 — only after validation passes.
		if (isTestRunSuccessfulForCurrentConfig()) {
			proceedWithStartExport();
			return;
		}

		showTestExportConfirmModal();
	}

	/** True when a Setup field group is currently shown on screen. */
	function isSetupFieldVisible(fieldKey) {
		var $fieldGroup = getSetupFormRoot().find('[data-field="' + fieldKey + '"]');
		return $fieldGroup.length > 0 && $fieldGroup.is(':visible');
	}

	function clearSetupFieldError(fieldKey) {
		if (!fieldKey) {
			return;
		}

		var $fieldGroup = getSetupFormRoot().find('[data-field="' + fieldKey + '"]');
		var $errorMessage = getSetupFormRoot().find('[data-field-error="' + fieldKey + '"]');

		$fieldGroup.removeClass('has-error');
		if ($errorMessage.length) {
			$errorMessage.text('').attr('hidden', true).hide();
		}
	}

	function clearSetupFormErrors() {
		Object.keys(SETUP_FIELD_MESSAGES).forEach(clearSetupFieldError);
	}

	function applySetupFormErrors(fieldErrors) {
		clearSetupFormErrors();

		Object.keys(fieldErrors || {}).forEach(function (fieldKey) {
			var message = fieldErrors[fieldKey];
			var $fieldGroup = getSetupFormRoot().find('[data-field="' + fieldKey + '"]');
			var $errorMessage = getSetupFormRoot().find('[data-field-error="' + fieldKey + '"]');

			$fieldGroup.addClass('has-error');
			if ($errorMessage.length) {
				$errorMessage.text(message).removeAttr('hidden').show();
			}
		});
	}

	/**
	 * Reads the visible label of a custom dropdown (useful for Pick List values).
	 * Example: value might be "Deals" while the label shown is "Opportunities".
	 */
	function getSelectedDropdownLabel(fieldKey) {
		var $dropdown = getSetupFormRoot().find('[data-field-key="' + fieldKey + '"]');
		if (!$dropdown.length) {
			return '';
		}

		var selectedValue = $.trim($dropdown.find('input[data-dt-field]').val() || '');
		if (!selectedValue) {
			return '';
		}

		var $selectedOption = $dropdown.find('[data-cdd-option]').filter(function () {
			return String($(this).data('value')) === String(selectedValue);
		}).first();

		if ($selectedOption.length) {
			return String($selectedOption.attr('data-label') || $selectedOption.text() || selectedValue).trim();
		}

		return selectedValue;
	}

	// Alias kept so older code that still calls getSelectedCddLabel keeps working.
	function getSelectedCddLabel(fieldKey) {
		return getSelectedDropdownLabel(fieldKey);
	}

	/** Whether the Data Configuration Filters toggle is ON. */
	function isFiltersToggleOn() {
		return $('#datatrsf-toggle-input').is(':checked');
	}

	/**
	 * Collect every filter row as { field, dataType, operator, value }.
	 * No validation — empty strings are kept as-is when a control has no selection.
	 */
	function collectFilterRowsForSave() {
		var rows = [];

		$('#datatrsf-rows-wrap .datatrsf-filter-row').each(function () {
			var $row = $(this);
			var $fieldCdd = $row.find('[data-filter-field-cdd="true"]').first();
			var $opCdd = $row.find('[data-filter-op-cdd="true"]').first();
			var $valueInput = $row.find('[data-filter-value-input="true"]').first();

			var fieldApi = $.trim($fieldCdd.attr('data-selected-value') || '');
			var fieldLabel = $.trim(
				$fieldCdd.find('.datatrsf-cdd-val, .datatrsf-cdd-display').first().text() || ''
			);
			var dataType = $.trim($fieldCdd.attr('data-selected-type') || '');
			var operator = $.trim($opCdd.attr('data-selected-value') || '');
			var value = $valueInput.length ? $.trim($valueInput.val() || '') : '';

			rows.push({
				field: fieldApi || fieldLabel,
				dataType: dataType,
				operator: operator,
				value: value
			});
		});

		return rows;
	}

	/** Selected Source Fields api_names (comma-separated for Zoho text field). */
	function getSelectedSourceFieldsForSave() {
		var selected = (sourceFieldsUi && sourceFieldsUi.selected) || {};
		var apiNames = Object.keys(selected);
		if (apiNames.length) {
			return apiNames.join(',');
		}

		// DOM fallback if state was cleared unexpectedly.
		var fromDom = [];
		$('#datatrsf-event-export-list-lead .datatrsf-mdd-item.selected').each(function () {
			var apiName = $.trim($(this).attr('data-value') || '');
			if (apiName) {
				fromDom.push(apiName);
			}
		});
		return fromDom.join(',');
	}

	/**
	 * Contacts → Field mapping rows for save (JSON array).
	 * Event flow continues to use comma-separated api_names via getSelectedSourceFieldsForSave().
	 */
	function collectContactsFieldMappingRowsForSave() {
		var rows = [];

		$('#mappingRows .mapping-row').each(function () {
			var $row = $(this);
			var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
			var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();

			rows.push({
				source_field: $.trim(
					$sourceDd.attr('data-selected-value')
						|| $sourceDd.attr('data-selected-label')
						|| ''
				),
				source_field_label: $.trim($sourceDd.attr('data-selected-label') || ''),
				source_dataType: $.trim($sourceDd.attr('data-selected-type') || ''),
				destination_field: $.trim(
					$destDd.attr('data-selected-value')
						|| $destDd.attr('data-selected-label')
						|| ''
				),
				destination_field_label: $.trim($destDd.attr('data-selected-label') || ''),
				destination_dataType: $.trim($destDd.attr('data-selected-type') || '')
			});
		});

		return rows;
	}

	/**
	 * Contacts → Field mapping rows JSON for netcore0__Destination_Custom_parameters.
	 * Event flow continues to use comma-separated api_names in the same CRM field.
	 */
	function getContactsFieldMappingForSave() {
		return JSON.stringify(collectContactsFieldMappingRowsForSave());
	}

	/** True when a saved value is Contacts field-mapping JSON (legacy or current format). */
	function isContactsFieldMappingJson(rawValue) {
		return parseContactsFieldMappingJson(rawValue).length > 0;
	}

	/**
	 * Read Contacts field mapping from a saved record.
	 * Current: JSON in netcore0__Destination_Custom_parameters (Contacts flow).
	 * Legacy: JSON was previously stored in netcore0__Source_Fields.
	 */
	function getContactsFieldMappingRawFromRecord(record) {
		record = record || {};

		if (isContactsFieldMappingJson(record.netcore0__Destination_Custom_parameters)) {
			return record.netcore0__Destination_Custom_parameters;
		}

		if (isContactsFieldMappingJson(record.netcore0__Source_Fields)) {
			return record.netcore0__Source_Fields;
		}

		return '';
	}

	/**
	 * Restore Data Configuration trigger fields from netcore0__Source_Fields.
	 * Skips legacy Contacts records where that field held field-mapping JSON.
	 */
	function applyDataConfigSourceFieldsFromRecord(record) {
		var raw = record && record.netcore0__Source_Fields;
		if (isContactsImportTargetSelected() && isContactsFieldMappingJson(raw)) {
			return;
		}
		applySourceFieldSelections(raw);
	}

	/**
	 * Unique Source field rows selected in Contacts → Field mapping (for TEST popup).
	 * Remove hides the mapping table, so it contributes no rows.
	 */
	function collectContactsTestSourceFieldRows() {
		var rows = [];
		var seen = {};

		if (!isContactsFieldMappingTableRequired()) {
			return rows;
		}

		$('#mappingRows .mapping-row').each(function () {
			var $sourceDd = $(this).find('[data-mapping-source-field-dd="true"]').first();
			var apiName = $.trim($sourceDd.attr('data-selected-value') || '');
			if (!apiName || seen[apiName]) {
				return;
			}
			seen[apiName] = true;
			rows.push({
				apiName: apiName,
				label: $.trim($sourceDd.attr('data-selected-label') || '') || apiName
			});
		});

		return rows;
	}

	function getRunTestApiConfig() {
		return isContactsImportTargetSelected() ? contactsRunTestApiConfig : eventRunTestApiConfig;
	}

	/** Selected Custom parameters api_names (comma-separated). */
	function getSelectedCustomParamsForSave() {
		return Object.keys((customParamsUi && customParamsUi.selected) || {}).join(',');
	}

	/** Contacts destination → Zoho CRM field API names. */
	var CONTACTS_DEST_ZOHO_FIELDS = {
		whatDoWithContacts: 'netcore0__What_Do_With_Contacts',
		removeContactsFrom: 'netcore0__Remove_Contacts_From',
		addToList: 'netcore0__Add_To_List',
		listContactsTo: 'netcore0__List_Contacts_To',
		listContactsFromName: 'netcore0__List_Contacts_From_Name'
	};

	function getContactsWhatDoWithForSave() {
		var $panel = getContactsDestinationPanel();
		if (!$panel.length) {
			return '';
		}
		return $.trim($panel.find('input[name="datatrsf-dest-action"]:checked').val() || '');
	}

	function getContactsRemoveFromForSave() {
		var $panel = getContactsDestinationPanel();
		if (!$panel.length) {
			return '';
		}
		return $.trim($panel.find('input[name="datatrsf-dest-remove-from"]:checked').val() || '');
	}

	function getContactsAddToListForSave() {
		var $panel = getContactsDestinationPanel();
		if (!$panel.length) {
			return false;
		}
		return $panel.find('#addToListToggle').is(':checked');
	}

	function getSelectedContactsAddListsForSave() {
		var selected = (contactsListUi && contactsListUi.addLists && contactsListUi.addLists.selected) || {};
		var values = Object.keys(selected);
		if (values.length) {
			return values.join(',');
		}

		var fromDom = [];
		$('#datatrsf-mdd-list .datatrsf-mdd-item.selected').each(function () {
			var value = $.trim($(this).attr('data-value') || '');
			if (value) {
				fromDom.push(value);
			}
		});
		return fromDom.join(',');
	}

	function getSelectedContactsRemoveListsForSave() {
		var selected = (contactsListUi && contactsListUi.removeLists && contactsListUi.removeLists.selected) || {};
		var values = Object.keys(selected);
		if (values.length) {
			return values.join(',');
		}

		var fromDom = [];
		$('#datatrsf-mdd-remove-list .datatrsf-mdd-item.selected').each(function () {
			var value = $.trim($(this).attr('data-value') || '');
			if (value) {
				fromDom.push(value);
			}
		});
		return fromDom.join(',');
	}

	/** Comma-separated data-label values for Contacts add-list multi-select. */
	function getSelectedContactsAddListLabelsForSave() {
		var selected = (contactsListUi && contactsListUi.addLists && contactsListUi.addLists.selected) || {};
		var values = Object.keys(selected);
		if (values.length) {
			return values.map(function (value) {
				return $.trim(selected[value] || '');
			}).filter(function (label) {
				return !!label;
			}).join(',');
		}

		var fromDom = [];
		$('#datatrsf-mdd-list .datatrsf-mdd-item.selected').each(function () {
			var label = $.trim($(this).attr('data-label') || '');
			if (label) {
				fromDom.push(label);
			}
		});
		return fromDom.join(',');
	}

	/** Comma-separated data-label values for Contacts remove-list multi-select. */
	function getSelectedContactsRemoveListLabelsForSave() {
		var selected = (contactsListUi && contactsListUi.removeLists && contactsListUi.removeLists.selected) || {};
		var values = Object.keys(selected);
		if (values.length) {
			return values.map(function (value) {
				return $.trim(selected[value] || '');
			}).filter(function (label) {
				return !!label;
			}).join(',');
		}

		var fromDom = [];
		$('#datatrsf-mdd-remove-list .datatrsf-mdd-item.selected').each(function () {
			var label = $.trim($(this).attr('data-label') || '');
			if (label) {
				fromDom.push(label);
			}
		});
		return fromDom.join(',');
	}

	/**
	 * Contacts list labels (add or remove path) — netcore0__List_Contacts_From_Name.
	 * Values continue to use netcore0__List_Contacts_To (comma-separated data-values).
	 */
	function getContactsListContactsFromNameForSave() {
		var action = getContactsWhatDoWithForSave();
		if (action === 'remove') {
			if (getContactsRemoveFromForSave() !== 'list') {
				return '';
			}
			return getSelectedContactsRemoveListLabelsForSave();
		}

		if (getContactsAddToListForSave()) {
			return getSelectedContactsAddListLabelsForSave();
		}
		return '';
	}

	/**
	 * Active Contacts list multi-select value (add vs remove path).
	 * Saved to netcore0__List_Contacts_To as comma-separated list ids/names.
	 */
	function getContactsListContactsToForSave() {
		var action = getContactsWhatDoWithForSave();
		if (action === 'remove') {
			if (getContactsRemoveFromForSave() === 'list') {
				return getSelectedContactsRemoveListsForSave();
			}
			return '';
		}

		if (getContactsAddToListForSave()) {
			return getSelectedContactsAddListsForSave();
		}
		return '';
	}

	/** Destination data (Contacts) tab fields — no validation; save current UI state. */
	function prepareContactsDestinationPayload() {
		var payload = {};
		payload[CONTACTS_DEST_ZOHO_FIELDS.whatDoWithContacts] = getContactsWhatDoWithForSave();
		payload[CONTACTS_DEST_ZOHO_FIELDS.removeContactsFrom] = getContactsRemoveFromForSave();
		payload[CONTACTS_DEST_ZOHO_FIELDS.addToList] = getContactsAddToListForSave();
		payload[CONTACTS_DEST_ZOHO_FIELDS.listContactsTo] = getContactsListContactsToForSave();
		payload[CONTACTS_DEST_ZOHO_FIELDS.listContactsFromName] = getContactsListContactsFromNameForSave();
		return payload;
	}

	/**
	 * Data Configuration tab → Zoho field map (no validation; save current UI values).
	 */
	function prepareDataConfigurationPayload() {
		var filterOn = isFiltersToggleOn();
		var filterRows = filterOn ? collectFilterRowsForSave() : [];
		var contactsFlow = isContactsImportTargetSelected();

		return $.extend({
			netcore0__Is_Filter_On: filterOn,
			netcore0__Filter_Data: JSON.stringify(filterRows),
			netcore0__Source: getSelectedZohoObjectValue() || '',
			netcore0__Source_Fields: getSelectedSourceFieldsForSave(),
			netcore0__Data_Transfer_Status: 'DRAFT',
			netcore0__Event_Name: $.trim((eventSelectUi && eventSelectUi.selectedValue) || ''),
			netcore0__Destination_Zoho_Identifier: $.trim(
				(zohoIdentifierUi && zohoIdentifierUi.selectedValue) || ''
			),
			netcore0__Destination_Netcore_CE_identifier: $.trim(
				(sfIdentifierUi && sfIdentifierUi.selectedValue) || ''
			),
			netcore0__Second_SourceIdentifier: contactsFlow
				? getContactsSecondarySourceIdentifierForSave()
				: '',
			netcore0__Second_DestinaitonIdentifier: contactsFlow
				? getContactsSecondaryDestinationIdentifierForSave()
				: '',
			// Same boolean already used by RUN TEST as is_identifier_primary.
			netcore0__Netcore_Identifier_Primary: isSelectedNetcoreCeIdentifierPrimary(),
			netcore0__Destination_Custom_parameters: contactsFlow
				? getContactsFieldMappingForSave()
				: getSelectedCustomParamsForSave()
		}, prepareContactsDestinationPayload());
	}

	/**
	 * Step 2 — prepare the payload for Zoho.
	 *
	 * Important: Zoho expects field API names (netcore0__...), not our HTML names.
	 * - Lookup field  → send the related record's id (string)
	 * - Pick List     → send one of the allowed option texts
	 * - Name          → standard CRM record title field
	 *
	 * Setup + Data Configuration are merged into one insertRecord APIData object.
	 */
	function prepareDataTransferPayload(formValues) {
		var values = formValues || getSetupFormValues();
		var transferName = $.trim(values.transferName || '') || buildDefaultTransferName();
		var zohoObjectLabel = getSelectedDropdownLabel(SETUP_FIELDS.sourceObject) || values.sourceObject;
		var netcoreObjectLabel = getSelectedDropdownLabel(SETUP_FIELDS.targetObject) || values.targetObject;

		// Setup tab fields.
		var setupPayload = {
			Name: transferName,
			netcore0__Connection: String(values.connectionId),
			netcore0__Which_Zoho_object: zohoObjectLabel,
			netcore0__Netcore_Object: netcoreObjectLabel,
			netcore0__Trigger_Type: values.triggerSync
		};

		// Data Configuration tab fields — same save request.
		return $.extend({}, setupPayload, prepareDataConfigurationPayload());
	}

	// Older name kept so existing DataTransferModule exports still work.
	function buildZohoDataTransferRecord(formValues) {
		return prepareDataTransferPayload(formValues);
	}

	function buildSetupSavePayload(extraFields) {
		return $.extend({}, prepareDataTransferPayload(), extraFields || {});
	}

	/**
	 * Pulls a human-readable message out of a Zoho API error object.
	 * Zoho errors can arrive in a few different shapes, so we check common ones.
	 */
	function getSaveErrorMessage(error) {
		var defaultMessage = 'Unable to save data transfer. Please try again.';

		if (!error) {
			return defaultMessage;
		}
		if (typeof error === 'string' && error.trim()) {
			return error;
		}
		if (error.message) {
			return String(error.message);
		}
		if (error.data && error.data[0] && error.data[0].message) {
			return String(error.data[0].message);
		}
		if (error.details && error.details.message) {
			return String(error.details.message);
		}

		return defaultMessage;
	}

	function hideSetupToasts() {
		if (state.toastHideTimer) {
			clearTimeout(state.toastHideTimer);
			state.toastHideTimer = null;
		}
		$('#dt-setup-success-toast, #dt-setup-error-toast').hide();
		syncSetupToastStacking();
	}

	function syncSetupToastStacking() {
		var $wrap = $('#data-transfer-setup .alert-success-msg').first();
		if (!$wrap.length) {
			return;
		}

		$wrap.toggleClass(
			'dt-toast-above-offcanvas',
			$('#createAttributePanel').hasClass('show')
		);
	}

	function showSuccessToast(message) {
		showSetupToast('success', message || 'Changes saved successfully.');
	}

	function showErrorToast(message) {
		showSetupToast('error', message || 'Unable to save data transfer. Please try again.');
	}

	function showSetupToast(toastType, message) {
		var isSuccess = toastType === 'success';
		var $toast = $(isSuccess ? '#dt-setup-success-toast' : '#dt-setup-error-toast');
		var $otherToast = $(isSuccess ? '#dt-setup-error-toast' : '#dt-setup-success-toast');

		if (!$toast.length) {
			return;
		}

		if (state.toastHideTimer) {
			clearTimeout(state.toastHideTimer);
			state.toastHideTimer = null;
		}

		$otherToast.hide();
		$toast.find('.dt-toast-text').text(message);
		$toast.show();
		syncSetupToastStacking();

		// Auto-hide after a few seconds so it does not stay forever.
		state.toastHideTimer = setTimeout(function () {
			$toast.hide();
			state.toastHideTimer = null;
		}, isSuccess ? 3500 : 5000);
	}

	/**
	 * Locks top-bar actions while Insert/Update runs (blocks double-clicks).
	 *
	 * options.useCommonLoader — SAVE / Setup→Data Config path: keep button
	 *   labels and primary colors unchanged (progress is common-loader-popup).
	 *   NEXT / START EXPORT use .is-save-locked instead of :disabled so
	 *   Bootstrap does not wash out their navy fill.
	 */
	function setSaveButtonLoading(isLoading, options) {
		options = options || {};
		var useCommonLoader = options.useCommonLoader === true;
		state.saving = !!isLoading;

		var $saveButton = $('#dt-setup-save-btn');
		if ($saveButton.length) {
			$saveButton.toggleClass('is-saving', !!isLoading);
			$saveButton.prop('disabled', !!isLoading);
			$saveButton.text('SAVE');
		}

		var $nextButton = $('#dt-setup-next-btn');
		if ($nextButton.length) {
			if (useCommonLoader) {
				// Keep navy look — do not use HTML disabled (Bootstrap fades it).
				$nextButton
					.prop('disabled', false)
					.toggleClass('is-save-locked', !!isLoading)
					.attr('aria-disabled', isLoading ? 'true' : null);
				$nextButton.text('NEXT');
			} else {
				$nextButton
					.removeClass('is-save-locked')
					.removeAttr('aria-disabled')
					.prop('disabled', !!isLoading);
				$nextButton.text(isLoading ? 'SAVING...' : 'NEXT');
			}
		}

		var $startExportButton = $('#dt-start-export-btn');
		if ($startExportButton.length) {
			if (useCommonLoader) {
				$startExportButton
					.prop('disabled', false)
					.toggleClass('is-save-locked', !!isLoading)
					.attr('aria-disabled', isLoading ? 'true' : null);
			} else {
				$startExportButton
					.removeClass('is-save-locked')
					.removeAttr('aria-disabled')
					.prop('disabled', !!isLoading);
			}
		}
	}

	// Keep the older name used elsewhere in this file.
	function setSetupSaveButtonState(isSaving) {
		setSaveButtonLoading(isSaving);
	}

	/**
	 * Step 3a — create a new record in netcore0__Data_Transfer (Insert mode).
	 *
	 * ZOHO.CRM.API.insertRecord({
	 *   Entity: 'Module_API_Name',
	 *   APIData: { ... }
	 * })
	 */
	function insertDataTransferRecord(recordPayload) {
		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.insertRecord !== 'function') {
			return Promise.reject({
				message: 'Zoho CRM API is unavailable.'
			});
		}

		return ZOHO.CRM.API.insertRecord({
			Entity: DATA_TRANSFER_ENTITY,
			APIData: recordPayload
		});
	}

	/**
	 * Step 3b — update an existing record (View/Edit mode).
	 * Zoho expects the record id inside APIData as `id`.
	 *
	 * ZOHO.CRM.API.updateRecord({
	 *   Entity: 'Module_API_Name',
	 *   APIData: { id: '...', ...fields }
	 * })
	 */
	function updateDataTransferRecord(recordPayload, recordId) {
		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.updateRecord !== 'function') {
			return Promise.reject({
				message: 'Zoho CRM API is unavailable.'
			});
		}

		var updatePayload = $.extend({}, recordPayload, {
			id: String(recordId)
		});

		return ZOHO.CRM.API.updateRecord({
			Entity: DATA_TRANSFER_ENTITY,
			APIData: updatePayload
		});
	}

	/**
	 * Choose Insert vs Update based on currentRecordId.
	 * - no id  → insertRecord (create)
	 * - has id → updateRecord (edit)
	 */
	function saveDataTransferRecord(recordPayload) {
		var existingId = getCurrentRecordId();

		if (existingId) {
			return updateDataTransferRecord(recordPayload, existingId);
		}

		return insertDataTransferRecord(recordPayload);
	}

	/**
	 * After a successful Insert/Update.
	 * options.showSuccessToast — true for the SAVE button, false for Next/tab auto-save.
	 */
	function handleSaveSuccess(response, options) {
		options = options || {};
		// Default ON so older callers keep the toast; Next/tab passes false.
		var showToast = options.showSuccessToast !== false;

		// After a successful insert, lock onto the new CRM id so the next
		// SAVE updates this record instead of creating a duplicate.
		// (Update responses may also return id — keep it in sync either way.)
		var savedId = extractSavedRecordId(response);
		if (savedId) {
			setCurrentRecordId(savedId);
		}

		// Do NOT clear/reset form fields — stay on the same filled screen.
		clearSetupFormErrors();
		clearDuplicateDataTransferNameError();
		// Saved state is the new baseline so Close won't false-prompt.
		setEditorFormBaseline();

		if (showToast) {
			showSuccessToast('Changes saved successfully.');
		}
	}

	function handleSaveError(error) {
		console.error('Data Transfer save error:', error);
		showErrorToast(getSaveErrorMessage(error));
	}

	/**
	 * Shared Insert/Update used by:
	 *   1) the SAVE button  → show "Changes saved successfully" toast
	 *   2) NEXT / "Data Configuration" tab → silent save (no success toast)
	 *
	 * Always goes through saveDataTransferRecord():
	 *   - no currentRecordId → insertRecord (create once)
	 *   - currentRecordId set → updateRecord (no duplicate inserts)
	 *
	 * Before create (and optional edit name check): uniqueness on Name — same
	 * getAllRecords pattern as Connections. Pass options.skipNameCheck to bypass
	 * (e.g. NEXT when the record was already created).
	 *
	 * options.showSuccessToast — pass false to skip the success popup.
	 * options.skipNameCheck — true to skip duplicate-name API (already-saved Next).
	 * options.showCommonLoader — true for SAVE button and Setup→Data Config
	 *   navigation: keep common-loader-popup open through Insert/Update and
	 *   leave button labels unchanged (no "SAVING..." on NEXT).
	 * options.skipStatusUpdate — true to omit netcore0__Data_Transfer_Status
	 *   (post–START EXPORT save must not overwrite Running set by the export API).
	 * Returns a Promise so callers can wait (e.g. navigate only after success).
	 */
	function persistDataTransferRecord(options) {
		options = options || {};
		var showSuccessToast = options.showSuccessToast !== false;
		var skipNameCheck = options.skipNameCheck === true;
		var showCommonLoader = options.showCommonLoader === true;
		var skipStatusUpdate = options.skipStatusUpdate === true;

		// Ignore overlapping saves (Save + Next / tab double-clicks).
		if (state.saving) {
			return Promise.reject({
				message: 'A save is already in progress.'
			});
		}

		hideSetupToasts();
		ensureDefaultTransferName();

		// ----- 1. Read form values -----
		var formValues = getSetupFormValues();
		var transferName = $.trim(formValues.transferName || '');
		var excludeRecordId = getCurrentRecordId() || null;

		// ----- 2. Prepare payload (Setup + Data Configuration merged) -----
		var recordPayload = prepareDataTransferPayload(formValues);
		if (skipStatusUpdate) {
			// Leave CRM status alone (e.g. Running after START EXPORT).
			delete recordPayload.netcore0__Data_Transfer_Status;
		}

		// Lock while name-check + save run (blocks double-clicks).
		setSaveButtonLoading(true, { useCommonLoader: showCommonLoader });

		var nameCheckPromise;
		if (skipNameCheck) {
			nameCheckPromise = Promise.resolve();
		} else {
			showDataTransferNameCheckLoader();
			nameCheckPromise = ensureUniqueDataTransferName(transferName, excludeRecordId);
		}

		return nameCheckPromise
			.then(function () {
				// SAVE button: keep / show common-loader through Insert/Update.
				// Other callers: dismiss name-check loader before the API call.
				if (showCommonLoader) {
					showDataTransferNameCheckLoader();
				} else {
					hideDataTransferNameCheckLoader();
				}

				// ----- 3. Insert OR Update, then handle success / error -----
				return Promise.resolve(saveDataTransferRecord(recordPayload))
					.then(function (response) {
						handleSaveSuccess(response, { showSuccessToast: showSuccessToast });
						return response;
					})
					.catch(function (error) {
						handleSaveError(error);
						return Promise.reject(error);
					});
			})
			.catch(function (error) {
				hideDataTransferNameCheckLoader();

				if (error && error.code === 'DUPLICATE_NAME') {
					showDuplicateDataTransferNameError();
					return Promise.reject(error);
				}

				if (error && error.code === 'NAME_CHECK_FAILED') {
					showSetupErrorAlert(
						error.message || DATA_TRANSFER_NAME_CHECK_FAILED_MESSAGE
					);
					return Promise.reject(error);
				}

				// Save failure already handled by handleSaveError above.
				return Promise.reject(error);
			})
			.finally(function () {
				setSaveButtonLoading(false, { useCommonLoader: showCommonLoader });
				if (showCommonLoader) {
					hideDataTransferNameCheckLoader();
				}
			});
	}

	/**
	 * Fetch Data Transfer records for Name uniqueness (Connections uses the same
	 * getAllRecords approach for connection names).
	 */
	function fetchAllDataTransferRecords() {
		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.API
			|| typeof ZOHO.CRM.API.getAllRecords !== 'function'
		) {
			return Promise.reject({
				message: 'Zoho CRM API is unavailable.'
			});
		}

		return Promise.resolve(
			ZOHO.CRM.API.getAllRecords({
				Entity: DATA_TRANSFER_ENTITY,
				sort_order: 'desc',
				per_page: 200,
				page: 1
			})
		).then(function (response) {
			return (response && response.data) || [];
		});
	}

	/**
	 * Case-insensitive Name match. excludeRecordId skips the open record in edit mode
	 * (same as hasDuplicateConnectionName).
	 */
	function hasDuplicateDataTransferName(records, transferName, excludeRecordId) {
		var normalizedName = String(transferName || '').trim().toLowerCase();
		if (!normalizedName) {
			return false;
		}

		return (records || []).some(function (record) {
			if (excludeRecordId && String(record.id) === String(excludeRecordId)) {
				return false;
			}
			return String(record.Name || '').trim().toLowerCase() === normalizedName;
		});
	}

	/**
	 * Resolves when the name is free; rejects with DUPLICATE_NAME or NAME_CHECK_FAILED.
	 */
	function ensureUniqueDataTransferName(transferName, excludeRecordId) {
		return fetchAllDataTransferRecords()
			.then(function (records) {
				if (hasDuplicateDataTransferName(records, transferName, excludeRecordId)) {
					return Promise.reject({
						code: 'DUPLICATE_NAME',
						message: DUPLICATE_DATA_TRANSFER_NAME_MESSAGE
					});
				}
			})
			.catch(function (error) {
				if (error && error.code === 'DUPLICATE_NAME') {
					return Promise.reject(error);
				}

				console.error('Data Transfer name uniqueness check failed:', error);
				return Promise.reject({
					code: 'NAME_CHECK_FAILED',
					message: DATA_TRANSFER_NAME_CHECK_FAILED_MESSAGE
				});
			});
	}

	/** common-loader-popup while the uniqueness getAllRecords call runs. */
	function showDataTransferNameCheckLoader() {
		if (
			window.DataTransferListing
			&& typeof window.DataTransferListing.showLoader === 'function'
		) {
			window.DataTransferListing.showLoader();
			return;
		}

		var el = document.getElementById('common-loader-popup');
		if (!el || typeof bootstrap === 'undefined' || !bootstrap.Modal) {
			return;
		}
		bootstrap.Modal.getOrCreateInstance(el, {
			backdrop: 'static',
			keyboard: false
		}).show();
	}

	function hideDataTransferNameCheckLoader() {
		if (
			window.DataTransferListing
			&& typeof window.DataTransferListing.hideLoader === 'function'
		) {
			window.DataTransferListing.hideLoader();
			return;
		}

		var el = document.getElementById('common-loader-popup');
		if (!el) {
			return;
		}

		try {
			if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
				var instance = bootstrap.Modal.getInstance(el);
				if (instance) {
					instance.hide();
				}
			}
		} catch (error) {
			console.error('hideDataTransferNameCheckLoader error:', error);
		}

		el.classList.remove('show');
		el.style.display = 'none';
		el.setAttribute('aria-hidden', 'true');
		el.removeAttribute('aria-modal');
		document.body.classList.remove('modal-open');
		document.body.style.removeProperty('overflow');
		document.body.style.removeProperty('padding-right');
		document.querySelectorAll('.modal-backdrop').forEach(function (backdrop) {
			backdrop.remove();
		});
	}

	/**
	 * Clear duplicate-name field error + tooltip (+ optional bottom alert).
	 * Called on editor reset, exit, successful save, and while the user retypes.
	 * options.keepAlert — leave the bottom banner alone (e.g. typing clears tip only).
	 */
	function clearDuplicateDataTransferNameError(options) {
		options = options || {};
		var $title = $('#datatrsf-title');

		$title.removeClass('input-error');
		try {
			if (typeof window.clearConnectionNameErrorTooltip === 'function') {
				window.clearConnectionNameErrorTooltip($title);
			}
		} catch (tooltipError) {
			console.error('clearDuplicateDataTransferNameError tooltip error:', tooltipError);
		}

		if (!options.keepAlert) {
			hideSetupNextStepAlert();
		}
	}

	/**
	 * Duplicate-name UX — same idea as Connections:
	 * bottom red alert (with ×) + single Rename/error tooltip on the title host.
	 */
	function showDuplicateDataTransferNameError() {
		var message = DUPLICATE_DATA_TRANSFER_NAME_MESSAGE;
		var $title = $('#datatrsf-title');

		$title.addClass('input-error');

		// Tooltip must never block the banner — wrap so a Bootstrap race cannot skip it.
		try {
			if (typeof window.setConnectionNameErrorTooltip === 'function') {
				window.setConnectionNameErrorTooltip($title, message);
			}
		} catch (tooltipError) {
			console.error('Duplicate name tooltip error:', tooltipError);
		}

		showSetupErrorAlert(message);
	}

	/**
	 * SAVE button click handler.
	 * Does NOT validate Setup fields (product rule).
	 * First successful save → insert + store id; later saves → update that id.
	 * Shows common-loader-popup while the save API runs (button stays "SAVE").
	 * Shows the "Changes saved successfully" toast on success.
	 */
	function handleSetupSaveClick() {
		if (state.saving) {
			return;
		}

		// Save button: no required-field checks — clear any leftover Setup errors.
		clearSetupFormErrors();

		persistDataTransferRecord({
			showSuccessToast: true,
			showCommonLoader: true
		}).catch(function () {
			// Error toast already shown inside persistDataTransferRecord.
		});
	}

	/* ------------------------------------------------------------------ */
	/* Source object → locked Netcore CE import target                     */
	/* ------------------------------------------------------------------ */

	function getTargetObjectField() {
		return getSetupFormRoot().find('[data-field-key="' + SETUP_FIELDS.targetObject + '"]');
	}

	function setCddDisabledState($cdd, disabled) {
		if (!$cdd || !$cdd.length) {
			return;
		}

		var isDisabled = !!disabled;
		$cdd.attr('data-disabled', isDisabled ? 'true' : 'false');
		$cdd.toggleClass('is-disabled', isDisabled);
		$cdd.find('[data-cdd-toggle]')
			.attr('aria-disabled', isDisabled ? 'true' : 'false')
			.attr('tabindex', isDisabled ? '-1' : '0');

		if (isDisabled) {
			closeAllCdds($cdd);
		}
	}

	function isEventOnlySourceObject(sourceObject) {
		var key = String(sourceObject || '').trim();
		if (!key) {
			return false;
		}

		if (EVENT_ONLY_SOURCE_OBJECTS[key]) {
			return true;
		}

		// Fallback by visible label (Task / Call / Meeting).
		var $sourceOption = getSetupFormRoot()
			.find('[data-field-key="' + SETUP_FIELDS.sourceObject + '"] [data-cdd-option]')
			.filter(function () {
				return String($(this).attr('data-value')) === key
					|| String($(this).attr('data-label')) === key;
			})
			.first();

		if ($sourceOption.length) {
			var labelKey = String($sourceOption.attr('data-label') || '').trim();
			if (EVENT_ONLY_SOURCE_OBJECTS[labelKey]) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Returns the Netcore CE import options for the selected Zoho object.
	 * Example: Tasks → [Event]; Leads → [Event, Contacts]
	 */
	function getImportTargetOptionsForSource(sourceObject) {
		var key = String(sourceObject || '').trim();
		if (!key) {
			return [];
		}

		if (isEventOnlySourceObject(key)) {
			return [NETCORE_IMPORT_EVENT];
		}

		return [NETCORE_IMPORT_EVENT, NETCORE_IMPORT_CONTACTS];
	}

	// Older single-option helper name kept for any leftover callers.
	function resolveImportTargetForSource(sourceObject) {
		var options = getImportTargetOptionsForSource(sourceObject);
		return options.length ? options[0] : null;
	}

	/**
	 * Progressive Setup fields (beginner-friendly):
	 *  1. Always show Connection + Zoho object
	 *  2. After Zoho object is selected → show Netcore import
	 *  3. Trigger real-time transfer:
	 *       - Task / Calls / Meetings → show immediately
	 *       - Leads / Contacts / Accounts / Opportunities (and other
	 *         non–event-only objects) → show only after import method is set
	 *  4. If Zoho object is cleared → hide Netcore import + Trigger
	 *
	 * When Trigger is hidden again (e.g. Lead selected but import method
	 * cleared), clear the radio so a stale choice is not saved. When it
	 * becomes visible with no selection, default to "Updated".
	 */
	function shouldShowTriggerSyncField(sourceObject, targetObject) {
		var source = $.trim(String(sourceObject || ''));
		if (!source) {
			return false;
		}

		// Task / Calls / Meetings (and label aliases Task / Call / Meeting).
		if (isEventOnlySourceObject(source)) {
			return true;
		}

		// Leads / Contacts / Accounts / Opportunities (Deals) — wait for import method.
		return !!$.trim(String(targetObject || ''));
	}

	/**
	 * The note under the Netcore CE import dropdown is entirely about event
	 * triggering, so it belongs to the Event option only — hidden for Contacts
	 * and while nothing is selected.
	 *
	 * Scoped to #dt-setup-target-object (the note sits inside it), which keeps
	 * the identically classed note in the Trigger group untouched.
	 */
	function updateTargetObjectNoteVisibility(targetObject) {
		var $note = getTargetObjectField().find('.datatrsf-field-desc');
		if (!$note.length) {
			return;
		}

		$note.toggle($.trim(String(targetObject || '')) === NETCORE_IMPORT_EVENT.value);
	}

	function updateSetupDependentFieldVisibility() {
		var values = getSetupFormValues();
		var $form = getSetupFormRoot();
		var $targetGroup = $form.find('[data-field="targetObject"]');
		var $triggerGroup = $form.find('[data-field="triggerSync"]');

		if (values.sourceObject) {
			$targetGroup.show();
		} else {
			$targetGroup.hide();
		}

		updateTargetObjectNoteVisibility(values.targetObject);

		var showTrigger = shouldShowTriggerSyncField(
			values.sourceObject,
			values.targetObject
		);

		if (showTrigger) {
			$triggerGroup.show();
			// "Zoho record is updated" is always the default when Trigger is shown empty.
			if (!values.triggerSync) {
				setTriggerSyncSelection('Updated');
			}
		} else {
			$triggerGroup.hide();
			// Hidden → drop prior radio so it cannot leak into the next selection.
			clearTriggerSyncSelection();
		}
	}

	/** Clears the Trigger radio selection (used when a parent field is cleared). */
	function clearTriggerSyncSelection() {
		var $form = getSetupFormRoot();
		$form.find('input[name="triggerSync"]').prop('checked', false);
		syncTriggerRadioStyles();
		clearSetupFieldError(SETUP_FIELDS.triggerSync);
	}

	/** Selects a Trigger radio by value (e.g. "Updated"). */
	function setTriggerSyncSelection(triggerValue) {
		var value = String(triggerValue || '').trim();
		var $form = getSetupFormRoot();
		if (!value) {
			clearTriggerSyncSelection();
			return;
		}

		$form.find('input[name="triggerSync"]').each(function () {
			this.checked = String(this.value) === value;
		});
		syncTriggerRadioStyles();
		clearSetupFieldError(SETUP_FIELDS.triggerSync);
	}

	/**
	 * Fills the Netcore CE import dropdown from the selected Zoho object.
	 * options.selectedValue — restore a known value (edit / load); otherwise clear it.
	 *
	 * Special case: Task / Meeting / Call → auto-select Event + "Zoho record is updated".
	 */
	function syncImportTargetForSourceObject(sourceObject, options) {
		options = options || {};
		var $target = getTargetObjectField();
		if (!$target.length) {
			return;
		}

		var targetOptions = getImportTargetOptionsForSource(sourceObject);
		if (!targetOptions.length) {
			// No Zoho object → hide + clear dependent fields.
			setSetupFieldOptions(SETUP_FIELDS.targetObject, []);
			$target.attr('data-placeholder', 'Select Zoho object first');
			setCddValue($target, '', '');
			setCddDisabledState($target, true);
			clearTriggerSyncSelection();
			updateSetupDependentFieldVisibility();
			updateDestinationDataHeading('');
			updateDataConfigurationDestinationPanel();
			updateFieldMappingWizardVisibility();
			return;
		}

		setSetupFieldOptions(SETUP_FIELDS.targetObject, targetOptions);
		$target.attr('data-placeholder', 'for ex: Contacts');
		setCddDisabledState($target, false);

		var selectedValue = options.selectedValue != null
			? String(options.selectedValue).trim()
			: '';

		// Older saved records may still say "Events" — treat as "Event".
		if (selectedValue === 'Events') {
			selectedValue = 'Event';
		}

		var matchedOption = null;
		if (selectedValue) {
			targetOptions.forEach(function (option) {
				if (
					String(option.value) === selectedValue
					|| String(option.label) === selectedValue
				) {
					matchedOption = option;
				}
			});
		}

		var isEventOnly = isEventOnlySourceObject(sourceObject);

		if (matchedOption) {
			setCddValue($target, matchedOption.value, matchedOption.label);
			// Keep Event-only sources locked to the single Event option.
			if (isEventOnly) {
				setCddDisabledState($target, true);
			}
			// Trigger may already be restored by setSetupFormValues — leave it alone.
		} else if (isEventOnly) {
			// Task / Meeting / Call → auto-select Event.
			setCddValue($target, NETCORE_IMPORT_EVENT.value, NETCORE_IMPORT_EVENT.label);
			setCddDisabledState($target, true);
			// Default trigger is always "Zoho record is updated".
			setTriggerSyncSelection('Updated');
		} else {
			// Other Zoho objects → user chooses Event or Contacts.
			setCddValue($target, '', '');
			// Default trigger is always "Zoho record is updated".
			setTriggerSyncSelection('Updated');
		}

		updateSetupDependentFieldVisibility();
		updateDestinationDataHeading();
		updateDataConfigurationDestinationPanel();
		updateFieldMappingWizardVisibility();
	}

	function bindSetupSectionInteractions() {
		var $root = $('#data-transfer-setup');

		$root.on('click', '#dt-setup-form [data-cdd-toggle]', function (event) {
			event.preventDefault();
			event.stopPropagation();
			openCdd(getCddRoot(this));
		});

		$root.on('keydown', '#dt-setup-form [data-cdd-toggle]', function (event) {
			if (event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				openCdd(getCddRoot(this));
			}
		});

		$root.on('keydown', '#dt-setup-form [data-cdd-search]', function (event) {
			if (event.key === 'Enter') {
				event.preventDefault();
			}
		});

		$root.on('click', '#dt-setup-form [data-cdd-option]', function (event) {
			event.preventDefault();
			event.stopPropagation();
			selectCddOption($(this));
		});

		$root.on('input', '#dt-setup-form [data-cdd-search]', function () {
			filterCddOptions(getCddRoot(this), $(this).val());
		});

		$root.on('change', '#dt-setup-form input[name="triggerSync"]', function () {
			syncTriggerRadioStyles();
			clearSetupFieldError(SETUP_FIELDS.triggerSync);
		});

		$(document).on('click.dtSetupCdd', function (event) {
			if (!$(event.target).closest('#dt-setup-form .datatrsf-cdd').length) {
				closeAllCdds($('#dt-setup-form'));
			}
		});
	}

	/* ------------------------------------------------------------------ */
	/* Legacy CDD helpers for data-configuration-sec static markup         */
	/* ------------------------------------------------------------------ */

	function ensureLegacyCddGlobals() {
		window.closeAllCdds = function () {
			closeAllCdds($(document));
		};

		window.toggleCdd = function (id) {
			var $cdd = $('#' + id);
			if ($cdd.length) {
				openCdd($cdd);
			}
		};

		window.selectCdd = function (id, el) {
			var $cdd = $('#' + id);
			if (!$cdd.length || !el) {
				return;
			}

			var $option = $(el);
			var value = $option.attr('data-value');
			var label = $option.attr('data-label') || $option.text();

			$cdd.find('.datatrsf-cdd-item').removeClass('datatrsf-selected');
			$option.addClass('datatrsf-selected');

			var $display = $cdd.find('.datatrsf-cdd-display, .datatrsf-cdd-val').first();
			$display.text(label);
			$cdd.find('.datatrsf-cdd-trigger').addClass('has-value datatrsf-has-value');
			closeAllCdds($cdd);
			setCddValue($cdd, value, label);
		};

		window.filterCdd = function (id, query) {
			filterCddOptions($('#' + id), query);
		};
	}

	function registerScreen(key, config) {
		if (!key || !config || !config.url || !config.rootSelector) {
			console.error('Invalid Data Transfer screen registration:', key, config);
			return;
		}

		screens[key] = $.extend({ key: key }, config);
	}

	function bindDataTransferTab() {
		$('#nav-data-transfer-tab').on('click', function (event) {
			event.preventDefault();
			// Auto-decide listing vs empty landing (do not force a screen).
			openDataTransferTab({ animate: true });
		});
	}

	bindDataTransferTab();
	ensureLegacyCddGlobals();

	window.DataTransferModule = {
		open: openDataTransferTab,
		showScreen: showScreen,
		registerScreen: registerScreen,
		getCurrentScreen: function () {
			return state.currentScreen;
		},
		/* Setup section API surface */
		SETUP_FIELDS: SETUP_FIELDS,
		SETUP_ZOHO_FIELD_MAP: SETUP_ZOHO_FIELD_MAP,
		getSetupFormValues: getSetupFormValues,
		setSetupFormValues: setSetupFormValues,
		setSetupFieldOptions: setSetupFieldOptions,
		validateSetupForm: validateSetupForm,
		buildSetupSavePayload: buildSetupSavePayload,
		prepareDataTransferPayload: prepareDataTransferPayload,
		prepareDataConfigurationPayload: prepareDataConfigurationPayload,
		buildZohoDataTransferRecord: buildZohoDataTransferRecord,
		handleSetupSaveClick: handleSetupSaveClick,
		persistDataTransferRecord: persistDataTransferRecord,
		saveDataTransferRecord: saveDataTransferRecord,
		getCurrentRecordId: getCurrentRecordId,
		setCurrentRecordId: setCurrentRecordId,
		clearCurrentRecordId: clearCurrentRecordId,
		resetEditor: resetDataTransferEditor,
		isDataTransferEditMode: isDataTransferEditMode,
		openForEdit: openDataTransferForEdit,
		openForDuplicate: openDataTransferForDuplicate,
		fetchDataTransferRecord: fetchDataTransferRecord,
		populateDataTransferEditor: populateDataTransferEditor,
		syncImportTargetForSourceObject: syncImportTargetForSourceObject,
		updateSetupDependentFieldVisibility: updateSetupDependentFieldVisibility,
		/* Connection dropdown API */
		loadConnectionOptions: loadConnectionOptions,
		reloadConnectionOptions: reloadConnectionOptions,
		getSelectedConnectionId: getSelectedConnectionId,
		getCachedConnections: getCachedConnections,
		invalidateConnectionsCache: function () {
			state.connections = [];
			state.connectionsLoaded = false;
			state.connectionsLoading = false;
		}
	};


	/*
	 * ==================================================================
	 * Data Configuration UI (adapted from Netcore designer JS)
	 * ==================================================================
	 */

	/** Updates the Setup / Data configuration / Field mapping step tabs. */
	function goToStep(stepIndex) {
		var $steps = $('#data-transfer-setup .datatrsf-step-item');

		$steps.removeClass('datatrsf-active datatrsf-fill');
		$steps.find('.datatrsf-step-icon').removeClass('datatrsf-active datatrsf-fill');

		$steps.each(function (index) {
			var $step = $(this);
			var $icon = $step.find('.datatrsf-step-icon');
			var parsedStep = parseInt($step.attr('data-dt-step'), 10);
			var stepNumber = isNaN(parsedStep) ? index : parsedStep;
			var isActive = stepNumber === stepIndex;

			// Mark visited earlier steps as "fill" (completed look), active as "active".
			if (stepNumber < stepIndex) {
				$step.addClass('datatrsf-fill');
				$icon.addClass('datatrsf-fill');
			} else if (isActive) {
				$step.addClass('datatrsf-active');
				$icon.addClass('datatrsf-active');
			}

			$step.attr('aria-selected', isActive ? 'true' : 'false');
		});
	}

	/**
	 * Field mapping tab + connector — visible only for Contacts import target.
	 *
	 * redirectActiveStep: when the tab is hidden under a user standing on it,
	 * move them back to Data configuration. showDataTransferWizardStep() passes
	 * false, because it is already choosing the step and .datatrsf-active still
	 * holds the previous one until its closing goToStep() — redirecting from
	 * there would keep re-entering with that same stale step until the stack
	 * ran out.
	 */
	function updateFieldMappingWizardVisibility(options) {
		var settings = options || {};
		var $tab = $('#dt-step-field-mapping');
		var $connector = $('#dt-step-field-mapping-connector');
		var showFieldMapping = isContactsImportTargetSelected();

		if ($tab.length) {
			if (showFieldMapping) {
				$tab.show();
			} else {
				$tab.hide();
				if (
					settings.redirectActiveStep !== false
					&& getActiveWizardStep() === WIZARD_STEP.FIELD_MAPPING
				) {
					showDataTransferWizardStep(WIZARD_STEP.DATA_CONFIG);
				}
			}
		}

		if ($connector.length) {
			$connector.toggle(showFieldMapping);
		}
	}

	/** Top-bar NEXT / START EXPORT swap for the active wizard step. */
	function updateWizardTopBarActions(stepIndex) {
		var $nextBtn = $('#dt-setup-next-btn');
		var $startExportBtn = $('#dt-start-export-btn');
		var contactsFlow = isContactsImportTargetSelected();

		$nextBtn.hide();
		$startExportBtn.hide();

		if (stepIndex === WIZARD_STEP.SETUP) {
			$nextBtn.show();
			return;
		}

		if (stepIndex === WIZARD_STEP.DATA_CONFIG) {
			if (contactsFlow) {
				$nextBtn.show();
			} else {
				$startExportBtn.show();
			}
			return;
		}

		if (stepIndex === WIZARD_STEP.FIELD_MAPPING) {
			$startExportBtn.show();
		}
	}

	/**
	 * Show Setup (0), Data configuration (1), or Field mapping (2).
	 * Form values stay in the DOM (not cleared).
	 *
	 * Top-bar actions:
	 *   Setup (0)                         → NEXT
	 *   Data Configuration (1) + Event    → START EXPORT
	 *   Data Configuration (1) + Contacts → NEXT
	 *   Field mapping (2) + Contacts        → START EXPORT
	 */
	function showDataTransferWizardStep(stepIndex) {
		updateFieldMappingWizardVisibility({ redirectActiveStep: false });

		if (stepIndex === WIZARD_STEP.FIELD_MAPPING && !isContactsImportTargetSelected()) {
			stepIndex = WIZARD_STEP.DATA_CONFIG;
		}

		var $setup = $('#data-transfer-setup .data-transfer-setup-sec');
		var $config = $('#data-transfer-setup .data-configuration-sec');
		var $fieldMapping = $('#data-transfer-setup .field-mapping-sec');
		var $configCols = $config.children('.datatrsf-col-left, .datatrsf-col-right');

		if (stepIndex === WIZARD_STEP.DATA_CONFIG || stepIndex === WIZARD_STEP.FIELD_MAPPING) {
			$setup.hide();
			$config.show();

			if (stepIndex === WIZARD_STEP.DATA_CONFIG) {
				$config.css('display', 'flex');
				$configCols.show();
				$fieldMapping.hide();
				refreshSourceDataSection();
				updateDestinationDataHeading();
				updateDataConfigurationDestinationPanel();
				refreshFilterTruncationTooltips();
			} else {
				$config.css('display', 'block');
				$configCols.hide();
				$fieldMapping.show();
				renderZohoIdentifierDisplay();
				syncZohoIdentifierListSelection(zohoIdentifierUi.selectedValue || '');
				renderNetcoreCeIdentifierDisplay();
				syncNetcoreCeIdentifierListSelection(sfIdentifierUi.selectedValue || '');
				refreshAllMappingSourceFieldDropdowns({ preserveSelection: true });
				refreshAllMappingDestAttributeDropdowns({ preserveSelection: true });
				updateContactsFieldMappingTableVisibility();
				updateContactsSecondaryIdentityVisibility();
			}
		} else {
			$config.hide();
			$fieldMapping.hide();
			$configCols.show();
			$setup.show();
		}

		updateWizardTopBarActions(stepIndex);
		goToStep(stepIndex);
	}

	/**
	 * Paint "Field is required." on every unfilled filter column and return the
	 * first one, so NEXT can scroll to it. Same rules and messages the TEST /
	 * START EXPORT pass uses. Filters are optional, so a card switched OFF is
	 * always complete.
	 */
	function getIncompleteFilterColumn() {
		try {
			var $rows = $('#datatrsf-rows-wrap .datatrsf-filter-row');

			// Start clean, or a column fixed since the last NEXT would stay red.
			$rows.find('[data-dc-filter]').removeClass('has-error');
			$rows.find('[data-dc-filter-error]').text('').attr('hidden', true).hide();

			if (!isFiltersToggleOn()) {
				return $();
			}

			var $firstIncompleteColumn = $();

			function markIncompleteFilterColumn($row, filterKey, message) {
				setFilterColError($row, filterKey, message);
				if (!$firstIncompleteColumn.length) {
					$firstIncompleteColumn = $row.find('[data-dc-filter="' + filterKey + '"]').first();
				}
			}

			$rows.each(function () {
				var $row = $(this);
				var $fieldCdd = $row.find('[data-filter-field-cdd="true"]').first();
				var $opCdd = $row.find('[data-filter-op-cdd="true"]').first();
				var $valueInput = $row.find('[data-filter-value-input="true"]').first();

				if (!$.trim($fieldCdd.attr('data-selected-value') || '')) {
					markIncompleteFilterColumn($row, 'field', DATA_CONFIG_TEST_MESSAGES.filterField);
				}

				if (!$.trim($opCdd.attr('data-selected-value') || '')) {
					markIncompleteFilterColumn($row, 'operator', DATA_CONFIG_TEST_MESSAGES.filterOperator);
				}

				// Value only exists after Operator is chosen — skip if input not in DOM / not visible.
				var valueInputVisible = $valueInput.length
					&& $valueInput.is(':visible')
					&& !$valueInput.closest('.datatrsf-filter-value-wrap').hasClass('is-empty');
				if (valueInputVisible && !$.trim($valueInput.val() || '')) {
					markIncompleteFilterColumn($row, 'value', DATA_CONFIG_TEST_MESSAGES.filterValue);
				}
			});

			return $firstIncompleteColumn;
		} catch (filterValidationError) {
			console.error('Filter validation failed:', filterValidationError);
			return $();
		}
	}

	/**
	 * Contacts flow: Data configuration → Field mapping (NEXT only; no forward tab click).
	 */
	// The Destination field that is on screen and still unanswered, if any.
	function getIncompleteContactsDestField() {
		var $panel = getContactsDestinationPanel();

		// Start clean, or a list picked since the last NEXT would stay red.
		clearDataConfigFieldError('addToList');
		clearDataConfigFieldError('removeFromList');

		// Filters and Destination are both checked, so every gap is marked in one
		// pass. Source data sits above, so its columns are measured first and the
		// first gap found is what NEXT scrolls to.
		var $firstIncompleteField = getIncompleteFilterColumn();

		function rememberFirstIncompleteField($field) {
			if (!$firstIncompleteField.length) {
				$firstIncompleteField = $field;
			}
		}

		if (getContactsDestActionValue() === 'remove') {
			var removeFrom = getContactsRemoveFromValue();

			// "Where would you like to remove the contacts from?" — must be answered.
			if (!removeFrom) {
				rememberFirstIncompleteField($panel.find('#dt-contacts-remove-from-group'));
				return $firstIncompleteField;
			}

			// Contact master needs no list; only the List route does.
			if (
				removeFrom === 'list'
				&& !Object.keys(contactsListUi.removeLists.selected || {}).length
			) {
				setDataConfigFieldError('removeFromList', DATA_CONFIG_TEST_MESSAGES.removeFromList);
				rememberFirstIncompleteField($panel.find('#dt-contacts-remove-list-field'));
			}

			return $firstIncompleteField;
		}

		// "Add to list(s)" is optional: left un-ticked the contacts go to the
		// master only, so NEXT is free to proceed. Ticked, though, the list
		// below it is on screen and must name at least one list.
		try {
			if (!getContactsAddToListForSave()) {
				return $firstIncompleteField;
			}
		} catch (addToListCheckError) {
			console.error('Add to list check failed:', addToListCheckError);
		}

		if (!Object.keys(contactsListUi.addLists.selected || {}).length) {
			setDataConfigFieldError('addToList', DATA_CONFIG_TEST_MESSAGES.addToList);
			rememberFirstIncompleteField($panel.find('#dt-contacts-add-list-field'));
		}

		return $firstIncompleteField;
	}

	function attemptNavigateToFieldMapping() {
		if (!isContactsImportTargetSelected()) {
			return false;
		}

		if (getActiveWizardStep() !== WIZARD_STEP.DATA_CONFIG) {
			return false;
		}

		var $incompleteField = getIncompleteContactsDestField();
		if ($incompleteField.length) {
			showSetupNextStepAlert();

			// Same as Setup's NEXT: bring the field the user must fill into view.
			if ($incompleteField.offset()) {
				$('html, body').stop(true).animate({
					scrollTop: $incompleteField.offset().top - 24
				}, 250);
			}

			return false;
		}

		hideSetupNextStepAlert();
		showDataTransferWizardStep(WIZARD_STEP.FIELD_MAPPING);
		return true;
	}

	/** Step the wizard is on right now — goToStep() marks it .datatrsf-active. */
	function getActiveWizardStep() {
		var active = parseInt(
			$('#data-transfer-setup .datatrsf-step-item.datatrsf-active')
				.first().attr('data-dt-step'),
			10
		);

		return isNaN(active) ? 0 : active;
	}

	/**
	 * A step tab was clicked (or Enter/Space'd).
	 *
	 * Tabs only walk back. Forward is the NEXT button's job alone — it is what
	 * validates and saves, so letting a tab skip ahead would skip both.
	 */
	function navigateToWizardStepFromTab($tab) {
		var stepIndex = parseInt($tab.attr('data-dt-step'), 10);

		if (isNaN(stepIndex) || stepIndex > getActiveWizardStep()) {
			return;
		}

		hideSetupNextStepAlert();
		showDataTransferWizardStep(stepIndex);
	}

	/**
	 * Try to open Data Configuration after Setup validation.
	 *
	 * Flow (beginner-friendly):
	 *  1. Validate Setup fields (same rules as before).
	 *  2. If invalid → stay on Setup, show errors (and Next alert if needed).
	 *  3. If valid → save via persistDataTransferRecord()
	 *       (insert once, or update if currentRecordId already exists).
	 *       First-time create also runs the duplicate-name check (same as SAVE).
	 *       Already-saved / edit mode skips the name check on Next.
	 *  4. Only after save succeeds → switch to the Data Configuration tab.
	 *
	 * options.showNextAlert — true only for the NEXT button (not the tab click).
	 * Returns true when a save+navigate was started, false if blocked.
	 */
	function attemptNavigateToDataConfiguration(options) {
		options = options || {};
		var showNextAlert = options.showNextAlert === true;

		// ----- Step 1: Setup validation (unchanged) -----
		var validationResult = validateSetupForm();
		if (!validationResult.isValid) {
			// Stay on Setup and scroll to the first invalid field.
			showDataTransferWizardStep(0);

			var $firstInvalidField = getSetupFormRoot().find('.datatrsf-field-group.has-error').first();
			if ($firstInvalidField.length && $firstInvalidField.offset()) {
				$('html, body').stop(true).animate({
					scrollTop: $firstInvalidField.offset().top - 24
				}, 250);
			}

			if (showNextAlert) {
				showSetupNextStepAlert();
			}

			return false;
		}

		hideSetupNextStepAlert();

		// Already saving (e.g. user double-clicked NEXT) — do nothing.
		if (state.saving) {
			return false;
		}

		// ----- Step 2: Save Setup (insert OR update via shared helper) -----
		// currentRecordId empty → Insert once (+ duplicate name check)
		// currentRecordId set   → Update; skip name check (already created / edit)
		// Same common-loader as SAVE button (no "SAVING..." on NEXT).
		var alreadySaved = !!getCurrentRecordId();
		persistDataTransferRecord({
			showSuccessToast: false,
			skipNameCheck: alreadySaved,
			showCommonLoader: true
		})
			.then(function () {
				// ----- Step 3: Only open Data Configuration after a successful save -----
				showDataTransferWizardStep(1);
			})
			.catch(function () {
				// Save / duplicate-name failed — stay on Setup (alert already shown).
				showDataTransferWizardStep(0);
			});

		return true;
	}

	function hideSetupNextStepAlert() {
		if (state.nextAlertHideTimer) {
			clearTimeout(state.nextAlertHideTimer);
			state.nextAlertHideTimer = null;
		}
		$('#dt-setup-next-alert').hide();
	}

	/** Bottom error alert (auto-hides in 2s). Reused for NEXT validation + duplicate create. */
	function showSetupErrorAlert(message) {
		var $alert = $('#dt-setup-next-alert');
		if (!$alert.length) {
			return;
		}

		// Don't stack with the Zoho-object info alert.
		hideZohoObjectChangedAlert();

		$alert.find('.alert-msg-text').text(message || SETUP_NEXT_STEP_ALERT_MESSAGE);
		// Force visible even if a prior hide() left conflicting inline styles.
		$alert.stop(true, true).css('display', 'block').show();

		// It sits at the panel's bottom edge, so it is off-screen from most buttons.
		scrollToSetupPanelBottom();

		if (state.nextAlertHideTimer) {
			clearTimeout(state.nextAlertHideTimer);
		}
		state.nextAlertHideTimer = setTimeout(function () {
			$alert.hide();
			state.nextAlertHideTimer = null;
		}, 2000);
	}

	/** Bottom alert shown only when NEXT fails validation (auto-hides in 2s). */
	function showSetupNextStepAlert() {
		showSetupErrorAlert(SETUP_NEXT_STEP_ALERT_MESSAGE);
	}

	function hideZohoObjectChangedAlert() {
		hideSetupInfoAlert();
	}

	function hideSetupInfoAlert() {
		if (state.zohoObjectAlertHideTimer) {
			clearTimeout(state.zohoObjectAlertHideTimer);
			state.zohoObjectAlertHideTimer = null;
		}
		$('#dt-setup-zoho-object-alert').hide();
	}

	/** Shared bottom info alert (Zoho object / Netcore entity change). */
	function showSetupInfoAlert(message, hideAfterMs) {
		var $alert = $('#dt-setup-zoho-object-alert');
		if (!$alert.length) {
			return;
		}

		// Don't stack with the NEXT validation alert.
		hideSetupNextStepAlert();

		$alert.find('.alert-msg-text').text(message || '');
		$alert.show();

		if (state.zohoObjectAlertHideTimer) {
			clearTimeout(state.zohoObjectAlertHideTimer);
		}
		// Default 4s for change notices; callers can pass 2000 for shorter toasts.
		var delay = typeof hideAfterMs === 'number' ? hideAfterMs : 4000;
		state.zohoObjectAlertHideTimer = setTimeout(function () {
			$alert.hide();
			state.zohoObjectAlertHideTimer = null;
		}, delay);
	}

	/**
	 * Info alert when "Which Zoho object..." changes (not the first selection).
	 */
	function showZohoObjectChangedAlert() {
		showSetupInfoAlert(ZOHO_OBJECT_CHANGED_ALERT_MESSAGE);
	}

	/**
	 * Info alert when "How would you like to import..." changes (not the first selection).
	 */
	function showNetcoreEntityChangedAlert() {
		showSetupInfoAlert(NETCORE_ENTITY_CHANGED_ALERT_MESSAGE);
	}

	/**
	 * Operator options by Zoho field data_type (Filter based on → Operator).
	 * Unknown types fall back to FILTER_OPERATOR_DEFAULT.
	 */
	var FILTER_OPERATOR_MAP = {
		datetime: ['Before', 'After', 'On'],
		date: ['Before', 'After', 'On'],
		picklist: ['Is', 'Is not'],
		text: ['Is', 'Is not'],
		lookup: ['Is', 'Is not'],
		phone: ['Is', 'Is not'],
		boolean: ['Is', 'Is not'],
		ownerlookup: ['Is', 'Is not'],
		email: ['Is', 'Is not'],
		textarea: ['Is', 'Is not'],
		profileimage: ['Is', 'Is not'],
		decimal: ['Is', 'Is not'],
		url: ['Is', 'Is not'],
		currency: ['Equals', 'Is greater than','Is less than','Is less than or equal to','Is greater than or equal to'],
		integer: ['Equals', 'Is greater than','Is less than','Is less than or equal to','Is greater than or equal to'],
		decimal: ['Equals', 'Is greater than','Is less than','Is less than or equal to','Is greater than or equal to']
	};
	var FILTER_OPERATOR_DEFAULT = ['Is', 'Is not'];
	var FILTER_OPERATOR_PLACEHOLDER = 'Select operator';

	/**
	 * Value input type is driven by Filter based on field data_type:
	 *  - datetime → date + time picker
	 *  - date     → date-only picker
	 *  - anything else → plain text
	 * Operator still controls whether Value is visible.
	 */
	var FILTER_VALUE_TEXT_PLACEHOLDER = 'Enter value';
	var FILTER_VALUE_DATE_PLACEHOLDER = 'mm/dd/yyyy';
	var FILTER_VALUE_DATETIME_PLACEHOLDER = 'mm/dd/yyyy --:-- --';

	/**
	 * Map Zoho field data_type → Value control kind.
	 * Returns: "datetime" | "date" | "text"
	 */
	function getFilterValueInputKindFromDataType(dataType) {
		var key = String(dataType || '').toLowerCase();
		if (key === 'datetime') {
			return 'datetime';
		}
		if (key === 'date') {
			return 'date';
		}
		return 'text';
	}

	/**
	 * Read the data_type stored on this row's "Filter based on" dropdown
	 * (set when the user picks a field — see data-selected-type).
	 */
	function getSelectedFilterFieldDataType($row) {
		if (!$row || !$row.length) {
			return '';
		}

		var $fieldCdd = $row.find('[data-filter-field-cdd="true"]').first();
		if (!$fieldCdd.length) {
			$fieldCdd = $row.find('.datatrsf-col-field .datatrsf-cdd').first();
		}
		return $.trim($fieldCdd.attr('data-selected-type') || '');
	}

	/** Calendar icon HTML shown on the right of the Date/DateTime Value input. */
	function getFilterDatetimeIconHtml() {
		// Decorative only (pointer-events: none in CSS) — clicks pass through to the input.
		return (
			'<span class="datatrsf-filter-datetime-icon" aria-hidden="true">' +
				'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">' +
					'<rect x="3" y="5" width="18" height="16" rx="2"></rect>' +
					'<path d="M3 10h18"></path>' +
					'<path d="M8 3v4M16 3v4"></path>' +
				'</svg>' +
			'</span>'
		);
	}

	/**
	 * Open the native date / datetime picker on a single user click.
	 * Input is already type="date" or type="datetime-local".
	 */
	function openFilterDatetimePicker(input) {
		if (!input) {
			return;
		}

		if (typeof input.showPicker === 'function') {
			try {
				input.showPicker();
			} catch (error) {
				// Fallback: native ::-webkit-calendar-picker-indicator covers the field.
				console.warn('showPicker failed:', error);
			}
		}
	}

	/** Keep the fake placeholder in sync with whether the date/datetime input has a value. */
	function syncFilterDatetimeEmptyState(input) {
		if (!input) {
			return;
		}
		var $group = $(input).closest('.datatrsf-filter-datetime');
		if (!$group.length) {
			return;
		}
		$group.toggleClass('is-empty', !input.value);
	}

	/**
	 * Build a date or datetime Value control (shared UI + calendar icon).
	 * kind = "date" → <input type="date">
	 * kind = "datetime" → <input type="datetime-local">
	 */
	function buildFilterDateValueInput(kind) {
		var isDateOnly = kind === 'date';
		var inputType = isDateOnly ? 'date' : 'datetime-local';
		var placeholderText = isDateOnly
			? FILTER_VALUE_DATE_PLACEHOLDER
			: FILTER_VALUE_DATETIME_PLACEHOLDER;

		var $group = $('<div class="datatrsf-filter-datetime is-empty"></div>');
		var $input = $(
			'<input class="form-control datatrsf-filter-value-input" ' +
				'data-filter-value-input="true" />'
		);
		$input.attr('type', inputType);
		$input.attr('data-value-kind', isDateOnly ? 'date' : 'datetime');

		var $placeholder = $(
			'<span class="datatrsf-filter-datetime-placeholder"></span>'
		).text(placeholderText);

		$group.append($input);
		$group.append($placeholder);
		$group.append(getFilterDatetimeIconHtml());
		return $group;
	}

	/**
	 * Show / rebuild the Value input for ONE filter row.
	 *
	 * Important: the Value COLUMN always stays in the flex row so Filter based on
	 * and Operator keep the same widths (no layout shift).
	 *
	 * Rules (beginner-friendly):
	 *  1. No operator selected → hide label + input; keep empty reserved space
	 *  2. Operator selected → show Value; input type comes from Filter based on data_type:
	 *       datetime → date + time picker
	 *       date     → date-only picker
	 *       other    → plain text
	 *  3. Always clear the previous value when rebuilding
	 */
	function updateFilterValueField($row, operator) {
		if (!$row || !$row.length) {
			return;
		}

		var $col = $row.find('[data-filter-value-col="true"]').first();
		if (!$col.length) {
			$col = $row.find('.datatrsf-col-val').first();
		}
		if (!$col.length) {
			return;
		}

		// Column must always remain in the flex row (never display:none).
		$col.show();

		var $wrap = $col.find('[data-filter-value-wrap="true"]').first();
		var $error = $col.find('[data-dc-filter-error="value"]').first();
		if (!$wrap.length) {
			// Safety: create the wrap if older markup is missing it (before error slot).
			$wrap = $('<div class="datatrsf-filter-value-wrap" data-filter-value-wrap="true"></div>');
			if ($error.length) {
				$error.before($wrap);
			} else {
				$col.append($wrap);
			}
		}

		var op = $.trim(String(operator || ''));

		// Label + input show/hide together via is-value-pending (CSS visibility).
		// Do not use jQuery .hide() on the label — that breaks row alignment.

		// Operator cleared / not chosen yet → hide label+input as one unit; keep layout spacer.
		if (!op || op === FILTER_OPERATOR_PLACEHOLDER) {
			$col.addClass('is-value-pending');
			$wrap.empty().addClass('is-empty');
			return;
		}

		// Operator chosen → show label and rebuild the correct input (always start empty).
		$col.removeClass('is-value-pending');
		$wrap.empty().removeClass('is-empty');

		// Input type comes from Filter based on field data_type (per row).
		var dataType = getSelectedFilterFieldDataType($row);
		var inputKind = getFilterValueInputKindFromDataType(dataType);

		if (inputKind === 'datetime' || inputKind === 'date') {
			$wrap.append(buildFilterDateValueInput(inputKind));
			return;
		}

		var $textInput = $(
			'<input type="text" class="form-control datatrsf-filter-value-input" ' +
				'data-filter-value-input="true" data-value-kind="text" />'
		);
		$textInput.attr('placeholder', FILTER_VALUE_TEXT_PLACEHOLDER);
		$wrap.append($textInput);
	}

	/** Return operator labels for a field data_type (case-insensitive). */
	function getOperatorsForDataType(dataType) {
		var key = String(dataType || '').toLowerCase();
		var mapped = FILTER_OPERATOR_MAP[key];
		if (mapped && mapped.length) {
			return mapped.slice();
		}
		return FILTER_OPERATOR_DEFAULT.slice();
	}

	var isMappingTooltipScrollBound = false;

	/** Field mapping lists plus the Identity mapping identifier lists. */
	var MAPPING_OPTION_DD_SELECTOR = [
		'[data-mapping-source-field-dd="true"]',
		'[data-mapping-dest-attribute-dd="true"]',
		'#source-identifier-dropdown',
		'#destination-identifier-dropdown',
		'#secondary-source-identifier-dropdown',
		'#secondary-destination-identifier-dropdown'
	].join(', ');

	/** Same stranding problem as the Filters list, on the Field mapping lists. */
	function bindMappingTooltipScrollHide() {
		if (isMappingTooltipScrollBound) {
			return;
		}
		isMappingTooltipScrollBound = true;

		document.addEventListener('scroll', function (scrollEvent) {
			try {
				var scrolledEl = scrollEvent.target;
				if (
					!scrolledEl
					|| !scrolledEl.classList
					|| !scrolledEl.classList.contains('dd-list')
					|| !scrolledEl.closest(MAPPING_OPTION_DD_SELECTOR)
					|| typeof bootstrap === 'undefined'
					|| !bootstrap.Tooltip
				) {
					return;
				}

				// hide(), not dispose() — the option must keep its tooltip for later.
				$(scrolledEl).find('[data-bs-toggle="tooltip"]').each(function () {
					var openTooltip = bootstrap.Tooltip.getInstance(this);
					if (openTooltip) {
						openTooltip.hide();
					}
				});
			} catch (mappingTooltipScrollError) {
				console.error('Field mapping tooltip scroll hide failed:', mappingTooltipScrollError);
			}
		}, true);
	}

	/**
	 * Tooltip for the chosen value on a dropdown trigger, when the CSS has
	 * clipped it. Same clipped-only rule as the option lists. The trigger is
	 * always on screen, so this can measure straight away.
	 */
	function refreshDropdownTriggerTooltip($dd) {
		try {
			if (!$dd || !$dd.length) {
				return;
			}

			var $value = $dd.find('.dd-trigger .dd-value').first();
			if (!$value.length) {
				return;
			}

			var valueEl = $value[0];
			var text = $.trim($value.text());

			if (text && valueEl.scrollWidth > valueEl.clientWidth) {
				$value.attr({
					'data-bs-toggle': 'tooltip',
					'data-bs-placement': 'bottom',
					'data-bs-container': 'body',
					'title': text
				});

				if (typeof window.initBootstrapTooltips === 'function') {
					window.initBootstrapTooltips(valueEl);
				}
				return;
			}

			// Fits now — drop any tooltip it picked up while it was longer.
			if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
				var existing = bootstrap.Tooltip.getInstance(valueEl);
				if (existing) {
					existing.dispose();
				}
			}
			$value.removeAttr(
				'data-bs-toggle data-bs-placement data-bs-container title data-bs-original-title'
			);
		} catch (triggerTooltipError) {
			console.error('Dropdown trigger tooltip refresh failed:', triggerTooltipError);
		}
	}

	/**
	 * The element a dropdown option shows its text in. Field mapping options wrap
	 * theirs in .item-name; Identity mapping options put it on the item itself.
	 */
	function getDropdownOptionLabels($dd) {
		var labels = [];

		$dd.find('.dd-simple-item').each(function () {
			var $itemName = $(this).find('.item-name').first();
			labels.push($itemName.length ? $itemName[0] : this);

			var $itemType = $(this).find('.item-type').first();
			if ($itemType.length) {
				labels.push($itemType[0]);
			}
		});

		return labels;
	}

	/**
	 * Tooltips for dropdown options the CSS has clipped.
	 * Same rule as the Filters list: scrollWidth beats clientWidth exactly when
	 * the browser is drawing the "…", so an option that fits stays tooltip-free.
	 * Widths only exist once the panel is on screen, so call this after it opens.
	 */
	function refreshMappingOptionTooltips($dd) {
		try {
			if (!$dd || !$dd.length) {
				return;
			}

			$(getDropdownOptionLabels($dd)).each(function () {
				var $label = $(this);
				var text = $.trim($label.text());

				if (text && this.scrollWidth > this.clientWidth) {
					$label.attr({
						'data-bs-toggle': 'tooltip',
						'data-bs-placement': 'bottom',
						'data-bs-container': 'body',
						'title': text
					});
					return;
				}

				// Fits now — drop any tooltip it picked up while it was longer.
				if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
					var existing = bootstrap.Tooltip.getInstance(this);
					if (existing) {
						existing.dispose();
					}
				}
				$label.removeAttr(
					'data-bs-toggle data-bs-placement data-bs-container title data-bs-original-title'
				);
			});

			if (typeof window.initBootstrapTooltips === 'function') {
				window.initBootstrapTooltips($dd[0]);
			}

			bindMappingTooltipScrollHide();
		} catch (mappingTooltipError) {
			console.error('Field mapping tooltip refresh failed:', mappingTooltipError);
		}
	}

	var isFilterTooltipScrollBound = false;

	/**
	 * Filter tooltips render under <body>, so scrolling the option list leaves them
	 * hanging where the item used to be. Close them; the next hover reopens correctly.
	 * Capture phase because "scroll" does not bubble, so delegation cannot see it.
	 */
	function bindFilterTooltipScrollHide() {
		if (isFilterTooltipScrollBound) {
			return;
		}
		isFilterTooltipScrollBound = true;

		document.addEventListener('scroll', function (scrollEvent) {
			try {
				var scrolledEl = scrollEvent.target;
				if (
					!scrolledEl
					|| !scrolledEl.classList
					|| !scrolledEl.classList.contains('datatrsf-cdd-list')
					|| !scrolledEl.closest('#datatrsf-filter-body')
					|| typeof bootstrap === 'undefined'
					|| !bootstrap.Tooltip
				) {
					return;
				}

				// hide(), not dispose() — the label must keep its tooltip for later.
				$(scrolledEl).find('[data-bs-toggle="tooltip"]').each(function () {
					var openTooltip = bootstrap.Tooltip.getInstance(this);
					if (openTooltip) {
						openTooltip.hide();
					}
				});
			} catch (filterTooltipScrollError) {
				console.error('Filter tooltip scroll hide failed:', filterTooltipScrollError);
			}
		}, true);
	}

	/** Clear Operator dropdown — no options, show placeholder. */
	/**
	 * Tooltips for Filters dropdown labels the CSS has clipped with an ellipsis.
	 *
	 * Only clipped labels get one: scrollWidth exceeds clientWidth exactly when
	 * the browser is drawing the "…", so a label that fits stays tooltip-free.
	 * Placeholder and chosen value are treated the same — whatever is on screen
	 * is what gets measured.
	 *
	 * Uses the project's own tooltip path (data-bs-toggle + initBootstrapTooltips
	 * in netcore.js), and placement "auto" so Bootstrap flips the arrow above or
	 * below depending on the room around the field.
	 */
	function refreshFilterTruncationTooltips() {
		var body = document.getElementById('datatrsf-filter-body');
		if (!body) {
			return;
		}

		// The chosen value / placeholder on the trigger, plus every option in
		// the list — both are clipped to one line, so both can need a tooltip.
		$(body).find('.datatrsf-cdd-val, .datatrsf-cdd-item').each(function () {
			var $label = $(this);
			var text = $.trim($label.text());

			if (text && this.scrollWidth > this.clientWidth) {
				$label.attr({
					'data-bs-toggle': 'tooltip',
					// "bottom", not "auto": auto lets Bootstrap drop the tooltip
					// beside the field, and the design only has it above or
					// below. Bootstrap still flips bottom → top when the space
					// below runs out, which is the other arrow in the design.
					'data-bs-placement': 'bottom',
					// Render under <body>. Left inside the dropdown the tooltip
					// inherits that control's line-height and comes out shorter
					// than every other tooltip in the product.
					'data-bs-container': 'body',
					'title': text
				});
				return;
			}

			// Fits now — drop any tooltip it picked up while it was longer.
			if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
				var existing = bootstrap.Tooltip.getInstance(this);
				if (existing) {
					existing.dispose();
				}
			}
			$label.removeAttr(
				'data-bs-toggle data-bs-placement data-bs-container title data-bs-original-title'
			);
		});

		if (typeof window.initBootstrapTooltips === 'function') {
			window.initBootstrapTooltips(body);
		}

		bindFilterTooltipScrollHide();
	}

	function clearFilterOperatorDropdown($opCdd) {
		if (!$opCdd || !$opCdd.length) {
			return;
		}

		var $list = $opCdd.find('.datatrsf-cdd-list').first();
		if ($list.length) {
			$list.empty();
		}

		$opCdd.removeAttr('data-selected-value');
		$opCdd.find('.datatrsf-cdd-item').removeClass('datatrsf-selected');
		$opCdd.find('.datatrsf-cdd-val').first().text(FILTER_OPERATOR_PLACEHOLDER);
		$opCdd.find('.datatrsf-cdd-trigger').removeClass('has-value datatrsf-has-value open');
		$opCdd.find('.datatrsf-cdd-panel').removeClass('open');

		// Operator cleared → reset Value to empty reserved space on this row.
		updateFilterValueField($opCdd.closest('.datatrsf-filter-row'), '');
		refreshFilterTruncationTooltips();
	}

	/**
	 * Fill Operator dropdown options for one filter row.
	 * operators = ["Is", "Is not"] or ["Before", "After", "On"]
	 */
	function fillFilterOperatorDropdown($opCdd, operators) {
		if (!$opCdd || !$opCdd.length) {
			return;
		}

		var opId = $opCdd.attr('id') || '';
		var $list = $opCdd.find('.datatrsf-cdd-list').first();
		if (!$list.length) {
			return;
		}

		$list.empty();

		(operators || []).forEach(function (opLabel) {
			var label = String(opLabel || '').trim();
			if (!label) {
				return;
			}

			var $item = $('<div class="datatrsf-cdd-item"></div>');
			$item.attr('data-value', label);
			$item.attr('data-label', label);
			$item.attr('onclick', "datatrsf_selectItem(this,'" + opId + "')");
			$item.text(label);
			$list.append($item);
		});

		// Always reset selection when options change (field type changed).
		$opCdd.removeAttr('data-selected-value');
		$opCdd.find('.datatrsf-cdd-val').first().text(FILTER_OPERATOR_PLACEHOLDER);
		$opCdd.find('.datatrsf-cdd-trigger').removeClass('has-value datatrsf-has-value open');
		$opCdd.find('.datatrsf-cdd-panel').removeClass('open');

		// Operator reset → clear Value input but keep column space reserved.
		updateFilterValueField($opCdd.closest('.datatrsf-filter-row'), '');
	}

	/**
	 * After user picks a Filter based on field, refresh that row's Operator list
	 * using the field's data_type (from data-type on the option).
	 */
	function syncOperatorDropdownForFilterRow($row, dataType) {
		if (!$row || !$row.length) {
			return;
		}

		var $opCdd = $row.find('.datatrsf-col-op .datatrsf-cdd').first();
		if (!$opCdd.length) {
			return;
		}

		fillFilterOperatorDropdown($opCdd, getOperatorsForDataType(dataType));
	}

	/**
	 * Filter the "Filter based on" option list by search text (case-insensitive).
	 * Reuses the same idea as Setup Connection search / field-export search.
	 */
	function filterFilterBasedOnOptions($cdd, query) {
		if (!$cdd || !$cdd.length) {
			return;
		}

		var normalized = String(query || '').trim().toLowerCase();
		var $list = $cdd.find('.datatrsf-cdd-list').first();
		var $items = $list.find('.datatrsf-cdd-item').not('.datatrsf-cdd-empty, .datatrsf-cdd-search-empty');
		var visibleCount = 0;

		$items.each(function () {
			var $item = $(this);
			var haystack = String(
				$item.attr('data-label') || $item.attr('data-value') || $item.text() || ''
			).toLowerCase();
			var match = !normalized || haystack.indexOf(normalized) !== -1;
			$item.toggle(match);
			if (match) {
				visibleCount += 1;
			}
		});

		var $noMatch = $list.find('.datatrsf-cdd-search-empty');
		if (normalized && visibleCount === 0 && $items.length) {
			if (!$noMatch.length) {
				$noMatch = $('<div class="datatrsf-cdd-item datatrsf-cdd-empty datatrsf-cdd-search-empty"></div>')
					.text('No matches found');
				$list.append($noMatch);
			}
			$noMatch.show();
		} else if ($noMatch.length) {
			$noMatch.remove();
		}
	}

	/**
	 * Filter-row dropdowns in the HTML use onclick="datatrsf_toggleCdd(...)" etc.
	 * Designer used window.toggleCdd; we expose the names the HTML already calls.
	 */
	function ensureFilterRowGlobals() {
		// Maximum number of filter rows the user can add (including the default row).
		var MAX_FILTER_ROWS = 5;

		/** How many filter rows are currently on screen. */
		function getFilterRowCount() {
			return $('#datatrsf-rows-wrap .datatrsf-filter-row').length;
		}

		/** Shared HTML for a filter-row Delete button (one place only). */
		function getFilterDeleteButtonHtml(rowId) {
			return (
				'<button class="btn btn-delete" type="button" onclick="datatrsf_deleteRow(\'' + rowId + '\')" aria-label="Delete" data-bs-toggle="tooltip" title="Delete" data-bs-placement="bottom" data-bs-original-title="Delete">' +
					'<svg width="18" height="18" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">' +
						'<path fill-rule="evenodd" clip-rule="evenodd" d="M4.38607 1.604C4.38607 1.36238 4.58194 1.1665 4.82357 1.1665H9.17505C9.41667 1.1665 9.61255 1.36238 9.61255 1.604V3.06585H12.3952C12.6368 3.06585 12.8327 3.26172 12.8327 3.50335C12.8327 3.74497 12.6368 3.94085 12.3952 3.94085H11.3202L10.6556 12.4298C10.6378 12.6575 10.4478 12.8332 10.2194 12.8332H3.77924C3.55086 12.8332 3.3609 12.6575 3.34307 12.4298L2.67842 3.94085H1.60352C1.36189 3.94085 1.16602 3.74497 1.16602 3.50335C1.16602 3.26172 1.36189 3.06585 1.60352 3.06585H4.38607V1.604ZM8.73755 3.05504H5.26107V2.0415H8.73755V3.05504ZM3.5561 3.94085L4.18382 11.9582H9.81484L10.4426 3.94085H3.5561ZM5.48407 5.48464C5.72488 5.46482 5.93616 5.64397 5.95598 5.88479L6.3041 10.1151C6.32391 10.3559 6.14476 10.5672 5.90395 10.587C5.66314 10.6068 5.45186 10.4277 5.43204 10.1869L5.08393 5.95655C5.06411 5.71574 5.24326 5.50446 5.48407 5.48464ZM8.51473 5.48464C8.75554 5.50446 8.9347 5.71574 8.91488 5.95655L8.56676 10.1869C8.54694 10.4277 8.33566 10.6068 8.09485 10.587C7.85404 10.5672 7.67489 10.3559 7.69471 10.1151L8.04283 5.88479C8.06264 5.64397 8.27392 5.46482 8.51473 5.48464Z" fill="currentColor"/>' +
					'</svg>' +
				'</button>'
			);
		}

		/**
		 * Show / hide Delete on every filter row based on total count:
		 * - 1 row  → no Delete buttons
		 * - 2+ rows → Delete on every row (including the first)
		 * Call this after ADD or Delete so the UI stays in sync.
		 */
		function updateFilterRowDeleteButtons() {
			var $rows = $('#datatrsf-rows-wrap .datatrsf-filter-row');
			var showDelete = $rows.length > 1;

			$rows.each(function () {
				var $row = $(this);
				var rowId = $row.attr('id') || '';
				var $btn = $row.children('.btn-delete');

				if (!showDelete) {
					// Only one row left → remove Delete so it cannot be emptied.
					disposeTooltipsIn($btn);
					$btn.remove();
					return;
				}

				if ($btn.length) {
					// Button already there — keep onclick pointed at this row's id.
					$btn.attr('onclick', "datatrsf_deleteRow('" + rowId + "')");
				} else {
					// Missing button (e.g. first row after ADD) → create it once.
					$row.append(getFilterDeleteButtonHtml(rowId));
				}
			});

			// These buttons are built long after the page-load tooltip pass, and
			// data-bs-toggle="tooltip" does nothing on its own — every element
			// needs its own Tooltip instance, or hover shows the browser's plain
			// grey title instead of the themed one.
			var rowsWrap = document.getElementById('datatrsf-rows-wrap');
			if (rowsWrap && typeof window.initBootstrapTooltips === 'function') {
				window.initBootstrapTooltips(rowsWrap);
			}

			// Rows were added or removed — the new row's labels need measuring.
			refreshFilterTruncationTooltips();
		}

		/**
		 * Enable ADD when under the limit; disable ADD at 5 rows.
		 * Also sets a helpful title so the user knows why it is disabled.
		 */
		function updateFilterAddButtonState() {
			var $addBtn = $('#datatrsf-add-filter-btn');
			if (!$addBtn.length) {
				return;
			}

			var atLimit = getFilterRowCount() >= MAX_FILTER_ROWS;
			$addBtn.prop('disabled', atLimit);
			$addBtn.toggleClass('is-disabled', atLimit);
			$addBtn.attr(
				'title',
				atLimit ? 'A maximum of 5 filters are allowed.' : 'Add filter'
			);
		}

		// Both live in this scope; resetFilterRowsToSingleEmpty needs them too.
		window.datatrsf_refreshRowControls = function () {
			updateFilterAddButtonState();
			updateFilterRowDeleteButtons();
		};

		window.datatrsf_toggleCdd = function (dropdownId, event) {
			if (event && event.stopPropagation) {
				event.stopPropagation();
			}

			var $cdd = $('#' + dropdownId);
			if (!$cdd.length) {
				return;
			}

			var $panel = $cdd.find('.datatrsf-cdd-panel').first();
			var $trigger = $cdd.find('.datatrsf-cdd-trigger').first();
			var willOpen = !$panel.hasClass('open');

			// Close other filter dropdowns first (same idea as designer closeAllCdds).
			$('#data-transfer-setup .data-configuration-sec .datatrsf-cdd-panel').removeClass('open');
			$('#data-transfer-setup .data-configuration-sec .datatrsf-cdd-trigger').removeClass('open');

			if (willOpen) {
				$panel.addClass('open');
				$trigger.addClass('open');

				window.requestAnimationFrame(function () {
					positionDatatrsfCddDropdown($cdd);
				});

				// The list only has a measurable width once the panel is open,
				// so this is where clipped options can pick up their tooltip.
				refreshFilterTruncationTooltips();

				// Filter based on: clear search, show full list, focus search box.
				var $search = $cdd.find('[data-filter-field-search]').first();
				if ($search.length) {
					$search.val('');
					filterFilterBasedOnOptions($cdd, '');
					setTimeout(function () {
						$search.trigger('focus');
					}, 0);
				}
			}
		};

		window.datatrsf_selectItem = function (element, dropdownId) {
			var $cdd = $('#' + dropdownId);
			var $item = $(element);
			if (!$cdd.length || !$item.length) {
				return;
			}

			// Prefer API metadata attributes when present (Filter based on).
			var label = $item.attr('data-label') || $.trim($item.text());
			var value = $item.attr('data-value') || label;

			$cdd.find('.datatrsf-cdd-item').removeClass('datatrsf-selected');
			$item.addClass('datatrsf-selected');
			$cdd.attr('data-selected-value', value);
			$cdd.find('.datatrsf-cdd-val, .datatrsf-cdd-display').first().text(label);
			$cdd.find('.datatrsf-cdd-trigger').addClass('has-value datatrsf-has-value');
			$cdd.find('.datatrsf-cdd-panel').removeClass('open');
			$cdd.find('.datatrsf-cdd-trigger').removeClass('open');

			// Filter based on changed → rebuild Operator options from data_type.
			if ($cdd.attr('data-filter-field-cdd') === 'true') {
				var dataType = $item.attr('data-type') || '';
				$cdd.attr('data-selected-type', dataType);
				syncOperatorDropdownForFilterRow($cdd.closest('.datatrsf-filter-row'), dataType);
				clearFilterColError($cdd.closest('.datatrsf-filter-row'), 'field');
			}

			// Operator changed → show the matching Value input (text or datetime).
			if ($cdd.attr('data-filter-op-cdd') === 'true') {
				var $filterRow = $cdd.closest('.datatrsf-filter-row');
				updateFilterValueField($filterRow, value);
				clearFilterColError($filterRow, 'operator');
			}

			// The label just changed, so what fits and what clips changed too.
			refreshFilterTruncationTooltips();
		};

		window.datatrsf_deleteRow = function (rowId) {
			// Always keep at least one filter row on screen.
			if (getFilterRowCount() <= 1) {
				return;
			}

			var $row = $('#' + rowId);
			if ($row.length) {
				// The Delete button being clicked is inside this row, and its
				// tooltip is open right now — dispose before the row goes.
				disposeTooltipsIn($row);
				$row.remove();
			}

			// After delete: ADD may reopen, and Delete visibility may change.
			updateFilterAddButtonState();
			updateFilterRowDeleteButtons();
		};

		// Clone the first row, reset its fields, then sync Delete buttons for all rows.
		window.datatrsf_addRow = function () {
			var $wrap = $('#datatrsf-rows-wrap');
			var $firstRow = $wrap.find('.datatrsf-filter-row').first();
			if (!$wrap.length || !$firstRow.length) {
				return;
			}

			// Step 1: stop if we already have 5 filter rows.
			if (getFilterRowCount() >= MAX_FILTER_ROWS) {
				updateFilterAddButtonState();
				return;
			}

			// Step 2: next index = highest existing row number + 1 (safe after deletes).
			var maxIndex = 0;
			$wrap.find('.datatrsf-filter-row').each(function () {
				var match = String(this.id || '').match(/datatrsf-row-(\d+)/);
				if (match) {
					maxIndex = Math.max(maxIndex, parseInt(match[1], 10));
				}
			});
			var nextIndex = maxIndex + 1;
			var $clone = $firstRow.clone();
			var newRowId = 'datatrsf-row-' + nextIndex;
			var fieldId = 'datatrsf-field-' + nextIndex;
			var opId = 'datatrsf-op-' + nextIndex;

			$clone.attr('id', newRowId);
			$clone.find('.form-control').val('');

			// Step 3: give the cloned dropdowns unique IDs + onclick handlers.
			rewriteFilterRowDropdownIds($clone, fieldId, opId);

			// Step 4: re-apply the shared field list (no new META.getFields call).
			fillOneFilterFieldDropdown($clone.find('[data-filter-field-cdd="true"]').first(), sourceFieldsUi.fieldsCache || []);

			// Step 5: new row starts with empty Operator options (until a field is chosen).
			clearFilterOperatorDropdown($clone.find('[data-filter-op-cdd="true"]').first());

			// Step 5b: Value column stays reserved; input appears after Operator is selected.
			updateFilterValueField($clone, '');

			// Clear any cloned Test-validation error state from the template row.
			$clone.find('[data-dc-filter]').removeClass('has-error');
			$clone.find('[data-dc-filter-error]').text('').attr('hidden', true).hide();

			// Step 6: strip any cloned Delete button — updateFilterRowDeleteButtons() will
			// add the correct button to every row (including the first) in one place.
			$clone.find('.btn-delete').remove();

			// Step 7: add the new row to the page.
			$wrap.append($clone);

			// Step 8: refresh ADD + Delete UI for the new total count.
			updateFilterAddButtonState();
			updateFilterRowDeleteButtons();
		};

		/**
		 * Date / DateTime Value inputs:
		 *  - type comes from Filter based on data_type (date vs datetime-local)
		 *  - First click opens the picker (showPicker + full-size indicator)
		 *  - Calendar icon is decorative; clicks pass through to the input
		 * Delegated on #datatrsf-rows-wrap so ADD rows work automatically.
		 */
		var $rowsWrap = $('#datatrsf-rows-wrap');
		if ($rowsWrap.length && $rowsWrap.attr('data-filter-value-bound') !== 'true') {
			$rowsWrap.attr('data-filter-value-bound', 'true');

			var dateValueSelector = 'input[data-value-kind="datetime"], input[data-value-kind="date"]';

			$rowsWrap.on('click.dtFilterValue', dateValueSelector, function () {
				openFilterDatetimePicker(this);
			});

			$rowsWrap.on('input.dtFilterValue change.dtFilterValue', dateValueSelector, function () {
				syncFilterDatetimeEmptyState(this);
			});

			$rowsWrap.on('blur.dtFilterValue', dateValueSelector, function () {
				syncFilterDatetimeEmptyState(this);
			});
		}

		/**
		 * Filter based on search — delegated so ADD rows work automatically.
		 * Uses the same live-filter behavior as Setup Connection search.
		 */
		if ($rowsWrap.length && $rowsWrap.attr('data-filter-field-search-bound') !== 'true') {
			$rowsWrap.attr('data-filter-field-search-bound', 'true');

			$rowsWrap.on('input.dtFilterFieldSearch', '[data-filter-field-search]', function (event) {
				event.stopPropagation();
				var $cdd = $(this).closest('.datatrsf-cdd');
				filterFilterBasedOnOptions($cdd, $(this).val());
			});

			$rowsWrap.on('click.dtFilterFieldSearch', '[data-filter-field-search]', function (event) {
				event.stopPropagation();
			});
		}

		// Set the correct ADD / Delete button state when the screen first loads.
		updateFilterAddButtonState();
		updateFilterRowDeleteButtons();

		// Ensure every existing row starts with Value hidden.
		$('#datatrsf-rows-wrap .datatrsf-filter-row').each(function () {
			updateFilterValueField($(this), '');
		});
	}

	/**
	 * After cloning a filter row, rewrite Field + Operator dropdown IDs
	 * so each row has unique toggle/select targets.
	 */
	function rewriteFilterRowDropdownIds($row, fieldId, opId) {
		var $fieldCdd = $row.find('.datatrsf-col-field .datatrsf-cdd').first();
		var $opCdd = $row.find('.datatrsf-col-op .datatrsf-cdd').first();

		if ($fieldCdd.length) {
			$fieldCdd.attr('id', fieldId);
			$fieldCdd.attr('data-filter-field-cdd', 'true');
			$fieldCdd.removeAttr('data-selected-value');
			$fieldCdd.removeAttr('data-selected-type');
			$fieldCdd.find('.datatrsf-cdd-trigger')
				.attr('onclick', "datatrsf_toggleCdd('" + fieldId + "',event)")
				.removeClass('has-value datatrsf-has-value open');
			$fieldCdd.find('.datatrsf-cdd-val').first().text('Select parameter');
			$fieldCdd.find('.datatrsf-cdd-panel').removeClass('open');
			$fieldCdd.find('[data-filter-field-search]').val('');
			filterFilterBasedOnOptions($fieldCdd, '');
		}

		if ($opCdd.length) {
			$opCdd.attr('id', opId);
			$opCdd.attr('data-filter-op-cdd', 'true');
			$opCdd.find('.datatrsf-cdd-trigger')
				.attr('onclick', "datatrsf_toggleCdd('" + opId + "',event)");
			$opCdd.find('.datatrsf-cdd-panel').removeClass('open');
			$opCdd.find('.datatrsf-cdd-trigger').removeClass('open');
			// New / reset row: Operator starts empty until Filter based on is chosen.
			clearFilterOperatorDropdown($opCdd);
		}
	}

	/**
	 * Multi-select: "Which field updates should trigger event export..."
	 *
	 * Flow (beginner-friendly):
	 *  1. Bind open/close/search/select UI once.
	 *  2. Load fields via refreshSourceDataSection() using the Setup Zoho object.
	 *  3. Build dropdown options from field_label + api_name.
	 */
	function initFieldExportMultiSelect() {
		var root = document.getElementById('datatrsf-event-export-lists-lead');
		var trigger = document.getElementById('datatrsf-event-export-trigger-lead');
		var tagsWrap = document.getElementById('datatrsf-event-export-tags-lead');
		var list = document.getElementById('datatrsf-event-export-list-lead');
		var searchInput = document.getElementById('datatrsf-mdd-search-input-lead');

		if (!root || !trigger || !tagsWrap || !list || !searchInput) {
			return;
		}
		if (root.getAttribute('data-dt-ui-bound') === 'true') {
			return;
		}
		root.setAttribute('data-dt-ui-bound', 'true');

		// selected[api_name] = field_label  (api_name is stable for future save payloads)
		// Keep the live object on sourceFieldsUi so SAVE can read it.
		sourceFieldsUi.selected = {};
		var maxSelection = 5;

		function openPanel() {
			root.classList.add('open');
			searchInput.value = '';
			filterItems('');
			window.requestAnimationFrame(function () {
				positionDatatrsfMddDropdown(root, trigger);
				searchInput.focus();
			});
		}

		function closePanel() {
			root.classList.remove('open');
			resetDatatrsfMddDropdown(root);
		}

		function getItemLabel(item) {
			return item.getAttribute('data-label') || item.getAttribute('data-value') || '';
		}

		function renderTags() {
			tagsWrap.innerHTML = '';
			var apiNames = Object.keys(sourceFieldsUi.selected);

			if (!apiNames.length) {
				var placeholder = document.createElement('span');
				placeholder.className = 'datatrsf-mdd-placeholder';
				placeholder.textContent = 'Select fields';
				tagsWrap.appendChild(placeholder);
				return;
			}

			apiNames.forEach(function (apiName) {
				var tag = document.createElement('span');
				tag.className = 'datatrsf-mdd-tag';

				var label = document.createElement('span');
				label.textContent = sourceFieldsUi.selected[apiName] || apiName;
				tag.appendChild(label);

				var remove = document.createElement('span');
				remove.className = 'datatrsf-mdd-tag-remove';
				remove.innerHTML =
					'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
					'<path d="M18 6 6 18M6 6l12 12"></path></svg>';
				remove.addEventListener('click', function (event) {
					event.stopPropagation();
					toggleItemValue(apiName);
				});
				tag.appendChild(remove);
				tagsWrap.appendChild(tag);
			});
		}

		function clearSelection() {
			sourceFieldsUi.selected = {};
			var allItems = list.querySelectorAll('.datatrsf-mdd-item');
			for (var i = 0; i < allItems.length; i++) {
				allItems[i].classList.remove('selected');
			}
			renderTags();
		}

		// So refreshSourceDataSection() can clear picks when the Zoho module changes.
		sourceFieldsUi.clearSelection = clearSelection;
		sourceFieldsUi.renderTags = renderTags;
		sourceFieldsUi.listElement = list;

		function toggleItemValue(apiName) {
			var item = null;
			var allItems = list.querySelectorAll('.datatrsf-mdd-item');
			for (var i = 0; i < allItems.length; i++) {
				if (allItems[i].getAttribute('data-value') === apiName) {
					item = allItems[i];
					break;
				}
			}
			if (!item) {
				return;
			}

			if (sourceFieldsUi.selected[apiName]) {
				delete sourceFieldsUi.selected[apiName];
				item.classList.remove('selected');
			} else {
				if (Object.keys(sourceFieldsUi.selected).length >= maxSelection) {
					return;
				}
				sourceFieldsUi.selected[apiName] = getItemLabel(item);
				item.classList.add('selected');
			}
			renderTags();
			if (Object.keys(sourceFieldsUi.selected).length) {
				clearDataConfigFieldError('sourceFields');
			}
		}

		function filterItems(query) {
			var normalized = String(query || '').trim().toLowerCase();
			var visibleCount = 0;
			var allItems = list.querySelectorAll('.datatrsf-mdd-item');

			for (var i = 0; i < allItems.length; i++) {
				var item = allItems[i];
				var value = String(item.getAttribute('data-value') || '').toLowerCase();
				var label = String(item.getAttribute('data-label') || '').toLowerCase();
				var match = !normalized || value.indexOf(normalized) !== -1 || label.indexOf(normalized) !== -1;
				item.style.display = match ? 'flex' : 'none';
				if (match) {
					visibleCount += 1;
				}
			}

			var emptyState = list.querySelector('.datatrsf-mdd-empty');
			if (visibleCount === 0 && allItems.length) {
				if (!emptyState) {
					emptyState = document.createElement('div');
					emptyState.className = 'datatrsf-mdd-empty';
					emptyState.textContent = 'No matches found';
					list.appendChild(emptyState);
				} else {
					emptyState.textContent = 'No matches found';
				}
			} else if (emptyState && allItems.length) {
				emptyState.parentNode.removeChild(emptyState);
			}
		}

		trigger.addEventListener('click', function (event) {
			event.stopPropagation();
			if (root.classList.contains('open')) {
				closePanel();
			} else {
				openPanel();
			}
		});

		// Delegated click — works for options added later from the API.
		list.addEventListener('click', function (event) {
			var item = event.target.closest
				? event.target.closest('.datatrsf-mdd-item')
				: null;
			if (!item || !list.contains(item)) {
				return;
			}
			toggleItemValue(item.getAttribute('data-value'));
		});

		searchInput.addEventListener('input', function (event) {
			filterItems(event.target.value);
		});
		searchInput.addEventListener('click', function (event) {
			event.stopPropagation();
		});

		document.addEventListener('click', function (event) {
			if (!root.contains(event.target)) {
				closePanel();
			}
		});

		renderTags();

		// Load fields for whatever Zoho object is already selected in Setup (if any).
		refreshSourceDataSection();
	}

	/** Tracks Contacts list multi-selects — add list is loaded from netcore0__get_all_audience. */
	var contactsListUi = {
		addLists: { selected: {}, loadingConnectionId: null },
		removeLists: { selected: {} }
	};

	/** Checkbox tick markup — same as Source data field multi-select items. */
	var MDD_ITEM_CHECKBOX_HTML =
		'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="4">' +
		'<path d="M20 6 9 17l-5-5"></path></svg>';

	/** Ensure each .datatrsf-mdd-item has a checkmark SVG inside .datatrsf-mdd-chk. */
	function ensureMddItemCheckboxMarkup(listElement) {
		if (!listElement) {
			return;
		}

		var items = listElement.querySelectorAll('.datatrsf-mdd-item');
		for (var i = 0; i < items.length; i++) {
			var chk = items[i].querySelector('.datatrsf-mdd-chk');
			if (chk && !chk.querySelector('svg')) {
				chk.innerHTML = MDD_ITEM_CHECKBOX_HTML;
			}
		}
	}

	/**
	 * Sync selected + max-limit styling on every list row.
	 * Matches Source data multi-select: .selected shows blue checkbox + tick;
	 * unselected rows get .is-limit-reached when the cap is hit.
	 */
	function syncMddListItemStates(listElement, selectedStore, maxSelection, options) {
		options = options || {};
		if (!listElement || !selectedStore) {
			return;
		}

		var markLimitReached = options.markLimitReached !== false;
		var selectedMap = selectedStore.selected || {};
		var selectedCount = Object.keys(selectedMap).length;
		var atLimit = selectedCount >= maxSelection;
		var allItems = listElement.querySelectorAll('.datatrsf-mdd-item');

		for (var i = 0; i < allItems.length; i++) {
			var item = allItems[i];
			var value = item.getAttribute('data-value');
			var isSelected = !!(value && selectedMap[value]);

			item.classList.toggle('selected', isSelected);
			if (markLimitReached) {
				item.classList.toggle('is-limit-reached', atLimit && !isSelected);
			}
		}
	}

	/**
	 * Bind open/close/search/select for a static Contacts list multi-select (.datatrsf-mdd).
	 * Same interaction pattern as initFieldExportMultiSelect().
	 */
	function initStaticContactsListMultiSelect(config) {
		config = config || {};
		var root = document.getElementById(config.rootId);
		var trigger = document.getElementById(config.triggerId);
		var tagsWrap = document.getElementById(config.tagsId);
		var list = document.getElementById(config.listId);
		var searchInput = document.getElementById(config.searchInputId);
		var selectedStore = config.selectedStore || { selected: {} };
		var placeholderText = config.placeholderText || 'Select list(s)';
		var maxSelection = config.maxSelection || 5;
		var markLimitReached = config.markLimitReached !== false;

		if (!root || !trigger || !tagsWrap || !list || !searchInput) {
			return;
		}
		if (root.getAttribute('data-dt-ui-bound') === 'true') {
			return;
		}
		root.setAttribute('data-dt-ui-bound', 'true');

		selectedStore.selected = selectedStore.selected || {};
		ensureMddItemCheckboxMarkup(list);

		function syncItemStates() {
			syncMddListItemStates(list, selectedStore, maxSelection, {
				markLimitReached: markLimitReached
			});
		}

		function openPanel() {
			root.classList.add('open');
			trigger.classList.add('datatrsf-open');
			searchInput.value = '';
			filterItems('');
			syncItemStates();
			window.requestAnimationFrame(function () {
				positionDatatrsfMddDropdown(root, trigger);
				searchInput.focus();
			});
		}

		function closePanel() {
			root.classList.remove('open');
			trigger.classList.remove('datatrsf-open');
			resetDatatrsfMddDropdown(root);
		}

		function getItemLabel(item) {
			return item.getAttribute('data-label') || item.getAttribute('data-value') || '';
		}

		/** One selected list pill (label + remove "x"). */
		function createListTag(value) {
			var tag = document.createElement('span');
			tag.className = 'datatrsf-mdd-tag';

			var label = document.createElement('span');
			label.textContent = selectedStore.selected[value] || value;
			tag.appendChild(label);

			var remove = document.createElement('span');
			remove.className = 'datatrsf-mdd-tag-remove';
			remove.innerHTML =
				'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
				'<path d="M18 6 6 18M6 6l12 12"></path></svg>';
			remove.addEventListener('click', function (event) {
				event.stopPropagation();
				toggleItemValue(value);
			});
			tag.appendChild(remove);

			return tag;
		}

		// One row of pills; the rest become a right-aligned (+N) that lists them
		// on hover — same behaviour as Custom parameters.
		function renderTags() {
			hideCustomParamsMoreTooltip();
			tagsWrap.innerHTML = '';

			var values = Object.keys(selectedStore.selected);

			if (!values.length) {
				var placeholder = document.createElement('span');
				placeholder.className = 'datatrsf-mdd-placeholder';
				placeholder.textContent = placeholderText;
				tagsWrap.appendChild(placeholder);
				return;
			}

			var pillsWrap = document.createElement('div');
			pillsWrap.className = 'datatrsf-mdd-tag-pills';
			tagsWrap.appendChild(pillsWrap);

			var containerWidth = tagsWrap.clientWidth;

			// Field still hidden → nothing can be measured. Paint them all and
			// measure once on the next frame.
			if (containerWidth < 20) {
				values.forEach(function (value) {
					pillsWrap.appendChild(createListTag(value));
				});
				if (tagsWrap.getAttribute('data-tags-measuring') !== 'true') {
					tagsWrap.setAttribute('data-tags-measuring', 'true');
					window.requestAnimationFrame(function () {
						tagsWrap.removeAttribute('data-tags-measuring');
						renderTags();
					});
				}
				return;
			}

			var gap = 6;

			// Measure inside the real container so the CSS applies.
			var widths = [];
			values.forEach(function (value) {
				var probe = createListTag(value);
				probe.style.visibility = 'hidden';
				pillsWrap.appendChild(probe);
				widths.push(probe.offsetWidth);
				pillsWrap.removeChild(probe);
			});

			// Room a worst-case (+N) would need on the right.
			var moreProbe = document.createElement('span');
			moreProbe.className = 'dd-tags-more';
			moreProbe.textContent = '(+' + values.length + ')';
			moreProbe.style.visibility = 'hidden';
			tagsWrap.appendChild(moreProbe);
			var moreReserve = moreProbe.offsetWidth + gap;
			tagsWrap.removeChild(moreProbe);

			var totalWidth = 0;
			widths.forEach(function (width, index) {
				totalWidth += width + (index ? gap : 0);
			});

			var visibleCount = values.length;

			if (totalWidth > containerWidth) {
				var used = 0;
				visibleCount = 0;
				for (var i = 0; i < widths.length; i += 1) {
					var next = used + (visibleCount ? gap : 0) + widths[i];
					// Always keep one pill so the field never looks empty.
					if (next <= containerWidth - moreReserve || visibleCount === 0) {
						used = next;
						visibleCount += 1;
					} else {
						break;
					}
				}
			}

			pillsWrap.innerHTML = '';
			for (var shown = 0; shown < visibleCount; shown += 1) {
				pillsWrap.appendChild(createListTag(values[shown]));
			}

			if (visibleCount >= values.length) {
				return;
			}

			var overflowLabels = values.slice(visibleCount).map(function (value) {
				return selectedStore.selected[value] || value;
			});
			var tooltipText = overflowLabels.join(', ');

			var more = document.createElement('span');
			more.className = 'dd-tags-more';
			more.textContent = '(+' + overflowLabels.length + ')';
			more.setAttribute('tabindex', '0');
			more.setAttribute('aria-label', tooltipText);

			more.addEventListener('mouseenter', function () {
				showCustomParamsMoreTooltip(more, tooltipText);
			});
			more.addEventListener('mouseleave', function () {
				scheduleCustomParamsMoreTooltipHide();
			});
			more.addEventListener('focus', function () {
				showCustomParamsMoreTooltip(more, tooltipText);
			});
			more.addEventListener('blur', function () {
				scheduleCustomParamsMoreTooltipHide();
			});
			// (+N) must not open or close the dropdown.
			more.addEventListener('click', function (event) {
				event.stopPropagation();
			});

			tagsWrap.appendChild(more);
		}

		function toggleItemValue(value) {
			var item = null;
			var allItems = list.querySelectorAll('.datatrsf-mdd-item');
			for (var i = 0; i < allItems.length; i++) {
				if (allItems[i].getAttribute('data-value') === value) {
					item = allItems[i];
					break;
				}
			}
			if (!item) {
				return;
			}

			if (selectedStore.selected[value]) {
				delete selectedStore.selected[value];
			} else {
				if (item.classList.contains('is-limit-reached')) {
					return;
				}
				if (Object.keys(selectedStore.selected).length >= maxSelection) {
					return;
				}
				selectedStore.selected[value] = getItemLabel(item);
			}

			renderTags();
			syncItemStates();

			// A pick clears the NEXT error sitting under that list.
			try {
				if (contactsListUi && selectedStore === contactsListUi.addLists) {
					clearDataConfigFieldError('addToList');
				} else if (contactsListUi && selectedStore === contactsListUi.removeLists) {
					clearDataConfigFieldError('removeFromList');
				}
			} catch (listErrorClearError) {
				console.error('List error clear failed:', listErrorClearError);
			}
		}

		function filterItems(query) {
			var normalized = String(query || '').trim().toLowerCase();
			var visibleCount = 0;
			var allItems = list.querySelectorAll('.datatrsf-mdd-item');

			for (var i = 0; i < allItems.length; i++) {
				var item = allItems[i];
				var itemValue = String(item.getAttribute('data-value') || '').toLowerCase();
				var itemLabel = String(item.getAttribute('data-label') || '').toLowerCase();
				var match = !normalized
					|| itemValue.indexOf(normalized) !== -1
					|| itemLabel.indexOf(normalized) !== -1;
				item.style.display = match ? 'flex' : 'none';
				if (match) {
					visibleCount += 1;
				}
			}

			syncItemStates();

			var emptyState = list.querySelector('.datatrsf-mdd-empty');
			if (visibleCount === 0 && allItems.length) {
				if (!emptyState) {
					emptyState = document.createElement('div');
					emptyState.className = 'datatrsf-mdd-empty';
					emptyState.textContent = 'No matches found';
					list.appendChild(emptyState);
				} else {
					emptyState.textContent = 'No matches found';
				}
			} else if (emptyState && allItems.length) {
				emptyState.parentNode.removeChild(emptyState);
			}
		}

		trigger.addEventListener('click', function (event) {
			event.stopPropagation();
			if (root.classList.contains('open')) {
				closePanel();
			} else {
				openPanel();
			}
		});

		list.addEventListener('click', function (event) {
			var item = event.target.closest
				? event.target.closest('.datatrsf-mdd-item')
				: null;
			if (!item || !list.contains(item)) {
				return;
			}
			if (item.classList.contains('is-limit-reached')) {
				return;
			}
			toggleItemValue(item.getAttribute('data-value'));
		});

		searchInput.addEventListener('input', function (event) {
			filterItems(event.target.value);
		});
		searchInput.addEventListener('click', function (event) {
			event.stopPropagation();
		});

		document.addEventListener('click', function (event) {
			if (!root.contains(event.target)) {
				closePanel();
			}
		});

		renderTags();
		syncItemStates();

		selectedStore.listElement = list;
		selectedStore.renderTags = renderTags;
		selectedStore.syncItemStates = syncItemStates;
	}

	/** Wire Contacts "add to list" and "remove from list" multi-select dropdowns. */
	function initContactsListMultiSelects() {
		initStaticContactsListMultiSelect({
			rootId: 'datatrsf-mdd-lists',
			triggerId: 'datatrsf-mdd-trigger',
			tagsId: 'datatrsf-mdd-tags',
			listId: 'datatrsf-mdd-list',
			searchInputId: 'datatrsf-mdd-search-input',
			selectedStore: contactsListUi.addLists,
			placeholderText: 'Select list(s)',
			maxSelection: 5,
			markLimitReached: true
		});

		initStaticContactsListMultiSelect({
			rootId: 'datatrsf-mdd-remove-lists',
			triggerId: 'datatrsf-mdd-remove-trigger',
			tagsId: 'datatrsf-mdd-remove-tags',
			listId: 'datatrsf-mdd-remove-list',
			searchInputId: 'datatrsf-mdd-remove-search-input',
			selectedStore: contactsListUi.removeLists,
			placeholderText: 'Select list(s)',
			maxSelection: 5,
			markLimitReached: true
		});
	}

	/**
	 * Shared helpers for Source data heading + META.getFields.
	 * Kept outside the multi-select so Setup dropdown changes can call them too.
	 */
	var sourceFieldsUi = {
		clearSelection: null,
		listElement: null,
		loadedModule: null,
		// Shared field list from one META.getFields call — used by Source data + all Filter rows.
		fieldsCache: [],
		// selected[api_name] = field_label — used by SAVE for netcore0__Source_Fields
		selected: {}
	};

	/** CRM module API name from Setup, e.g. "Leads", "Deals", "Tasks". */
	function getSelectedZohoObjectValue() {
		return $.trim(getSetupFormRoot().find('[name="sourceObject"]').val() || '');
	}

	/**
	 * Text shown in "Source data (...)".
	 * Uses the Setup dropdown value (Leads, Deals, Tasks, …) — same as META Entity.
	 */
	function getSelectedZohoObjectDisplayName() {
		return getSelectedZohoObjectValue();
	}

	function updateSourceDataHeading(displayName) {
		var $label = $('#dt-source-object-name');
		if (!$label.length) {
			return;
		}
		$label.text(displayName || '—');
	}

	/** Accounts asks about the event; every other Zoho object keeps the generic wording. */
	function updateEventSelectLabel(zohoObjectValue) {
		try {
			var $eventSelectText = $('[data-dc-event-select-text]').first();
			if (!$eventSelectText.length) {
				return;
			}

			$eventSelectText.text(
				$.trim(zohoObjectValue || '') === ACCOUNTS_SOURCE_OBJECT
					? EVENT_SELECT_LABEL_ACCOUNTS
					: EVENT_SELECT_LABEL_DEFAULT
			);
		} catch (eventSelectLabelError) {
			console.error('Setup: event select label update failed:', eventSelectLabelError);
		}
	}

	/**
	 * Text shown in "Destination data (...)".
	 * Bound to Setup → "How would you like to import this object into Netcore CE?"
	 * (targetObject): currently Event and/or Contacts depending on Zoho object.
	 */
	function getSelectedImportTargetDisplayName() {
		return $.trim(
			getSelectedDropdownLabel(SETUP_FIELDS.targetObject)
			|| getSetupFormRoot().find('[name="targetObject"]').val()
			|| ''
		);
	}

	function updateDestinationDataHeading(displayName) {
		var $label = $('#dt-destination-object-name');
		if (!$label.length) {
			return;
		}
		var name = displayName != null
			? $.trim(String(displayName))
			: getSelectedImportTargetDisplayName();
		$label.text(name || '—');
	}

	/** Setup → targetObject stored value (Event / Contacts). */
	function getSelectedImportTargetValue() {
		return $.trim(getSetupFormRoot().find('[name="targetObject"]').val() || '');
	}

	function isContactsImportTargetSelected() {
		return getSelectedImportTargetValue() === NETCORE_IMPORT_CONTACTS.value;
	}

	/**
	 * Source data → "Which field updates should trigger event export…"
	 * Event only; hidden for Contacts (selection preserved, validation skipped elsewhere).
	 */
	function updateEventExportSourceFieldsVisibility() {
		var $field = $('#dt-event-export-source-fields-field');
		if (!$field.length) {
			return;
		}

		var showEventField = !isContactsImportTargetSelected();
		if (showEventField) {
			$field.removeAttr('hidden').show();
		} else {
			$field.attr('hidden', 'hidden').hide();
			clearDataConfigFieldError('sourceFields');
		}
	}

	/**
	 * Data Configuration right column: Event destination vs Contacts destination.
	 * Driven by Setup → "How would you like to import this object into Netcore CE?"
	 */
	function updateDataConfigurationDestinationPanel() {
		var $eventPanel = $('#dt-data-config-dest-event');
		var $contactsPanel = $('#dt-data-config-dest-contacts');
		if (!$eventPanel.length && !$contactsPanel.length) {
			updateEventExportSourceFieldsVisibility();
			return;
		}

		var showContacts = isContactsImportTargetSelected();
		if ($eventPanel.length) {
			$eventPanel.toggle(!showContacts);
		}
		if ($contactsPanel.length) {
			if (showContacts) {
				$contactsPanel.removeAttr('hidden').show();
				updateContactsDestinationFieldsVisibility();
			} else {
				$contactsPanel.attr('hidden', 'hidden').hide();
			}
		}

		updateContactsSecondaryIdentityVisibility();
		updateEventExportSourceFieldsVisibility();
	}

	/** Contacts destination panel root (Data Configuration → Destination data Contacts). */
	function getContactsDestinationPanel() {
		return $('#dt-data-config-dest-contacts');
	}

	/** Selected value for "What do you want to do with these contacts?" (add / remove). */
	function getContactsDestActionValue() {
		var value = getContactsDestinationPanel()
			.find('input[name="datatrsf-dest-action"]:checked')
			.val();
		return $.trim(String(value || 'add'));
	}

	/** Selected value for "Where would you like to remove the contacts from?" (list / contactmaster). */
	function getContactsRemoveFromValue() {
		var value = getContactsDestinationPanel()
			.find('input[name="datatrsf-dest-remove-from"]:checked')
			.val();
		return $.trim(String(value || ''));
	}

	/** Keep Contacts destination radio labels in sync with checked state. */
	function syncContactsDestRadioStyles() {
		getContactsDestinationPanel().find('.datatrsf-radio-group input[type="radio"]').each(function () {
			var $label = $(this).closest('.datatrsf-radio-label');
			if (this.checked) {
				$label.removeClass('datatrsf-inactive');
			} else {
				$label.addClass('datatrsf-inactive');
			}
		});
	}

	/**
	 * Show/hide Contacts destination fields based on Add vs Remove and sub-selections.
	 *
	 * Add (default):
	 *   - "Add to list(s)" visible; list picker visible only when checkbox is checked.
	 *   - Remove-from fields hidden.
	 *
	 * Remove:
	 *   - "Add to list(s)" + add list picker hidden.
	 *   - "Where would you like to remove..." visible.
	 *   - Remove list picker visible only when "List" is selected.
	 */
	function updateContactsDestinationFieldsVisibility() {
		var $panel = getContactsDestinationPanel();
		if (!$panel.length) {
			return;
		}

		syncContactsDestRadioStyles();

		var isRemove = getContactsDestActionValue() === 'remove';
		var isRemoveFromList = getContactsRemoveFromValue() === 'list';
		var addToListChecked = $panel.find('#addToListToggle').is(':checked');

		var $removeFromGroup = $panel.find('#dt-contacts-remove-from-group');
		var $removeListField = $panel.find('#dt-contacts-remove-list-field');
		var $removeMasterInfo = $panel.find('#dt-contacts-remove-master-info');
		var $addInfo = $panel.find('#dt-contacts-add-info');
		var $addListBlock = $panel.find('#dt-contacts-add-list-block');
		var $addListField = $panel.find('#dt-contacts-add-list-field');

		if (isRemove) {
			$removeFromGroup.removeAttr('hidden').show();
			if (isRemoveFromList) {
				$removeListField.removeAttr('hidden').show();
				// Pills can only be measured once the field is on screen.
				if (typeof contactsListUi.removeLists.renderTags === 'function') {
					contactsListUi.removeLists.renderTags();
				}
			} else {
				$removeListField.attr('hidden', 'hidden').hide();
			}

			// Contact master takes the lists with it; the List route does not.
			$removeMasterInfo.toggle(getContactsRemoveFromValue() === 'contactmaster');

			$addInfo.hide();
			$addListBlock.hide();
			$addListField.attr('hidden', 'hidden').hide();
			updateContactsFieldMappingTableVisibility();
			return;
		}

		// Add mode (default).
		$removeFromGroup.attr('hidden', 'hidden').hide();
		$removeListField.attr('hidden', 'hidden').hide();
		$removeMasterInfo.hide();
		$addInfo.show();
		$addListBlock.show();

		if (addToListChecked) {
			$addListField.removeAttr('hidden').show();
			// Pills can only be measured once the field is on screen.
			if (typeof contactsListUi.addLists.renderTags === 'function') {
				contactsListUi.addLists.renderTags();
			}
		} else {
			$addListField.attr('hidden', 'hidden').hide();
		}

		updateContactsFieldMappingTableVisibility();
	}

	/**
	 * Contacts → Field mapping: hide Source/Destination mapping table when action is Remove.
	 * Visibility only — does not clear mapping row DOM or saved state.
	 */
	function updateContactsFieldMappingTableVisibility() {
		var $card = $('#data-transfer-setup .field-mapping-sec .mapping-table-card');
		if (!$card.length) {
			return;
		}

		if (!isContactsImportTargetSelected()) {
			$card.show();
			return;
		}

		var showTable = isContactsFieldMappingTableRequired();
		if (showTable) {
			$card.show();
			$('#mappingRows .mapping-row').each(function () {
				refreshMappingRowTypeMismatch($(this));
			});
			return;
		}

		$card.hide();
		toggleFieldMappingErrorAlert(false);
		$('#mappingRows .mapping-row').each(function () {
			var $row = $(this);
			clearMappingRowColError($row, 'sourceField');
			clearMappingRowColError($row, 'destAttribute');
			refreshMappingRowTypeMismatch($row);
		});
	}

	/**
	 * Add ↔ Remove switch: mapping picks live only in the row DOM, so they are
	 * dropped here — otherwise the previous action's pairs would still reach the
	 * Test popup, the RUN TEST payload and SAVE.
	 */
	function resetContactsFieldMappingRows() {
		if (!isContactsImportTargetSelected()) {
			return;
		}

		resetMappingRowsToDefault();
		toggleFieldMappingErrorAlert(false);
		$('#mappingRows .mapping-row').each(function () {
			var $row = $(this);
			clearMappingRowColError($row, 'sourceField');
			clearMappingRowColError($row, 'destAttribute');
			refreshMappingRowTypeMismatch($row);
		});
	}

	/** Contacts + main Destination identifier CUST_ID → secondary identity row is required. */
	function isContactsSecondaryIdentityRequired() {
		return isContactsImportTargetSelected()
			&& $.trim(String(sfIdentifierUi.selectedValue || '')).toUpperCase() === 'CUST_ID';
	}

	/** Contacts SAVE → netcore0__Second_SourceIdentifier (empty when not CUST_ID). */
	function getContactsSecondarySourceIdentifierForSave() {
		if (!isContactsSecondaryIdentityRequired()) {
			return '';
		}
		return $.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceValue) || '');
	}

	/** Contacts SAVE → netcore0__Second_DestinaitonIdentifier (empty when not CUST_ID). */
	function getContactsSecondaryDestinationIdentifierForSave() {
		if (!isContactsSecondaryIdentityRequired()) {
			return '';
		}
		return $.trim(
			(contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.destValue) || CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE
		);
	}

	function renderSecondarySourceIdentifierDisplay() {
		var label = '';
		if ($.trim(contactsSecondaryIdentityUi.sourceValue || '')) {
			label = contactsSecondaryIdentityUi.sourceLabel
				|| (zohoIdentifierUi.labels && zohoIdentifierUi.labels[contactsSecondaryIdentityUi.sourceValue])
				|| contactsSecondaryIdentityUi.sourceValue;
		}

		['#secondarySourceIdentifierValue', '#secondary-source-identifier-dropdown .dd-value'].forEach(function (selector) {
			var valueEl = document.querySelector(selector);
			if (!valueEl) {
				return;
			}
			if (!label) {
				valueEl.textContent = 'for ex: Email';
				valueEl.classList.add('is-placeholder');
				return;
			}
			valueEl.textContent = label;
			valueEl.classList.remove('is-placeholder');
		});
	}

	function syncSecondarySourceIdentifierListSelection(apiName) {
		var list = document.getElementById('secondarySourceIdentifierList');
		if (!list) {
			return;
		}

		Array.prototype.forEach.call(list.querySelectorAll('.dd-simple-item'), function (el) {
			if (el.getAttribute('data-value') === apiName) {
				el.classList.add('selected');
			} else {
				el.classList.remove('selected');
			}
		});
	}

	function selectSecondarySourceIdentifierValue(apiName, fieldLabel) {
		var label = fieldLabel
			|| (zohoIdentifierUi.labels && zohoIdentifierUi.labels[apiName])
			|| apiName;

		contactsSecondaryIdentityUi.sourceValue = apiName || '';
		contactsSecondaryIdentityUi.sourceLabel = label || '';

		syncSecondarySourceIdentifierListSelection(apiName);

		var valueEl = document.getElementById('secondarySourceIdentifierValue');
		if (valueEl) {
			if (!$.trim(apiName || '')) {
				valueEl.textContent = 'for ex: Email';
				valueEl.classList.add('is-placeholder');
			} else {
				valueEl.textContent = label;
				valueEl.classList.remove('is-placeholder');
			}
		}

		var $ddValue = $('#secondary-source-identifier-dropdown .dd-value').first();
		if ($ddValue.length) {
			if (!$.trim(apiName || '')) {
				$ddValue.text('for ex: Email').addClass('is-placeholder');
			} else {
				$ddValue.text(label).removeClass('is-placeholder');
			}
		}

		if ($.trim(contactsSecondaryIdentityUi.sourceValue || '')) {
			clearDataConfigFieldError('secondarySourceIdentifier');
		}
	}

	function ensureSecondaryDestinationIdentifierSelected() {
		contactsSecondaryIdentityUi.destValue = CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE;
		contactsSecondaryIdentityUi.destLabel = CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE;

		var list = document.getElementById('secondaryDestinationIdentifierList');
		if (list) {
			Array.prototype.forEach.call(list.querySelectorAll('.dd-simple-item'), function (item) {
				var itemValue = $.trim(item.getAttribute('data-value') || '');
				if (itemValue === CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE) {
					item.classList.add('selected');
				} else {
					item.classList.remove('selected');
				}
			});
		}

		$('#secondaryDestinationIdentifierValue')
			.text(CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE)
			.removeClass('is-placeholder');
		$('#secondary-destination-identifier-dropdown .dd-value')
			.first()
			.text(CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE)
			.removeClass('is-placeholder');

		clearDataConfigFieldError('secondaryDestinationIdentifier');
	}

	/**
	 * Rebuild Contacts secondary Source identifier options from sourceFieldsUi.fieldsCache.
	 * Independent selection from the main Source identifier.
	 */
	function refreshSecondarySourceIdentifierDropdown(options) {
		options = options || {};
		var list = document.getElementById('secondarySourceIdentifierList');
		if (!list) {
			return;
		}

		var pendingValue = $.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceValue) || '');
		var pendingLabel = $.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceLabel) || '');
		var fields = sourceFieldsUi.fieldsCache || [];

		populateIdentifierDropdownList(list, fields, options);

		if (pendingValue) {
			selectSecondarySourceIdentifierValue(
				pendingValue,
				pendingLabel || (zohoIdentifierUi.labels && zohoIdentifierUi.labels[pendingValue]) || pendingValue
			);
			return;
		}

		renderSecondarySourceIdentifierDisplay();
	}

	/**
	 * Contacts → Field mapping: show/hide secondary identity row when Destination identifier is CUST_ID.
	 * Visibility only for secondary Source selection — values stay in state when hidden.
	 */
	function updateContactsSecondaryIdentityVisibility() {
		var $row = $('#dt-contacts-secondary-identity-row');
		if (!$row.length) {
			return;
		}

		if (!isContactsSecondaryIdentityRequired()) {
			$row.attr('hidden', 'hidden').hide();
			clearDataConfigFieldError('secondarySourceIdentifier');
			clearDataConfigFieldError('secondaryDestinationIdentifier');
			return;
		}

		$row.removeAttr('hidden').show();
		ensureSecondaryDestinationIdentifierSelected();
		refreshSecondarySourceIdentifierDropdown({ preserveSelection: true });
	}

	function resetContactsSecondaryIdentity() {
		contactsSecondaryIdentityUi.sourceValue = '';
		contactsSecondaryIdentityUi.sourceLabel = '';
		contactsSecondaryIdentityUi.destValue = CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE;
		contactsSecondaryIdentityUi.destLabel = CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE;
		renderSecondarySourceIdentifierDisplay();
		ensureSecondaryDestinationIdentifierSelected();
		updateContactsSecondaryIdentityVisibility();
	}

	/** Clear one Contacts list multi-select: stored picks, pills and dropdown ticks. */
	function clearContactsListSelection(selectedStore) {
		if (!selectedStore) {
			return;
		}

		selectedStore.selected = {};
		if (typeof selectedStore.renderTags === 'function') {
			selectedStore.renderTags();
		}
		if (typeof selectedStore.syncItemStates === 'function') {
			selectedStore.syncItemStates();
		}
	}

	/** Add ↔ Remove switch starts both list pickers, the toggle and the remove-from radios fresh. */
	function resetContactsListSelections() {
		var $panel = getContactsDestinationPanel();

		clearContactsListSelection(contactsListUi && contactsListUi.addLists);
		clearContactsListSelection(contactsListUi && contactsListUi.removeLists);
		$panel.find('input[name="datatrsf-dest-remove-from"]').prop('checked', false);
		$panel.find('#addToListToggle').prop('checked', false);
	}

	/** Default Destination data (Contacts) UI when starting a fresh editor session. */
	function resetContactsDestinationFields() {
		var $panel = getContactsDestinationPanel();
		if (!$panel.length) {
			return;
		}

		$panel.find('input[name="datatrsf-dest-action"]').prop('checked', false);
		$panel.find('input[name="datatrsf-dest-action"][value="add"]').prop('checked', true);
		$panel.find('input[name="datatrsf-dest-remove-from"]').prop('checked', false);
		$panel.find('#addToListToggle').prop('checked', false);

		clearContactsListSelection(contactsListUi && contactsListUi.addLists);
		clearContactsListSelection(contactsListUi && contactsListUi.removeLists);

		updateContactsDestinationFieldsVisibility();
	}

	/**
	 * A Setup choice changed, so both later steps start over: Data configuration
	 * back to Filters-off with one empty row and Destination defaults, and Field
	 * mapping back to empty identifiers with a single blank row.
	 * Screen only — CRM keeps its data until the user saves.
	 */
	function resetStepsAfterSetup() {
		try {
			// ----- Data configuration -----
			setFiltersToggleState(false);
			resetFilterRowsToSingleEmpty();
			resetContactsDestinationFields();

			// ----- Field mapping: Identity mapping -----
			zohoIdentifierUi.selectedValue = '';
			zohoIdentifierUi.selectedLabel = '';
			syncZohoIdentifierListSelection('');
			renderZohoIdentifierDisplay();

			sfIdentifierUi.selectedValue = '';
			syncNetcoreCeIdentifierListSelection('');
			renderNetcoreCeIdentifierDisplay('');

			resetContactsSecondaryIdentity();

			// ----- Field mapping: mapping rows -----
			resetMappingRowsToDefault();
		} catch (setupChangeResetError) {
			console.error('Step reset after Setup change failed:', setupChangeResetError);
		}
	}

	/**
	 * Keep field pieces we need across Source / Filter / Test panel.
	 * Also keep pick-list options + lookup module for typed Test value controls.
	 */
	function normalizeModuleFields(fields) {
		var out = [];
		(fields || []).forEach(function (field) {
			if (!field || !field.api_name) {
				return;
			}

			var pickOptions = [];
			(field.pick_list_values || []).forEach(function (item) {
				if (typeof item === 'string' && item) {
					pickOptions.push(item);
					return;
				}
				if (!item) {
					return;
				}
				var display = item.display_value || item.actual_value || '';
				if (display) {
					pickOptions.push(String(display));
				}
			});

			var lookupModule = '';
			if (field.lookup && field.lookup.module) {
				if (typeof field.lookup.module === 'string') {
					lookupModule = field.lookup.module;
				} else {
					lookupModule = field.lookup.module.api_name || '';
				}
			}
			// Polymorphic lookups (e.g. What_Id / Related To) may not expose a
			// single usable module in META — resolve known fields below at search time.

			out.push({
				api_name: String(field.api_name),
				field_label: String(field.field_label || field.api_name),
				data_type: String(field.data_type || ''),
				pick_list_values: pickOptions,
				lookup_module: String(lookupModule || '')
			});
		});
		return out;
	}

	/**
	 * Fill ONE "Filter based on" dropdown from the shared cache.
	 * Does NOT call the Metadata API.
	 */
	function fillOneFilterFieldDropdown($cdd, fields, options) {
		options = options || {};
		if (!$cdd || !$cdd.length) {
			return;
		}

		var dropdownId = $cdd.attr('id') || '';
		var $list = $cdd.find('.datatrsf-cdd-list').first();
		if (!$list.length) {
			return;
		}

		$list.empty();

		if (options.message) {
			$list.append(
				$('<div class="datatrsf-cdd-item datatrsf-cdd-empty"></div>').text(options.message)
			);
		} else if (!fields || !fields.length) {
			$list.append(
				$('<div class="datatrsf-cdd-item datatrsf-cdd-empty"></div>').text('No fields available')
			);
		} else {
			fields.forEach(function (field) {
				var $item = $('<div class="datatrsf-cdd-item"></div>');
				$item.attr('data-value', field.api_name);
				$item.attr('data-label', field.field_label);
				$item.attr('data-type', field.data_type || '');
				$item.attr('onclick', "datatrsf_selectItem(this,'" + dropdownId + "')");
				$item.text(field.field_label);
				$list.append($item);
			});
		}

		// Reset selection whenever we rebuild the list (module change / new row).
		$cdd.removeAttr('data-selected-value');
		$cdd.removeAttr('data-selected-type');
		$cdd.find('.datatrsf-cdd-item').removeClass('datatrsf-selected');
		$cdd.find('.datatrsf-cdd-val').first().text(options.placeholder || 'Select parameter');
		$cdd.find('.datatrsf-cdd-trigger').removeClass('has-value datatrsf-has-value open');
		$cdd.find('.datatrsf-cdd-panel').removeClass('open');
		$cdd.find('[data-filter-field-search]').val('');
		filterFilterBasedOnOptions($cdd, '');
	}

	/**
	 * Apply the shared fieldsCache to EVERY "Filter based on" dropdown
	 * (default row + any rows added with ADD).
	 * Also clears each row's Operator list (must re-select field first).
	 */
	function refreshAllFilterFieldDropdowns(options) {
		options = options || {};
		var fields = sourceFieldsUi.fieldsCache || [];
		var $all = $('#datatrsf-rows-wrap [data-filter-field-cdd="true"]');

		if (!$all.length) {
			// Fallback if the marker is missing on older HTML.
			$all = $('#datatrsf-rows-wrap .datatrsf-col-field .datatrsf-cdd');
		}

		$all.each(function () {
			var $fieldCdd = $(this);
			fillOneFilterFieldDropdown($fieldCdd, fields, options);
			clearFilterOperatorDropdown(
				$fieldCdd.closest('.datatrsf-filter-row').find('.datatrsf-col-op .datatrsf-cdd').first()
			);
		});
	}

	/**
	 * Filter options in a Field mapping "Source field" dropdown (.dd).
	 * Uses the same field metadata as "Filter based on" (label, api_name, data_type).
	 */
	function filterMappingSourceFieldOptions($dd, query) {
		if (!$dd || !$dd.length) {
			return;
		}

		var normalized = String(query || '').trim().toLowerCase();
		var $list = $dd.find('[data-mapping-source-field-list="true"]').first();
		if (!$list.length) {
			$list = $dd.find('.dd-list').first();
		}

		var $items = $list.find('.dd-simple-item');
		var takenValues = getTakenMappingValues('[data-mapping-source-field-dd="true"]', $dd);
		var visibleCount = 0;

		$items.each(function () {
			var $item = $(this);
			var haystack = String(
				$item.attr('data-label')
					|| $item.attr('data-value')
					|| $item.find('.item-name').text()
					|| ''
			).toLowerCase();
			var typeHaystack = String($item.attr('data-type') || $item.find('.item-type').text() || '').toLowerCase();
			var isTaken = !!takenValues[$.trim($item.attr('data-value') || '')];
			var match = !isTaken && (
				!normalized
				|| haystack.indexOf(normalized) !== -1
				|| typeHaystack.indexOf(normalized) !== -1
			);
			$item.toggle(match);
			if (match) {
				visibleCount += 1;
			}
		});

		var $noMatch = $list.find('.dd-search-empty');
		if (normalized && visibleCount === 0 && $items.length) {
			if (!$noMatch.length) {
				$noMatch = $('<div class="dd-empty dd-search-empty"></div>').text('No matches found');
				$list.append($noMatch);
			} else {
				$noMatch.text('No matches found').show();
			}
		} else if ($noMatch.length) {
			$noMatch.remove();
		}
	}

	function resetMappingSourceFieldDropdownDisplay($dd, options) {
		options = options || {};
		if (!$dd || !$dd.length) {
			return;
		}

		$dd.removeAttr('data-selected-value');
		$dd.removeAttr('data-selected-label');
		$dd.removeAttr('data-selected-type');
		$dd.find('.dd-simple-item').removeClass('selected');

		var placeholder = options.placeholder || 'Select field';
		var $wrap = $dd.find('.dd-value-wrap').first();
		if ($wrap.length) {
			$wrap.find('.dd-value').text(placeholder).addClass('is-placeholder');
			$wrap.find('.dd-type').text('');
		}
	}

	function selectMappingSourceFieldItem($dd, $item) {
		if (!$dd || !$dd.length || !$item || !$item.length) {
			return;
		}

		var value = $item.attr('data-value');
		var label = $item.attr('data-label') || $item.find('.item-name').text() || value;
		var dataType = String($item.attr('data-type') || '').trim();

		$dd.find('.dd-simple-item').removeClass('selected');
		$item.addClass('selected');

		var $wrap = $dd.find('.dd-value-wrap').first();
		$wrap.find('.dd-value').text(label).removeClass('is-placeholder placeholder');
		$wrap.find('.dd-type').text(dataType ? '(' + dataType + ')' : '');

		$dd.attr('data-selected-value', value);
		$dd.attr('data-selected-label', label);
		$dd.attr('data-selected-type', dataType);

		clearMappingRowColError($dd.closest('.mapping-row'), 'sourceField');
		refreshMappingRowTypeMismatch($dd.closest('.mapping-row'));
	}

	/**
	 * Fill ONE Field mapping "Source field" dropdown from the shared fieldsCache.
	 * Does NOT call the Metadata API.
	 */
	function fillOneMappingSourceFieldDropdown($dd, fields, options) {
		options = options || {};
		if (!$dd || !$dd.length) {
			return;
		}

		var $list = $dd.find('[data-mapping-source-field-list="true"]').first();
		if (!$list.length) {
			$list = $dd.find('.dd-list').first();
		}
		if (!$list.length) {
			return;
		}

		var preservedSelection = null;
		if (options.preserveSelection) {
			var preservedValue = $.trim($dd.attr('data-selected-value') || '');
			var preservedLabel = $.trim($dd.attr('data-selected-label') || '');
			if (preservedValue || preservedLabel) {
				preservedSelection = {
					value: preservedValue,
					label: preservedLabel,
					dataType: $.trim($dd.attr('data-selected-type') || '')
				};
			}
		}

		$list.empty();

		if (options.message) {
			$list.append($('<div class="dd-empty"></div>').text(options.message));
		} else if (!fields || !fields.length) {
			$list.append($('<div class="dd-empty"></div>').text('No fields available'));
		} else {
			fields.forEach(function (field) {
				var dataType = String(field.data_type || '').trim();
				var $item = $('<div class="dd-simple-item"></div>');
				$item.attr('data-value', field.api_name);
				$item.attr('data-label', field.field_label);
				$item.attr('data-type', dataType);
				// text-truncate: a long field label ellipsizes instead of breaking the row.
				$item.append($('<span class="item-name text-truncate"></span>').text(field.field_label));
				$item.append($('<span class="item-type"></span>').text(dataType));
				$list.append($item);
			});
		}

		if (preservedSelection) {
			applyMappingSourceFieldSelection(
				$dd,
				preservedSelection.label || preservedSelection.value,
				preservedSelection.dataType
			);
		} else {
			resetMappingSourceFieldDropdownDisplay($dd, options);
		}

		$dd.find('.dd-search-input').val('');
		filterMappingSourceFieldOptions($dd, '');
	}

	/**
	 * Apply the shared fieldsCache to every Field mapping "Source field" dropdown.
	 */
	function refreshAllMappingSourceFieldDropdowns(options) {
		options = options || {};
		var fields = sourceFieldsUi.fieldsCache || [];
		var $all = $('#mappingRows [data-mapping-source-field-dd="true"]');

		if (!$all.length) {
			$all = $('#mappingRows .col-source .dd');
		}

		$all.each(function () {
			fillOneMappingSourceFieldDropdown($(this), fields, options);
		});
	}

	/**
	 * Field mapping rows — ADD FIELD / delete row.
	 * Source field uses shared fieldsCache; Destination attribute uses shared attributesCache.
	 */
	function getMappingRowCount() {
		return $('#mappingRows .mapping-row').length;
	}

	function getNextMappingRowIndex() {
		var maxIndex = 0;
		$('#mappingRows .mapping-row').each(function () {
			var fromAttr = parseInt($(this).attr('data-row') || '0', 10);
			var fromId = String(this.id || '').match(/mapping-row-(\d+)/);
			var index = fromId ? parseInt(fromId[1], 10) : fromAttr;
			if (index > maxIndex) {
				maxIndex = index;
			}
		});
		return maxIndex + 1;
	}

	function rewriteMappingRowIds($row, index) {
		if (!$row || !$row.length) {
			return;
		}

		var rowId = 'mapping-row-' + index;
		$row.attr('id', rowId);
		$row.attr('data-row', String(index));

		var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
		if ($sourceDd.length) {
			$sourceDd.attr('id', 'source-field-' + index + '-dropdown');
		}

		var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();
		if ($destDd.length) {
			$destDd.attr('id', 'destination-attribute-' + index + '-dropdown');
		}
	}

	// Values already picked in the OTHER mapping rows — each one maps only once.
	// Options are hidden, never removed, so nothing is lost when a row frees one.
	function getTakenMappingValues(ddSelector, $currentDd) {
		var taken = {};

		$('#mappingRows ' + ddSelector).each(function () {
			var $dd = $(this);
			if ($currentDd && $currentDd.length && $dd[0] === $currentDd[0]) {
				return;
			}

			var value = $.trim($dd.attr('data-selected-value') || '');
			if (value) {
				taken[value] = true;
			}
		});

		return taken;
	}

	function filterMappingDestAttributeOptions($dd, query) {
		if (!$dd || !$dd.length) {
			return;
		}

		var normalized = String(query || '').trim().toLowerCase();
		var $list = $dd.find('.dd-list').first();
		var $items = $list.find('.dd-simple-item');
		var takenValues = getTakenMappingValues('[data-mapping-dest-attribute-dd="true"]', $dd);
		var visibleCount = 0;

		$items.each(function () {
			var $item = $(this);
			var haystack = String(
				$item.attr('data-label')
					|| $item.attr('data-value')
					|| $item.find('.item-name').text()
					|| ''
			).toLowerCase();
			var typeHaystack = String($item.attr('data-type') || $item.find('.item-type').text() || '').toLowerCase();
			var isTaken = !!takenValues[$.trim($item.attr('data-value') || '')];
			var match = !isTaken && (
				!normalized
				|| haystack.indexOf(normalized) !== -1
				|| typeHaystack.indexOf(normalized) !== -1
			);
			$item.toggle(match);
			if (match) {
				visibleCount += 1;
			}
		});

		// An empty list counts as "nothing found" too, so both cues still show.
		var hasNoMatches = !!normalized && visibleCount === 0;

		var $noMatch = $list.find('.dd-search-empty');
		if (hasNoMatches) {
			if (!$noMatch.length) {
				$noMatch = $('<div class="dd-empty dd-search-empty"></div>').text('No matches found');
				$list.append($noMatch);
			} else {
				$noMatch.text('No matches found').show();
			}
		} else if ($noMatch.length) {
			$noMatch.remove();
		}

		// Create attribute only helps when the search found nothing.
		$dd.find('.dd-create-link').first().toggle(hasNoMatches);
	}

	/**
	 * Create attribute panel (#createAttributePanel) — Lead field label from Setup Zoho object.
	 */
	function getCreateAttributeLeadFieldLabel() {
		var displayName = $.trim(
			getSelectedDropdownLabel(SETUP_FIELDS.sourceObject)
			|| getSelectedZohoObjectDisplayName()
			|| 'Lead'
		);

		if (CREATE_ATTR_LEAD_FIELD_LABELS[displayName]) {
			return CREATE_ATTR_LEAD_FIELD_LABELS[displayName];
		}

		if (displayName.slice(-1) === 's') {
			return displayName.slice(0, -1) + ' field';
		}

		return displayName + ' field';
	}

	function refreshCreateAttributeConnectionField() {
		var $input = $('#createAttrConnection');
		if (!$input.length) {
			return;
		}

		$input.val(
			$.trim(getSelectedDropdownLabel(SETUP_FIELDS.connectionId) || '')
		);

		if (getSelectedConnectionId()) {
			clearCreateAttributeFieldError('connection');
		}
	}

	function filterCreateAttributeLeadFieldOptions($dd, query) {
		if (!$dd || !$dd.length) {
			return;
		}

		var normalized = String(query || '').trim().toLowerCase();
		var $list = $dd.find('[data-create-attr-lead-field-list="true"]').first();
		if (!$list.length) {
			$list = $dd.find('.dd-list').first();
		}

		var $items = $list.find('.dd-simple-item');
		var visibleCount = 0;

		$items.each(function () {
			var $item = $(this);
			var haystack = String(
				$item.attr('data-label')
					|| $item.attr('data-value')
					|| $item.find('.item-name').text()
					|| ''
			).toLowerCase();
			var typeHaystack = String($item.attr('data-type') || $item.find('.item-type').text() || '').toLowerCase();
			var match = !normalized
				|| haystack.indexOf(normalized) !== -1
				|| typeHaystack.indexOf(normalized) !== -1;
			$item.toggle(match);
			if (match) {
				visibleCount += 1;
			}
		});

		var $noMatch = $list.find('.dd-search-empty');
		if (normalized && visibleCount === 0 && $items.length) {
			if (!$noMatch.length) {
				$noMatch = $('<div class="dd-empty dd-search-empty"></div>').text('No matches found');
				$list.append($noMatch);
			} else {
				$noMatch.text('No matches found').show();
			}
		} else if ($noMatch.length) {
			$noMatch.remove();
		}
	}

	function resetCreateAttributeLeadFieldSelection(options) {
		options = options || {};
		var $dd = $('#' + CREATE_ATTR_LEAD_FIELD_DD_ID);
		if (!$dd.length) {
			return;
		}

		$dd.removeAttr('data-selected-value');
		$dd.removeAttr('data-selected-label');
		$dd.removeAttr('data-selected-type');
		$dd.find('.dd-simple-item').removeClass('selected');

		var $wrap = $dd.find('.dd-value-wrap').first();
		if ($wrap.length) {
			$wrap.find('.dd-value').text('Select field').addClass('is-placeholder');
			$wrap.find('.dd-type').text('');
		}

		$('#createAttrContactAttribute').val('');
		$('#createAttrDataType').val('');

		if (!options.skipFilterReset) {
			$dd.find('.dd-search-input').val('');
			filterCreateAttributeLeadFieldOptions($dd, '');
		}
	}

	function selectCreateAttributeLeadFieldItem($dd, $item) {
		if (!$dd || !$dd.length || !$item || !$item.length) {
			return;
		}

		var apiName = $.trim($item.attr('data-value') || '');
		var label = $.trim(
			$item.attr('data-label')
				|| $item.find('.item-name').text()
				|| apiName
		);
		var dataType = $.trim(String($item.attr('data-type') || $item.find('.item-type').text() || ''));

		$dd.find('.dd-simple-item').removeClass('selected');
		$item.addClass('selected');

		var $wrap = $dd.find('.dd-value-wrap').first();
		if ($wrap.length) {
			$wrap.find('.dd-value').text(label).removeClass('is-placeholder placeholder');
			$wrap.find('.dd-type').text('');
		}

		$dd.attr('data-selected-value', apiName);
		$dd.attr('data-selected-label', label);
		$dd.attr('data-selected-type', dataType);

		$('#createAttrContactAttribute').val(apiName);
		$('#createAttrDataType').val(dataType);

		clearCreateAttributeFieldError('leadField');
		clearCreateAttributeFieldError('contactAttribute');
		clearCreateAttributeFieldError('dataType');
	}

	/**
	 * Populate Create attribute Lead field dropdown from sourceFieldsUi.fieldsCache
	 * (same META.getFields data as Source identifier).
	 */
	function fillCreateAttributeLeadFieldDropdown(options) {
		options = options || {};
		var $dd = $('#' + CREATE_ATTR_LEAD_FIELD_DD_ID);
		var $list = $dd.find('[data-create-attr-lead-field-list="true"]').first();
		if (!$list.length) {
			$list = $dd.find('.dd-list').first();
		}
		if (!$dd.length || !$list.length) {
			return;
		}

		$list.empty();

		if (options.message) {
			$list.append($('<div class="dd-empty"></div>').text(options.message));
		} else if (!(sourceFieldsUi.fieldsCache || []).length) {
			$list.append($('<div class="dd-empty"></div>').text('No fields available'));
		} else {
			(sourceFieldsUi.fieldsCache || []).forEach(function (field) {
				var dataType = String(field.data_type || '').trim();
				var $item = $('<div class="dd-simple-item"></div>');
				$item.attr('data-value', field.api_name);
				$item.attr('data-label', field.field_label);
				$item.attr('data-type', dataType);
				$item.append($('<span class="item-name"></span>').text(field.field_label));
				$item.append($('<span class="item-type"></span>').text(dataType));
				$list.append($item);
			});
		}

		resetCreateAttributeLeadFieldSelection({ skipFilterReset: true });
		$dd.find('.dd-search-input').val('');
		filterCreateAttributeLeadFieldOptions($dd, '');
	}

	/** Refresh all Create attribute panel fields when the offcanvas opens. */
	function refreshCreateAttributePanel() {
		clearCreateAttributeFieldErrors();
		refreshCreateAttributeConnectionField();

		var $label = $('#createAttrLeadFieldLabel');
		if ($label.length) {
			$label.text(getCreateAttributeLeadFieldLabel());
		}

		refreshCreateAttributeLeadFieldDropdownFromCache({ allowLoad: true });
	}

	/** Rebuild Create attribute Lead field list from sourceFieldsUi.fieldsCache. */
	function refreshCreateAttributeLeadFieldDropdownFromCache(options) {
		options = options || {};
		var moduleApiName = getSelectedZohoObjectValue();
		var fields = sourceFieldsUi.fieldsCache || [];
		var message = '';

		if (!moduleApiName) {
			message = 'Select a Zoho object first.';
		} else if (sourceFieldsUi.loadedModule !== moduleApiName) {
			message = 'Loading fields...';
			if (options.allowLoad) {
				var listElement = sourceFieldsUi.listElement
					|| document.getElementById('datatrsf-event-export-list-lead');
				if (listElement) {
					loadSourceModuleFields(listElement, moduleApiName);
				}
			}
		} else if (!fields.length) {
			message = 'No fields available';
		}

		fillCreateAttributeLeadFieldDropdown(message ? { message: message } : {});
	}

	function setCreateAttributeFieldError(fieldKey, message) {
		var $group = $('#createAttributePanel [data-create-attr-field="' + fieldKey + '"]').first();
		var $error = $('#createAttributePanel [data-create-attr-error="' + fieldKey + '"]').first();

		if (message) {
			$group.addClass('has-error');
			if ($error.length) {
				$error.text(message).removeAttr('hidden').show();
			}
		} else {
			$group.removeClass('has-error');
			if ($error.length) {
				$error.text('').attr('hidden', true).hide();
			}
		}
	}

	function clearCreateAttributeFieldError(fieldKey) {
		setCreateAttributeFieldError(fieldKey, '');
	}

	function clearCreateAttributeFieldErrors() {
		$('#createAttributePanel [data-create-attr-field]').each(function () {
			var fieldKey = $(this).attr('data-create-attr-field');
			if (fieldKey) {
				clearCreateAttributeFieldError(fieldKey);
			}
		});
	}

	function getCreateAttributeFormValues() {
		return {
			connectionId: $.trim(getSelectedConnectionId() || ''),
			leadFieldApiName: $.trim($('#' + CREATE_ATTR_LEAD_FIELD_DD_ID).attr('data-selected-value') || ''),
			attributeName: $.trim($('#createAttrContactAttribute').val() || ''),
			dataType: $.trim($('#createAttrDataType').val() || '')
		};
	}

	function validateCreateAttributeForm() {
		var values = getCreateAttributeFormValues();
		var isValid = true;

		clearCreateAttributeFieldErrors();

		if (!values.connectionId) {
			setCreateAttributeFieldError('connection', CREATE_ATTR_REQUIRED_MESSAGE);
			isValid = false;
		}

		if (!values.leadFieldApiName) {
			setCreateAttributeFieldError('leadField', CREATE_ATTR_REQUIRED_MESSAGE);
			isValid = false;
		}

		if (!values.attributeName) {
			setCreateAttributeFieldError('contactAttribute', CREATE_ATTR_REQUIRED_MESSAGE);
			isValid = false;
		}

		if (!values.dataType) {
			setCreateAttributeFieldError('dataType', CREATE_ATTR_REQUIRED_MESSAGE);
			isValid = false;
		}

		return isValid;
	}

	function setCreateAttributeSaving(isSaving) {
		createAttributeUi.saving = !!isSaving;
		$('#saveCreateAttrBtn').prop('disabled', !!isSaving);
	}

	function getCreateAttributeBusinessResult(output) {
		if (!output || typeof output !== 'object' || !output.data || typeof output.data !== 'object') {
			return null;
		}
		return output.data;
	}

	function getCreateAttributeBusinessStatus(output) {
		var business = getCreateAttributeBusinessResult(output);
		if (!business) {
			return '';
		}
		return $.trim(String(business.status || '')).toLowerCase();
	}

	function extractCreatedAttributeFromOutput(output) {
		if (getCreateAttributeBusinessStatus(output) !== 'success') {
			return null;
		}

		var business = getCreateAttributeBusinessResult(output);
		var rows = (business && Array.isArray(business.data)) ? business.data : [];
		if (!rows.length || !rows[0]) {
			return null;
		}

		var row = rows[0];
		var attributeName = $.trim(String(row.attribute_name != null ? row.attribute_name : ''));
		var attributeCode = $.trim(String(row.attribute_code != null ? row.attribute_code : ''));
		var attributeType = $.trim(String(row.attribute_type != null ? row.attribute_type : ''));

		if (!attributeName || !attributeCode) {
			return null;
		}

		return {
			id: row.id,
			attribute_code: attributeCode,
			attribute_name: attributeName,
			attribute_type: attributeType
		};
	}

	function isCreateAttributeResponseSuccessful(response) {
		if (!response) {
			return false;
		}

		if (
			response.status === 'error'
			|| response.code === 'ERROR'
			|| response.code === 'INVALID_DATA'
		) {
			return false;
		}

		var output = parseEventListingOutput(response);
		if (!output || typeof output !== 'object') {
			return false;
		}

		// Business status lives at details.output.data.status (not details.output.status).
		return getCreateAttributeBusinessStatus(output) === 'success';
	}

	function getCreateAttributeErrorMessage(response, fallback) {
		var output = parseEventListingOutput(response);
		if (output && typeof output === 'object') {
			var business = getCreateAttributeBusinessResult(output);
			if (business) {
				if (Array.isArray(business.errors) && business.errors.length) {
					var errorMessages = [];
					business.errors.forEach(function (entry) {
						if (!entry) {
							return;
						}
						var message = $.trim(String(entry.message || ''));
						if (message) {
							errorMessages.push(message);
						}
					});
					if (errorMessages.length) {
						return errorMessages.join(' ');
					}
				}

				if (business.description && $.trim(String(business.description))) {
					return $.trim(String(business.description));
				}
			}

			if (output.message && $.trim(String(output.message))) {
				return $.trim(String(output.message));
			}
		}

		if (response && response.message && $.trim(String(response.message))) {
			return $.trim(String(response.message));
		}

		return fallback || CREATE_ATTR_ERROR_MESSAGE;
	}

	function hideCreateAttributePanel() {
		var panelEl = document.getElementById('createAttributePanel');
		if (!panelEl || typeof bootstrap === 'undefined' || !bootstrap.Offcanvas) {
			return;
		}

		var instance = bootstrap.Offcanvas.getInstance(panelEl);
		if (instance) {
			instance.hide();
		}
	}

	/**
	 * Put the just-created attribute at the top of this row's list.
	 * Netcore may or may not return it in the refreshed list — either way it goes
	 * first, so the user sees it without scrolling past a hundred options.
	 */
	function ensureCreatedAttributeInDropdownList($dd, createdAttribute) {
		try {
			var createdAttributeName = $.trim(String(createdAttribute.attribute_name || ''));
			if (!createdAttributeName) {
				return;
			}

			var $attributeList = $dd.find('[data-mapping-dest-attribute-list="true"]').first();
			if (!$attributeList.length) {
				$attributeList = $dd.find('.dd-list').first();
			}
			if (!$attributeList.length) {
				return;
			}

			// Already in the refreshed list → just move that same node to the top.
			var $listedAttribute = $attributeList.find('.dd-simple-item').filter(function () {
				return $.trim($(this).attr('data-value') || '').toLowerCase()
					=== createdAttributeName.toLowerCase();
			}).first();

			if ($listedAttribute.length) {
				$attributeList.prepend($listedAttribute);
				return;
			}

			// An empty-state line cannot stay once a real option lands under it.
			$attributeList.find('.dd-empty').remove();

			var createdAttributeType = $.trim(
				String(createdAttribute.attribute_type || createdAttribute.data_type || '')
			);

			var $attributeItem = $('<div class="dd-simple-item"></div>');
			$attributeItem.attr('data-value', createdAttributeName);
			$attributeItem.attr('data-label', createdAttributeName);
			$attributeItem.attr('data-type', createdAttributeType);
			if (createdAttribute.id != null && createdAttribute.id !== '') {
				$attributeItem.attr('data-attribute-id', String(createdAttribute.id));
			}
			$attributeItem.append($('<span class="item-name"></span>').text(createdAttributeName));
			$attributeItem.append($('<span class="item-type"></span>').text(createdAttributeType));
			$attributeList.prepend($attributeItem);
		} catch (dropdownListError) {
			console.error('Create attribute: dropdown list update failed:', dropdownListError);
		}
	}

	/**
	 * Keep the new attribute in the shared cache, not just in one row's markup.
	 * ADD FIELD builds each new row from this cache, so without it the attribute
	 * is missing everywhere except the row it was created from.
	 */
	function rememberCreatedAttribute(createdAttribute) {
		try {
			var createdAttributeName = $.trim(String(createdAttribute.attribute_name || ''));
			var createdAttributeType = $.trim(
				String(createdAttribute.attribute_type || createdAttribute.data_type || '')
			);
			if (!createdAttributeName || !createdAttributeType) {
				return;
			}

			var cachedAttributes = mappingDestAttributeUi.attributesCache || [];
			var isAlreadyCached = cachedAttributes.some(function (cachedAttribute) {
				return $.trim(String(cachedAttribute.attribute_name || '')).toLowerCase()
					=== createdAttributeName.toLowerCase();
			});
			if (isAlreadyCached) {
				return;
			}

			// First, so every row that is rebuilt from the cache shows it at the top.
			cachedAttributes.unshift({
				id: createdAttribute.id,
				attribute_name: createdAttributeName,
				attribute_type: createdAttributeType,
				attribute_code: $.trim(String(createdAttribute.attribute_code || ''))
			});
			mappingDestAttributeUi.attributesCache = cachedAttributes;
		} catch (attributeCacheError) {
			console.error('Create attribute: cache update failed:', attributeCacheError);
		}
	}

	function applyCreatedAttributeToTargetDropdown(createdAttribute) {
		try {
			if (!createdAttribute || !(createdAttribute.attribute_code || createdAttribute.attribute_name)) {
				return;
			}

			var $targetDestAttributeDd = createAttributeUi.targetDestAttributeDd;
			if (!$targetDestAttributeDd || !$targetDestAttributeDd.length) {
				return;
			}

			rememberCreatedAttribute(createdAttribute);
			ensureCreatedAttributeInDropdownList($targetDestAttributeDd, createdAttribute);

			applyMappingDestAttributeSelection(
				$targetDestAttributeDd,
				createdAttribute.attribute_name,
				createdAttribute.attribute_type || createdAttribute.data_type
			);

			if (createdAttribute.id != null && createdAttribute.id !== '') {
				$targetDestAttributeDd.attr('data-selected-id', String(createdAttribute.id));
			}

			clearMappingRowColError($targetDestAttributeDd.closest('.mapping-row'), 'destAttribute');
		} catch (targetDropdownError) {
			console.error('Create attribute: target dropdown update failed:', targetDropdownError);
		}
	}

	/** Find a just-created attribute in the refreshed cache — that is where its real id lives. */
	function findCachedAttributeByName(attributeName) {
		try {
			var wantedAttributeName = $.trim(String(attributeName || '')).toLowerCase();
			if (!wantedAttributeName) {
				return null;
			}

			var matchedAttribute = null;
			(mappingDestAttributeUi.attributesCache || []).forEach(function (cachedAttribute) {
				if (
					!matchedAttribute
					&& $.trim(String(cachedAttribute.attribute_name || '')).toLowerCase()
						=== wantedAttributeName
				) {
					matchedAttribute = cachedAttribute;
				}
			});

			return matchedAttribute;
		} catch (attributeLookupError) {
			console.error('Create attribute: cache lookup failed:', attributeLookupError);
			return null;
		}
	}

	/** Netcore returns one request_id per create call — that becomes the record title. */
	function getCreateAttributeRequestId(output) {
		try {
			var createAttributeResult = getCreateAttributeBusinessResult(output);

			return $.trim(String((createAttributeResult && createAttributeResult.request_id) || ''));
		} catch (requestIdError) {
			console.error('Create attribute: request_id read failed:', requestIdError);
			return '';
		}
	}

	/**
	 * Log an approved attribute request against the open Data Transfer.
	 * The id comes from the reloaded attribute list, not the create response —
	 * that response returns the whole attribute list, so its first row is not ours.
	 * A failed log never breaks the create flow: the attribute itself already exists.
	 */
	function createAttributeRequestRecord(createdAttribute, formValues, requestId) {
		try {
			var dataTransferId = getCurrentRecordId();
			if (!dataTransferId) {
				console.error('Attribute request record skipped: data transfer is not saved yet.');
				return Promise.resolve();
			}

			if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.insertRecord !== 'function') {
				console.error('Attribute request record skipped: Zoho CRM API is unavailable.');
				return Promise.resolve();
			}

			// The typed name is what Netcore actually created, so match on that.
			var requestedAttributeName = $.trim(
				(formValues && formValues.attributeName)
					|| (createdAttribute && createdAttribute.attribute_name)
					|| ''
			);
			// The create response carries the new id; the listing only gets it after approval.
			var respondedAttributeName = $.trim(
				String((createdAttribute && createdAttribute.attribute_name) || '')
			);
			var hasRespondedAttributeId = createdAttribute
				&& createdAttribute.id != null
				&& createdAttribute.id !== ''
				&& respondedAttributeName.toLowerCase() === requestedAttributeName.toLowerCase();

			var cachedAttribute = findCachedAttributeByName(requestedAttributeName);
			var createdAttributeId = '';
			if (hasRespondedAttributeId) {
				createdAttributeId = createdAttribute.id;
			} else if (cachedAttribute && cachedAttribute.id != null) {
				createdAttributeId = cachedAttribute.id;
			}

			var createdAttributeDataType = $.trim(
				(createdAttribute && createdAttribute.attribute_type)
					|| (cachedAttribute && cachedAttribute.attribute_type)
					|| (formValues && formValues.dataType)
					|| ''
			);

			if (createdAttributeId === '') {
				console.error(
					'Attribute request record: no id found for "' + requestedAttributeName + '".'
				);
			}

			return Promise.resolve(
				ZOHO.CRM.API.insertRecord({
					Entity: ATTRIBUTE_REQUEST_ENTITY,
					APIData: {
						// Record title is Netcore's request_id for this create call.
						Name: requestId,
						netcore0__Data_Transfer: String(dataTransferId),
						netcore0__Attribute_ID: createdAttributeId === ''
							? ''
							: String(createdAttributeId),
						netcore0__Attribute_Name: requestedAttributeName,
						netcore0__Attribute_DataType: createdAttributeDataType,
						netcore0__Request_Status: ATTRIBUTE_REQUEST_PENDING_STATUS
					}
				})
			).then(function (insertResponse) {
				// START EXPORT reads this for both the status and the New Attributes count.
				pendingAttributeRequestCount += 1;
			}).catch(function (insertError) {
				console.error('Attribute request record error:', insertError);
			});
		} catch (attributeRequestError) {
			console.error('Attribute request record build failed:', attributeRequestError);
			return Promise.resolve();
		}
	}

	/**
	 * After START EXPORT, set Data Transfer status from
	 * netcore0__data_t_status_attribute_based (details.output JSON string).
	 * pendingCount maps to the existing netcore0__New_Attributes field.
	 */
	function applyAttributeRequestToDataTransfer() {
		try {
			var dataTransferId = getCurrentRecordId();
			if (!dataTransferId) {
				return Promise.resolve();
			}

			if (
				!window.ZOHO
				|| !ZOHO.CRM
				|| !ZOHO.CRM.FUNCTIONS
				|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
			) {
				console.error('Attribute-based status skipped: ZOHO.CRM.FUNCTIONS.execute is unavailable.');
				return Promise.resolve();
			}

			var reqData = {
				arguments: JSON.stringify({
					dataTransferId: String(dataTransferId)
				})
			};

			return Promise.resolve(ZOHO.CRM.FUNCTIONS.execute(ATTRIBUTE_BASED_STATUS_FUNCTION, reqData))
				.then(function (response) {
					var output = parseEventListingOutput(response);
					if (!output || typeof output !== 'object') {
						console.error('Attribute-based status: missing or invalid details.output.', response);
						return;
					}

					if (String(output.status || '').toLowerCase() !== 'success') {
						console.error('Attribute-based status: function did not succeed.', output);
						return;
					}

					var dataTransferStatus = $.trim(String(output.dataTransferStatus || ''));
					if (!dataTransferStatus) {
						console.error('Attribute-based status: dataTransferStatus is missing.', output);
						return;
					}

					var updatePayload = {
						netcore0__Data_Transfer_Status: dataTransferStatus
					};

					if (output.pendingCount != null && output.pendingCount !== '') {
						var pendingCount = Number(output.pendingCount);
						if (!isNaN(pendingCount)) {
							updatePayload.netcore0__New_Attributes = pendingCount;
						}
					} else if (pendingAttributeRequestCount) {
						updatePayload.netcore0__New_Attributes = pendingAttributeRequestCount;
					}

					return updateDataTransferRecord(updatePayload, dataTransferId);
				})
				.then(function (attributeStatusResponse) {
					if (attributeStatusResponse) {
						console.log('Data transfer attribute request update response:', attributeStatusResponse);
					}
				})
				.catch(function (attributeStatusError) {
					console.error('Data transfer attribute request update error:', attributeStatusError);
				});
		} catch (attributeStatusBuildError) {
			console.error('Data transfer attribute request update failed:', attributeStatusBuildError);
			return Promise.resolve();
		}
	}

	function handleCreateAttributeSaveSuccess(response, formValues) {
		var output = parseEventListingOutput(response);
		var createdAttribute = extractCreatedAttributeFromOutput(output);
		var requestId = getCreateAttributeRequestId(output);

		if (!createdAttribute && formValues && formValues.attributeName) {
			createdAttribute = {
				attribute_name: formValues.attributeName,
				data_type: formValues.dataType
			};
		}

		var connectionId = formValues && formValues.connectionId
			? formValues.connectionId
			: getSelectedConnectionId();

		return loadMappingDestAttributes(connectionId, { preserveSelection: true })
			.then(function () {
				if (createdAttribute) {
					applyCreatedAttributeToTargetDropdown(createdAttribute);
				}
				return createAttributeRequestRecord(createdAttribute, formValues, requestId);
			})
			.catch(function (reloadError) {
				console.error('Create attribute: reload attribute list failed:', reloadError);
				if (createdAttribute) {
					applyCreatedAttributeToTargetDropdown(createdAttribute);
				}
				return createAttributeRequestRecord(createdAttribute, formValues, requestId);
			})
			.then(function () {
				showSuccessToast(CREATE_ATTR_SUCCESS_MESSAGE);
				hideCreateAttributePanel();
				// The toast lives at the panel's bottom edge — bring it into view.
				scrollToSetupPanelBottom();
			});
	}

	function handleSaveCreateAttributeClick(event) {
		if (event) {
			event.preventDefault();
			event.stopPropagation();
		}

		if (createAttributeUi.saving) {
			return;
		}

		if (!validateCreateAttributeForm()) {
			return;
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			showErrorToast(CREATE_ATTR_ERROR_MESSAGE);
			return;
		}

		var values = getCreateAttributeFormValues();
		// The form shows the Zoho type; Netcore only understands its own.
		var netcoreCreateDataType = getNetcoreCreateDataType(values.dataType);
		var reqData = {
			arguments: JSON.stringify({
				connection_id: values.connectionId,
				attribute_name: values.attributeName,
				data_type: netcoreCreateDataType,
				dataTransferId:getCurrentRecordId()
			})
		};

		setCreateAttributeSaving(true);
		showDataTransferNameCheckLoader();

		var savePromise;
		try {
			savePromise = ZOHO.CRM.FUNCTIONS.execute(CREATE_ATTRIBUTE_FUNCTION, reqData);
		} catch (executeError) {
			console.error('Create attribute execute threw:', executeError);
			hideDataTransferNameCheckLoader();
			setCreateAttributeSaving(false);
			showErrorToast(CREATE_ATTR_ERROR_MESSAGE);
			return;
		}

		Promise.resolve(savePromise)
			.then(function (response) {
				if (!isCreateAttributeResponseSuccessful(response)) {
					showErrorToast(getCreateAttributeErrorMessage(response));
					return;
				}

				return handleCreateAttributeSaveSuccess(response, values);
			})
			.catch(function (error) {
				console.error('Create attribute error:', error);
				showErrorToast(getCreateAttributeErrorMessage(error));
			})
			.finally(function () {
				hideDataTransferNameCheckLoader();
				setCreateAttributeSaving(false);
			});
	}

	function initCreateAttributePanel() {
		var panel = document.getElementById('createAttributePanel');
		if (!panel || panel.getAttribute('data-create-attr-bound') === 'true') {
			return;
		}
		panel.setAttribute('data-create-attr-bound', 'true');
	}

	function resetMappingDestAttributeDropdown($dd, options) {
		options = options || {};
		if (!$dd || !$dd.length) {
			return;
		}

		$dd.removeClass('warn');
		$dd.removeAttr('data-selected-value');
		$dd.removeAttr('data-selected-label');
		$dd.removeAttr('data-selected-type');
		$dd.removeAttr('data-selected-id');
		$dd.find('.dd-simple-item').removeClass('selected');
		$dd.find('.dd-trigger > span[data-bs-toggle="tooltip"]').remove();

		var placeholder = options.placeholder || 'Select attribute';
		var $wrap = $dd.find('.dd-value-wrap').first();
		if ($wrap.length) {
			$wrap.find('.dd-value').text(placeholder).addClass('is-placeholder');
			$wrap.find('.dd-type').text('');
		}

		$dd.find('.dd-search-input').val('');
		filterMappingDestAttributeOptions($dd, '');
	}


	// Field mapping data-type matching

	// Zoho and Netcore spell the same type differently — these count as equal.
	// Zoho data_type → every Netcore CE type it may land on (client's matrix).
	var ZOHO_TO_NETCORE_DATA_TYPES = {
		text: ['textline'],
		textarea: ['longtext'],
		email: ['email', 'textline'],
		phone: ['mobile', 'email', 'textline'],
		picklist: ['textline'],
		multiselectpicklist: ['longtext'],
		date: ['date'],
		datetime: ['date'],
		integer: ['integer'],
		autonumber: ['textline'],
		currency: ['decimal'],
		double: ['decimal'],
		percent: ['decimal'],
		bigint: ['integer'],
		boolean: ['textline'],
		website: ['url'],
		lookup: ['textline'],
		formula: ['textline'],
		userlookup: ['textline'],
		multiuserlookup: ['longtext'],
		fileupload: ['url'],
		imageupload: ['url'],
		rollup_summary: ['decimal'],
		multiselectlookup: ['longtext']
	};

	// One Netcore type, several names — varchar / text / Textline are the same thing.
	var NETCORE_DATA_TYPE_ALIASES = {
		varchar: 'textline',
		text: 'textline',
		int: 'integer'
	};

	// How Netcore spells each type when we send it back on Create attribute.
	var NETCORE_DATA_TYPE_LABELS = {
		textline: 'Textline',
		longtext: 'Longtext',
		email: 'Email',
		mobile: 'Mobile',
		date: 'Date',
		integer: 'Integer',
		decimal: 'Decimal',
		url: 'URL'
	};

	// Zoho types outside the matrix still have to land somewhere Netcore accepts.
	var NETCORE_DEFAULT_CREATE_DATA_TYPE = 'Textline';

	var MAPPING_TYPE_MISMATCH_TOOLTIP =
		'<span data-bs-toggle="tooltip" data-bs-placement="bottom"' +
		' title="There is a data type mismatch."' +
		' aria-label="There is a data type mismatch.">' +
		'<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">' +
		'<path fill-rule="evenodd" clip-rule="evenodd" d="M9.18644 1.76239C8.80251 1.0792 7.8613 1.0792 7.47737 1.7624L1.38846 12.5974C0.982884 13.3191 1.50675 14.1667 2.243 14.1667H14.4208C15.1571 14.1667 15.6809 13.319 15.2754 12.5974L9.18644 1.76239ZM6.38765 1.15001C7.24934 -0.383333 9.41447 -0.383339 10.2762 1.15001L16.3651 11.985C17.2077 13.4844 16.1758 15.4167 14.4208 15.4167H2.243C0.487983 15.4167 -0.5439 13.4844 0.29874 11.985L6.38765 1.15001ZM8.34371 4.16616C8.68888 4.16616 8.96871 4.44598 8.96871 4.79116V8.95783C8.96871 9.303 8.68888 9.58283 8.34371 9.58283C7.99853 9.58283 7.71871 9.303 7.71871 8.95783V4.79116C7.71871 4.44598 7.99853 4.16616 8.34371 4.16616Z" fill="#F05C5C"></path>' +
		'<path fill-rule="evenodd" clip-rule="evenodd" d="M8.34363 10.7073C8.6888 10.7073 8.96863 10.9871 8.96863 11.3323V11.3353C8.96863 11.6804 8.6888 11.9603 8.34363 11.9603C7.99845 11.9603 7.71863 11.6804 7.71863 11.3353V11.3323C7.71863 10.9871 7.99845 10.7073 8.34363 10.7073Z" fill="#F05C5C"></path>' +
		'</svg>' +
		'</span>';

	// Types reach us as "varchar" or "(Textline)" — strip brackets and settle on one word.
	function normalizeNetcoreDataType(rawType) {
		try {
			var netcoreDataType = $.trim(String(rawType || ''))
				.toLowerCase()
				.replace(/^\(|\)$/g, '');

			return NETCORE_DATA_TYPE_ALIASES[netcoreDataType] || netcoreDataType;
		} catch (netcoreDataTypeError) {
			console.error('Field mapping: Netcore data type read failed:', netcoreDataTypeError);
			return '';
		}
	}

	// Netcore types this Zoho field may land on; empty list when the type is unlisted.
	function getAllowedNetcoreDataTypes(zohoDataType) {
		try {
			var normalizedZohoDataType = $.trim(String(zohoDataType || ''))
				.toLowerCase()
				.replace(/^\(|\)$/g, '');

			return ZOHO_TO_NETCORE_DATA_TYPES[normalizedZohoDataType] || [];
		} catch (zohoDataTypeError) {
			console.error('Field mapping: Zoho data type read failed:', zohoDataTypeError);
			return [];
		}
	}

	// Create attribute sends Netcore's own spelling, not the Zoho type the form shows.
	function getNetcoreCreateDataType(zohoDataType) {
		try {
			var primaryNetcoreDataType = getAllowedNetcoreDataTypes(zohoDataType)[0] || '';

			return NETCORE_DATA_TYPE_LABELS[primaryNetcoreDataType] || NETCORE_DEFAULT_CREATE_DATA_TYPE;
		} catch (createDataTypeError) {
			console.error('Create attribute: data type mapping failed:', createDataTypeError);
			return NETCORE_DEFAULT_CREATE_DATA_TYPE;
		}
	}

	// Red border + warning icon on the destination when the row's two types differ.
	function refreshMappingRowTypeMismatch($row) {
		if (!$row || !$row.length) {
			return;
		}

		var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
		var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();
		if (!$sourceDd.length || !$destDd.length) {
			return;
		}

		// Both selections already store their type here.
		var zohoDataType = $.trim(String($sourceDd.attr('data-selected-type') || ''));
		var allowedNetcoreDataTypes = getAllowedNetcoreDataTypes(zohoDataType);
		var selectedNetcoreDataType = normalizeNetcoreDataType($destDd.attr('data-selected-type'));

		// A Zoho type outside the matrix has no approved pair, so it never passes.
		var hasMismatch = isContactsFieldMappingTableRequired()
			&& !!zohoDataType
			&& !!selectedNetcoreDataType
			&& allowedNetcoreDataTypes.indexOf(selectedNetcoreDataType) === -1;

		// Bootstrap builds the tooltip outside the row, so dispose before removing.
		$destDd.find('.dd-trigger > span[data-bs-toggle="tooltip"]').each(function () {
			if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
				var openTooltip = bootstrap.Tooltip.getInstance(this);
				if (openTooltip) {
					openTooltip.dispose();
				}
			}
		}).remove();

		$destDd.toggleClass('warn', hasMismatch);

		// Export banner goes as soon as the last mismatch anywhere is cleared.
		if (!hasFieldMappingTypeMismatch()) {
			toggleFieldMappingErrorAlert(false);
		}

		if (!hasMismatch) {
			return;
		}

		// Sits after the value, before the chevron.
		$destDd.find('.dd-trigger .dd-value-wrap').first()
			.after(MAPPING_TYPE_MISMATCH_TOOLTIP);

		if (typeof window.initBootstrapTooltips === 'function') {
			window.initBootstrapTooltips($destDd[0]);
		}
	}

	function selectMappingDestAttributeItem($dd, $item) {
		if (!$dd || !$dd.length || !$item || !$item.length) {
			return;
		}

		var value = $item.attr('data-value');
		var label = $item.attr('data-label') || $item.find('.item-name').text() || value;
		var dataType = String($item.attr('data-type') || $item.find('.item-type').text() || '').trim();

		$dd.find('.dd-simple-item').removeClass('selected');
		$item.addClass('selected');

		var $wrap = $dd.find('.dd-value-wrap').first();
		$wrap.find('.dd-value').text(label).removeClass('is-placeholder placeholder');
		$wrap.find('.dd-type').text(dataType ? '(' + dataType + ')' : '');

		$dd.attr('data-selected-value', value);
		$dd.attr('data-selected-label', label);
		$dd.attr('data-selected-type', dataType);

		var attributeId = $.trim($item.attr('data-attribute-id') || '');
		if (attributeId) {
			$dd.attr('data-selected-id', attributeId);
		} else {
			$dd.removeAttr('data-selected-id');
		}

		clearMappingRowColError($dd.closest('.mapping-row'), 'destAttribute');
		refreshMappingRowTypeMismatch($dd.closest('.mapping-row'));
		refreshDropdownTriggerTooltip($dd);
	}

	function applyMappingSourceFieldSelection($dd, sourceField, sourceDataType, sourceFieldLabel) {
		if (!$dd || !$dd.length) {
			return;
		}

		var savedValue = $.trim(String(sourceField || ''));
		var normalizedSource = savedValue;
		if (!normalizedSource) {
			resetMappingSourceFieldDropdownDisplay($dd);
			return;
		}

		var resolvedDataType = $.trim(String(sourceDataType || ''));
		var fields = sourceFieldsUi.fieldsCache || [];
		fields.some(function (field) {
			if (!field) {
				return false;
			}
			var apiName = $.trim(String(field.api_name || ''));
			var fieldLabel = $.trim(String(field.field_label || ''));
			if (
				apiName === normalizedSource
				|| fieldLabel === normalizedSource
				|| apiName.toLowerCase() === normalizedSource.toLowerCase()
				|| fieldLabel.toLowerCase() === normalizedSource.toLowerCase()
			) {
				normalizedSource = fieldLabel || apiName;
				if (!resolvedDataType) {
					resolvedDataType = $.trim(String(field.data_type || ''));
				}
				return true;
			}
			return false;
		});

		var $item = null;
		$dd.find('.dd-simple-item').each(function () {
			var $el = $(this);
			var value = $.trim($el.attr('data-value') || '');
			var label = $.trim($el.attr('data-label') || $el.find('.item-name').text() || '');
			if (
				value === savedValue
				|| label === savedValue
				|| value === normalizedSource
				|| label === normalizedSource
				|| value.toLowerCase() === savedValue.toLowerCase()
				|| label.toLowerCase() === savedValue.toLowerCase()
				|| value.toLowerCase() === normalizedSource.toLowerCase()
				|| label.toLowerCase() === normalizedSource.toLowerCase()
			) {
				$item = $el;
				return false;
			}
		});

		if ($item && $item.length) {
			selectMappingSourceFieldItem($dd, $item);
			return;
		}

		var displayLabel = $.trim(String(sourceFieldLabel || '')) || normalizedSource;
		$dd.attr('data-selected-value', savedValue || normalizedSource);
		$dd.attr('data-selected-label', displayLabel);
		$dd.attr('data-selected-type', resolvedDataType);

		var $wrap = $dd.find('.dd-value-wrap').first();
		$wrap.find('.dd-value').text(displayLabel).removeClass('is-placeholder placeholder');
		$wrap.find('.dd-type').text(resolvedDataType ? '(' + resolvedDataType + ')' : '');
	}

	function applyMappingDestAttributeSelection($dd, destinationValue, destinationDataType, destinationFieldLabel) {
		if (!$dd || !$dd.length) {
			return;
		}

		var normalizedValue = $.trim(String(destinationValue || ''));
		if (!normalizedValue) {
			resetMappingDestAttributeDropdown($dd);
			return;
		}

		var resolvedName = normalizedValue;
		var resolvedLabel = normalizedValue;
		var resolvedDataType = $.trim(String(destinationDataType || ''));
		var attributes = mappingDestAttributeUi.attributesCache || [];
		attributes.some(function (attribute) {
			if (!attribute) {
				return false;
			}

			var attributeCode = $.trim(String(attribute.attribute_code || ''));
			var attributeName = $.trim(String(attribute.attribute_name || ''));
			if (
				attributeName === normalizedValue
				|| attributeCode === normalizedValue
				|| attributeName.toLowerCase() === normalizedValue.toLowerCase()
				|| attributeCode.toLowerCase() === normalizedValue.toLowerCase()
			) {
				resolvedName = attributeName || normalizedValue;
				resolvedLabel = attributeName || normalizedValue;
				if (!resolvedDataType) {
					resolvedDataType = $.trim(String(attribute.attribute_type || ''));
				}
				return true;
			}
			return false;
		});

		var $item = null;
		$dd.find('.dd-simple-item').each(function () {
			var $el = $(this);
			var value = $.trim($el.attr('data-value') || '');
			var label = $.trim($el.attr('data-label') || $el.find('.item-name').text() || '');
			if (
				value === normalizedValue
				|| label === normalizedValue
				|| value === resolvedName
				|| label === resolvedLabel
				|| value.toLowerCase() === normalizedValue.toLowerCase()
				|| label.toLowerCase() === normalizedValue.toLowerCase()
			) {
				$item = $el;
				return false;
			}
		});

		if ($item && $item.length) {
			selectMappingDestAttributeItem($dd, $item);
			return;
		}

		var displayLabel = $.trim(String(destinationFieldLabel || '')) || resolvedLabel;
		$dd.attr('data-selected-value', resolvedName);
		$dd.attr('data-selected-label', displayLabel);
		$dd.attr('data-selected-type', resolvedDataType);
		$dd.removeAttr('data-selected-id');

		var $wrap = $dd.find('.dd-value-wrap').first();
		$wrap.find('.dd-value').text(displayLabel).removeClass('is-placeholder placeholder');
		$wrap.find('.dd-type').text(resolvedDataType ? '(' + resolvedDataType + ')' : '');
		refreshMappingRowTypeMismatch($dd.closest('.mapping-row'));
		refreshDropdownTriggerTooltip($dd);
	}

	function applyOneSavedMappingRow($row, rowData) {
		if (!$row || !$row.length || !rowData) {
			return;
		}

		applyMappingSourceFieldSelection(
			$row.find('[data-mapping-source-field-dd="true"]').first(),
			rowData.source_field,
			rowData.source_dataType,
			rowData.source_field_label
		);
		applyMappingDestAttributeSelection(
			$row.find('[data-mapping-dest-attribute-dd="true"]').first(),
			rowData.destination_field,
			rowData.destination_dataType,
			rowData.destination_field_label
		);
	}

	function parseContactsFieldMappingJson(rawValue) {
		if (!rawValue) {
			return [];
		}
		if ($.isArray(rawValue)) {
			return rawValue;
		}

		if (typeof rawValue === 'object') {
			return $.isArray(rawValue.data) ? rawValue.data : [];
		}

		var trimmed = $.trim(String(rawValue));
		if (!trimmed) {
			return [];
		}
		if (trimmed.charAt(0) !== '[') {
			return [];
		}

		try {
			var parsed = JSON.parse(trimmed);
			return $.isArray(parsed) ? parsed : [];
		} catch (error) {
			return [];
		}
	}

	function resetMappingRowsToDefault() {
		var $wrap = $('#mappingRows');
		if (!$wrap.length) {
			return;
		}

		$wrap.find('.mapping-row').slice(1).remove();

		var $first = $wrap.find('.mapping-row').first();
		if (!$first.length) {
			return;
		}

		rewriteMappingRowIds($first, 1);
		fillOneMappingSourceFieldDropdown(
			$first.find('[data-mapping-source-field-dd="true"]').first(),
			sourceFieldsUi.fieldsCache || []
		);
		fillOneMappingDestAttributeDropdown(
			$first.find('[data-mapping-dest-attribute-dd="true"]').first(),
			mappingDestAttributeUi.attributesCache || []
		);
		updateMappingRowDeleteButtons();
	}

	function applyContactsFieldMappingFromRecord(rawValue) {
		var mappings = parseContactsFieldMappingJson(rawValue);

		resetMappingRowsToDefault();
		if (!mappings.length) {
			return;
		}

		mappings.forEach(function (rowData, index) {
			if (index > 0) {
				addMappingRow();
			}

			applyOneSavedMappingRow($('#mappingRows .mapping-row').eq(index), rowData);
		});

		updateMappingRowDeleteButtons();
	}

	function updateMappingRowDeleteButtons() {
		var $rows = $('#mappingRows .mapping-row');
		var showDelete = $rows.length > 1;

		$rows.each(function () {
			// Hidden with visibility, not display — the button keeps its 32px slot
			// so a single row's columns still line up with the header.
			$(this).find('[data-mapping-row-delete="true"]').first()
				.css('visibility', showDelete ? '' : 'hidden');
		});
	}

	function addMappingRow() {
		var $wrap = $('#mappingRows');
		var $firstRow = $wrap.find('.mapping-row').first();
		if (!$wrap.length || !$firstRow.length) {
			return;
		}

		var nextIndex = getNextMappingRowIndex();
		var $clone = $firstRow.clone(false, false);

		rewriteMappingRowIds($clone, nextIndex);

		fillOneMappingSourceFieldDropdown(
			$clone.find('[data-mapping-source-field-dd="true"]').first(),
			sourceFieldsUi.fieldsCache || []
		);
		fillOneMappingDestAttributeDropdown(
			$clone.find('[data-mapping-dest-attribute-dd="true"]').first(),
			mappingDestAttributeUi.attributesCache || []
		);

		$clone.find('[data-dc-mapping-col]').removeClass('has-error');
		$clone.find('[data-dc-mapping-error]').text('').attr('hidden', true).hide();

		$clone.find('.dd').removeClass('open');
		$wrap.append($clone);
		updateMappingRowDeleteButtons();
	}

	function deleteMappingRow($row) {
		if (!$row || !$row.length) {
			return;
		}

		if (getMappingRowCount() <= 1) {
			return;
		}

		$row.remove();
		updateMappingRowDeleteButtons();
	}

	function initFieldMappingRows() {
		var $root = $('#data-transfer-setup');
		var $wrap = $('#mappingRows');
		if (!$root.length || !$wrap.length || $wrap.attr('data-mapping-rows-bound') === 'true') {
			return;
		}
		$wrap.attr('data-mapping-rows-bound', 'true');

		var $addFieldBtn = $('#addFieldBtn');

		$addFieldBtn.on('click.dtMappingRow', function () {
			addMappingRow();
		});

		// The screen partial loads after netcore.js has already swept the page.
		try {
			if ($addFieldBtn.length && typeof window.initBootstrapTooltips === 'function') {
				window.initBootstrapTooltips($addFieldBtn[0]);
			}
		} catch (addFieldTooltipError) {
			console.error('Field mapping: ADD FIELD tooltip init failed:', addFieldTooltipError);
		}

		$wrap.on('click.dtMappingRowDelete', '[data-mapping-row-delete="true"]', function () {
			deleteMappingRow($(this).closest('.mapping-row'));
		});

		fillOneMappingDestAttributeDropdown(
			$wrap.find('.mapping-row').first().find('[data-mapping-dest-attribute-dd="true"]').first(),
			mappingDestAttributeUi.attributesCache || [],
			{ message: MAPPING_DEST_ATTRIBUTE_SELECT_CONNECTION_MESSAGE }
		);

		updateMappingRowDeleteButtons();
	}

	/**
	 * Zoho identifier (#ncIdentifier) and Contacts Field mapping Source identifier
	 * (#source-identifier-dropdown) share one state + save key.
	 * selectedValue = api_name; selectedLabel = field_label.
	 */
	var zohoIdentifierUi = {
		selectedValue: '',
		selectedLabel: '',
		labels: {},
		bound: false
	};

	/** Contacts → secondary identity row when main Destination identifier is CUST_ID. */
	var contactsSecondaryIdentityUi = {
		sourceValue: '',
		sourceLabel: '',
		destValue: CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE,
		destLabel: CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE,
		bound: false
	};

	var SOURCE_IDENTIFIER_DD_ID = 'source-identifier-dropdown';
	var CREATE_ATTR_LEAD_FIELD_DD_ID = 'create-attribute-lead-field-dropdown';

	/** Setup Zoho object label → Create attribute "Lead field" group label. */
	var CREATE_ATTR_LEAD_FIELD_LABELS = {
		Leads: 'Lead field',
		Lead: 'Lead field',
		Contacts: 'Contact field',
		Contact: 'Contact field',
		Accounts: 'Account field',
		Account: 'Account field',
		Deals: 'Deal field',
		Opportunities: 'Opportunity field',
		Tasks: 'Task field',
		Task: 'Task field',
		Calls: 'Call field',
		Call: 'Call field',
		Meetings: 'Meeting field',
		Meeting: 'Meeting field',
		Events: 'Meeting field'
	};

	function getZohoIdentifierDisplayLabel() {
		if (!zohoIdentifierUi.selectedValue) {
			return '';
		}
		return zohoIdentifierUi.selectedLabel
			|| zohoIdentifierUi.labels[zohoIdentifierUi.selectedValue]
			|| zohoIdentifierUi.selectedValue;
	}

	function renderOneIdentifierDropdownDisplay(valueSelector, placeholder) {
		var valueEl = document.querySelector(valueSelector);
		if (!valueEl) {
			return;
		}

		var label = getZohoIdentifierDisplayLabel();
		if (!label) {
			valueEl.textContent = placeholder || 'for ex: Email';
			valueEl.classList.add('is-placeholder');
			return;
		}

		valueEl.textContent = label;
		valueEl.classList.remove('is-placeholder');
	}

	function renderZohoIdentifierDisplay() {
		renderOneIdentifierDropdownDisplay('#ncIdentifierValue', 'for ex: Email');
		renderOneIdentifierDropdownDisplay('#ncIdentifier .dd-value', 'for ex: Email');
		renderOneIdentifierDropdownDisplay('#sourceIdentifierValue', 'for ex: Email');
		renderOneIdentifierDropdownDisplay('#source-identifier-dropdown .dd-value', 'for ex: Email');
	}

	function syncZohoIdentifierListSelection(apiName) {
		var listIds = ['ncIdentifierList', 'sourceIdentifierList'];
		listIds.forEach(function (listId) {
			var list = document.getElementById(listId);
			if (!list) {
				return;
			}
			Array.prototype.forEach.call(list.querySelectorAll('.dd-simple-item'), function (el) {
				if (el.getAttribute('data-value') === apiName) {
					el.classList.add('selected');
				} else {
					el.classList.remove('selected');
				}
			});
		});
	}

	function selectZohoIdentifierValue(apiName, fieldLabel) {
		var label = fieldLabel
			|| zohoIdentifierUi.labels[apiName]
			|| apiName;

		zohoIdentifierUi.selectedValue = apiName || '';
		zohoIdentifierUi.selectedLabel = label || '';

		syncZohoIdentifierListSelection(apiName);
		renderZohoIdentifierDisplay();

		if ($.trim(zohoIdentifierUi.selectedValue || '')) {
			clearDataConfigFieldError('zohoIdentifier');
			clearDataConfigFieldError('sourceIdentifier');
		}
	}

	function populateIdentifierDropdownList(list, fields, options) {
		options = options || {};
		if (!list) {
			return;
		}

		list.innerHTML = '';

		if (options.message) {
			var empty = document.createElement('div');
			empty.className = 'dd-empty';
			empty.textContent = options.message;
			list.appendChild(empty);
			return;
		}

		if (!fields || !fields.length) {
			var noFields = document.createElement('div');
			noFields.className = 'dd-empty';
			noFields.textContent = 'No fields available';
			list.appendChild(noFields);
			return;
		}

		fields.forEach(function (field) {
			var item = document.createElement('div');
			item.className = 'dd-simple-item';
			item.setAttribute('data-value', field.api_name);
			item.setAttribute('data-label', field.field_label);
			item.textContent = field.field_label;
			list.appendChild(item);
		});
	}

	/**
	 * Rebuild Zoho identifier + Source identifier options from sourceFieldsUi.fieldsCache.
	 * Single-select items (dd-simple-item) — no checkboxes.
	 * Does NOT call META.getFields again.
	 */
	function refreshZohoIdentifierDropdown(options) {
		options = options || {};
		var lists = [
			document.getElementById('ncIdentifierList'),
			document.getElementById('sourceIdentifierList')
		];

		var hasList = lists.some(function (list) {
			return !!list;
		});
		if (!hasList) {
			return;
		}

		var pendingValue = $.trim((zohoIdentifierUi && zohoIdentifierUi.selectedValue) || '');
		var pendingLabel = $.trim((zohoIdentifierUi && zohoIdentifierUi.selectedLabel) || '');

		zohoIdentifierUi.selectedValue = '';
		zohoIdentifierUi.selectedLabel = '';
		zohoIdentifierUi.labels = {};

		var fields = sourceFieldsUi.fieldsCache || [];
		if (!options.message && fields.length) {
			fields.forEach(function (field) {
				zohoIdentifierUi.labels[field.api_name] = field.field_label;
			});
		}

		lists.forEach(function (list) {
			if (!list) {
				return;
			}
			populateIdentifierDropdownList(list, fields, options);
		});

		if (pendingValue) {
			selectZohoIdentifierValue(
				pendingValue,
				pendingLabel || zohoIdentifierUi.labels[pendingValue] || pendingValue
			);
			return;
		}

		renderZohoIdentifierDisplay();
	}

	/**
	 * Custom parameters (#customParams) state.
	 * Same shared fieldsCache as Source data / Filter / Zoho identifier.
	 * selected keys = api_name; labels map = api_name → field_label.
	 */
	var customParamsUi = {
		selected: {},
		labels: {},
		bound: false,
		resizeBound: false
	};

	/**
	 * (+N) overflow tooltip state.
	 * Visual pattern = Bootstrap tooltip (same as data-bs-toggle="tooltip" elsewhere).
	 * Hover-through: delayed hide + tip mouseenter keeps it open across the arrow gap.
	 */
	var customParamsMoreTooltipTimer = null;
	var customParamsMoreTooltipAnchor = null;

	function cancelCustomParamsMoreTooltipHide() {
		if (customParamsMoreTooltipTimer) {
			clearTimeout(customParamsMoreTooltipTimer);
			customParamsMoreTooltipTimer = null;
		}
	}

	/** Delay hide so the cursor can cross the arrow gap into the tooltip body. */
	function scheduleCustomParamsMoreTooltipHide() {
		cancelCustomParamsMoreTooltipHide();
		customParamsMoreTooltipTimer = setTimeout(function () {
			hideCustomParamsMoreTooltip();
		}, 180);
	}

	/** Hide the floating (+N) overflow tooltip (appended to document.body). */
	function hideCustomParamsMoreTooltip() {
		cancelCustomParamsMoreTooltipHide();
		customParamsMoreTooltipAnchor = null;
		var tip = document.getElementById('customParamsMoreTooltip');
		if (tip && tip.parentNode) {
			tip.parentNode.removeChild(tip);
		}
	}

	/**
	 * Position Bootstrap-style tooltip BELOW the (+N) badge (arrow points up).
	 * Falls back above if there is not enough room under the trigger.
	 */
	function positionCustomParamsMoreTooltip(tip, anchorEl) {
		if (!tip || !anchorEl) {
			return;
		}

		var rect = anchorEl.getBoundingClientRect();
		// Keep arrow visually touching the (+N) chip (Figma: zero gap).
		var gap = 2;

		// Bootstrap's default .tooltip { max-width: 100% } is 100% of <body>
		// (= full viewport). Force shrink-wrap BEFORE measuring width.
		tip.style.position = 'fixed';
		tip.style.top = '0px';
		tip.style.left = '0px';
		tip.style.transform = 'none';
		tip.style.margin = '0';
		tip.style.width = 'max-content';
		tip.style.maxWidth = '280px';

		var tipWidth = tip.offsetWidth;
		var tipHeight = tip.offsetHeight;
		// Default: below trigger (Figma pattern).
		var placement = 'bottom';
		var top = rect.bottom + gap;
		// Center the tooltip on the (+N) trigger.
		var left = rect.left + (rect.width / 2) - (tipWidth / 2);

		// Stay inside the field box the (+N) belongs to, so the tooltip lines up
		// with that field instead of sticking to the window edge.
		var boundaryEl = anchorEl.closest
			? anchorEl.closest('.datatrsf-mdd-trigger, .dd-trigger')
			: null;
		var boundaryRect = boundaryEl ? boundaryEl.getBoundingClientRect() : null;
		var minLeft = boundaryRect ? boundaryRect.left : 8;
		var maxRight = boundaryRect ? boundaryRect.right : window.innerWidth - 8;

		if (left < minLeft) {
			left = minLeft;
		}
		if (left + tipWidth > maxRight) {
			left = Math.max(minLeft, maxRight - tipWidth);
		}

		// A tooltip wider than its field must still not run off the window.
		if (left + tipWidth > window.innerWidth - 8) {
			left = Math.max(8, window.innerWidth - tipWidth - 8);
		}

		// Not enough room below → flip above.
		if (top + tipHeight > window.innerHeight - 8) {
			placement = 'top';
			top = Math.max(8, rect.top - tipHeight - gap);
		}

		tip.classList.remove('bs-tooltip-top', 'bs-tooltip-bottom');
		tip.classList.add(placement === 'bottom' ? 'bs-tooltip-bottom' : 'bs-tooltip-top');
		tip.style.top = top + 'px';
		tip.style.left = left + 'px';

		// Point the arrow at the center of (+N).
		var arrow = tip.querySelector('.tooltip-arrow');
		if (arrow) {
			var tipRect = tip.getBoundingClientRect();
			var anchorCenter = rect.left + (rect.width / 2);
			var arrowLeft = anchorCenter - tipRect.left - (arrow.offsetWidth / 2);
			arrow.style.position = 'absolute';
			arrow.style.left = Math.max(10, Math.min(tipRect.width - 20, arrowLeft)) + 'px';
			arrow.style.right = 'auto';
			arrow.style.transform = 'none';
			if (placement === 'bottom') {
				// Arrow on top edge of tip, pointing up into (+N).
				arrow.style.bottom = 'auto';
				arrow.style.top = '0';
			} else {
				arrow.style.top = 'auto';
				arrow.style.bottom = '0';
			}
		}
	}

	/**
	 * Show Figma/Bootstrap-matched tooltip for (+N) overflow labels.
	 * Placement: bottom (under (+N), arrow points up). Reuses Bootstrap tooltip
	 * DOM classes used by initBootstrapTooltips() elsewhere in the app.
	 */
	function showCustomParamsMoreTooltip(anchorEl, text) {
		cancelCustomParamsMoreTooltipHide();
		if (!anchorEl || !text) {
			return;
		}

		var existing = document.getElementById('customParamsMoreTooltip');
		if (existing && customParamsMoreTooltipAnchor === anchorEl) {
			var existingInner = existing.querySelector('.tooltip-inner');
			if (existingInner) {
				existingInner.textContent = text;
			}
			positionCustomParamsMoreTooltip(existing, anchorEl);
			return;
		}

		hideCustomParamsMoreTooltip();
		customParamsMoreTooltipAnchor = anchorEl;

		// Same structure Bootstrap Tooltip renders.
		var tip = document.createElement('div');
		tip.id = 'customParamsMoreTooltip';
		tip.className = 'tooltip bs-tooltip-bottom show dd-tags-more-bs-tooltip';
		tip.setAttribute('role', 'tooltip');
		tip.innerHTML =
			'<div class="tooltip-arrow"></div>' +
			'<div class="tooltip-inner"></div>';
		tip.querySelector('.tooltip-inner').textContent = text;
		document.body.appendChild(tip);

		// Hover-through: keep open while cursor is on the tooltip (incl. arrow area).
		tip.addEventListener('mouseenter', function () {
			cancelCustomParamsMoreTooltipHide();
		});
		tip.addEventListener('mouseleave', function () {
			scheduleCustomParamsMoreTooltipHide();
		});

		positionCustomParamsMoreTooltip(tip, anchorEl);
	}

	/** Build one selected-value pill (label + remove "x"). */
	function createCustomParamTag(apiName) {
		var tag = document.createElement('span');
		tag.className = 'dd-tag';
		tag.setAttribute('data-value', apiName);

		var label = document.createElement('span');
		label.textContent = customParamsUi.labels[apiName] || apiName;
		tag.appendChild(label);

		var remove = document.createElement('span');
		remove.className = 'dd-tag-remove';
		remove.setAttribute('role', 'button');
		remove.setAttribute('aria-label', 'Remove');
		remove.innerHTML =
			'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
			'<path d="M18 6 6 18M6 6l12 12"></path></svg>';
		remove.addEventListener('click', function (event) {
			event.stopPropagation();
			toggleCustomParamsValue(apiName);
		});
		tag.appendChild(remove);
		return tag;
	}

	/**
	 * Render Custom parameters pills in a SINGLE row.
	 * Show as many pills as fit; remaining become a right-aligned (+N) badge
	 * with a hover tooltip listing overflowed labels.
	 */
	function renderCustomParamsTags() {
		hideCustomParamsMoreTooltip();

		var tagsEl = document.getElementById('customParamsTags');
		if (!tagsEl) {
			return;
		}

		tagsEl.innerHTML = '';
		var apiNames = Object.keys(customParamsUi.selected);

		if (!apiNames.length) {
			var placeholder = document.createElement('span');
			placeholder.className = 'dd-value';
			placeholder.classList.add('is-placeholder');
			placeholder.textContent = 'for ex: Full name';
			tagsEl.appendChild(placeholder);
			return;
		}

		var pillsWrap = document.createElement('div');
		pillsWrap.className = 'dd-tags-pills';
		tagsEl.appendChild(pillsWrap);

		var containerWidth = tagsEl.clientWidth;
		// If layout is not ready yet, render all then remeasure on next frame (once).
		if (containerWidth < 20) {
			apiNames.forEach(function (apiName) {
				pillsWrap.appendChild(createCustomParamTag(apiName));
			});
			if (tagsEl.getAttribute('data-tags-measuring') !== 'true') {
				tagsEl.setAttribute('data-tags-measuring', 'true');
				window.requestAnimationFrame(function () {
					tagsEl.removeAttribute('data-tags-measuring');
					renderCustomParamsTags();
				});
			}
			return;
		}

		var gap = 8;

		// Measure each pill width (hidden, inside the real container for correct CSS).
		var widths = [];
		apiNames.forEach(function (apiName) {
			var probe = createCustomParamTag(apiName);
			probe.style.visibility = 'hidden';
			pillsWrap.appendChild(probe);
			widths.push(probe.offsetWidth);
			pillsWrap.removeChild(probe);
		});

		// Measure space needed for a (+N) badge (use worst-case digit width).
		var moreProbe = document.createElement('span');
		moreProbe.className = 'dd-tags-more';
		moreProbe.textContent = '(+' + String(apiNames.length) + ')';
		moreProbe.style.visibility = 'hidden';
		tagsEl.appendChild(moreProbe);
		var moreReserve = moreProbe.offsetWidth + gap;
		tagsEl.removeChild(moreProbe);

		function countFitting(budget) {
			var used = 0;
			var count = 0;
			var i;
			for (i = 0; i < widths.length; i += 1) {
				var next = used + (count ? gap : 0) + widths[i];
				// Always allow at least one pill so the field is never empty.
				if (next <= budget || count === 0) {
					used = next;
					count += 1;
				} else {
					break;
				}
			}
			return count;
		}

		// Pass 1: can everything fit without a (+N) badge?
		var totalWidth = 0;
		widths.forEach(function (w, index) {
			totalWidth += w + (index ? gap : 0);
		});

		var visibleCount;
		if (totalWidth <= containerWidth) {
			visibleCount = apiNames.length;
		} else {
			// Pass 2: reserve room for (+N) on the right, then fit pills.
			visibleCount = countFitting(containerWidth - moreReserve);
			if (visibleCount >= apiNames.length) {
				visibleCount = apiNames.length;
			}
		}

		pillsWrap.innerHTML = '';
		var i;
		for (i = 0; i < visibleCount; i += 1) {
			pillsWrap.appendChild(createCustomParamTag(apiNames[i]));
		}

		if (visibleCount < apiNames.length) {
			var overflowNames = apiNames.slice(visibleCount);
			var overflowLabels = overflowNames.map(function (name) {
				return customParamsUi.labels[name] || name;
			});

			var more = document.createElement('span');
			more.className = 'dd-tags-more';
			more.textContent = '(+' + overflowNames.length + ')';
			more.setAttribute('tabindex', '0');
			more.setAttribute('aria-label', overflowLabels.join(', '));

			var tooltipText = overflowLabels.join(', ');

			// Bootstrap-style tooltip with hover-through (delay hide across arrow gap).
			more.addEventListener('mouseenter', function () {
				showCustomParamsMoreTooltip(more, tooltipText);
			});
			more.addEventListener('mouseleave', function () {
				scheduleCustomParamsMoreTooltipHide();
			});
			more.addEventListener('focus', function () {
				showCustomParamsMoreTooltip(more, tooltipText);
			});
			more.addEventListener('blur', function () {
				scheduleCustomParamsMoreTooltipHide();
			});

			// Don't toggle the dropdown when interacting with (+N).
			more.addEventListener('click', function (event) {
				event.stopPropagation();
			});

			tagsEl.appendChild(more);
		}
	}

	function toggleCustomParamsValue(apiName) {
		if (!apiName) {
			return;
		}

		var list = document.getElementById('customParamsList');
		var item = null;
		if (list) {
			Array.prototype.forEach.call(list.querySelectorAll('.dd-check-item'), function (el) {
				if (el.getAttribute('data-value') === apiName) {
					item = el;
				}
			});
		}

		if (customParamsUi.selected[apiName]) {
			delete customParamsUi.selected[apiName];
			if (item) {
				item.classList.remove('selected');
			}
		} else {
			customParamsUi.selected[apiName] = true;
			if (item) {
				item.classList.add('selected');
			}
		}
		renderCustomParamsTags();
		if (Object.keys(customParamsUi.selected).length) {
			clearDataConfigFieldError('customParams');
		}
	}

	/**
	 * Rebuild Custom parameters options from sourceFieldsUi.fieldsCache.
	 * Does NOT call META.getFields again.
	 */
	function refreshCustomParamsDropdown(options) {
		options = options || {};
		var list = document.getElementById('customParamsList');
		if (!list) {
			return;
		}

		customParamsUi.selected = {};
		customParamsUi.labels = {};
		list.innerHTML = '';

		function showMessage(message) {
			var empty = document.createElement('div');
			empty.className = 'dd-empty';
			empty.textContent = message;
			list.appendChild(empty);
			renderCustomParamsTags();
		}

		if (options.message) {
			showMessage(options.message);
			return;
		}

		var fields = sourceFieldsUi.fieldsCache || [];
		if (!fields.length) {
			showMessage('No fields available');
			return;
		}

		fields.forEach(function (field) {
			customParamsUi.labels[field.api_name] = field.field_label;

			var item = document.createElement('div');
			item.className = 'dd-check-item';
			item.setAttribute('data-value', field.api_name);
			item.setAttribute('data-label', field.field_label);

			item.innerHTML =
				'<span class="dd-chk">' +
					'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
						'<path d="M20 6 9 17l-5-5"></path>' +
					'</svg>' +
				'</span>' +
				escapeHtmlText(field.field_label);

			list.appendChild(item);
		});

		renderCustomParamsTags();
	}

	/**
	 * One helper that refreshes every UI that shares fieldsCache:
	 * Filter based on + Zoho identifier + Custom parameters.
	 */
	function refreshSharedFieldConsumers(options) {
		refreshAllFilterFieldDropdowns(options);
		refreshAllMappingSourceFieldDropdowns(options);
		refreshZohoIdentifierDropdown(options);
		refreshSecondarySourceIdentifierDropdown(options);
		refreshCustomParamsDropdown(options);

		if ($('#createAttributePanel').hasClass('show')) {
			refreshCreateAttributeLeadFieldDropdownFromCache();
		}
	}

	/**
	 * Bind Zoho identifier + Source identifier open/search once (lists rebuilt later).
	 * Selection uses the shared .dd-simple-item click handler (single select).
	 */
	function bindIdentifierDropdownSearch(dd, list, searchInput) {
		if (!dd || !list || !searchInput) {
			return;
		}

		function filterList() {
			var query = String(searchInput.value || '').trim().toLowerCase();
			var visibleCount = 0;
			var items = list.querySelectorAll('.dd-simple-item');

			Array.prototype.forEach.call(items, function (item) {
				var value = String(item.getAttribute('data-value') || '').toLowerCase();
				var label = String(item.getAttribute('data-label') || item.textContent || '').toLowerCase();
				var match = !query || value.indexOf(query) !== -1 || label.indexOf(query) !== -1;
				item.style.display = match ? '' : 'none';
				if (match) {
					visibleCount += 1;
				}
			});

			var emptyState = list.querySelector('.dd-empty');
			if (visibleCount === 0 && items.length) {
				if (!emptyState) {
					emptyState = document.createElement('div');
					emptyState.className = 'dd-empty';
					emptyState.textContent = 'No matches found';
					list.appendChild(emptyState);
				} else {
					emptyState.textContent = 'No matches found';
					emptyState.style.display = '';
				}
			} else if (emptyState && items.length) {
				emptyState.parentNode.removeChild(emptyState);
			}
		}

		searchInput.addEventListener('input', filterList);
		searchInput.addEventListener('click', function (event) {
			event.stopPropagation();
		});

		$(dd).on('click', '.dd-trigger', function () {
			searchInput.value = '';
			filterList();
		});
	}

	function initZohoIdentifierDropdown() {
		if (zohoIdentifierUi.bound) {
			return;
		}

		var ncDd = document.getElementById('ncIdentifier');
		var ncList = document.getElementById('ncIdentifierList');
		var ncSearch = document.getElementById('ncIdentifierSearch');
		var sourceDd = document.getElementById(SOURCE_IDENTIFIER_DD_ID);
		var sourceList = document.getElementById('sourceIdentifierList');
		var sourceSearch = document.getElementById('sourceIdentifierSearch');
		var secondarySourceDd = document.getElementById(SECONDARY_SOURCE_IDENTIFIER_DD_ID);
		var secondarySourceList = document.getElementById('secondarySourceIdentifierList');
		var secondarySourceSearch = document.getElementById('secondarySourceIdentifierSearch');

		if (
			(!ncDd || !ncList || !ncSearch)
			&& (!sourceDd || !sourceList || !sourceSearch)
			&& (!secondarySourceDd || !secondarySourceList || !secondarySourceSearch)
		) {
			return;
		}

		zohoIdentifierUi.bound = true;

		bindIdentifierDropdownSearch(ncDd, ncList, ncSearch);
		bindIdentifierDropdownSearch(sourceDd, sourceList, sourceSearch);
		bindIdentifierDropdownSearch(secondarySourceDd, secondarySourceList, secondarySourceSearch);
		renderZohoIdentifierDisplay();
		ensureSecondaryDestinationIdentifierSelected();
		updateContactsSecondaryIdentityVisibility();
	}

	/**
	 * Bind Custom parameters open/search/select once (list HTML is rebuilt later).
	 */
	function initCustomParamsDropdown() {
		var dd = document.getElementById('customParams');
		var list = document.getElementById('customParamsList');
		var searchInput = document.getElementById('customParamsSearch');

		if (!dd || !list || !searchInput || customParamsUi.bound) {
			return;
		}
		customParamsUi.bound = true;

		$(list).on('click', '.dd-check-item', function (event) {
			event.stopPropagation();
			toggleCustomParamsValue(this.getAttribute('data-value'));
		});

		function filterList() {
			var query = String(searchInput.value || '').trim().toLowerCase();
			var visibleCount = 0;
			var items = list.querySelectorAll('.dd-check-item');

			Array.prototype.forEach.call(items, function (item) {
				var value = String(item.getAttribute('data-value') || '').toLowerCase();
				var label = String(item.getAttribute('data-label') || item.textContent || '').toLowerCase();
				var match = !query || value.indexOf(query) !== -1 || label.indexOf(query) !== -1;
				item.style.display = match ? 'flex' : 'none';
				if (match) {
					visibleCount += 1;
				}
			});

			var emptyState = list.querySelector('.dd-empty');
			if (visibleCount === 0 && items.length) {
				if (!emptyState) {
					emptyState = document.createElement('div');
					emptyState.className = 'dd-empty';
					emptyState.textContent = 'No matches found';
					list.appendChild(emptyState);
				} else {
					emptyState.textContent = 'No matches found';
					emptyState.style.display = '';
				}
			} else if (emptyState && items.length) {
				emptyState.parentNode.removeChild(emptyState);
			}
		}

		searchInput.addEventListener('input', filterList);
		searchInput.addEventListener('click', function (event) {
			event.stopPropagation();
		});

		$(dd).on('click', '.dd-trigger', function () {
			searchInput.value = '';
			filterList();
		});

		// Recalculate visible pills / (+N) when the widget width changes.
		if (!customParamsUi.resizeBound) {
			customParamsUi.resizeBound = true;
			window.addEventListener('resize', function () {
				if (Object.keys(customParamsUi.selected).length) {
					renderCustomParamsTags();
				}
			});
		}

		renderCustomParamsTags();
	}

	/**
	 * Updates the heading AND reloads the field multi-select when needed.
	 * - Same module already loaded → keep current field picks (tab switch).
	 * - Module changed / first load → clear picks and fetch new fields.
	 */
	function refreshSourceDataSection(options) {
		options = options || {};
		var forceReload = options.forceReload === true;
		var moduleApiName = getSelectedZohoObjectValue();
		var displayName = getSelectedZohoObjectDisplayName();

		updateSourceDataHeading(displayName);
		updateEventSelectLabel(moduleApiName);

		var listElement = sourceFieldsUi.listElement
			|| document.getElementById('datatrsf-event-export-list-lead');

		if (!listElement) {
			return;
		}

		if (!moduleApiName) {
			sourceFieldsUi.loadedModule = null;
			sourceFieldsUi.fieldsCache = [];
			if (typeof sourceFieldsUi.clearSelection === 'function') {
				sourceFieldsUi.clearSelection();
			}
			listElement.innerHTML = '';
			var hint = document.createElement('div');
			hint.className = 'datatrsf-mdd-empty';
			hint.textContent = 'Select a Zoho object in Setup first.';
			listElement.appendChild(hint);
			refreshSharedFieldConsumers({
				message: 'Select a Zoho object in Setup first.'
			});
			return;
		}

		// Tab switch with the same module — do not wipe the user's field selections.
		if (!forceReload && sourceFieldsUi.loadedModule === moduleApiName) {
			return;
		}

		if (typeof sourceFieldsUi.clearSelection === 'function') {
			sourceFieldsUi.clearSelection();
		}

		loadSourceModuleFields(listElement, moduleApiName);
	}

	/**
	 * Calls Zoho Fields Metadata API for the given module (not hardcoded Leads),
	 * then paints Source data options AND shares the same list with
	 * Filter "based on" + Zoho identifier (one API call only).
	 *
	 * moduleApiName is the Setup dropdown data-value (e.g. Meetings).
	 * META may use a different Entity (e.g. Events for Meetings).
	 */
	function loadSourceModuleFields(listElement, moduleApiName) {
		if (!listElement) {
			return Promise.resolve([]);
		}

		var moduleKey = String(moduleApiName || '').trim();
		var entityName = resolveCrmModuleEntityForMeta(moduleKey);

		function showListMessage(message) {
			listElement.innerHTML = '';
			var emptyState = document.createElement('div');
			emptyState.className = 'datatrsf-mdd-empty';
			emptyState.textContent = message;
			listElement.appendChild(emptyState);
		}

		if (!moduleKey) {
			sourceFieldsUi.fieldsCache = [];
			showListMessage('Select a Zoho object in Setup first.');
			refreshSharedFieldConsumers({
				message: 'Select a Zoho object in Setup first.'
			});
			return Promise.resolve([]);
		}

		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.META || typeof ZOHO.CRM.META.getFields !== 'function') {
			sourceFieldsUi.fieldsCache = [];
			showListMessage('Zoho CRM API is unavailable.');
			refreshSharedFieldConsumers({
				message: 'Zoho CRM API is unavailable.'
			});
			return Promise.resolve([]);
		}

		// Clear previous options before loading the new module.
		showListMessage('Loading fields...');
		// Cache key = Setup data-value (Meetings), not META Entity (Events).
		sourceFieldsUi.loadedModule = moduleKey;
		sourceFieldsUi.fieldsCache = [];
		refreshSharedFieldConsumers({
			message: 'Loading fields...'
		});

		return Promise.resolve(ZOHO.CRM.META.getFields({
			Entity: entityName
		})).then(function (response) {
			// Ignore late responses if the user already picked a different module.
			if (sourceFieldsUi.loadedModule !== moduleKey) {
				return [];
			}

			var fields = [];
			if (response && Array.isArray(response.fields)) {
				fields = response.fields;
			} else if (response && response.data && Array.isArray(response.data.fields)) {
				fields = response.data.fields;
			} else if (Array.isArray(response)) {
				fields = response;
			}

			// One fetch → Source data + Filter based on + Zoho identifier + Custom parameters.
			sourceFieldsUi.fieldsCache = normalizeModuleFields(fields);
			renderSourceModuleFieldOptions(listElement, fields);
			refreshSharedFieldConsumers();
			return sourceFieldsUi.fieldsCache;
		}, function (error) {
			if (sourceFieldsUi.loadedModule !== moduleKey) {
				return [];
			}
			console.error(entityName + ' getFields error:', error);
			sourceFieldsUi.fieldsCache = [];
			showListMessage('Unable to load ' + entityName + ' fields. Please try again.');
			refreshSharedFieldConsumers({
				message: 'Unable to load fields. Please try again.'
			});
			return [];
		});
	}

	// Older name kept so existing exports still work.
	function loadLeadFieldsIntoExportDropdown(listElement) {
		loadSourceModuleFields(listElement, getSelectedZohoObjectValue() || 'Leads');
	}

	/**
	 * Turns the API fields array into dropdown HTML.
	 * data-value  = api_name   (good for saving later)
	 * data-label  = field_label (what the user sees)
	 */
	function renderSourceModuleFieldOptions(listElement, fields) {
		listElement.innerHTML = '';

		if (!fields || !fields.length) {
			var emptyState = document.createElement('div');
			emptyState.className = 'datatrsf-mdd-empty';
			emptyState.textContent = 'No fields available';
			listElement.appendChild(emptyState);
			return;
		}

		fields.forEach(function (field) {
			if (!field || !field.api_name) {
				return;
			}

			var apiName = String(field.api_name);
			var fieldLabel = String(field.field_label || field.api_name);

			var item = document.createElement('div');
			item.className = 'datatrsf-mdd-item';
			item.setAttribute('data-value', apiName);
			item.setAttribute('data-label', fieldLabel);
			item.setAttribute('data-type', String(field.data_type || ''));

			item.innerHTML =
				'<span class="datatrsf-mdd-chk">' +
					'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="4">' +
						'<path d="M20 6 9 17l-5-5"></path>' +
					'</svg>' +
				'</span>' +
				escapeHtmlText(fieldLabel);

			listElement.appendChild(item);
		});
	}

	// Alias used by older name in render path.
	function renderLeadFieldOptions(listElement, fields) {
		renderSourceModuleFieldOptions(listElement, fields);
	}

	// Prevent XSS if a field label ever contains HTML characters.
	function escapeHtmlText(text) {
		return String(text)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	/** Destination "Select event" searchable dropdown (#eventSelect). */
	function initEventSelectDropdown() {
		var root = document.getElementById('eventSelect');
		var trigger = document.getElementById('eventSelectTrigger');
		var valueEl = document.getElementById('eventSelectValue');
		var list = document.getElementById('eventSelectList');
		var searchInput = document.getElementById('eventSelectSearch');
		var createBtn = document.getElementById('eventSelectCreate');
		var createLabel = document.getElementById('eventSelectCreateLabel');

		if (!root || !trigger || !valueEl || !list || !searchInput || !createBtn) {
			return;
		}
		if (root.getAttribute('data-dt-ui-bound') === 'true') {
			return;
		}
		root.setAttribute('data-dt-ui-bound', 'true');

		// Always re-query items so dynamic API options work after Connection changes.
		function getItems() {
			return Array.prototype.slice.call(list.querySelectorAll('.sdd-item'));
		}

		function openPanel() {
			root.classList.add('open');
			searchInput.value = '';
			filterItems('');
			window.requestAnimationFrame(function () {
				positionDropdownPanel({
					rootEl: root,
					panelEl: root.querySelector('.sdd-panel'),
					triggerEl: trigger,
					gap: 6,
					scrollableEl: list,
					fixedHeaderEl: root.querySelector('.sdd-search'),
					maxPanelHeight: 320
				});
				searchInput.focus();
			});
		}

		function closePanel() {
			root.classList.remove('open');
			resetDropdownPanelPosition({
				rootEl: root,
				panelEl: root.querySelector('.sdd-panel'),
				scrollableEl: list
			});
		}

		function selectItem(item) {
			getItems().forEach(function (entry) {
				entry.classList.remove('selected');
			});
			item.classList.add('selected');
			var selected = item.getAttribute('data-value') || '';
			valueEl.textContent = selected;
			valueEl.classList.remove('placeholder');
			valueEl.classList.remove('is-placeholder');
			eventSelectUi.selectedValue = selected;
			closePanel();
			if ($.trim(selected || '')) {
				clearDataConfigFieldError('eventSelect');
			}
		}

		/**
		 * "+ Create New" only when the user typed a query that matches nothing.
		 * Empty search / matching results → hide (standard searchable-create UX).
		 * This dropdown (#eventSelect) is the only .sdd with create — not a shared component.
		 */
		function updateCreateOption(query, visibleMatchCount) {
			var text = $.trim(String(query || ''));
			var showCreate = !!text && Number(visibleMatchCount) === 0;

			createBtn.hidden = !showCreate;
			createBtn.style.display = showCreate ? '' : 'none';

			if (!createLabel) {
				return;
			}
			createLabel.textContent = text ? ('Create "' + text + '"') : 'Create new';
		}

		/**
		 * Find an existing option with the same name (ignore case + trim).
		 * Returns the matching DOM item, or null.
		 */
		function findExistingEventItem(name) {
			var needle = $.trim(String(name || '')).toLowerCase();
			if (!needle) {
				return null;
			}

			var found = null;
			getItems().forEach(function (item) {
				var value = $.trim(String(item.getAttribute('data-value') || '')).toLowerCase();
				if (value === needle) {
					found = item;
				}
			});
			return found;
		}

		function filterItems(query) {
			var normalized = String(query || '').trim().toLowerCase();
			var items = getItems();
			var visibleCount = 0;

			// Status-only list (loading / empty) — no options to match against.
			if (!items.length) {
				var statusEmpty = list.querySelector('.sdd-empty');
				if (statusEmpty && normalized) {
					statusEmpty.textContent = 'No matches found';
				}
				updateCreateOption(query, 0);
				return;
			}

			items.forEach(function (item) {
				var value = String(item.getAttribute('data-value') || '').toLowerCase();
				var match = !normalized || value.indexOf(normalized) !== -1;
				item.style.display = match ? 'block' : 'none';
				if (match) {
					visibleCount += 1;
				}
			});

			var emptyState = list.querySelector('.sdd-empty');
			if (visibleCount === 0) {
				if (!emptyState) {
					emptyState = document.createElement('div');
					emptyState.className = 'sdd-empty';
					emptyState.textContent = 'No matches found';
					list.appendChild(emptyState);
				} else {
					emptyState.textContent = 'No matches found';
				}
			} else if (emptyState) {
				emptyState.parentNode.removeChild(emptyState);
			}

			updateCreateOption(query, visibleCount);
		}

		trigger.addEventListener('click', function (event) {
			event.stopPropagation();
			if (root.classList.contains('open')) {
				closePanel();
			} else {
				openPanel();
			}
		});

		// Event delegation — works for items added later by loadNetcoreEventEntities().
		$(list).on('click', '.sdd-item', function () {
			selectItem(this);
		});

		searchInput.addEventListener('input', function (event) {
			filterItems(event.target.value);
		});
		searchInput.addEventListener('click', function (event) {
			event.stopPropagation();
		});

		createBtn.addEventListener('click', function (event) {
			event.stopPropagation();

			// Use the search box text (trimmed) — no browser prompt.
			var name = $.trim(String(searchInput.value || ''));
			if (!name) {
				showSetupErrorAlert('Enter an event name in the search box to create a new event.');
				return;
			}

			// Scenario 2: name already exists (case-insensitive) → alert, keep selection.
			if (findExistingEventItem(name)) {
				showSetupErrorAlert('"' + name + '" already exists in the list.');
				return;
			}

			// Scenario 1: new name → add option, select it, close dropdown.
			var emptyState = list.querySelector('.sdd-empty');
			if (emptyState) {
				emptyState.parentNode.removeChild(emptyState);
			}

			var newItem = document.createElement('div');
			newItem.className = 'sdd-item';
			newItem.setAttribute('data-value', name);
			newItem.textContent = name;
			list.appendChild(newItem);
			selectItem(newItem);
		});

		document.addEventListener('click', function (event) {
			if (!root.contains(event.target)) {
				closePanel();
			}
		});

		// Default: create option stays hidden until a no-match search.
		updateCreateOption('', 0);
	}

	/**
	 * Generic .dd dropdowns (Zoho identifier, Netcore identifier, Custom params).
	 * Simplified from designer script; skips missing elements safely.
	 */
	function initGenericDdDropdowns() {
		var $root = $('#data-transfer-setup');
		if (!$root.length || $root.attr('data-dd-ui-bound') === 'true') {
			return;
		}
		$root.attr('data-dd-ui-bound', 'true');

		var multiSelectFilters = [];

		function closeAllDd(exceptElement) {
			$root.find('.dd').each(function () {
				if (this !== exceptElement) {
					if ($(this).hasClass('open')) {
						resetDropdownPanelPosition({
							rootEl: this,
							panelEl: $(this).find('.dd-panel')[0] || null,
							scrollableEl: $(this).find('.dd-list')[0] || null
						});
					}
					$(this).removeClass('open');
				}
			});
		}

		function positionDdDropdown(dd) {
			if (!dd) {
				return;
			}

			var $dd = $(dd);
			var $panel = $dd.find('.dd-panel').first();
			positionDropdownPanel({
				rootEl: dd,
				panelEl: $panel[0] || null,
				triggerEl: $dd.find('.dd-trigger')[0] || null,
				gap: 6,
				scrollableEl: $panel.find('.dd-list')[0] || null,
				fixedHeaderEl: $panel.find('.dd-search')[0] || null,
				maxPanelHeight: 280
			});
		}

		$root.on('click.dtDd', '.dd .dd-trigger', function (event) {
			event.stopPropagation();
			var dd = $(this).closest('.dd')[0];
			var isOpen = $(dd).hasClass('open');
			closeAllDd(dd);
			$(dd).toggleClass('open', !isOpen);

			if (!isOpen) {
				var $search = $(dd).find('.dd-search input').first();
				if ($search.length) {
					$search.val('');
					if ($(dd).attr('data-mapping-source-field-dd') === 'true') {
						filterMappingSourceFieldOptions($(dd), '');
					}
					if ($(dd).attr('data-mapping-dest-attribute-dd') === 'true') {
						filterMappingDestAttributeOptions($(dd), '');
					}
					multiSelectFilters.forEach(function (entry) {
						if (entry.dd === dd && typeof entry.filterList === 'function') {
							entry.filterList();
						}
					});
					window.requestAnimationFrame(function () {
						positionDdDropdown(dd);
						$search.trigger('focus');
						// Widths exist only after the panel is placed, so measure last.
						if ($(dd).is(MAPPING_OPTION_DD_SELECTOR)) {
							refreshMappingOptionTooltips($(dd));
						}
					});
				} else {
					window.requestAnimationFrame(function () {
						positionDdDropdown(dd);
						// Widths exist only after the panel is placed, so measure last.
						if ($(dd).is(MAPPING_OPTION_DD_SELECTOR)) {
							refreshMappingOptionTooltips($(dd));
						}
					});
				}
			}
		});

		$root.on('input.dtMappingSourceField', '[data-mapping-source-field-dd="true"] .dd-search-input', function (event) {
			event.stopPropagation();
			filterMappingSourceFieldOptions($(this).closest('.dd'), $(this).val());
		});

		$root.on('click.dtMappingSourceField', '[data-mapping-source-field-dd="true"] .dd-search-input', function (event) {
			event.stopPropagation();
		});

		$root.on('input.dtMappingDestAttribute', '[data-mapping-dest-attribute-dd="true"] .dd-search-input', function (event) {
			event.stopPropagation();
			filterMappingDestAttributeOptions($(this).closest('.dd'), $(this).val());
		});

		$root.on('click.dtMappingDestAttribute', '[data-mapping-dest-attribute-dd="true"] .dd-search-input', function (event) {
			event.stopPropagation();
		});

		// Single-select items (e.g. #sfIdentifier, #ncIdentifier)
		$root.on('click.dtDd', '.dd .dd-simple-item', function (event) {
			event.stopPropagation();
			var $item = $(this);
			var $dd = $item.closest('.dd');

			if ($dd.attr('data-mapping-source-field-dd') === 'true') {
				selectMappingSourceFieldItem($dd, $item);
				$dd.removeClass('open');
				return;
			}

			if ($dd.attr('data-mapping-dest-attribute-dd') === 'true') {
				selectMappingDestAttributeItem($dd, $item);
				$dd.removeClass('open');
				return;
			}

			var value = $item.attr('data-value');
			var label = $item.attr('data-label') || value;

			$dd.find('.dd-simple-item').removeClass('selected');
			$item.addClass('selected');
			$dd.find('.dd-value').first().text(label).removeClass('placeholder');
			$dd.find('.dd-value').first().removeClass('is-placeholder');
			$dd.removeClass('open');

			// Keep Zoho / Source identifier state in sync (api_name + field_label).
			if ($dd.attr('id') === 'ncIdentifier' || $dd.attr('id') === SOURCE_IDENTIFIER_DD_ID) {
				selectZohoIdentifierValue(value, label);
			}

			if ($dd.attr('id') === SECONDARY_SOURCE_IDENTIFIER_DD_ID) {
				selectSecondarySourceIdentifierValue(value, label);
			}

			// Keep Netcore CE / Destination identifier state in sync.
			if ($dd.attr('id') === 'sfIdentifier' || $dd.attr('id') === DESTINATION_IDENTIFIER_DD_ID) {
				selectSfIdentifierByValue(value, label);
			}

			if ($dd.attr('id') === SECONDARY_DESTINATION_IDENTIFIER_DD_ID) {
				ensureSecondaryDestinationIdentifierSelected();
			}
		});

		function initMultiSelect(config) {
			var dd = document.getElementById(config.ddId);
			var tagsEl = document.getElementById(config.tagsId);
			var searchInput = document.getElementById(config.searchId);
			var list = document.getElementById(config.listId);

			if (!dd || !tagsEl || !searchInput || !list) {
				return;
			}

			var checkItems = Array.prototype.slice.call(list.querySelectorAll('.dd-check-item'));
			var selected = {};

			checkItems.forEach(function (item) {
				if (item.classList.contains('selected')) {
					selected[item.getAttribute('data-value')] = true;
				}
			});

			function renderTags() {
				tagsEl.innerHTML = '';
				var values = Object.keys(selected);

				if (!values.length) {
					var placeholder = document.createElement('span');
					placeholder.className = 'dd-value placeholder';
					placeholder.textContent = config.placeholderText;
					tagsEl.appendChild(placeholder);
					return;
				}

				if (config.renderAsText) {
					var text = document.createElement('span');
					text.className = 'dd-value';
					text.textContent = values.join(', ');
					tagsEl.appendChild(text);
					return;
				}

				values.forEach(function (value) {
					var tag = document.createElement('span');
					tag.className = 'dd-tag';

					var label = document.createElement('span');
					label.textContent = value;
					tag.appendChild(label);

					var remove = document.createElement('span');
					remove.className = 'dd-tag-remove';
					remove.innerHTML =
						'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
						'<path d="M18 6 6 18M6 6l12 12"></path></svg>';
					remove.addEventListener('click', function (event) {
						event.stopPropagation();
						toggleValue(value);
					});
					tag.appendChild(remove);
					tagsEl.appendChild(tag);
				});
			}

			function toggleValue(value) {
				var item = null;
				checkItems.forEach(function (entry) {
					if (entry.getAttribute('data-value') === value) {
						item = entry;
					}
				});

				if (selected[value]) {
					delete selected[value];
					if (item) {
						item.classList.remove('selected');
					}
				} else {
					selected[value] = true;
					if (item) {
						item.classList.add('selected');
					}
				}
				renderTags();
			}

			function filterList() {
				var query = String(searchInput.value || '').trim().toLowerCase();
				var visibleCount = 0;

				checkItems.forEach(function (item) {
					var value = String(item.getAttribute('data-value') || '').toLowerCase();
					var match = !query || value.indexOf(query) !== -1;
					item.style.display = match ? 'flex' : 'none';
					if (match) {
						visibleCount += 1;
					}
				});

				var emptyState = list.querySelector('.dd-empty');
				if (visibleCount === 0) {
					if (!emptyState) {
						emptyState = document.createElement('div');
						emptyState.className = 'dd-empty';
						emptyState.textContent = 'No matches found';
						list.appendChild(emptyState);
					}
				} else if (emptyState) {
					emptyState.parentNode.removeChild(emptyState);
				}
			}

			checkItems.forEach(function (item) {
				item.addEventListener('click', function () {
					toggleValue(item.getAttribute('data-value'));
				});
			});

			searchInput.addEventListener('input', filterList);
			searchInput.addEventListener('click', function (event) {
				event.stopPropagation();
			});

			multiSelectFilters.push({ dd: dd, filterList: filterList });
			renderTags();
		}

		// Custom parameters + Zoho identifier are filled from fieldsCache
		// (see initCustomParamsDropdown / initZohoIdentifierDropdown).

		$(document).on('click.dtDdOutside', function (event) {
			if (!$(event.target).closest('#data-transfer-setup .dd').length) {
				closeAllDd(null);
			}
		});
	}

	/**
	 * ------------------------------------------------------------------
	 * Test your configurations panel (#testConfigPanel)
	 * ------------------------------------------------------------------
	 * Dynamic rows (not a hardcoded Task list):
	 *  1) Always first → selected Zoho identifier field (searchable)
	 *  2+) One row per selected Custom parameters field
	 *
	 * Value control type comes from META field data_type
	 * (picklist / date / datetime / boolean / lookup / tag / text…).
	 * Choosing a search result on the identifier row fills ALL rows
	 * from that CRM record (same idea as the teammate reference).
	 */

	var testConfigSearchUi = {
		debounceTimer: null,
		debounceMs: 350,
		perPage: 10,
		/** searchStates[fieldApiName] = { page, hasMore, isFetching, queryVal } */
		searchStates: {}
	};

	/**
	 * Cached CRM records for Run Test enrichment (teammate pattern):
	 *  - identifier → full Task/Lead/… record from Zoho identifier search
	 *  - whoId → Contact/Lead chosen for Who_Id (or fetched from identifier record)
	 *  - whatId → Account/Deal/… chosen for What_Id (or fetched from identifier record)
	 */
	var testConfigSelectedRecords = {
		identifier: null,
		whoId: null,
		whatId: null
	};

	function clearTestConfigSelectedRecords() {
		testConfigSelectedRecords.identifier = null;
		testConfigSelectedRecords.whoId = null;
		testConfigSelectedRecords.whatId = null;
	}

	/** Clear one cached related record when that field is edited/cleared. */
	function clearTestConfigSelectedRecordForField(fieldApiName) {
		var api = String(fieldApiName || '');
		if (api === 'Who_Id') {
			testConfigSelectedRecords.whoId = null;
		} else if (api === 'What_Id') {
			testConfigSelectedRecords.whatId = null;
		}
	}

	/** Find one field from the shared META cache by api_name. */
	function getCachedFieldMeta(apiName) {
		var fields = (sourceFieldsUi && sourceFieldsUi.fieldsCache) || [];
		var i;
		for (i = 0; i < fields.length; i++) {
			if (fields[i].api_name === apiName) {
				return fields[i];
			}
		}
		return null;
	}

	/**
	 * Map Zoho META data_type → Test panel control type.
	 * Beginner tip: this decides date picker vs picklist vs plain text.
	 */
	function mapZohoDataTypeToTestControlType(dataType, apiName) {
		var key = String(dataType || '').toLowerCase();
		var name = String(apiName || '').toLowerCase();

		if (key === 'picklist' || key === 'multiselectpicklist') {
			return 'picklist';
		}
		if (key === 'date') {
			return 'date';
		}
		if (key === 'datetime') {
			return 'datetime';
		}
		if (key === 'boolean') {
			return 'boolean';
		}
		if (
			key === 'lookup'
			|| key === 'ownerlookup'
			|| key === 'multi_module_lookup'
			|| name === 'what_id'
			|| name === 'who_id'
		) {
			return 'lookup';
		}
		if (key === 'tag' || key === 'tags') {
			return 'tag';
		}
		// Recurring fields are often stored as objects / special types.
		if (key.indexOf('recurr') >= 0 || name.indexOf('recurring') >= 0) {
			return 'recurring';
		}
		return 'text';
	}

	function sanitizeSearchTermForCriteria(text) {
		return String(text || '')
			.replace(/[():\\]/g, ' ')
			.replace(/\s+/g, ' ')
			.trim();
	}

	function formatTestConfigDateTime(isoString) {
		try {
			var d = new Date(isoString);
			if (isNaN(d.getTime())) {
				return String(isoString || '');
			}
			return d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
		} catch (error) {
			return String(isoString || '');
		}
	}

	/**
	 * Convert a CRM field value into what we show in the Test value control.
	 * Mirrors the teammate formatValue() helper.
	 */
	function formatTestConfigValue(val, controlType) {
		if (val === null || val === undefined || val === '') {
			return '';
		}

		switch (controlType) {
			case 'lookup':
				return (val && typeof val === 'object') ? String(val.name || '') : String(val);
			case 'boolean':
				if (val === true || val === 'true') {
					return 'Yes';
				}
				if (val === false || val === 'false') {
					return 'No';
				}
				return '';
			case 'recurring':
				return val ? 'Repeats' : 'Does not repeat';
			case 'tag':
				if ($.isArray(val)) {
					return val.map(function (t) {
						return (t && t.name) ? t.name : String(t);
					}).join(', ');
				}
				return String(val);
			case 'date':
				return String(val).slice(0, 10);
			case 'datetime':
				return formatTestConfigDateTime(val);
			default:
				if (val && typeof val === 'object') {
					return String(val.name || val.id || '');
				}
				return String(val);
		}
	}

	function hideZohoIdentifierSearchResults() {
		$('#testConfigPanel .dt-test-id-results').removeClass('open').empty();
	}

	/** SVG markup for the Test panel search / clear icons (same slot). */
	function getTestConfigSearchIconSvg() {
		return (
			'<svg class="field-search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' +
				'<circle cx="11" cy="11" r="7"></circle>' +
				'<path d="m21 21-4.35-4.35"></path>' +
			'</svg>'
		);
	}

	function getTestConfigClearIconSvg() {
		return (
			'<svg class="field-search-icon field-clear-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' +
				'<path d="M18 6 6 18"></path>' +
				'<path d="M6 6l12 12"></path>' +
			'</svg>'
		);
	}

	/**
	 * Toggle search ↔ clear (X) icon for one Test value wrap based on input text.
	 * Empty → search icon; any text → clear icon.
	 */
	function syncTestConfigSearchIcon($wrap) {
		if (!$wrap || !$wrap.length) {
			return;
		}

		var $input = $wrap.find('[data-test-id-search="true"]').first();
		var $btn = $wrap.find('[data-test-search-icon-btn]').first();
		if (!$input.length || !$btn.length) {
			return;
		}

		var hasText = $.trim($input.val() || '') !== '';
		if (hasText) {
			$btn
				.attr('data-icon-mode', 'clear')
				.attr('aria-label', 'Clear value')
				.attr('title', 'Clear')
				.html(getTestConfigClearIconSvg());
		} else {
			$btn
				.attr('data-icon-mode', 'search')
				.attr('aria-label', 'Search')
				.attr('title', 'Search')
				.html(getTestConfigSearchIconSvg());
		}
	}

	/** Clear one searchable Test value: empty input, hide results, restore search icon. */
	function clearTestConfigSearchInput($wrap) {
		if (!$wrap || !$wrap.length) {
			return;
		}

		var $input = $wrap.find('[data-test-id-search="true"]').first();
		if (!$input.length) {
			return;
		}

		if (testConfigSearchUi.debounceTimer) {
			clearTimeout(testConfigSearchUi.debounceTimer);
			testConfigSearchUi.debounceTimer = null;
		}

		var fieldApi = $.trim($input.attr('data-search-api-name') || '');
		var isIdentifierRow = $input.closest('.field-row').attr('data-test-is-identifier') === 'true';

		$input.val('').removeClass('filled');
		$wrap.find('.dt-test-id-results').removeClass('open').empty();
		syncTestConfigSearchIcon($wrap);

		if (isIdentifierRow) {
			clearTestConfigSelectedRecords();
		} else {
			clearTestConfigSelectedRecordForField(fieldApi);
		}
	}

	/** Primary / subtitle / status text for one search result row. */
	function buildSearchResultDisplay(record, moduleName, fieldApiName) {
		var primary =
			record[fieldApiName]
			|| record.Subject
			|| record.Full_Name
			|| record.Account_Name
			|| record.Deal_Name
			|| record.Name
			|| ((record.First_Name || '') + ' ' + (record.Last_Name || '')).trim()
			|| '(No Name)';

		if (primary && typeof primary === 'object') {
			primary = primary.name || primary.id || '(No Name)';
		}

		var subText = (record.Owner && record.Owner.name) ? record.Owner.name : '-';
		var statusText =
			record._dtSearchModule
			|| record.Status
			|| record.Stage
			|| moduleName
			|| '';

		return {
			primary: String(primary),
			subText: String(subText),
			statusText: String(statusText)
		};
	}

	/**
	 * Render search results (with title / subtitle / status pill).
	 * Each item keeps the full record in jQuery data for "fill all rows".
	 */
	function showZohoIdentifierSearchResults($wrap, records, moduleName, fieldApiName, append) {
		var $list = $wrap.find('.dt-test-id-results').first();
		if (!$list.length) {
			return;
		}

		if (!append) {
			$list.empty();
		}

		$list.find('.dt-test-id-results-empty, .dt-test-id-loading').remove();

		if (!records || !records.length) {
			if (!append) {
				$list.append(
					'<div class="dt-test-id-results-empty">No matching records found.</div>'
				);
				$list.addClass('open');
			}
			return;
		}

		records.forEach(function (record) {
			var display = buildSearchResultDisplay(record, moduleName, fieldApiName);
			var $item = $(
				'<div class="dt-test-id-result-item" role="option" tabindex="-1">' +
					'<div class="dt-test-id-result-main">' +
						'<div class="dt-test-id-result-title"></div>' +
					'</div>' +
				'</div>'
			);
			$item.find('.dt-test-id-result-title').text(display.primary);
			$item.data('record', record);
			$item.attr('data-value', display.primary);
			$item.attr('data-record-id', record.id || '');
			$list.append($item);
		});

		$list.addClass('open');

		// Scroll does not bubble — bind directly on this list for infinite scroll.
		$list.off('scroll.dtTestSearch').on('scroll.dtTestSearch', function () {
			var $input = $list.closest('.field-value-wrap').find('[data-test-id-search="true"]').first();
			var apiName = $.trim($input.attr('data-search-api-name') || '');
			var state = testConfigSearchUi.searchStates[apiName];
			if (!state || state.isFetching || !state.hasMore) {
				return;
			}
			var el = $list[0];
			if (el.scrollTop + el.clientHeight >= el.scrollHeight - 20) {
				state.page += 1;
				fetchTestConfigSearchRecords($input, false);
			}
		});
	}

	/**
	 * Display name for a Contact/Lead-style record (Contact_Name in Run Test payload).
	 */
	function getRelatedRecordDisplayName(record) {
		if (!record) {
			return '';
		}
		return $.trim(
			record.Full_Name
			|| ((record.First_Name || '') + ' ' + (record.Last_Name || '')).trim()
			|| record.Account_Name
			|| record.Deal_Name
			|| record.Name
			|| record.name
			|| ''
		);
	}

	/**
	 * After the user picks an identifier record, fetch Who_Id / What_Id details
	 * (when present) so Run Test can send email, mobile, and CRM ids.
	 */
	function loadRelatedRecordsForIdentifier(identifierRecord) {
		testConfigSelectedRecords.whoId = null;
		testConfigSelectedRecords.whatId = null;

		if (!identifierRecord) {
			return;
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.API
			|| typeof ZOHO.CRM.API.getRecord !== 'function'
		) {
			return;
		}

		var seModule = $.trim(identifierRecord.$se_module || '');

		if (identifierRecord.Who_Id && identifierRecord.Who_Id.id) {
			var whoModule =
				(identifierRecord.Who_Id.module && identifierRecord.Who_Id.module.api_name)
				|| identifierRecord.Who_Id.module
				|| (seModule === 'Leads' ? 'Leads' : 'Contacts');
			if (typeof whoModule === 'object') {
				whoModule = whoModule.api_name || 'Contacts';
			}

			ZOHO.CRM.API.getRecord({
				Entity: String(whoModule),
				RecordID: identifierRecord.Who_Id.id
			}).then(function (res) {
				if (res && res.data && res.data[0]) {
					testConfigSelectedRecords.whoId = res.data[0];
					testConfigSelectedRecords.whoId._module = String(whoModule);
				}
			}).catch(function (error) {
				console.warn('Failed to load Who_Id record for Run Test:', error);
			});
		}

		if (identifierRecord.What_Id && identifierRecord.What_Id.id) {
			var whatModule =
				(identifierRecord.What_Id.module && identifierRecord.What_Id.module.api_name)
				|| identifierRecord.What_Id.module
				|| (seModule || 'Accounts');
			if (typeof whatModule === 'object') {
				whatModule = whatModule.api_name || 'Accounts';
			}

			ZOHO.CRM.API.getRecord({
				Entity: String(whatModule),
				RecordID: identifierRecord.What_Id.id
			}).then(function (res) {
				if (res && res.data && res.data[0]) {
					testConfigSelectedRecords.whatId = res.data[0];
					testConfigSelectedRecords.whatId._module = String(whatModule);
				}
			}).catch(function (error) {
				console.warn('Failed to load What_Id record for Run Test:', error);
			});
		}
	}

	/**
	 * Fill every Test panel value control from one CRM record.
	 * Used when the user picks a result from the Zoho identifier search.
	 */
	function populateTestConfigRowsFromRecord(record) {
		if (!record) {
			return;
		}

		testConfigSelectedRecords.identifier = record;
		loadRelatedRecordsForIdentifier(record);

		$('#dt-test-config-rows .field-row').each(function () {
			var $row = $(this);
			var apiName = $.trim($row.attr('data-test-field-key') || '');
			var controlType = $.trim($row.attr('data-test-control-type') || 'text');
			if (!apiName) {
				return;
			}

			var formatted = formatTestConfigValue(record[apiName], controlType);
			var $control = $row.find('[data-test-field-value]').first();
			if (!$control.length) {
				return;
			}

			$control.val(formatted);
			$control.toggleClass('filled', formatted !== '');

			var $wrap = $control.closest('.field-value-wrap');
			if ($wrap.length) {
				syncTestConfigSearchIcon($wrap);
			}
		});
	}

	/**
	 * Polymorphic lookups can point at more than one module.
	 * Searching only Accounts for What_Id returns HTTP 204 when the typed
	 * name belongs to a Lead/Deal instead of an Account.
	 * We search a small safe list in parallel and skip any module that errors.
	 */
	var POLYMORPHIC_SEARCH_MODULES = {
		Who_Id: ['Contacts', 'Leads'],
		What_Id: ['Accounts', 'Leads', 'Deals']
	};

	function isInvalidSearchModule(mod) {
		var name = $.trim(String(mod || ''));
		if (!name) {
			return true;
		}
		var blocked = {
			users: true,
			Users: true,
			null: true,
			undefined: true,
			'[object Object]': true
		};
		return !!blocked[name];
	}

	/**
	 * Pick a searchable CRM module for a non-polymorphic lookup field.
	 * Who_Id / What_Id use POLYMORPHIC_SEARCH_MODULES instead.
	 */
	function resolveTestConfigLookupSearchModule(fieldApiName, metaLookupModule) {
		var apiName = String(fieldApiName || '');

		if (POLYMORPHIC_SEARCH_MODULES[apiName]) {
			return POLYMORPHIC_SEARCH_MODULES[apiName][0];
		}

		var mod = $.trim(String(metaLookupModule || ''));
		if (isInvalidSearchModule(mod)) {
			return '';
		}
		return mod;
	}

	/**
	 * Criteria for one target module. Person modules also handle "first last"
	 * via Full_Name + First/Last split.
	 */
	function buildCriteriaForSearchModule(moduleName, safeValue) {
		if (!safeValue) {
			return '';
		}

		if (moduleName === 'Contacts' || moduleName === 'Leads') {
			var parts = safeValue.split(/\s+/).filter(Boolean);
			var criteria =
				'(Last_Name:starts_with:' + safeValue + ')' +
				'or(First_Name:starts_with:' + safeValue + ')';

			// Two words: also match First_Name = first word AND Last_Name = last word
			if (parts.length >= 2) {
				criteria +=
					'or((First_Name:starts_with:' + parts[0] + ')' +
					'and(Last_Name:starts_with:' + parts[parts.length - 1] + '))';
			}
			return criteria;
		}

		if (moduleName === 'Accounts') {
			return '(Account_Name:starts_with:' + safeValue + ')';
		}
		if (moduleName === 'Deals') {
			return '(Deal_Name:starts_with:' + safeValue + ')';
		}
		return '(Name:starts_with:' + safeValue + ')';
	}

	/**
	 * Build one searchRecord request for a single Entity.
	 * useFieldCriteria=true → identifier search: (FieldApiName:starts_with:...)
	 * useFieldCriteria=false → lookup search: module name fields (Account_Name, etc.)
	 */
	function buildTestConfigSearchParamsForModule(moduleName, searchValue, page, perPage, fieldApiName, useFieldCriteria) {
		var entityName = $.trim(String(moduleName || ''));
		var safeValue = sanitizeSearchTermForCriteria(searchValue);

		if (!entityName || isInvalidSearchModule(entityName)) {
			return null;
		}

		var params = {
			Entity: entityName,
			Config: {
				page: page || 1,
				per_page: perPage || testConfigSearchUi.perPage
			}
		};

		var criteria = '';
		if (useFieldCriteria && fieldApiName) {
			criteria = safeValue
				? '(' + fieldApiName + ':starts_with:' + safeValue + ')'
				: '';
		} else {
			criteria = buildCriteriaForSearchModule(entityName, safeValue);
		}

		if (criteria) {
			params.Type = 'criteria';
			params.Query = criteria;
		}

		return params;
	}

	/**
	 * Modules to search for this field.
	 * What_Id / Who_Id → parallel list; other lookups → one META module;
	 * identifier → Setup Zoho object only.
	 */
	function getTestConfigSearchModules(fieldApiName, lookupModule, isLookupRow) {
		var apiName = String(fieldApiName || '');

		if (POLYMORPHIC_SEARCH_MODULES[apiName]) {
			return POLYMORPHIC_SEARCH_MODULES[apiName].slice();
		}

		if (isLookupRow) {
			var resolved = resolveTestConfigLookupSearchModule(apiName, lookupModule);
			return resolved ? [resolved] : [];
		}

		var setupModule = getSelectedZohoObjectValue();
		return setupModule ? [setupModule] : [];
	}

	/**
	 * Build searchRecord params (single-module helper).
	 * Prefer getTestConfigSearchModules + multi fetch for What_Id / Who_Id.
	 */
	function buildTestConfigSearchParams(fieldApiName, searchValue, page, perPage, lookupModule) {
		var isLookup = !!lookupModule || !!POLYMORPHIC_SEARCH_MODULES[fieldApiName];
		var modules = getTestConfigSearchModules(fieldApiName, lookupModule, isLookup);
		if (!modules.length) {
			return null;
		}
		return buildTestConfigSearchParamsForModule(
			modules[0],
			searchValue,
			page,
			perPage,
			fieldApiName,
			!isLookup
		);
	}

	/** Run one searchRecord call; treat API error / 204 as empty (never throw). */
	function runOneSearchRecord(params) {
		return Promise.resolve(ZOHO.CRM.API.searchRecord(params))
			.then(function (response) {
				if (
					!response
					|| response.status === 'error'
					|| response.code === 'INVALID_MODULE'
				) {
					return [];
				}
				return (response.data) || [];
			})
			.catch(function () {
				return [];
			});
	}

	function fetchTestConfigSearchRecords($input, isInitialLoad) {
		var fieldApiName = $.trim($input.attr('data-search-api-name') || '');
		var lookupModule = $.trim($input.attr('data-search-lookup-module') || '');
		var $wrap = $input.closest('.field-value-wrap');
		var $list = $wrap.find('.dt-test-id-results').first();
		var state = testConfigSearchUi.searchStates[fieldApiName];
		var isLookupRow = !!lookupModule || !!POLYMORPHIC_SEARCH_MODULES[fieldApiName];

		if (!state || !fieldApiName) {
			return;
		}

		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.searchRecord !== 'function') {
			console.error('ZOHO.CRM.API.searchRecord is unavailable.');
			return;
		}

		var modules = getTestConfigSearchModules(fieldApiName, lookupModule, isLookupRow);
		if (!modules.length) {
			showZohoIdentifierSearchResults($wrap, [], '', fieldApiName, false);
			return;
		}

		state.isFetching = true;

		if (isInitialLoad) {
			$list.html('<div class="dt-test-id-loading">Loading...</div>').addClass('open');
		} else {
			$list.append(
				'<div class="dt-test-id-loading dt-test-id-loading-more">Loading more...</div>'
			);
		}

		var requests = modules.map(function (moduleName) {
			var params = buildTestConfigSearchParamsForModule(
				moduleName,
				state.queryVal,
				state.page,
				state.perPage,
				fieldApiName,
				!isLookupRow
			);
			if (!params) {
				return Promise.resolve({ moduleName: moduleName, records: [] });
			}

			return runOneSearchRecord(params).then(function (records) {
				// Tag each record with the module it came from (for the status pill).
				(records || []).forEach(function (rec) {
					if (rec && !rec._dtSearchModule) {
						rec._dtSearchModule = moduleName;
					}
				});
				return { moduleName: moduleName, records: records || [] };
			});
		});

		Promise.all(requests)
			.then(function (results) {
				state.isFetching = false;
				$list.find('.dt-test-id-loading').remove();

				var merged = [];
				var anyFullPage = false;

				results.forEach(function (result) {
					var records = result.records || [];
					if (records.length >= state.perPage) {
						anyFullPage = true;
					}
					merged = merged.concat(records);
				});

				// Polymorphic multi-search: keep paging simple — stop after first page
				// unless a single-module search still has more.
				if (modules.length > 1 || !anyFullPage) {
					state.hasMore = modules.length === 1 && anyFullPage;
				} else {
					state.hasMore = anyFullPage;
				}

				var displayModule = modules.length === 1 ? modules[0] : 'Related';
				showZohoIdentifierSearchResults(
					$wrap,
					merged,
					displayModule,
					fieldApiName,
					!isInitialLoad
				);
			})
			.catch(function (error) {
				console.error('Test config searchRecord error:', error);
				state.isFetching = false;
				$list.find('.dt-test-id-loading').remove();
				if (isInitialLoad) {
					showZohoIdentifierSearchResults($wrap, [], '', fieldApiName, false);
				}
			});
	}

	/** Start (or restart) search for one value input. */
	function initiateTestConfigSearch($input, forced) {
		var fieldApiName = $.trim($input.attr('data-search-api-name') || '');
		var searchValue = $.trim($input.val() || '');
		var $wrap = $input.closest('.field-value-wrap');

		if (!fieldApiName) {
			return;
		}
		if (!forced && !searchValue) {
			hideZohoIdentifierSearchResults();
			return;
		}

		// Close other open result lists in this panel.
		$('#testConfigPanel .dt-test-id-results').each(function () {
			if (this !== $wrap.find('.dt-test-id-results')[0]) {
				$(this).removeClass('open').empty();
			}
		});

		testConfigSearchUi.searchStates[fieldApiName] = {
			page: 1,
			perPage: testConfigSearchUi.perPage,
			hasMore: true,
			isFetching: false,
			queryVal: searchValue
		};

		fetchTestConfigSearchRecords($input, true);
	}

	function scheduleTestConfigSearch($input) {
		if (testConfigSearchUi.debounceTimer) {
			clearTimeout(testConfigSearchUi.debounceTimer);
			testConfigSearchUi.debounceTimer = null;
		}

		var typedText = $.trim($input.val() || '');
		if (typedText.length < 1) {
			hideZohoIdentifierSearchResults();
			return;
		}

		testConfigSearchUi.debounceTimer = setTimeout(function () {
			testConfigSearchUi.debounceTimer = null;
			initiateTestConfigSearch($input, false);
		}, testConfigSearchUi.debounceMs);
	}

	/**
	 * Build the right-side value control for one field type.
	 * Returns a jQuery element (input or select).
	 */
	function buildTestConfigValueControl(options) {
		options = options || {};
		var controlType = options.controlType || 'text';
		var fieldKey = options.fieldKey || '';
		var label = options.label || '';
		var pickOptions = options.pickOptions || [];
		var $control;

		if (controlType === 'picklist') {
			$control = $('<select class="form-control field-value-input value-select"></select>');
			$control.append(
				$('<option></option>').val('').text('- Select ' + label + ' -')
			);
			pickOptions.forEach(function (optStr) {
				$control.append($('<option></option>').val(optStr).text(optStr));
			});
		} else if (controlType === 'boolean') {
			$control = $('<select class="form-control field-value-input value-select"></select>');
			$control.append($('<option></option>').val('').text('- Select -'));
			$control.append($('<option></option>').val('Yes').text('Yes'));
			$control.append($('<option></option>').val('No').text('No'));
		} else if (controlType === 'date') {
			$control = $('<input type="date" class="form-control field-value-input" />');
		} else if (controlType === 'datetime') {
			// Keep as text so CRM datetime strings display cleanly (like the reference).
			$control = $('<input type="text" class="form-control field-value-input" />');
			$control.attr('placeholder', 'mm/dd/yyyy hh:mm');
		} else {
			$control = $('<input type="text" class="form-control field-value-input" />');
		}

		$control.attr('data-test-field-value', fieldKey);
		$control.attr('autocomplete', 'off');
		return $control;
	}

	/**
	 * Build one label + value row.
	 * options:
	 *  - label, fieldKey, controlType, pickOptions
	 *  - isIdentifier / hasSearch / lookupModule
	 */
	function buildTestConfigFieldRow(options) {
		options = options || {};
		var label = options.label || '';
		var fieldKey = options.fieldKey || '';
		var controlType = options.controlType || 'text';
		var hasSearch = options.hasSearch === true;
		var lookupModule = options.lookupModule || '';

		var $row = $('<div class="field-row"></div>');
		$row.attr('data-test-field-key', fieldKey);
		$row.attr('data-test-control-type', controlType);
		if (options.isIdentifier) {
			$row.attr('data-test-is-identifier', 'true');
		}

		// Left: field name (disabled look — same as designer).
		var $nameCol = $('<div class="field-col"></div>');
		var $nameInput = $(
			'<input type="text" class="form-control field-name-input" disabled />'
		);
		$nameInput.val(label);
		$nameCol.append($nameInput);
		$row.append($nameCol);

		// Right: typed value control.
		var $valueCol = $('<div class="field-col"></div>');
		var $control = buildTestConfigValueControl({
			controlType: controlType,
			fieldKey: fieldKey,
			label: label,
			pickOptions: options.pickOptions || []
		});

		if (hasSearch) {
			$valueCol.addClass('field-value-wrap');
			$control.attr('data-test-id-search', 'true');
			$control.attr('data-search-api-name', fieldKey);
			if (lookupModule) {
				$control.attr('data-search-lookup-module', lookupModule);
			}
			if (options.isIdentifier) {
				$control.attr('placeholder', 'Search or type a value');
			}
			$valueCol.append($control);
			$valueCol.append(
				'<button type="button" class="field-search-icon-btn" data-test-search-icon-btn ' +
					'data-icon-mode="search" aria-label="Search" title="Search">' +
					getTestConfigSearchIconSvg() +
				'</button>'
			);
			$valueCol.append(
				'<div class="dt-test-id-results" role="listbox" aria-label="Search results"></div>'
			);
		} else {
			$valueCol.append($control);
		}

		$row.append($valueCol);
		return $row;
	}

	/** Build row options from one cached META field (+ identifier flag). */
	function buildTestRowOptionsFromFieldMeta(apiName, fieldLabel, isIdentifier) {
		var meta = getCachedFieldMeta(apiName) || {};
		var controlType = mapZohoDataTypeToTestControlType(meta.data_type, apiName);
		var lookupModule = resolveTestConfigLookupSearchModule(
			apiName,
			meta.lookup_module || ''
		);
		var hasSearch = false;

		if (isIdentifier) {
			hasSearch = true;
			lookupModule = '';
		} else if (apiName === 'Who_Id' || apiName === 'What_Id') {
			// Always searchable — polymorphic (may not be data_type "lookup" in META).
			hasSearch = true;
		} else if (controlType === 'lookup' && lookupModule) {
			hasSearch = true;
		}

		return {
			label: fieldLabel || meta.field_label || apiName,
			fieldKey: apiName,
			controlType: controlType,
			pickOptions: meta.pick_list_values || [],
			isIdentifier: !!isIdentifier,
			hasSearch: hasSearch,
			lookupModule: lookupModule
		};
	}

	/**
	 * Rebuild all Test panel rows from current UI state.
	 * Call this every time the Test panel opens.
	 */
	function populateTestConfigRows() {
		if (isContactsImportTargetSelected()) {
			populateContactsTestConfigRows();
			return;
		}
		populateEventTestConfigRows();
	}

	/** Event → Zoho identifier + Custom parameters. */
	function populateEventTestConfigRows() {
		var $rowsWrap = $('#dt-test-config-rows');
		if (!$rowsWrap.length) {
			return;
		}

		$rowsWrap.empty();
		testConfigSearchUi.searchStates = {};
		clearTestConfigSelectedRecords();

		// ----- Row 1 (always first): selected Zoho identifier -----
		var zohoIdApi = (zohoIdentifierUi && zohoIdentifierUi.selectedValue) || '';
		var zohoIdLabel = $.trim(
			(zohoIdentifierUi && (
				zohoIdentifierUi.selectedLabel
				|| (zohoIdentifierUi.labels && zohoIdentifierUi.labels[zohoIdApi])
				|| zohoIdApi
			)) || ''
		);

		$rowsWrap.append(
			buildTestConfigFieldRow(
				buildTestRowOptionsFromFieldMeta(
					zohoIdApi || 'zoho_identifier',
					zohoIdLabel || 'Zoho identifier',
					true
				)
			)
		);

		// ----- Remaining rows: selected Custom parameters -----
		// Skip any custom param that is already the Zoho identifier (avoids duplicate Subject rows).
		var selectedApiNames = Object.keys((customParamsUi && customParamsUi.selected) || {});
		selectedApiNames.forEach(function (apiName) {
			if (zohoIdApi && apiName === zohoIdApi) {
				return;
			}
			var fieldLabel =
				(customParamsUi.labels && customParamsUi.labels[apiName]) || apiName;
			$rowsWrap.append(
				buildTestConfigFieldRow(
					buildTestRowOptionsFromFieldMeta(apiName, fieldLabel, false)
				)
			);
		});

		hideTestConfigStatusBoxes();
	}

	/** Contacts → Source identifier + mapped Source field rows (same pattern as Event). */
	function populateContactsTestConfigRows() {
		var $rowsWrap = $('#dt-test-config-rows');
		if (!$rowsWrap.length) {
			return;
		}

		$rowsWrap.empty();
		testConfigSearchUi.searchStates = {};
		clearTestConfigSelectedRecords();

		var sourceIdApi = (zohoIdentifierUi && zohoIdentifierUi.selectedValue) || '';
		var sourceIdLabel = $.trim(
			(zohoIdentifierUi && (
				zohoIdentifierUi.selectedLabel
				|| (zohoIdentifierUi.labels && zohoIdentifierUi.labels[sourceIdApi])
				|| sourceIdApi
			)) || ''
		) || 'Source identifier';

		$rowsWrap.append(
			buildTestConfigFieldRow(
				buildTestRowOptionsFromFieldMeta(
					sourceIdApi || 'source_identifier',
					sourceIdLabel,
					true
				)
			)
		);

		if (isContactsSecondaryIdentityRequired()) {
			var secondarySourceApi = $.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceValue) || '');
			var secondarySourceLabel = $.trim(
				(contactsSecondaryIdentityUi && (
					contactsSecondaryIdentityUi.sourceLabel
					|| (zohoIdentifierUi.labels && zohoIdentifierUi.labels[secondarySourceApi])
					|| secondarySourceApi
				)) || ''
			) || 'Source identifier';

			$rowsWrap.append(
				buildTestConfigFieldRow(
					buildTestRowOptionsFromFieldMeta(
						secondarySourceApi || 'secondary_source_identifier',
						secondarySourceLabel,
						false
					)
				)
			);
		}

		collectContactsTestSourceFieldRows().forEach(function (fieldRow) {
			if (sourceIdApi && fieldRow.apiName === sourceIdApi) {
				return;
			}
			if (isContactsSecondaryIdentityRequired()) {
				var secondaryApi = $.trim((contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceValue) || '');
				if (secondaryApi && fieldRow.apiName === secondaryApi) {
					return;
				}
			}
			$rowsWrap.append(
				buildTestConfigFieldRow(
					buildTestRowOptionsFromFieldMeta(
						fieldRow.apiName,
						fieldRow.label,
						false
					)
				)
			);
		});

		hideTestConfigStatusBoxes();
	}

	/** Hide loading / success / error status boxes in the Test panel. */
	function hideTestConfigStatusBoxes() {
		$('#statusLoading, #statusSuccess, #statusError, #statusTimeout').removeClass('show');
		hideContactsTestErrorStatus();
	}

	/** Show only the loading status box. */
	function showTestConfigLoadingStatus() {
		hideTestConfigStatusBoxes();
		hideContactsTestErrorStatus();
		$('#statusLoading').addClass('show');
	}

	/** Show only the success status box (replace any prior status). */
	function showTestConfigSuccessStatus(message) {
		hideTestConfigStatusBoxes();
		var $box = $('#statusSuccess');
		if (!$box.length) {
			return;
		}
		var $text = $box.find('[data-test-status-text]').first();
		if ($text.length) {
			$text.text(message || RUN_TEST_SUCCESS_MESSAGE);
		}
		$box.addClass('show');
	}

	/** Show only the error status box (same slot as success; replace any prior status). */
	function showTestConfigErrorStatus(message) {
		hideTestConfigStatusBoxes();
		var $box = $('#statusError');
		if (!$box.length) {
			return;
		}
		var $text = $box.find('[data-test-status-text]').first();
		if ($text.length) {
			$text.text(message || RUN_TEST_ERROR_MESSAGE);
		}
		$box.addClass('show');
	}

	function escapeContactsGatewayHtml(value) {
		return String(value == null ? '' : value)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function formatContactsGatewayJsonValueToken(token) {
		var value = $.trim(String(token || ''));
		if (!value) {
			return '';
		}

		var trailingComma = '';
		if (value.charAt(value.length - 1) === ',') {
			trailingComma = '<span class="json-punct">,</span>';
			value = value.slice(0, -1).trim();
		}

		if (value.charAt(0) === '"' && value.charAt(value.length - 1) === '"') {
			return '<span class="json-string">' + escapeContactsGatewayHtml(value) + '</span>' + trailingComma;
		}

		if (/^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test(value)) {
			return '<span class="json-number">' + escapeContactsGatewayHtml(value) + '</span>' + trailingComma;
		}

		if (value === '{' || value === '}' || value === '[' || value === ']') {
			return '<span class="json-punct">' + escapeContactsGatewayHtml(value) + '</span>' + trailingComma;
		}

		return escapeContactsGatewayHtml(value) + trailingComma;
	}

	function formatContactsGatewayJsonLine(line) {
		var indentMatch = String(line || '').match(/^(\s*)(.*)$/);
		var indent = (indentMatch && indentMatch[1] || '').replace(/ /g, '&nbsp;');
		var content = $.trim(indentMatch && indentMatch[2] || '');

		if (!content) {
			return indent;
		}

		var keyMatch = content.match(/^"([^"]+)":\s*(.*)$/);
		if (keyMatch) {
			return indent
				+ '<span class="json-key">"' + escapeContactsGatewayHtml(keyMatch[1]) + '"</span>'
				+ '<span class="json-punct">:</span> '
				+ formatContactsGatewayJsonValueToken(keyMatch[2]);
		}

		if (/^[\[\]{},]+$/.test(content)) {
			return indent + '<span class="json-punct">' + escapeContactsGatewayHtml(content) + '</span>';
		}

		return indent + formatContactsGatewayJsonValueToken(content);
	}

	/** Populate #gatewayJsonCard using the existing static markup/classes. */
	function populateContactsGatewayJsonCard(data) {
		var $card = $('#gatewayJsonCard');
		if (!$card.length) {
			return '';
		}

		var jsonStr = '';
		try {
			jsonStr = JSON.stringify(data, null, 2);
		} catch (error) {
			jsonStr = String(data || '');
		}

		contactsTestErrorUi.lastGatewayJson = jsonStr;

		var linesHtml = jsonStr.split('\n').map(function (line, index) {
			return (
				'<div class="json-line">' +
				'<span class="json-line-num">' + (index + 1) + '</span>' +
				formatContactsGatewayJsonLine(line) +
				'</div>'
			);
		}).join('');

		$card.children('.json-line').remove();
		var $copyWrap = $card.find('.gateway-json-copy-wrap').first();
		if ($copyWrap.length) {
			$copyWrap.before(linesHtml);
		} else {
			$card.find('#copyJsonBtn').before(linesHtml);
		}
		$card.addClass('show');
		return jsonStr;
	}

	function hideContactsGatewayCopiedToast() {
		if (contactsTestErrorUi.copyToastTimer) {
			clearTimeout(contactsTestErrorUi.copyToastTimer);
			contactsTestErrorUi.copyToastTimer = null;
		}

		$('#contactsGatewayCopiedToast').removeClass('show');
	}

	function showContactsGatewayCopiedToast() {
		var $toast = $('#contactsGatewayCopiedToast');
		if (!$toast.length) {
			return;
		}

		hideContactsGatewayCopiedToast();
		$toast.addClass('show');
		contactsTestErrorUi.copyToastTimer = setTimeout(function () {
			$toast.removeClass('show');
			contactsTestErrorUi.copyToastTimer = null;
		}, 2000);
	}

	function copyContactsGatewayJsonToClipboard(jsonText) {
		if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
			return navigator.clipboard.writeText(jsonText);
		}

		return new Promise(function (resolve, reject) {
			var $temp = $('<textarea readonly></textarea>').val(jsonText).appendTo('body');
			$temp[0].select();

			try {
				if (document.execCommand('copy')) {
					resolve();
				} else {
					reject(new Error('execCommand copy failed'));
				}
			} catch (copyError) {
				reject(copyError);
			}

			$temp.remove();
		});
	}

	function hideContactsTestErrorStatus() {
		var $box = $('#statusErrorContactTest');
		if (!$box.length) {
			return;
		}

		$box.removeClass('show');
		$('#gatewayJsonCard').removeClass('show');
		contactsTestErrorUi.lastGatewayJson = '';
		hideContactsGatewayCopiedToast();
	}

	/** Parsed business payload from Contacts RUN TEST details.output (never the Zoho wrapper). */
	function getContactsRunTestParsedOutput(response) {
		return parseEventListingOutput(response);
	}

	/**
	 * Contacts RUN TEST success — only from parsed details.output, not outer code: "success".
	 */
	function isContactsRunTestResponseSuccessful(response) {
		if (!response) {
			return false;
		}

		var output = getContactsRunTestParsedOutput(response);
		if (!output || typeof output !== 'object') {
			return false;
		}

		var businessResult = getRunTestBusinessResult(output);

		if (businessResult && businessResult !== output) {
			if (isRunTestBusinessFailure(businessResult)) {
				return false;
			}
			if (isRunTestBusinessSuccess(businessResult)) {
				return true;
			}
		}

		if (isRunTestBusinessFailure(output) || isRunTestBusinessFailure(businessResult)) {
			return false;
		}

		if (isRunTestBusinessSuccess(businessResult) || isRunTestBusinessSuccess(output)) {
			return true;
		}

		return false;
	}

	/** Collect every user-facing message from parsed details.output (Contacts RUN TEST). */
	function collectContactsRunTestErrorMessages(response) {
		var messages = [];
		var output = getContactsRunTestParsedOutput(response);
		var businessResult = (output && getRunTestBusinessResult(output)) || output;

		if (businessResult && $.isArray(businessResult.errors)) {
			businessResult.errors.forEach(function (err) {
				if (err && $.trim(err.message || '')) {
					messages.push(String(err.message));
				} else if (typeof err === 'string' && $.trim(err)) {
					messages.push(String(err));
				}
			});
		}

		if (!messages.length && businessResult) {
			['description', 'message', 'error', 'response'].forEach(function (key) {
				var text = $.trim(businessResult[key] || '');
				if (text) {
					messages.push(String(businessResult[key]));
				}
			});
		}

		if (!messages.length) {
			var fallback = getRunTestErrorMessage(response, RUN_TEST_ERROR_MESSAGE);
			if ($.trim(fallback || '')) {
				messages.push(fallback);
			}
		}

		return messages;
	}

	function getContactsRunTestDisplayOutput(response) {
		var parsed = getContactsRunTestParsedOutput(response);
		if (parsed && typeof parsed === 'object') {
			return parsed;
		}

		if (response && typeof response === 'object') {
			return response;
		}

		return {
			message: String(response || RUN_TEST_ERROR_MESSAGE)
		};
	}

	/** Contacts-only failed RUN TEST → existing #statusErrorContactTest banner. */
	function showContactsTestErrorStatus(response) {
		hideTestConfigStatusBoxes();

		var $box = $('#statusErrorContactTest');
		if (!$box.length) {
			return;
		}

		var messages = collectContactsRunTestErrorMessages(response);
		$box.find('.error-text').first().text(
			messages.length ? messages.join(' ') : RUN_TEST_ERROR_MESSAGE
		);

		populateContactsGatewayJsonCard(getContactsRunTestDisplayOutput(response));
		$box.addClass('show');
	}

	function hideContactsTestTimeoutStatus() {
		$('#statusTimeout').removeClass('show');
	}

	function showContactsTestTimeoutStatus() {
		hideTestConfigStatusBoxes();
		$('#statusTimeout').addClass('show');
	}

	/** Collect text/code/status hints used to detect connector/API timeout (Contacts RUN TEST). */
	function collectContactsRunTestTimeoutSignals(errorOrResponse) {
		var signals = [];

		if (errorOrResponse == null) {
			return signals;
		}

		if (typeof errorOrResponse === 'string') {
			signals.push(errorOrResponse);
			return signals;
		}

		if (typeof errorOrResponse !== 'object') {
			signals.push(String(errorOrResponse));
			return signals;
		}

		['message', 'description', 'error', 'response', 'code', 'status'].forEach(function (key) {
			if (errorOrResponse[key] != null && errorOrResponse[key] !== '') {
				signals.push(String(errorOrResponse[key]));
			}
		});

		if (errorOrResponse.details && typeof errorOrResponse.details === 'object') {
			['message', 'output', 'http_status'].forEach(function (key) {
				if (errorOrResponse.details[key] != null && errorOrResponse.details[key] !== '') {
					signals.push(String(errorOrResponse.details[key]));
				}
			});
		}

		var output = getContactsRunTestParsedOutput(errorOrResponse);
		if (output && typeof output === 'object') {
			['message', 'description', 'error', 'response', 'code', 'status', 'status_code', 'statusCode'].forEach(function (key) {
				if (output[key] != null && output[key] !== '') {
					signals.push(String(output[key]));
				}
			});

			var businessResult = getRunTestBusinessResult(output);
			if (businessResult && typeof businessResult === 'object') {
				['message', 'description', 'error', 'response', 'code', 'status', 'status_code', 'statusCode'].forEach(function (key) {
					if (businessResult[key] != null && businessResult[key] !== '') {
						signals.push(String(businessResult[key]));
					}
				});
			}
		}

		return signals;
	}

	/**
	 * Contacts RUN TEST timeout — SDK reject, HTTP 408/504, or gateway "timed out" / "no response".
	 * Mirrors connector-style timeout detection used elsewhere in the app.
	 */
	function isContactsRunTestTimeoutError(errorOrResponse) {
		var signals = collectContactsRunTestTimeoutSignals(errorOrResponse);
		if (!signals.length) {
			return false;
		}

		var combined = signals.join(' ').toLowerCase();
		if (
			/timeout|timed\s*out|time-out|no\s+response|gateway\s+timeout|connection\s+timed|etimedout|econnaborted|request timed out|read timed out/.test(combined)
		) {
			return true;
		}

		var output = getContactsRunTestParsedOutput(errorOrResponse);
		var statusValues = [
			errorOrResponse && errorOrResponse.status,
			output && output.status,
			output && output.data && output.data.status
		];

		if (statusValues.some(function (status) {
			return String(status || '').toLowerCase() === 'timeout';
		})) {
			return true;
		}

		var codeCandidates = [
			errorOrResponse && errorOrResponse.code,
			errorOrResponse && errorOrResponse.status_code,
			errorOrResponse && errorOrResponse.statusCode,
			errorOrResponse && errorOrResponse.details && errorOrResponse.details.http_status,
			output && output.code,
			output && output.status_code,
			output && output.statusCode
		];

		return codeCandidates.some(function (code) {
			var codeNum = Number(code);
			return !isNaN(codeNum) && (codeNum === 408 || codeNum === 504);
		});
	}

	function handleContactsRunTestResponse(response) {
		if (isContactsRunTestTimeoutError(response)) {
			resetTestRunSuccessfulFlag();
			showContactsTestTimeoutStatus();
			return;
		}

		if (isContactsRunTestResponseSuccessful(response)) {
			hideContactsTestTimeoutStatus();
			hideContactsTestErrorStatus();
			markTestRunSuccessful();
			showTestConfigSuccessStatus(RUN_TEST_SUCCESS_MESSAGE);
			return;
		}

		resetTestRunSuccessfulFlag();
		hideContactsTestTimeoutStatus();
		showContactsTestErrorStatus(response);
	}

	function handleContactsRunTestFailure(error) {
		resetTestRunSuccessfulFlag();

		if (isContactsRunTestTimeoutError(error)) {
			showContactsTestTimeoutStatus();
			return;
		}

		hideContactsTestTimeoutStatus();
		showContactsTestErrorStatus(error);
	}

	/**
	 * Contacts-only RUN TEST execute (initial run + Retry test).
	 * Caches payload/reqData so #retryTestBtn can replay the same request.
	 */
	function executeContactsRunTest(payload, reqData) {
		contactsTestErrorUi.lastRunTestPayload = payload;
		contactsTestErrorUi.lastRunTestReqData = reqData;

		showTestConfigLoadingStatus();

		var $btn = $('#runTestBtn');
		var $retryBtn = $('#retryTestBtn');
		$btn.prop('disabled', true).addClass('is-running');
		$retryBtn.prop('disabled', true);

		return ZOHO.CRM.FUNCTIONS.execute(CONTACTS_RUN_TEST_FUNCTION, reqData)
			.then(function (response) {
				$btn.prop('disabled', false).removeClass('is-running');
				$retryBtn.prop('disabled', false);
				handleContactsRunTestResponse(response);
			})
			.catch(function (error) {
				$btn.prop('disabled', false).removeClass('is-running');
				$retryBtn.prop('disabled', false);
				console.error('Contacts Run Test error:', error);
				handleContactsRunTestFailure(error);
			});
	}

	function retryContactsRunTest(event) {
		if (event) {
			event.preventDefault();
			event.stopPropagation();
		}

		if (!isContactsImportTargetSelected()) {
			return;
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			showTestConfigErrorStatus(RUN_TEST_UNAVAILABLE_MESSAGE);
			return;
		}

		if (contactsTestErrorUi.lastRunTestReqData) {
			executeContactsRunTest(
				contactsTestErrorUi.lastRunTestPayload,
				contactsTestErrorUi.lastRunTestReqData
			);
			return;
		}

		handleRunTestClick(event);
	}

	/**
	 * Collect Test panel values as a flat map: { FieldApiName: value, ... }.
	 * First occurrence of a field name wins (dedupes identifier + custom-param overlap).
	 */
	function collectTestConfigFieldValues() {
		var valuesByField = {};

		$('#dt-test-config-rows .field-row').each(function () {
			var $row = $(this);
			if ($row.attr('data-test-readonly-row') === 'true') {
				return;
			}
			var fieldApi = $.trim($row.attr('data-test-field-key') || '');
			if (!fieldApi || fieldApi.indexOf('__') === 0) {
				return;
			}
			// Already captured (e.g. duplicate Subject from identifier + custom params).
			if (Object.prototype.hasOwnProperty.call(valuesByField, fieldApi)) {
				return;
			}

			var $control = $row.find('[data-test-field-value]').first();
			valuesByField[fieldApi] = $control.length
				? $.trim($control.val() || '')
				: '';
		});

		return valuesByField;
	}

	/** Read the Zoho identifier row's current Value (first / marked identifier row). */
	function getTestConfigIdentifierValue() {
		var $row = $('#dt-test-config-rows .field-row[data-test-is-identifier="true"]').first();
		if (!$row.length) {
			$row = $('#dt-test-config-rows .field-row').first();
		}
		if (!$row.length) {
			return '';
		}
		return $.trim($row.find('[data-test-field-value]').first().val() || '');
	}

	function buildRunTestTaskDetailsBase(taskData) {
		var identifierRecord = testConfigSelectedRecords.identifier;
		var whoRecord = testConfigSelectedRecords.whoId;
		var whatRecord = testConfigSelectedRecords.whatId;

		taskData.id = identifierRecord && identifierRecord.id
			? String(identifierRecord.id)
			: '';

		if (whoRecord && whoRecord.id) {
			taskData.Who_Id = String(whoRecord.id);
			taskData.Contact_Name = getRelatedRecordDisplayName(whoRecord);
		} else if (
			identifierRecord
			&& identifierRecord.Who_Id
			&& identifierRecord.Who_Id.id
		) {
			taskData.Who_Id = String(identifierRecord.Who_Id.id);
			taskData.Contact_Name = String(identifierRecord.Who_Id.name || '');
		} else {
			taskData.Who_Id = '';
			taskData.Contact_Name = '';
		}

		if (whatRecord && whatRecord.id) {
			taskData.What_Id = String(whatRecord.id);
			taskData.Related_To = getRelatedRecordDisplayName(whatRecord);
		} else if (
			identifierRecord
			&& identifierRecord.What_Id
			&& identifierRecord.What_Id.id
		) {
			taskData.What_Id = String(identifierRecord.What_Id.id);
			taskData.Related_To = String(identifierRecord.What_Id.name || '');
		} else {
			taskData.What_Id = '';
			taskData.Related_To = '';
		}

		var sourceObj = whoRecord || whatRecord;
		if (sourceObj) {
			taskData.email = sourceObj.Email || sourceObj.Account_Email || '';
			taskData.mobile = sourceObj.Mobile || sourceObj.Phone || '';
		} else {
			taskData.email = '';
			taskData.mobile = '';
		}

		taskData.se_module = identifierRecord
			? String(identifierRecord.$se_module || '')
			: '';

		taskData.netcoreCeIdentifier = $.trim(
			(sfIdentifierUi && sfIdentifierUi.selectedValue) || ''
		);
		taskData.is_identifier_primary = isSelectedNetcoreCeIdentifierPrimary();
		taskData.connection_id = $.trim(getSelectedConnectionId() || '');

		return taskData;
	}

	function buildEventRunTestPayload() {
		var taskData = buildRunTestTaskDetailsBase(collectTestConfigFieldValues());
		taskData.activity_name = $.trim(
			(eventSelectUi && eventSelectUi.selectedValue) || ''
		);
		return {
			task_details: taskData
		};
	}

	/** Selected audience_id values of one Contacts list multi-select (state, DOM fallback). */
	function collectContactsListIdsForRunTest(selectedStore, listSelector) {
		var ids = [];
		var selected = (selectedStore && selectedStore.selected) || {};
		var keys = Object.keys(selected);

		if (keys.length) {
			keys.forEach(function (id) {
				ids.push(String(id));
			});
			return ids;
		}

		$(listSelector + ' .datatrsf-mdd-item.selected').each(function () {
			var value = $.trim($(this).attr('data-value') || '');
			if (value) {
				ids.push(String(value));
			}
		});

		return ids;
	}

	/**
	 * Contacts RUN TEST → ContactList audience_id values.
	 * The key never changes; only its source does — Add reads the add-list
	 * picker, Remove reads the remove-list picker (List route only, same as SAVE).
	 */
	function getSelectedContactsListIdsForRunTest() {
		if (getContactsWhatDoWithForSave() === 'remove') {
			if (getContactsRemoveFromForSave() !== 'list') {
				return [];
			}

			return collectContactsListIdsForRunTest(
				contactsListUi && contactsListUi.removeLists,
				'#datatrsf-mdd-remove-list'
			);
		}

		return collectContactsListIdsForRunTest(
			contactsListUi && contactsListUi.addLists,
			'#datatrsf-mdd-list'
		);
	}

	/** Contacts RUN TEST → Source field api_name → Destination attribute_name from #mappingRows. */
	function buildContactsRunTestFieldsMapping() {
		var mapping = {};

		if (!isContactsFieldMappingTableRequired()) {
			return mapping;
		}

		$('#mappingRows .mapping-row').each(function () {
			var $row = $(this);
			var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
			var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();

			var sourceKey = $.trim($sourceDd.attr('data-selected-value') || '');
			var destValue = $.trim($destDd.attr('data-selected-value') || '');

			if (!sourceKey || !destValue) {
				return;
			}

			mapping[sourceKey] = destValue;
		});

		return mapping;
	}

	/** Contacts RUN TEST → Destination attribute_name → TEST popup value for mapped Source field. */
	function buildContactsRunTestZohoResult() {
		var testValues = collectTestConfigFieldValues();
		var result = {};

		if (!isContactsFieldMappingTableRequired()) {
			return result;
		}

		$('#mappingRows .mapping-row').each(function () {
			var $row = $(this);
			var $sourceDd = $row.find('[data-mapping-source-field-dd="true"]').first();
			var $destDd = $row.find('[data-mapping-dest-attribute-dd="true"]').first();

			var sourceKey = $.trim($sourceDd.attr('data-selected-value') || '');
			var destKey = $.trim($destDd.attr('data-selected-value') || '');

			if (!sourceKey || !destKey) {
				return;
			}

			result[destKey] = Object.prototype.hasOwnProperty.call(testValues, sourceKey)
				? testValues[sourceKey]
				: '';
		});

		return result;
	}

	function buildContactsRunTestPayload() {
		var taskData = buildRunTestTaskDetailsBase(collectTestConfigFieldValues());
		taskData.activity_name = '';
		var payload = {
			task_details: taskData,
			ContactList: getSelectedContactsListIdsForRunTest(),
			ActionType: getContactsWhatDoWithForSave(),
			FieldsMapping: buildContactsRunTestFieldsMapping(),
			ZohoResult: buildContactsRunTestZohoResult()
		};

		if (isContactsSecondaryIdentityRequired()) {
			payload.second_sourceIdentifier = $.trim(
				(contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.sourceValue) || ''
			);
			payload.second_destinaitonIdentifier = $.trim(
				(contactsSecondaryIdentityUi && contactsSecondaryIdentityUi.destValue)
					|| CONTACTS_SECONDARY_DEST_IDENTIFIER_VALUE
			);
		}

		return payload;
	}

	function buildRunTestPayload() {
		var config = getRunTestApiConfig();
		if (config && typeof config.buildPayload === 'function') {
			return config.buildPayload();
		}
		return buildEventRunTestPayload();
	}

	eventRunTestApiConfig.buildPayload = buildEventRunTestPayload;
	contactsRunTestApiConfig.buildPayload = buildContactsRunTestPayload;

	/**
	 * JSON.stringify for FUNCTIONS.execute arguments.
	 *
	 * Zoho's FUNCTIONS_EXECUTE transport often form-encodes the arguments string
	 * (application/x-www-form-urlencoded), which turns spaces into "+". If that
	 * "+" is not decoded before JSON.parse on the CRM side, Deluge sees
	 * "test+1" / "Not+Started". Escaping spaces as \u0020 keeps the JSON free of
	 * raw spaces so form-encoding cannot corrupt them; JSON.parse still yields
	 * real spaces.
	 *
	 * We do NOT call encodeURIComponent on field values.
	 */
	function stringifyRunTestArguments(payload) {
		return JSON.stringify(payload).replace(/ /g, '\\u0020');
	}

	/**
	 * Decide if a Run Test FUNCTIONS.execute response means business success.
	 *
	 * Zoho wrapper often looks like:
	 *   { code: "success", details: { output: "<json string>" }, message: "..." }
	 * The outer code only means the Deluge function ran. Real result is inside
	 * details.output — prefer nested data.status when present:
	 *   { status: "success", data: { status: "failed", code: 400, description: "..." } }
	 *   { status: "failed", description: "Unauthorized access.", code: 401 }
	 *   { status: "success", data: { status: "success", ... } }
	 */
	function getRunTestBusinessResult(output) {
		if (!output || typeof output !== 'object') {
			return null;
		}

		// Preferred shape: details.output.data.{ status, code, description, errors }
		var nested = output.data;
		if (nested && typeof nested === 'object' && !$.isArray(nested)) {
			return nested;
		}

		return output;
	}

	function isRunTestBusinessFailure(result) {
		if (!result || typeof result !== 'object') {
			return false;
		}

		var status = String(result.status || '').toLowerCase();
		if (
			status === 'failed'
			|| status === 'error'
			|| status === 'failure'
			|| result.success === false
		) {
			return true;
		}

		var codeNum = Number(result.status_code || result.statusCode || result.code);
		if (!isNaN(codeNum) && codeNum >= 400) {
			return true;
		}

		if ($.isArray(result.errors) && result.errors.length > 0) {
			return true;
		}

		return false;
	}

	function isRunTestBusinessSuccess(result) {
		if (!result || typeof result !== 'object') {
			return false;
		}

		if (isRunTestBusinessFailure(result)) {
			return false;
		}

		var status = String(result.status || '').toLowerCase();
		return (
			status === 'success'
			|| status === 'ok'
			|| result.success === true
		);
	}

	function isRunTestResponseSuccessful(response) {
		if (!response) {
			return false;
		}

		if (
			response.status === 'error'
			|| response.code === 'ERROR'
			|| response.code === 'INVALID_DATA'
		) {
			return false;
		}

		var output = parseEventListingOutput(response);
		if (output && typeof output === 'object') {
			var businessResult = getRunTestBusinessResult(output);

			// Nested data.status / code wins over a misleading outer output.status.
			if (businessResult && businessResult !== output) {
				if (isRunTestBusinessFailure(businessResult)) {
					return false;
				}
				if (isRunTestBusinessSuccess(businessResult)) {
					return true;
				}
			}

			if (isRunTestBusinessFailure(output) || isRunTestBusinessFailure(businessResult)) {
				return false;
			}

			if (isRunTestBusinessSuccess(businessResult) || isRunTestBusinessSuccess(output)) {
				return true;
			}

			// details.output was present but had no clear success flag.
			return false;
		}

		// No parseable details.output — fall back to Zoho wrapper code only.
		return String(response.code || '').toLowerCase() === 'success';
	}

	/**
	 * Pull a human-readable error string from a failed Run Test response.
	 * Prefers details.output.data.description / errors, then top-level output fields.
	 */
	function getRunTestErrorMessage(response, fallback) {
		var output = parseEventListingOutput(response);
		if (output && typeof output === 'object') {
			var businessResult = getRunTestBusinessResult(output) || output;

			if (
				businessResult.response
				&& typeof businessResult.response === 'string'
				&& $.trim(businessResult.response)
			) {
				return String(businessResult.response);
			}

			if ($.isArray(businessResult.errors) && businessResult.errors.length) {
				var firstError = businessResult.errors[0];
				if (firstError && firstError.message) {
					return String(firstError.message);
				}
				if (typeof firstError === 'string' && $.trim(firstError)) {
					return String(firstError);
				}
			}

			if (businessResult.description) {
				return String(businessResult.description);
			}
			if (businessResult.message) {
				return String(businessResult.message);
			}
			if (businessResult.error) {
				return String(businessResult.error);
			}

			// Fall back to outer output fields if nested data had none.
			if (output !== businessResult) {
				if (output.description) {
					return String(output.description);
				}
				if (output.message) {
					return String(output.message);
				}
			}
		}

		// Do not surface Zoho's generic "function executed successfully" as the error.
		if (response && response.message) {
			var outerMessage = String(response.message);
			if (!/function executed successfully/i.test(outerMessage)) {
				return outerMessage;
			}
		}

		return fallback || RUN_TEST_ERROR_MESSAGE;
	}

	/**
	 * RUN TEST click:
	 *  1) Require Zoho identifier Value only
	 *  2) Call netcore0__Run_Test with task_details (incl. netcoreCeIdentifier)
	 *  3) Show success / error status box below the rows (replace prior status)
	 */
	function handleRunTestClick(event) {
		if (event) {
			event.preventDefault();
		}

		if (isContactsImportTargetSelected()) {
			hideContactsTestErrorStatus();
			hideContactsTestTimeoutStatus();
		}

		var identifierValue = getTestConfigIdentifierValue();
		if (!identifierValue) {
			showTestConfigErrorStatus(RUN_TEST_VALIDATION_MESSAGE);
			return;
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			showTestConfigErrorStatus(RUN_TEST_UNAVAILABLE_MESSAGE);
			return;
		}

		var payload = buildRunTestPayload();
		var testApiConfig = getRunTestApiConfig();
		var reqData = {
			arguments: stringifyRunTestArguments(payload)
		};

		if (isContactsImportTargetSelected()) {
			executeContactsRunTest(payload, reqData);
			return;
		}

		showTestConfigLoadingStatus();

		var $btn = $('#runTestBtn');
		$btn.prop('disabled', true).addClass('is-running');

		ZOHO.CRM.FUNCTIONS.execute(testApiConfig.functionName, reqData)
			.then(function (response) {
				$btn.prop('disabled', false).removeClass('is-running');

				if (isRunTestResponseSuccessful(response)) {
					hideContactsTestErrorStatus();
					markTestRunSuccessful();
					showTestConfigSuccessStatus(RUN_TEST_SUCCESS_MESSAGE);
					return;
				}

				resetTestRunSuccessfulFlag();
				hideContactsTestErrorStatus();
				showTestConfigErrorStatus(getRunTestErrorMessage(response));
			})
			.catch(function (error) {
				$btn.prop('disabled', false).removeClass('is-running');
				console.error('Run Test error:', error);
				resetTestRunSuccessfulFlag();

				hideContactsTestErrorStatus();
				showTestConfigErrorStatus(
					getRunTestErrorMessage(error, RUN_TEST_ERROR_MESSAGE)
				);
			});
	}

	/**
	 * Bind one-time delegated UI events for Data configuration.
	 * Called from bindEventScreenEvents (safe even before HTML is injected).
	 */
	function bindDataConfigurationEvents() {
		// NEXT → Setup validates + saves, then Data configuration.
		// On Data configuration (Contacts) → Field mapping (no forward tab click).
		$('body').on('click', '#dt-setup-next-btn', function (event) {
			event.preventDefault();

			if (
				getActiveWizardStep() === WIZARD_STEP.DATA_CONFIG
				&& isContactsImportTargetSelected()
			) {
				attemptNavigateToFieldMapping();
				return;
			}

			attemptNavigateToDataConfiguration({ showNextAlert: true });
		});

		// Tab clicks: only ever go back. Moving forward is the NEXT button's job
		// alone, so a forward tab click is ignored — no validation, no save.
		$('body').on('click', '#data-transfer-setup .datatrsf-step-item[data-dt-step]', function (event) {
			event.preventDefault();
			navigateToWizardStepFromTab($(this));
		});

		// Keyboard support (Enter / Space) for accessibility.
		$('body').on('keydown', '#data-transfer-setup .datatrsf-step-item[data-dt-step]', function (event) {
			if (event.key !== 'Enter' && event.key !== ' ') {
				return;
			}
			event.preventDefault();
			navigateToWizardStepFromTab($(this));
		});

		// Filter card toggle (default OFF → body hidden via CSS / init).
		$('body').on('change', '#datatrsf-toggle-input', function () {
			var $body = $('#datatrsf-filter-body');
			if (!$body.length) {
				return;
			}

			if ($(this).is(':checked')) {
				// Measure after the slide finishes — a collapsing element has no
				// usable width, so a label would never register as clipped.
				$body.stop(true, true).slideDown(refreshFilterTruncationTooltips);
			} else {
				// Switching off starts the filters over — one empty row. Only the
				// screen is cleared; CRM keeps its data until the user saves.
				resetFilterRowsToSingleEmpty();

				$body.stop(true, true).slideUp();
				// Filters off → those row errors no longer apply.
				$('#datatrsf-rows-wrap [data-dc-filter]').removeClass('has-error');
				$('#datatrsf-rows-wrap [data-dc-filter-error]').text('').attr('hidden', true).hide();
			}
		});

		// Live-clear filter Value errors as the user types / picks a date.
		$('body').on(
			'input.dtDcFilterValueClear change.dtDcFilterValueClear',
			'#datatrsf-rows-wrap [data-filter-value-input="true"]',
			function () {
				var $row = $(this).closest('.datatrsf-filter-row');
				if (!$row.length) {
					return;
				}
				if ($.trim($(this).val() || '')) {
					clearFilterColError($row, 'value');
				}
			}
		);

		// Close filter-row CDDs when clicking outside them.
		$(document).on('click.dtFilterCdd', function (event) {
			if (!$(event.target).closest('#data-transfer-setup .data-configuration-sec .datatrsf-cdd').length) {
				$('#data-transfer-setup .data-configuration-sec .datatrsf-cdd-panel').removeClass('open');
				$('#data-transfer-setup .data-configuration-sec .datatrsf-cdd-trigger').removeClass('open');
			}
		});

		// Test button: validate before opening the Test panel (Event + Contacts).
		$('body').on('click', '#dt-test-config-btn, #dt-field-mapping-test-btn', function (event) {
			handleTestConfigButtonClick(event);
		});

		// Contacts destination — Add / Remove and dependent fields.
		$('body').on(
			'change',
			'#dt-data-config-dest-contacts input[name="datatrsf-dest-action"], ' +
			'#dt-data-config-dest-contacts input[name="datatrsf-dest-remove-from"], ' +
			'#dt-data-config-dest-contacts #addToListToggle',
			function () {
				// Add ↔ Remove switch: the other side's picks must not carry over.
				if (this.name === 'datatrsf-dest-action') {
					resetContactsListSelections();
					resetContactsFieldMappingRows();
				}

				try {
					// Add to list(s): every tick and un-tick starts the picker empty.
					if (this.id === 'addToListToggle') {
						clearContactsListSelection(contactsListUi && contactsListUi.addLists);
					}

					// Landing back on the List route starts its picker empty too.
					if (this.name === 'datatrsf-dest-remove-from' && this.value === 'list') {
						clearContactsListSelection(contactsListUi && contactsListUi.removeLists);
					}
				} catch (listSelectionResetError) {
					console.error('List selection reset failed:', listSelectionResetError);
				}

				updateContactsDestinationFieldsVisibility();
			}
		);

		// START EXPORT: require RUN TEST success, or confirm via test-export-modal.
		$('body').on('click', '#dt-start-export-btn', function (event) {
			handleStartExportClick(event);
		});

		// test-export-modal → close and open Test Your Configuration (same as TEST).
		$('body').on('click', '#dt-test-export-run-test-btn', function (event) {
			event.preventDefault();
			event.stopPropagation();
			var $modal = $('#test-export-modal');
			$modal.one('hidden.bs.modal', function () {
				handleTestConfigButtonClick(event);
			});
			hideTestExportConfirmModal();
		});

		// test-export-modal → close and run existing START EXPORT flow.
		$('body').on('click', '#dt-test-export-anyway-btn', function (event) {
			event.preventDefault();
			event.stopPropagation();
			var $modal = $('#test-export-modal');
			$modal.one('hidden.bs.modal', function () {
				proceedWithStartExport();
			});
			hideTestExportConfirmModal();
		});

		// Dismiss bottom validation / NEXT error banner independently.
		$('body').on('click', '[data-dt-alert-dismiss="next"]', function (event) {
			event.preventDefault();
			event.stopPropagation();
			hideSetupNextStepAlert();
		});

		// Dismiss Test modal error status box only (does not touch the page banner).
		$('body').on('click', '[data-dt-status-dismiss="error"]', function (event) {
			event.preventDefault();
			event.stopPropagation();
			$('#statusError').removeClass('show');
		});

		// Contacts RUN TEST error banner — dismiss + copy gateway JSON.
		$('body').on('click', '#errorClose', function (event) {
			event.preventDefault();
			event.stopPropagation();
			hideContactsTestErrorStatus();
		});

		$('body').on('click', '#copyJsonBtn', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var jsonText = $.trim(contactsTestErrorUi.lastGatewayJson || '');
			if (!jsonText) {
				return;
			}

			copyContactsGatewayJsonToClipboard(jsonText)
				.then(function () {
					showContactsGatewayCopiedToast();
				})
				.catch(function (error) {
					console.error('copyJsonBtn clipboard error:', error);
				});
		});

		// RUN TEST: validate identifier Value, then call netcore0__Run_Test.
		$('body').on('click', '#runTestBtn', function (event) {
			handleRunTestClick(event);
		});

		// Contacts RUN TEST timeout — retry with the last prepared payload.
		$('body').on('click', '#retryTestBtn', function (event) {
			retryContactsRunTest(event);
		});

		// Test panel: rebuild Zoho identifier + Custom parameters rows each time it opens.
		$('body').on('show.bs.offcanvas', '#testConfigPanel', function () {
			hideZohoIdentifierSearchResults();
			populateTestConfigRows();
		});

		// Create attribute panel: populate from Setup Connection + shared fields cache.
		$('body').on('show.bs.offcanvas', '#createAttributePanel', function (event) {
			var trigger = event.relatedTarget;
			if (trigger) {
				createAttributeUi.targetDestAttributeDd = $(trigger).closest('[data-mapping-dest-attribute-dd="true"]');
			}
			refreshCreateAttributePanel();
		});

		$('body').on('hidden.bs.offcanvas', '#createAttributePanel', function () {
			syncSetupToastStacking();
		});

		$('body').on('click', '#saveCreateAttrBtn', function (event) {
			handleSaveCreateAttributeClick(event);
		});

		$('body').on('click.dtCreateAttr', '#create-attribute-lead-field-dropdown .dd-trigger', function (event) {
			event.stopPropagation();
			var $dd = $(this).closest('.dd');
			var isOpen = $dd.hasClass('open');
			$('#createAttributePanel .dd').not($dd).removeClass('open');
			$dd.toggleClass('open', !isOpen);

			if (!isOpen) {
				var $search = $dd.find('.dd-search-input').first();
				$search.val('');
				filterCreateAttributeLeadFieldOptions($dd, '');
				setTimeout(function () {
					$search.trigger('focus');
				}, 0);
			}
		});

		$('body').on('click.dtCreateAttr', '#create-attribute-lead-field-dropdown .dd-search-input', function (event) {
			event.stopPropagation();
		});

		$('body').on('input.dtCreateAttr', '#create-attribute-lead-field-dropdown .dd-search-input', function (event) {
			event.stopPropagation();
			filterCreateAttributeLeadFieldOptions($(this).closest('.dd'), $(this).val());
		});

		$('body').on('click.dtCreateAttr', '#create-attribute-lead-field-dropdown .dd-simple-item', function (event) {
			event.stopPropagation();
			var $item = $(this);
			var $dd = $item.closest('.dd');
			selectCreateAttributeLeadFieldItem($dd, $item);
			$dd.removeClass('open');
		});

		$('body').on('click.dtCreateAttr', function (event) {
			if (!$(event.target).closest('#create-attribute-lead-field-dropdown').length) {
				$('#create-attribute-lead-field-dropdown').removeClass('open');
			}
		});

		// Debounced search while typing in a searchable Test value field.
		$('body').on('input', '#testConfigPanel [data-test-id-search="true"]', function () {
			var $input = $(this);
			var $wrap = $input.closest('.field-value-wrap');
			var fieldApi = $.trim($input.attr('data-search-api-name') || '');
			var isIdentifierRow = $input.closest('.field-row').attr('data-test-is-identifier') === 'true';

			$input.toggleClass('filled', $.trim($input.val() || '') !== '');
			syncTestConfigSearchIcon($wrap);

			// Typing invalidates a previously selected CRM record for that field.
			if (isIdentifierRow) {
				testConfigSelectedRecords.identifier = null;
				testConfigSelectedRecords.whoId = null;
				testConfigSelectedRecords.whatId = null;
			} else {
				clearTestConfigSelectedRecordForField(fieldApi);
			}

			scheduleTestConfigSearch($input);
		});

		// Clear (X) icon: empty the value, close results, restore search icon.
		$('body').on('click', '#testConfigPanel [data-test-search-icon-btn]', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var $btn = $(this);
			if ($btn.attr('data-icon-mode') !== 'clear') {
				return;
			}

			clearTestConfigSearchInput($btn.closest('.field-value-wrap'));
		});

		// Mark picklist / date / other controls as filled when changed.
		$('body').on('change input', '#testConfigPanel [data-test-field-value]', function () {
			var $el = $(this);
			$el.toggleClass('filled', $.trim($el.val() || '') !== '');
		});

		// Click a search result:
		// - Identifier search → fill ALL rows + cache record (+ fetch Who/What)
		// - Who_Id / What_Id lookup → fill that field + cache related record
		// - Other lookup → fill that field only
		$('body').on('click', '#testConfigPanel .dt-test-id-result-item', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var $item = $(this);
			var record = $item.data('record');
			var value = $item.attr('data-value') || $.trim($item.find('.dt-test-id-result-title').text());
			var $wrap = $item.closest('.field-value-wrap');
			var $input = $wrap.find('[data-test-id-search="true"]').first();
			var fieldApi = $.trim($input.attr('data-search-api-name') || '');
			var isLookupOnly = $.trim($input.attr('data-search-lookup-module') || '') !== '';
			var isIdentifierRow = $input.closest('.field-row').attr('data-test-is-identifier') === 'true';

			if (record && (isIdentifierRow || !isLookupOnly)) {
				populateTestConfigRowsFromRecord(record);
			} else if (record && fieldApi === 'Who_Id') {
				testConfigSelectedRecords.whoId = record;
				if (record._dtSearchModule) {
					testConfigSelectedRecords.whoId._module = record._dtSearchModule;
				}
				$input.val(value);
				$input.toggleClass('filled', value !== '');
				syncTestConfigSearchIcon($wrap);
			} else if (record && fieldApi === 'What_Id') {
				testConfigSelectedRecords.whatId = record;
				if (record._dtSearchModule) {
					testConfigSelectedRecords.whatId._module = record._dtSearchModule;
				}
				$input.val(value);
				$input.toggleClass('filled', value !== '');
				syncTestConfigSearchIcon($wrap);
			} else {
				$input.val(value);
				$input.toggleClass('filled', value !== '');
				syncTestConfigSearchIcon($wrap);
			}

			hideZohoIdentifierSearchResults();
		});

		// Close results when clicking outside a value wrap.
		$(document).on('click.dtTestIdSearch', function (event) {
			if (!$(event.target).closest('#testConfigPanel .field-value-wrap').length) {
				hideZohoIdentifierSearchResults();
			}
		});

		// Escape closes the results list.
		$('body').on('keydown', '#testConfigPanel [data-test-id-search="true"]', function (event) {
			if (event.key === 'Escape') {
				hideZohoIdentifierSearchResults();
			}
		});
	}

	/**
	 * Run after the event screen HTML is in the DOM.
	 * Sets initial visibility and binds element-specific dropdown logic once.
	 */
	function initDataConfigurationUi() {
		ensureFilterRowGlobals();

		// Initial state (designer): config section + filter body hidden.
		$('#data-transfer-setup .data-configuration-sec').hide();
		$('#datatrsf-filter-body').hide();
		showDataTransferWizardStep(0);

		initFieldExportMultiSelect();
		initEventSelectDropdown();
		initZohoIdentifierDropdown();
		initCustomParamsDropdown();
		initGenericDdDropdowns();
		initFieldMappingRows();
		initContactsListMultiSelects();
		initCreateAttributePanel();
		updateContactsDestinationFieldsVisibility();
		updateFieldMappingWizardVisibility();
	}

	// Attach after functions exist (clearer than relying on hoisting for beginners).
	window.DataTransferModule.goToStep = goToStep;
	window.DataTransferModule.showDataTransferWizardStep = showDataTransferWizardStep;
	window.DataTransferModule.initDataConfigurationUi = initDataConfigurationUi;
	window.DataTransferModule.loadLeadFieldsIntoExportDropdown = loadLeadFieldsIntoExportDropdown;
	window.DataTransferModule.refreshSourceDataSection = refreshSourceDataSection;
	window.DataTransferModule.loadSourceModuleFields = loadSourceModuleFields;

});
