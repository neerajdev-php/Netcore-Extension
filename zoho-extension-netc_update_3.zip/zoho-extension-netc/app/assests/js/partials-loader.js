jQuery(function ($) {
	var partials = [
		{ container: '#section-common-loader', url: 'partials/modals/common-loader.html' },
		{ container: '#section-connection-shared-modals', url: 'partials/modals/connection-shared-modals.html' },
		{ container: '#section-nav-netcore', url: 'partials/sections/nav-netcore.html' },
		{ container: '#section-nav-connections', url: 'partials/sections/nav-connections.html' },
		{ container: '#section-nav-connections-list', url: 'partials/sections/nav-connections-list.html' },
		{ container: '#section-nav-connections-view-edit', url: 'partials/sections/nav-connections-view-edit.html' }
	];

	function showEarlyLoader() {
		var loaderElement = document.getElementById('common-loader-popup');
		if (!loaderElement || typeof bootstrap === 'undefined') {
			return;
		}

		bootstrap.Modal.getOrCreateInstance(loaderElement, {
			backdrop: 'static',
			keyboard: false
		}).show();
	}

	var loadPromises = partials.map(function (partial) {
		return $(partial.container).load(partial.url);
	});

	$.when.apply($, loadPromises).then(function () {
		// Show loader as soon as partials exist — before app scripts / PageLoad
		showEarlyLoader();
		return $.getScript('assests/js/netcore.js');
	}).then(function () {
		return $.getScript('assests/js/connections.js');
	}).then(function () {
		// Data Transfer is modular: script registers tab handlers;
		// screens load on demand when the tab is opened.
		return $.getScript('assests/js/data-transfer.js');
	}).then(function () {
		// Listing module registers itself with DataTransferModule.
		return $.getScript('assests/js/data-transfer-listing.js');
	}).fail(function (error) {
		console.error('Failed to load widget partials or scripts:', error);
		document.body.classList.remove('widget-loading');
	});
});