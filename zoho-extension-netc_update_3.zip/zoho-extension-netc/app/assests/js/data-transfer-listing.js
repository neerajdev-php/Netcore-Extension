/**
 * Data Transfer Listing module
 * - Owns listing fetch / show helpers
 * - Stays separate from Setup / Data Configuration (data-transfer.js)
 * - Listing UI (search, sort, filter, detail panel) binds AFTER listing HTML loads
 */
jQuery(function ($) {
	var DATA_TRANSFER_ENTITY = 'netcore0__Data_Transfer';
	var LISTING_SCREEN_KEY = 'listing';
	var LISTING_ROOT_SELECTOR = '#data-transfer-listing';
	// One self-contained partial: header, filter panel, chips, empty state,
	// table, sync detail panel and the action modals.
	var LISTING_URL = 'partials/sections/data-transfer-screens/dt-listing-filter-and-sync.html';

	var FILTER_DROPDOWN_IDS = ['statusFilter', 'sourceFilter', 'destinationFilter'];

	/**
	 * Saved netcore0__Source → the name shown for it.
	 * Setup offers "Opportunities" but saves Zoho's module API name, "Deals".
	 * Display only — CRM keeps "Deals".
	 */
	var SOURCE_DISPLAY_LABELS = {
		Deals: 'Opportunities'
	};

	/** Source value as the listing shows it — unmapped values pass through. */
	function getSourceDisplayLabel(sourceValue) {
		var savedValue = $.trim(sourceValue == null ? '' : String(sourceValue));

		return SOURCE_DISPLAY_LABELS[savedValue] || savedValue;
	}

	/**
	 * Dropdown id → state key, record field and chip label.
	 *
	 * toDisplayValue — for a filter whose options carry the shown name rather
	 * than the saved one. Source is the only such case: its "Opportunities"
	 * option has to meet a record holding "Deals".
	 */
	var FILTER_FIELDS = {
		statusFilter: { key: 'status', field: 'netcore0__Data_Transfer_Status', label: 'Status' },
		sourceFilter: {
			key: 'source',
			field: 'netcore0__Source',
			label: 'Source',
			toDisplayValue: getSourceDisplayLabel
		},
		destinationFilter: { key: 'destination', field: 'netcore0__Netcore_Object', label: 'Destination' }
	};

	// The item the markup ships as selected. It is only what the dropdown
	// *shows* while untouched — see listingState.sortKey for why nothing is
	// actually sorted until the user picks something.
	var DEFAULT_SORT_KEY = 'Name: A to Z';

	/** One logs pane's state — see logsPanes below for what each field means. */
	function makeLogsPane() {
		return {
			rows: [],
			from: '',
			to: '',
			perPage: 10,
			page: 1,
			totalPages: 1,
			total: 0,
			failed: 0,
			listedTotal: 0,
			anyLogs: false
		};
	}

	var listingState = {
		bound: {},
		uiBound: {},
		lastRecords: [],
		rowTemplate: '',
		// Empty = untouched: no comparator runs, so rows stay in the order CRM
		// sent them (newest first), and a freshly created transfer sits on top.
		// The dropdown still reads "Name: A to Z" in grey; picking any item —
		// that one included — sets this and sorting starts.
		sortKey: '',
		filters: { status: [], source: [], destination: [] },
		// Custom range is a two-date range: start = left calendar, end = right.
		// picked* is committed by APPLY; draft* is what the calendars show.
		pickedStart: '',
		pickedEnd: '',
		draftStart: '',
		draftEnd: '',
		// Committed Sort by state, kept only while the Custom range calendar is
		// open. APPLY discards it; any other exit rolls back to it.
		sortSnapshot: null,
		startYear: 0,
		startMonth: 0,
		datePickerBound: false,
		wasVisible: false,
		pendingLoad: null,
		pendingPauseId: '',
		pendingResumeId: '',
		pendingDeleteId: '',
		pendingDuplicateId: '',
		pendingHistoricSyncId: '',
		historicSyncBatchSize: '',
		historicSyncDefaultBatchSize: '',
		logsRowTemplate: {},
		// Real-time and Historic keep completely separate filters and paging.
		// Only the visible page lives here; CRM counts the rest.
		//   rows        — the page on screen
		//   total       — logs matching the date window
		//   failed      — of those, the failed ones
		//   listedTotal — what this pane lists (Real-time = failed only)
		//   anyLogs     — has any log at all, date window ignored
		logsPanes: {
			realtime: makeLogsPane(),
			historic: makeLogsPane()
		},
		activeLogsTab: 'realtime',
		logsRecordId: '',
		visibilityObserver: null,
		logsPanelBound: false,
		historicSyncPopupBound: false,
		successAlertHideTimer: null,
		errorAlertHideTimer: null,
		// Bottom edge (iframe px) of the screen the user was looking at when
		// they confirmed an action. Listing banners pin to that edge.
		alertViewportBottom: null,
		recordsLoadedAt: 0
	};

	/**
	 * Freshness window for the shared records fetch.
	 * A single tab open asks for the same data several times in a row (decide
	 * listing vs create → paint rows → visibility observer), so they all read
	 * one response instead of racing separate round trips.
	 */
	var RECORDS_CACHE_TTL_MS = 2000;

	function getDataTransferModule() {
		return window.DataTransferModule || null;
	}

	/** Root of the listing screen. */
	function getListingRoot() {
		return $(LISTING_ROOT_SELECTOR);
	}

	/**
	 * Fetch Data Transfer records from Zoho CRM.
	 * options.per_page — use 1 for a quick "any records?" check.
	 */
	function fetchDataTransferRecords(options) {
		options = options || {};

		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.getAllRecords !== 'function') {
			return Promise.reject({
				message: 'Zoho CRM API is unavailable.'
			});
		}

		return Promise.resolve(
			ZOHO.CRM.API.getAllRecords({
				Entity: DATA_TRANSFER_ENTITY,
				// Newest first. Without sort_by, Zoho falls back to Modified_Time,
				// so a pause or resume would drag an old sync above a new one.
				sort_by: options.sort_by || 'Created_Time',
				sort_order: options.sort_order || 'desc',
				per_page: options.per_page || 200,
				page: options.page || 1
			})
		).then(function (response) {
			var records = (response && response.data) || [];
			listingState.lastRecords = records;
			return records;
		});
	}

	/** CRM picklist field + values used by Pause / Resume. */
	var STATUS_FIELD = 'netcore0__Data_Transfer_Status';
	var PAUSED_STATUS = 'Paused';
	var RUNNING_STATUS = 'Running';
	var WORKFLOW_ID_FIELD = 'netcore0__Workflow_Id';
	var WEBHOOK_ID_FIELD = 'netcore0__Webhook_Id';
	var WORKFLOW_STATUS_CONNECTOR = 'netcore0.zohocrm0.workflowenableordisable';
	var DELETE_WORKFLOW_CONNECTOR = 'netcore0.zohocrm0.deleteworkflow';
	var DELETE_WEBHOOK_CONNECTOR = 'netcore0.zohocrm0.deletewebhook';
	var COQL_CONNECTOR = 'netcore0.zohocrm0.coqlquesy';
	/** CRM function behind the historic sync popup's YES, START SYNC. */
	var BULK_CONTACT_UPLOAD_FUNCTION = 'netcore0__historial_bulk_contact_upload';
	/** Shown when the function fails without saying anything usable. */
	var HISTORIC_SYNC_FAILED_MESSAGE = 'Could not start the historic sync. Please try again.';

	/**
	 * Write one Data Transfer record's status back to CRM.
	 * Zoho answers 200 even when the row itself was rejected, so the per-record
	 * code/status inside the payload is what actually decides success.
	 */
	function updateDataTransferStatus(recordId, status) {
		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.updateRecord !== 'function') {
			return Promise.reject(new Error('Zoho CRM API is unavailable.'));
		}

		var payload = { id: String(recordId) };
		payload[STATUS_FIELD] = status;

		return Promise.resolve(
			ZOHO.CRM.API.updateRecord({
				Entity: DATA_TRANSFER_ENTITY,
				APIData: payload
			})
		).then(function (response) {
			var result = response && response.data && response.data[0];
			var failed = !result ||
				String(result.code || '').toUpperCase() === 'ERROR' ||
				String(result.status || '').toLowerCase() === 'error';

			if (failed) {
				throw new Error((result && result.message) || 'Could not update the status.');
			}

			return true;
		});
	}

	/** Keep the cached record in step with CRM so a re-render shows the new status. */
	function setCachedRecordStatus(recordId, status) {
		(listingState.lastRecords || []).forEach(function (record) {
			if (String(record.id) === String(recordId)) {
				record[STATUS_FIELD] = status;
			}
		});
	}

	/**
	 * Fetch one Data Transfer record.
	 * getRecord returns { data: [ record ], ... } — always use data[0].
	 */
	function fetchDataTransferRecord(recordId) {
		var id = $.trim(recordId == null ? '' : String(recordId));
		if (!id) {
			return Promise.reject(new Error('Invalid data transfer selected.'));
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.API
			|| typeof ZOHO.CRM.API.getRecord !== 'function'
		) {
			return Promise.reject(new Error('Zoho CRM API is unavailable.'));
		}

		return Promise.resolve(
			ZOHO.CRM.API.getRecord({
				Entity: DATA_TRANSFER_ENTITY,
				RecordID: id
			})
		).then(function (response) {
			var record = response && response.data && response.data[0]
				? response.data[0]
				: null;
			if (!record) {
				console.error('Data transfer record not found in response:', response);
				throw new Error('Data transfer record not found.');
			}
			return record;
		});
	}

	/**
	 * Pause (isActive=false) or activate (isActive=true) the linked Zoho Workflow.
	 * Connector: netcore0.zohocrm0.workflowenableordisable
	 *
	 * Zoho Update Workflow Rule API is PUT with a JSON body:
	 *   { workflow_rules: [{ id, status: { active, delete_schedule_action? } }] }
	 * The connector must be configured as PUT + application/json. We send the
	 * full body as a JSON object (expected_data_type: jsonobject) — not form fields.
	 */
	function updateLinkedWorkflowStatus(workflowId, isActive) {
		var id = $.trim(workflowId == null ? '' : String(workflowId));
		if (!id) {
			return Promise.reject(new Error('No workflow is linked to this data transfer.'));
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.CONNECTOR
			|| typeof ZOHO.CRM.CONNECTOR.invokeAPI !== 'function'
		) {
			return Promise.reject(new Error('Zoho connector API is unavailable.'));
		}

		var active = !!isActive;
		var statusPayload = {
			active: active
		};
		// Required when deactivating (DEPENDENT_FIELD_MISSING if omitted).
		if (!active) {
			statusPayload.delete_schedule_action = false;
		}

		// Full PUT body for /settings/automation/workflow_rules
		var requestBody = {
			"workflow_rules": [
			  {
				"id": "id",
				"status": {
				  "active": active,
				  "delete_schedule_action": false
				}
			  }
			]
		  };

		var data = {
			
			    WORKFLOW_ID: id,
				WORKFLOW_STATUS: active,
				//DELETE_SCHEDULE_ACTION: false,
				// Connector body placeholder — must be a JSON object, not a string.
				//body: requestBody
			
			
		};

		return Promise.resolve(
			ZOHO.CRM.CONNECTOR.invokeAPI(WORKFLOW_STATUS_CONNECTOR, data)
		).then(function (response) {
			return assertWorkflowConnectorSuccess(response);
		});
	}

	/**
	 * Connector may resolve with HTTP 400 in the payload — treat that as failure.
	 */
	function assertConnectorSuccess(response, fallbackMessage) {
		if (!response) {
			return response;
		}

		var statusCode = Number(
			response.status_code
			|| response.statusCode
			|| (response.details && response.details.status_code)
		);
		if (!isNaN(statusCode) && statusCode >= 400) {
			var nested = response.response;
			var message = fallbackMessage || 'Connector request failed.';
			if (typeof nested === 'string' && $.trim(nested)) {
				try {
					var parsed = JSON.parse(nested);
					if (parsed && parsed.message) {
						message = String(parsed.message);
					}
				} catch (parseError) {
					message = nested;
				}
			} else if (response.message) {
				message = String(response.message);
			}
			throw new Error(message);
		}

		return response;
	}

	function assertWorkflowConnectorSuccess(response) {
		return assertConnectorSuccess(response, 'Could not update the linked workflow.');
	}

	/**
	 * Shared CONNECTOR.invokeAPI helper for deleteworkflow / deletewebhook.
	 *
	 * Zoho path templates look like:
	 *   .../workflow_rules/${ID}
	 * VARIABLES keys must match the placeholder name exactly or ${ID} is left
	 * literal and the request fails with "Illegal character in path".
	 *
	 * extras — optional extra placeholder aliases (WORKFLOW_ID, WEBHOOK_ID, …).
	 */
	function invokeConnectorById(connectorName, resourceId, errorMessage, extras) {
		var id = $.trim(resourceId == null ? '' : String(resourceId));
		if (!id) {
			return Promise.reject(new Error(errorMessage || 'Missing resource id.'));
		}

		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.CONNECTOR
			|| typeof ZOHO.CRM.CONNECTOR.invokeAPI !== 'function'
		) {
			return Promise.reject(new Error('Zoho connector API is unavailable.'));
		}

		// Cover common connector path-param names for the same id value.
		var variables = $.extend(
			{
				ID: id,
				id: id
			},
			extras || {}
		);

		// var data = {
		// 	VARIABLES: variables
		// };

		var data = {
		         "ID": id ,
		  };

		return Promise.resolve(
			ZOHO.CRM.CONNECTOR.invokeAPI(connectorName, data)
		).then(function (response) {
			return assertConnectorSuccess(response, errorMessage || 'Connector delete failed.');
		}); 
	}
 

	function deleteLinkedWorkflow(workflowId) {
		return invokeConnectorById(
			DELETE_WORKFLOW_CONNECTOR,
			workflowId,
			'Could not delete the linked workflow.',
			{
				WORKFLOW_ID: String(workflowId),
				rule_id: String(workflowId),
				ruleId: String(workflowId)
			}
		);
	}

	function deleteLinkedWebhook(webhookId) {
		return invokeConnectorById(
			DELETE_WEBHOOK_CONNECTOR,
			webhookId,
			'Could not delete the linked webhook.',
			{
				WEBHOOK_ID: String(webhookId),
				webhook_id: String(webhookId),
				webhookId: String(webhookId)
			}
		);
	}

	/**
	 * Delete linked Workflow then Webhook (when ids exist).
	 * Missing ids are skipped (e.g. draft never exported).
	 * Any connector failure rejects — caller must not delete the DT record.
	 */
	function deleteLinkedWorkflowAndWebhook(record) {
		var workflowId = $.trim(String(
			(record && (record[WORKFLOW_ID_FIELD] || record.netcore0__Workflow_Id)) || ''
		));
		var webhookId = $.trim(String(
			(record && (record[WEBHOOK_ID_FIELD] || record.netcore0__Webhook_Id)) || ''
		));

		var chain = Promise.resolve();

		if (workflowId) {
			chain = chain.then(function () {
				return deleteLinkedWorkflow(workflowId);
			});
		}

		if (webhookId) {
			chain = chain.then(function () {
				return deleteLinkedWebhook(webhookId);
			});
		}

		return chain;
	}

	/**
	 * After DT status is saved: load the record, read netcore0__Workflow_Id,
	 * then pause/activate that workflow. Skips quietly when no workflow id
	 * (e.g. draft never exported).
	 */
	function syncLinkedWorkflowAfterStatusChange(recordId, isWorkflowActive) {
		return fetchDataTransferRecord(recordId).then(function (record) {
			var workflowId = record[WORKFLOW_ID_FIELD]
				|| (record.netcore0__Workflow_Id != null ? record.netcore0__Workflow_Id : '');
			
				
			workflowId = $.trim(String(workflowId || ''));

			if (!workflowId) {
				// No linked workflow yet — DT status change alone is enough.
				return null;
			}

			return updateLinkedWorkflowStatus(workflowId, isWorkflowActive);
		});
	}

	/**
	 * Shared Pause / Resume:
	 *  1) update DT status
	 *  2) sync linked workflow
	 *  3) on workflow failure after DT succeeded → roll DT status back
	 *
	 * Errors are tagged:
	 *   STATUS_UPDATE_FAILED — CRM status write failed
	 *   WORKFLOW_SYNC_FAILED — workflow failed; DT rolled back
	 *   WORKFLOW_OUT_OF_SYNC — workflow failed and DT rollback also failed
	 */
	function applyDataTransferStatusWithWorkflow(recordId, nextStatus, previousStatus, isWorkflowActive) {
		return updateDataTransferStatus(recordId, nextStatus)
			.then(function () {
				setCachedRecordStatus(recordId, nextStatus);
				return syncLinkedWorkflowAfterStatusChange(recordId, isWorkflowActive)
					.catch(function (workflowError) {
						console.error('Workflow sync failed after status change:', workflowError);
						// Keep DT and workflow aligned: undo the DT status write.
						return updateDataTransferStatus(recordId, previousStatus).then(
							function () {
								setCachedRecordStatus(recordId, previousStatus);
								var detail = (workflowError && workflowError.message)
									? String(workflowError.message)
									: 'Could not update the linked workflow.';
								var restoredError = new Error(
									detail + ' Data transfer status was restored.'
								);
								restoredError.code = 'WORKFLOW_SYNC_FAILED';
								throw restoredError;
							},
							function (rollbackError) {
								console.error('Failed to roll back data transfer status:', rollbackError);
								// Cache still has nextStatus — repaint so the row matches CRM.
								var outOfSyncError = new Error(
									'Data transfer status updated, but workflow update failed'
								);
								outOfSyncError.code = 'WORKFLOW_OUT_OF_SYNC';
								throw outOfSyncError;
							}
						);
					});
			}, function (statusError) {
				var failed = new Error(
					(statusError && statusError.message)
					|| 'Failed to update data transfer status'
				);
				failed.code = 'STATUS_UPDATE_FAILED';
				throw failed;
			})
			.then(function () {
				renderListingRows(listingState.lastRecords);
			})
			.catch(function (error) {
				if (error && error.code === 'WORKFLOW_OUT_OF_SYNC') {
					renderListingRows(listingState.lastRecords);
				}
				throw error;
			});
	}

	/**
	 * Delete one Data Transfer record.
	 * Same caveat as the status update — a 200 can still carry a per-record
	 * failure, so the payload's code/status is what we trust.
	 */
	function deleteDataTransferRecord(recordId) {
		if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API || typeof ZOHO.CRM.API.deleteRecord !== 'function') {
			return Promise.reject(new Error('Zoho CRM API is unavailable.'));
		}

		return Promise.resolve(
			ZOHO.CRM.API.deleteRecord({
				Entity: DATA_TRANSFER_ENTITY,
				RecordID: String(recordId)
			})
		).then(function (response) {
			var result = response && response.data && response.data[0];
			var failed = !result ||
				String(result.code || '').toUpperCase() === 'ERROR' ||
				String(result.status || '').toLowerCase() === 'error';

			if (failed) {
				throw new Error((result && result.message) || 'Could not delete the record.');
			}

			return true;
		});
	}

	/** Drop a deleted record from the cache so the repaint loses its row. */
	function removeCachedRecord(recordId) {
		listingState.lastRecords = (listingState.lastRecords || []).filter(function (record) {
			return String(record.id) !== String(recordId);
		});
	}

	/* ------------------------------------------------------------------ */
	/* Transfer logs (netcore0__Data_Transfer_Logs) — read over COQL       */
	/* ------------------------------------------------------------------ */

	var LOGS_ENTITY = 'netcore0__Data_Transfer_Logs';
	var LOGS_LINK_FIELD = 'netcore0__Data_Transfer_Id';

	/** Pane key → the netcore0__Log_Type value CRM stores. */
	var LOGS_TYPE_QUERY = {
		realtime: 'Real Time',
		historic: 'Historic'
	};

	/** What counts as a failure, in COQL rather than a regex. */
	var LOGS_FAILED_WHERE = "netcore0__Log_Status in ('Fail', 'Error')";

	/** Only what paintLogsRows reads. */
	var LOGS_SELECT_FIELDS = [
		'id',
		'netcore0__Start_Time',
		'netcore0__Log_Type',
		'netcore0__Log_Status',
		'netcore0__Error_Message',
		'netcore0__Completed_On'
	].join(', ');

	function getLogsPane(key) {
		return listingState.logsPanes[key];
	}

	/* ---------- query building ---------- */

	/**
	 * CRM's own UTC offset, read off any Created_Time it sends back.
	 *
	 * The table prints CRM's wall clock with the offset stripped, so the day a
	 * user reads off a row is CRM's day. Cutting the window on the browser's
	 * offset instead put the two ~12 hours apart, and an evening log showed as
	 * one day but filtered as the next.
	 */
	var logsOrgOffset = '';

	function rememberLogsOrgOffset(rows) {
		if (logsOrgOffset || !rows || !rows.length) {
			return;
		}

		var found = String(rows[0].Created_Time || '').match(/([+-]\d{2}:\d{2})$/);
		if (found) {
			logsOrgOffset = found[1];
		}
	}

	/** Browser's offset as "+05:30" — the fallback until CRM's is known. */
	function browserUtcOffset() {
		var minutes = -new Date().getTimezoneOffset();
		var sign = minutes < 0 ? '-' : '+';
		var abs = Math.abs(minutes);

		return sign + pad2(Math.floor(abs / 60)) + ':' + pad2(abs % 60);
	}

	function logsQueryOffset() {
		return logsOrgOffset || browserUtcOffset();
	}

	function logsDayStart(dateKey) {
		return dateKey + 'T00:00:00' + logsQueryOffset();
	}

	function logsDayEnd(dateKey) {
		return dateKey + 'T23:59:59' + logsQueryOffset();
	}

	/**
	 * COQL parses only two conditions at a time, so anything longer has to be
	 * nested in pairs: a, b, c → ((a and b) and c). Flat "a and b and c" comes
	 * back as "error occured while parsing the query".
	 */
	function joinLogsConditions(conditions) {
		return conditions.reduce(function (left, right) {
			return '(' + left + ' and ' + right + ')';
		});
	}

	/**
	 * WHERE shared by this pane's count and page queries.
	 * options.ignoreDates — the pane's whole history, filter aside.
	 * options.failedOnly  — only rows Real-time would list.
	 */
	function buildLogsWhere(recordId, key, pane, options) {
		options = options || {};

		var conditions = [
			LOGS_LINK_FIELD + " = '" + recordId + "'",
			"netcore0__Log_Type = '" + LOGS_TYPE_QUERY[key] + "'"
		];

		if (!options.ignoreDates && pane.from) {
			conditions.push("Created_Time >= '" + logsDayStart(pane.from) + "'");
		}
		if (!options.ignoreDates && pane.to) {
			conditions.push("Created_Time <= '" + logsDayEnd(pane.to) + "'");
		}
		if (options.failedOnly) {
			conditions.push(LOGS_FAILED_WHERE);
		}

		return joinLogsConditions(conditions);
	}

	/* ---------- fetch ---------- */

	/** Runs one COQL statement through the connector, resolves its rows. */
	function runLogsCoql(query) {
		try {
			var data = { query: query };

			return Promise.resolve(
				ZOHO.CRM.CONNECTOR.invokeAPI(COQL_CONNECTOR, data)
			).then(function (response) {
				// The connector resolves even on HTTP 400, so check the payload.
				assertConnectorSuccess(response, 'Could not load transfer logs.');

				// 204 means no rows — its body is an empty string, not JSON.
				var body = $.trim((response && response.response) || '');
				if (!body) {
					return [];
				}

				var parsedLogsBody;
				// A failed connector can answer with HTML instead of JSON.
				try {
					parsedLogsBody = JSON.parse(body);
				} catch (logsBodyParseError) {
					console.error('Transfer logs response was not JSON:', logsBodyParseError, body);
					throw logsBodyParseError;
				}

				var rows = (parsedLogsBody || {}).data || [];

				// Learn CRM's timezone from the first rows that carry a timestamp.
				rememberLogsOrgOffset(rows);

				return rows;
			});
		} catch (logsCoqlError) {
			console.error('runLogsCoql failed:', logsCoqlError);
			throw logsCoqlError;
		}
	}

	/** CRM does the counting, so totals hold however many logs there are. */
	function runLogsCount(where) {
		var query = 'SELECT COUNT(id) FROM ' + LOGS_ENTITY + ' WHERE ' + where;

		return runLogsCoql(query).then(function (rows) {
			var row = rows[0] || {};
			return Number(row['COUNT(id)'] || 0);
		});
	}

	/** Only the rows this pane shows right now. */
	function runLogsPage(where, perPage, offset) {
		var query = 'SELECT ' + LOGS_SELECT_FIELDS
			+ ' FROM ' + LOGS_ENTITY
			+ ' WHERE ' + where
			+ ' ORDER BY Created_Time DESC'
			+ ' LIMIT ' + perPage
			+ ' OFFSET ' + offset;

		return runLogsCoql(query);
	}

	/**
	 * Load one pane: counts first, then the single page on screen.
	 * Nothing but that page is ever held in memory.
	 */
	function loadLogsPane(key) {
		try {
			var pane = getLogsPane(key);
			var id = listingState.logsRecordId;

			if (!pane || !id) {
				return Promise.resolve();
			}

			if (
				!window.ZOHO
				|| !ZOHO.CRM
				|| !ZOHO.CRM.CONNECTOR
				|| typeof ZOHO.CRM.CONNECTOR.invokeAPI !== 'function'
			) {
				return Promise.reject(new Error('Zoho connector API is unavailable.'));
			}

			var listsFailedOnly = key === 'realtime';
			var hasDateFilter = !!(pane.from || pane.to);

			var counts = [
				runLogsCount(buildLogsWhere(id, key, pane)),
				runLogsCount(buildLogsWhere(id, key, pane, { failedOnly: true }))
			];

			// Without a date filter the first count already answers "any logs?".
			if (hasDateFilter) {
				counts.push(runLogsCount(buildLogsWhere(id, key, pane, { ignoreDates: true })));
			}

			return Promise.all(counts).then(function (result) {
				pane.total = result[0];
				pane.failed = result[1];
				pane.anyLogs = (hasDateFilter ? result[2] : result[0]) > 0;
				pane.listedTotal = listsFailedOnly ? pane.failed : pane.total;
				pane.totalPages = Math.max(1, Math.ceil(pane.listedTotal / pane.perPage));

				// A shrunken result can leave the user past the last page.
				pane.page = Math.min(Math.max(pane.page, 1), pane.totalPages);

				var where = buildLogsWhere(id, key, pane, { failedOnly: listsFailedOnly });

				return runLogsPage(where, pane.perPage, (pane.page - 1) * pane.perPage);
			}).then(function (rows) {
				// A slower earlier request must not overwrite a newer sync's page.
				if (listingState.logsRecordId !== id) {
					return;
				}

				pane.rows = rows;
				renderLogsPane(key);
			});
		} catch (logsPaneError) {
			console.error('loadLogsPane failed:', key, logsPaneError);
			throw logsPaneError;
		}
	}

	/* ---------- durations ---------- */

	/** Date → "YYYY-MM-DD" from its own local parts, never toISOString(). */
	function toLogDateKey(date) {
		return [
			date.getFullYear(),
			String(date.getMonth() + 1).padStart(2, '0'),
			String(date.getDate()).padStart(2, '0')
		].join('-');
	}

	/** "YYYY-MM-DD" → Date, built as a local day so no timezone shifts it. */
	function parseLogDateKey(dateKey) {
		var key = String(dateKey || '');

		return new Date(+key.slice(0, 4), +key.slice(5, 7) - 1, +key.slice(8, 10));
	}

	/** Date → "01 Aug 2026". */
	function formatRangeDay(date) {
		return date.toLocaleDateString('en-GB', {
			day: '2-digit',
			month: 'short',
			year: 'numeric'
		});
	}

	/** "Duration: 26 Jul 2026 - 01 Aug 2026", or one day when both match. */
	function buildRangeLabel(fromDate, toDate) {
		var start = formatRangeDay(fromDate);
		var end = formatRangeDay(toDate);

		return 'Duration: ' + (start === end ? start : start + ' - ' + end);
	}

	/**
	 * Duration preset → { from, to, label }, counted from today.
	 * "Last 7 days" includes today plus the six before it.
	 */
	function buildPresetRange(option) {
		var today = new Date();
		today.setHours(0, 0, 0, 0);

		var from = new Date(today);
		var to = new Date(today);

		if (option === 'Yesterday') {
			from.setDate(from.getDate() - 1);
			to = new Date(from);
		} else if (option === 'Last 7 days') {
			from.setDate(from.getDate() - 6);
		} else if (option === 'Last 30 days') {
			from.setDate(from.getDate() - 29);
		} else {
			return null;
		}

		return {
			from: toLogDateKey(from),
			to: toLogDateKey(to),
			label: buildRangeLabel(from, to)
		};
	}

	/* ---------- paging ---------- */

	/** "10 per page" → 10. */
	function parsePerPage(value) {
		var size = parseInt(String(value || '').replace(/[^0-9]/g, ''), 10);
		return size > 0 ? size : 10;
	}

	/* ---------- formatting ---------- */

	/** Record ID / Zoho job ID column — the log row's own CRM id. */
	function getLogRecordId(record) {
		return $.trim((record && record.id) || '');
	}

	/** CRM timestamp → "Dec 16, 2025 10:23 AM" (CRM's own wall clock). */
	function formatLogTimestamp(value) {
		if (!value) {
			return '-';
		}

		// Drop the offset so the browser does not shift the time into the
		// viewer's timezone.
		var parts = String(value).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
		var date = parts
			? new Date(+parts[1], +parts[2] - 1, +parts[3], +parts[4], +parts[5])
			: new Date(value);

		if (isNaN(date.getTime())) {
			return '-';
		}

		var datePart = date.toLocaleDateString('en-US', {
			month: 'short',
			day: '2-digit',
			year: 'numeric'
		});

		var timePart = date.toLocaleTimeString('en-US', {
			hour: '2-digit',
			minute: '2-digit',
			hour12: true
		});

		return datePart + ' ' + timePart.toUpperCase();
	}

	/** "6102" → "6,102", matching the designer's numbers. */
	function formatLogCount(value) {
		return Number(value || 0).toLocaleString('en-US');
	}

	/* ------------------------------------------------------------------ */
	/* Shared loader popup (partials/modals/common-loader.html)           */
	/* partials-loader.js drops it into the page, so it is always present.*/
	/* ------------------------------------------------------------------ */

	var COMMON_LOADER_ID = 'common-loader-popup';
	var commonLoaderModal = null;
	var commonLoaderRetryHide = null;

	function showCommonLoader() {
		var element = document.getElementById(COMMON_LOADER_ID);
		if (!element || typeof bootstrap === 'undefined') {
			return;
		}

		// A retry left over from the previous hide belongs to that hide — it
		// must not close the loader this caller is opening.
		dropCommonLoaderRetryHide(element);

		commonLoaderModal = bootstrap.Modal.getOrCreateInstance(element, {
			backdrop: 'static',
			keyboard: false
		});
		commonLoaderModal.show();
	}

	function hideCommonLoader() {
		var element = document.getElementById(COMMON_LOADER_ID);
		if (!element || typeof bootstrap === 'undefined') {
			return;
		}

		// The live instance wins: a stale cached one may already be disposed.
		var instance = bootstrap.Modal.getInstance(element) || commonLoaderModal;
		if (instance) {
			instance.hide();

			// Bootstrap drops hide() while the show transition is still running.
			// Clearing the DOM by hand then leaves the instance counted as open
			// with its focus trap still on the document, its queued show able to
			// repaint the popup over the next screen, and every later
			// show()/hide() a no-op. Hide again once the show has settled.
			if (instance._isTransitioning) {
				commonLoaderRetryHide = function () {
					commonLoaderRetryHide = null;
					instance.hide();
					clearCommonLoaderDom(element);
				};
				$(element).one('shown.bs.modal', commonLoaderRetryHide);
			}
		}

		clearCommonLoaderDom(element);
	}

	function dropCommonLoaderRetryHide(element) {
		if (!commonLoaderRetryHide) {
			return;
		}
		$(element).off('shown.bs.modal', commonLoaderRetryHide);
		commonLoaderRetryHide = null;
	}

	/** Same cleanup as Connections: a fast response can race the hide animation. */
	function clearCommonLoaderDom(element) {
		element.classList.remove('show');
		element.style.display = 'none';
		element.setAttribute('aria-hidden', 'true');
		element.removeAttribute('aria-modal');
		document.body.classList.remove('modal-open');
		document.body.style.removeProperty('overflow');
		document.body.style.removeProperty('padding-right');
		document.querySelectorAll('.modal-backdrop').forEach(function (backdrop) {
			backdrop.remove();
		});
	}

	/* ------------------------------------------------------------------ */
	/* Shared popup state repair                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * Put the shared popups back in sync with the DOM.
	 *
	 * Several flows close a modal by hand (see clearCommonLoaderDom and
	 * hideStartingExportModal): classes stripped, display forced to none, every
	 * backdrop deleted. When that lands inside Bootstrap's show transition the
	 * instance keeps reporting itself as open, so its backdrop can stay over the
	 * page and its next show()/hide() does nothing. The listing is where that
	 * has to be clean — until now only a reload cleared it.
	 */
	function resyncSharedOverlays() {
		if (typeof bootstrap === 'undefined') {
			return;
		}

		var busy = false;

		Array.prototype.forEach.call(
			document.querySelectorAll('.modal, .offcanvas'),
			function (element) {
				// Open, or mid-animation (offcanvas marks that with a class):
				// Bootstrap's own callbacks will finish it.
				if (
					element.classList.contains('show')
					|| element.classList.contains('showing')
					|| element.classList.contains('hiding')
				) {
					busy = true;
					return;
				}

				var instance = getOverlayInstance(element);
				if (!instance || !instance._isShown) {
					return;
				}

				if (instance._isTransitioning) {
					busy = true;
					return;
				}

				resetStrandedOverlay(element, instance);
			}
		);

		if (busy) {
			return;
		}

		Array.prototype.forEach.call(
			document.querySelectorAll('.modal-backdrop, .offcanvas-backdrop'),
			function (backdrop) {
				backdrop.remove();
			}
		);
		document.body.classList.remove('modal-open');
		document.body.style.removeProperty('overflow');
		document.body.style.removeProperty('padding-right');
	}

	function getOverlayInstance(element) {
		var Overlay = element.classList.contains('offcanvas')
			? bootstrap.Offcanvas
			: bootstrap.Modal;

		if (!Overlay || typeof Overlay.getInstance !== 'function') {
			return null;
		}
		return Overlay.getInstance(element);
	}

	/**
	 * One hidden popup whose instance still reports itself as open. Disposing it
	 * drops its backdrop and focus trap and lets the next getOrCreateInstance
	 * start from a clean state. _isShown / _isTransitioning are Bootstrap
	 * internals, read only to spot the desync.
	 */
	function resetStrandedOverlay(element, instance) {
		// Offcanvas is driven by classes, not display — an inline display would
		// stop it from ever opening again.
		if (element.classList.contains('modal')) {
			element.style.display = 'none';
			element.setAttribute('aria-hidden', 'true');
		}
		element.removeAttribute('aria-modal');

		try {
			instance.dispose();
		} catch (error) {
			console.error('resyncSharedOverlays: could not reset #' + element.id, error);
		}

		if (element.id === COMMON_LOADER_ID) {
			commonLoaderModal = null;
			commonLoaderRetryHide = null;
		}
	}

	/**
	 * Run a synchronous repaint behind the shared loader.
	 *
	 * Bootstrap ignores hide() while the show transition is still running, so
	 * hiding in the same tick left the loader stranded on screen. Wait for
	 * shown.bs.modal, do the work, then hide. The timer is a fallback for the
	 * case where the loader was already open and shown never fires again.
	 */
	function runBehindCommonLoader(task) {
		var element = document.getElementById('common-loader-popup');

		if (!element || typeof bootstrap === 'undefined') {
			task();
			return;
		}

		var finished = false;

		function finish() {
			if (finished) {
				return;
			}
			finished = true;

			task();
			hideCommonLoader();
		}

		$(element).one('shown.bs.modal', finish);
		window.setTimeout(finish, 400);

		showCommonLoader();
	}

	/** Shows the loader and returns the function that hides it. */
	function beginCommonLoader() {
		var element = document.getElementById('common-loader-popup');

		if (!element || typeof bootstrap === 'undefined') {
			return function () {};
		}

		var ready = false;
		var wantHide = false;

		// hide() is ignored mid-show, so wait for the modal to settle first.
		function markReady() {
			ready = true;
			if (wantHide) {
				hideCommonLoader();
			}
		}

		$(element).one('shown.bs.modal', markReady);
		// Fallback for an already-open loader, where shown never fires again.
		window.setTimeout(markReady, 400);

		showCommonLoader();

		return function () {
			wantHide = true;
			if (ready) {
				hideCommonLoader();
			}
		};
	}

	/**
	 * Single in-flight (or just-settled) records fetch shared by every caller.
	 *
	 * Resolves with the records array and rejects when the API call fails, so
	 * callers can tell "zero records" apart from "could not load" instead of
	 * treating both as an empty listing.
	 */
	function loadDataTransferRecordsOnce(options) {
		var settings = (options && typeof options === 'object') ? options : {};

		if (listingState.pendingLoad) {
			return listingState.pendingLoad;
		}

		if (
			!settings.forceReload
			&& listingState.recordsLoadedAt
			&& (Date.now() - listingState.recordsLoadedAt) < RECORDS_CACHE_TTL_MS
		) {
			return Promise.resolve(listingState.lastRecords.slice());
		}

		showCommonLoader();

		listingState.pendingLoad = fetchDataTransferRecords()
			.then(function (records) {
				listingState.recordsLoadedAt = Date.now();
				return records;
			})
			.finally(function () {
				listingState.pendingLoad = null;
				hideCommonLoader();
			});

		return listingState.pendingLoad;
	}

	/** Drop the freshness window so the next read goes back to CRM. */
	function invalidateRecordsCache() {
		listingState.recordsLoadedAt = 0;
	}

	/**
	 * Does at least one Data Transfer record exist?
	 * Resolves only once the API call has settled. Retries once so a single
	 * failed round trip is never read as "no records"; a second failure
	 * rejects rather than guessing.
	 */
	function hasDataTransferRecords() {
		return loadDataTransferRecordsOnce()
			.catch(function (error) {
				console.error('Data Transfer records fetch failed — retrying once:', error);
				return loadDataTransferRecordsOnce({ forceReload: true });
			})
			.then(function (records) {
				return (records || []).length > 0;
			});
	}

	/** CRM timestamp → "Mon, 27 Jul 2026 04:54 AM". */
	function formatTooltipDate(value) {
		if (!value) {
			return '-';
		}

		// Show CRM's own wall-clock time: drop the trailing offset so the browser
		// does not shift 04:54 into the viewer's local timezone.
		var parts = String(value).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
		var date = parts
			? new Date(+parts[1], +parts[2] - 1, +parts[3], +parts[4], +parts[5])
			: new Date(value);

		if (isNaN(date.getTime())) {
			return '-';
		}

		var datePart = date.toLocaleDateString('en-GB', {
			weekday: 'short',
			day: '2-digit',
			month: 'short',
			year: 'numeric'
		});

		var timePart = date.toLocaleTimeString('en-US', {
			hour: '2-digit',
			minute: '2-digit',
			hour12: true
		});

		return datePart + ' ' + timePart;
	}

	/**
	 * Fill the tooltip markup with record values.
	 * Rows are matched by their label, so the markup can be reordered freely.
	 */
	function buildTooltipTitle(templateHtml, record) {
		var $wrap = $('<div>').html(templateHtml);

		$wrap.find('.stt-title').text(record.Name || '');

		$wrap.find('.stt-row').each(function () {
			var $row = $(this);
			var label = $.trim($row.find('.stt-label').text());
			var $value = $row.find('.stt-value');

			if (label === 'Created on') {
				$value.text(' ' + formatTooltipDate(record.Created_Time));
			} else if (label === 'Connection') {
				$value.text(' ' + ((record.netcore0__Connection && record.netcore0__Connection.name) || '-'));
			} else if (label === 'Zoho job ID' || label === 'Apex job ID') {
				// "Apex job ID" is the original wording — accept both
				// so the id still renders if that markup comes back.
				$value.text(' ' + (record.id || '-'));
			}
		});

		return $wrap.html();
	}

	/** Status → the slug used for badge classes and action lookups ("Creating Attributes" → creating-attributes). */
	function getStatusSlug(status) {
		return $.trim(status || '').toLowerCase().replace(/\s+/g, '-');
	}

	/**
	 * Status badge text + colour.
	 * CSS ships status-draft / status-paused; anything else falls back to the
	 * green .status-badge base, which is what status-running already uses.
	 */
	function applyStatusBadge($row, status) {
		var $badge = $row.find('.status-badge');
		if (!$badge.length) {
			return;
		}

		var value = $.trim(status || '');
		if (!value) {
			$badge.hide();
			return;
		}

		$badge
			.removeClass('status-running status-draft status-paused status-creating-attributes')
			.addClass('status-' + getStatusSlug(value))
			.text(value.toUpperCase());
	}

	/**
	 * Which action buttons a row keeps, by status (lowercased).
	 * A status that is not listed keeps whatever the template ships.
	 */
	var ROW_ACTIONS_BY_STATUS = {
		running: ['historic', 'pause', 'duplicate', 'delete'],
		paused: ['resume', 'duplicate', 'delete'],
		stopped: ['duplicate', 'delete'],
		draft: ['edit', 'duplicate', 'delete'],
		'creating-attributes': ['duplicate', 'delete']
	};

	/** Drop the action buttons this row's record / status should not offer. */
	function applyRowActions($row, status, record) {
		var $buttons = $row.find('.actions-cell [data-action]');
		if (!$buttons.length) {
			return;
		}

		// Historic sync only exists for Contacts transfers that are Running.
		if (!isContactsSyncRecord(record) || getStatusSlug(status) !== 'running') {
			$buttons.filter('[data-action="historic"]').remove();
		}

		var allowed = ROW_ACTIONS_BY_STATUS[getStatusSlug(status)];
		if (!allowed) {
			return;
		}

		$buttons.each(function () {
			var $button = $(this);
			if (allowed.indexOf($button.attr('data-action')) === -1) {
				$button.remove();
			}
		});
	}

	/** Statuses whose rows offer no Logs to open. */
	var STATUSES_WITHOUT_LOGS = ['draft'];

	/**
	 * A draft has never run, so there is nothing to open: the Logs cell shows
	 * a dash instead of the View link — the same placeholder the Source and
	 * Destination cells use when a value is missing.
	 */
	function applyLogsLink($row, status) {
		var $link = $row.find('.view-link');
		if (!$link.length) {
			return;
		}

		var hasLogs = STATUSES_WITHOUT_LOGS.indexOf(
			$.trim(status || '').toLowerCase()
		) === -1;

		if (!hasLogs) {
			// Rows are cloned fresh from the template on every render, so
			// replacing the cell here never has to be undone.
			$link.closest('td').text('-');
		}
	}

	/**
	 * Numeric-aware name compare, so Datatransfer_2 sorts before
	 * Datatransfer_10 instead of after it.
	 */
	function compareBySyncName(a, b) {
		return String(a.Name || '').localeCompare(
			String(b.Name || ''),
			undefined,
			{ numeric: true, sensitivity: 'base' }
		);
	}

	function toTimestamp(value) {
		var time = value ? new Date(value).getTime() : 0;
		return isNaN(time) ? 0 : time;
	}

	function compareByModifiedTime(a, b) {
		return toTimestamp(a.Modified_Time) - toTimestamp(b.Modified_Time);
	}

	var CUSTOM_RANGE_KEY = 'Custom range';

	function compareByCreatedTime(a, b) {
		return toTimestamp(a.Created_Time) - toTimestamp(b.Created_Time);
	}

	/**
	 * CRM timestamp → "YYYY-MM-DD", the same shape <input type="date"> returns.
	 * Sliced off the raw string so the browser timezone cannot shift the day.
	 */
	function toDateKey(value) {
		var match = String(value || '').match(/^(\d{4}-\d{2}-\d{2})/);
		return match ? match[1] : '';
	}

	/**
	 * Created_Time falls inside the picked range, both ends included.
	 * "YYYY-MM-DD" keys compare correctly as plain strings, so no Date parsing.
	 */
	function recordMatchesPickedDate(record) {
		if (!listingState.pickedStart || !listingState.pickedEnd) {
			return true;
		}

		var key = toDateKey(record.Created_Time);
		if (!key) {
			return false;
		}

		return key >= listingState.pickedStart && key <= listingState.pickedEnd;
	}

	/** Keys are the dropdown items' data-value attributes. */
	var SORT_COMPARATORS = {
		'Name: A to Z': compareBySyncName,
		'Name: Z to A': function (a, b) {
			return compareBySyncName(b, a);
		},
		'Date modified: New to Old': function (a, b) {
			return compareByModifiedTime(b, a);
		},
		'Date modified: Old to New': compareByModifiedTime,
		// Custom range is about dates, so newest first reads naturally.
		'Custom range': function (a, b) {
			return compareByCreatedTime(b, a);
		}
	};

	/**
	 * Match the dropdown's data-value to a comparator, ignoring case and
	 * stray spaces — a "New to old" / "New to Old" slip used to kill sorting
	 * silently. Anything still unmatched is logged instead of ignored.
	 */
	function getSortComparator(sortKey) {
		var wanted = $.trim(sortKey || '').toLowerCase();

		// Nobody has picked a sort yet — keep the fetch order, and say nothing.
		if (!wanted) {
			return null;
		}

		var name = Object.keys(SORT_COMPARATORS).filter(function (key) {
			return key.toLowerCase() === wanted;
		})[0];

		if (!name) {
			console.warn('No sort comparator for "' + sortKey + '" — order left as fetched.');
			return null;
		}

		return SORT_COMPARATORS[name];
	}

	/** Sorted copy — never reorders listingState.lastRecords in place. */
	function sortRecords(records) {
		var comparator = getSortComparator(listingState.sortKey);
		var sorted = (records || []).slice();

		if (comparator) {
			sorted.sort(comparator);
		}

		return sorted;
	}

	/**
	 * initBootstrapTooltips creates tooltips with container:'body', so the popup
	 * element lives outside the row. Replacing rows without disposing first
	 * leaves the popup of whatever was hovered stranded in the page corner.
	 */
	var TOOLTIP_SELECTOR = '[data-bs-toggle="tooltip"], .action-icon-btn, .view-link';

	function disposeTooltipsIn($container) {
		if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
			return;
		}

		$container.find(TOOLTIP_SELECTOR).each(function () {
			var instance = bootstrap.Tooltip.getInstance(this);
			if (instance) {
				instance.dispose();
			}
		});
	}

	/**
	 * Action buttons ship with two data-bs-toggle attributes ("modal" and
	 * "tooltip"). HTML keeps only the first, so initBootstrapTooltips never
	 * matches them and the browser's own grey title tooltip shows instead.
	 * Build those tooltips here; the modal data API is left untouched.
	 */
	function initActionTooltips($root) {
		if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
			return;
		}

		$root.find('.action-icon-btn[title], .view-link[title]').each(function () {
			bootstrap.Tooltip.getOrCreateInstance(this, {
				trigger: 'hover',
				placement: this.getAttribute('data-bs-placement') || 'bottom',
				container: 'body'
			});
		});
	}

	/**
	 * Safety net for popups whose trigger vanished some other way.
	 * Bootstrap points a live trigger at its popup through aria-describedby,
	 * so a popup nobody references is stale.
	 */
	function removeOrphanTooltips() {
		$('body > .tooltip').each(function () {
			var id = this.getAttribute('id');
			if (!id || !document.querySelector('[aria-describedby="' + id + '"]')) {
				$(this).remove();
			}
		});
	}

	/**
	 * Row container of the listing table, looked up by class rather than id.
	 */
	function getListingTbody() {
		return getListingRoot().find('.data-table-card tbody').first();
	}

	/** Whatever is currently typed in the listing search box. */
	function getListingSearchQuery() {
		return $.trim(getListingRoot().find('#searchInput').val() || '');
	}

	/**
	 * Substring match anywhere in the sync name, letters or digits alike.
	 * On Datatransfer_20260727163641 "data", "20", "2026" and "3641" all hit.
	 * Space-separated words are ANDed, so "data 2026" also works.
	 * Both arguments are expected lowercased already.
	 */
	function matchesSyncName(name, needle) {
		if (!needle) {
			return true;
		}

		return needle.split(/\s+/).every(function (term) {
			return !term || name.indexOf(term) !== -1;
		});
	}

	/**
	 * Show only the rows whose sync name matches the query.
	 * Rows are hidden, never removed, so clearing the box needs no refetch.
	 */
	function filterListingRows(query) {
		var $tbody = getListingTbody();
		if (!$tbody.length) {
			return;
		}

		var needle = $.trim(query || '').toLowerCase();
		var $rows = $tbody.find('tr').not('.dt-listing-message, .dt-row-template');
		var matches = 0;

		$rows.each(function () {
			var $row = $(this);
			var name = $.trim($row.find('.sync-name').text()).toLowerCase();
			var isMatch = matchesSyncName(name, needle);

			$row.toggle(isMatch);
			if (isMatch) {
				matches += 1;
			}
		});

		$tbody.find('.dt-listing-no-match').remove();

		if ($rows.length && !matches) {
			$tbody.append(
				'<tr class="dt-listing-message dt-listing-no-match">' +
				'<td colspan="5">No syncs match &ldquo;' + escapeHtml(query) + '&rdquo;.</td>' +
				'</tr>'
			);
		}
	}

	/** HTML-safe text. */
	function escapeHtml(value) {
		return $('<div>').text(value == null ? '' : value).html();
	}

	function findRecordById(recordId) {
		var id = $.trim(recordId || '');
		if (!id) {
			return null;
		}

		var found = null;
		listingState.lastRecords.some(function (record) {
			if (String(record.id) === id) {
				found = record;
				return true;
			}
			return false;
		});

		return found;
	}

	/**
	 * netcore0__Trigger_Type → the wording the Setup radios use.
	 * Values come from dt-event-screen.html: "Updated" on
	 * #dt-setup-trigger-updated, "Both" on #dt-setup-trigger-created-or-updated.
	 */
	var TRIGGER_TYPE_LABELS = {
		updated: 'Zoho record is updated',
		both: 'Zoho record is created or updated'
	};

	function describeTriggerType(value) {
		return TRIGGER_TYPE_LABELS[$.trim(value || '').toLowerCase()] || '-';
	}

	/** netcore0__Is_Filter_On mirrors the #datatrsf-toggle-input switch. */
	function isFilterOn(record) {
		return record.netcore0__Is_Filter_On === true ||
			String(record.netcore0__Is_Filter_On || '').toLowerCase() === 'true';
	}

	/**
	 * netcore0__Filter_Data is the JSON array written by collectFilterRowsForSave():
	 * [{ field, dataType, operator, value }, ...]
	 */
	function parseFilterRows(record) {
		var raw = record.netcore0__Filter_Data;

		if (Array.isArray(raw)) {
			return raw;
		}

		try {
			var parsed = JSON.parse($.trim(raw || '') || '[]');
			return Array.isArray(parsed) ? parsed : [];
		} catch (error) {
			console.warn('Bad netcore0__Filter_Data on record', record.id, raw);
			return [];
		}
	}

	/**
	 * "Company Is 1000". Saved rows keep the field's API name, so underscores
	 * become spaces — Annual_Revenue reads as "Annual Revenue".
	 */
	function describeFilterRow(row) {
		var field = $.trim((row && row.field) || '').replace(/_/g, ' ');
		var operator = $.trim((row && row.operator) || '');
		var value = $.trim((row && row.value) || '');

		var parts = [field, operator, value].filter(function (part) {
			return part.length > 0;
		});

		return parts.length ? parts.join(' ') : '-';
	}

	/** Contacts syncs get their own detail layout instead of the Event one. */
	function isContactsSyncRecord(record) {
		return $.trim((record && record.netcore0__Netcore_Object) || '') === 'Contacts';
	}

	var CONTACTS_ACTION_LABELS = { add: 'Add contacts', remove: 'Remove contacts' };

	/** Contacts field mapping is saved as a JSON array; legacy records kept it in Source_Fields. */
	function parseContactsMappingRows(record) {
		var candidates = [
			(record && record.netcore0__Destination_Custom_parameters) || '',
			(record && record.netcore0__Source_Fields) || ''
		];
		var rows = [];

		candidates.forEach(function (candidate) {
			var raw = $.trim(String(candidate));
			if (rows.length || raw.charAt(0) !== '[') {
				return;
			}

			try {
				var parsed = JSON.parse(raw);
				if ($.isArray(parsed)) {
					rows = parsed;
				}
			} catch (parseError) {
				rows = [];
			}
		});

		return rows;
	}

	/** Types are stored either as "varchar" or "(varchar)" — show exactly one pair of brackets. */
	function formatMappingDataType(rawType) {
		var type = $.trim(String(rawType == null ? '' : rawType)).replace(/^\(|\)$/g, '');

		return type ? '(' + type + ')' : '';
	}

	/** Rebuild one Additional mapping column from the saved mapping rows. */
	function renderContactsMappingColumn($column, rows, nameKeys, typeKey) {
		if (!$column.length) {
			return;
		}

		// Rows are rebuilt on every open, so drop the old tooltips with them.
		disposeTooltipsIn($column);
		$column.empty();

		if (!rows.length) {
			$column.append($('<div class="attr-row"><span class="attr-name">-</span></div>'));
			return;
		}

		rows.forEach(function (row) {
			var name = '';
			nameKeys.forEach(function (key) {
				name = name || $.trim(String((row && row[key]) || ''));
			});

			var $attrRow = $('<div class="attr-row"></div>');
			$attrRow.append($('<span class="attr-name"></span>').text(name || '-'));
			$attrRow.append(
				$('<span class="attr-type"></span>').text(formatMappingDataType(row && row[typeKey]))
			);
			$column.append($attrRow);
		});
	}

	/**
	 * Tooltips for Field mapping values the CSS has clipped in the detail panel.
	 * Same rule used everywhere else: scrollWidth beats clientWidth exactly when
	 * the browser is drawing the "…", so a value that fits stays tooltip-free.
	 * Widths only exist once the panel is laid out, so this runs on a frame.
	 */
	function refreshContactsMappingTooltips($panel) {
		try {
			if (!$panel || !$panel.length) {
				return;
			}

			$panel
				.find('[data-contacts-mapping] .attr-name, [data-contacts-mapping] .attr-type')
				.each(function () {
					var $label = $(this);
					var text = $.trim($label.text());

					if (text && this.scrollWidth > this.clientWidth) {
						$label.attr({
							'data-bs-toggle': 'tooltip',
							'data-bs-placement': 'bottom',
							'data-bs-container': 'body',
							'title': text
						});
						return;
					}

					// Fits now — drop any tooltip it picked up while it was longer.
					if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
						var existing = bootstrap.Tooltip.getInstance(this);
						if (existing) {
							existing.dispose();
						}
					}
					$label.removeAttr(
						'data-bs-toggle data-bs-placement data-bs-container title data-bs-original-title'
					);
				});

			if (typeof window.initBootstrapTooltips === 'function') {
				window.initBootstrapTooltips($panel[0]);
			}
		} catch (contactsMappingTooltipError) {
			console.error('Contacts mapping tooltip refresh failed:', contactsMappingTooltipError);
		}
	}

	/** One Identity mapping pair → its two value boxes. */
	function fillContactsIdentityRow($row, pair) {
		$row.find('[data-contacts-detail="sourceIdentifier"]')
			.text($.trim((pair && pair.source) || '') || '-');
		$row.find('[data-contacts-detail="destIdentifier"]')
			.text($.trim((pair && pair.dest) || '') || '-');
	}

	/**
	 * Identity mapping rows: the primary pair plus the CUST_ID secondary pair.
	 * The first row in the markup is the template; clones carry
	 * data-contacts-identity-clone so the next render can drop them again.
	 */
	function renderContactsIdentityRows($block, record) {
		var $template = $block.find('[data-contacts-identity-row="true"]').first();
		if (!$template.length) {
			return;
		}

		$block.find('[data-contacts-identity-clone="true"]').remove();

		// Row 1 always shows; later pairs only when the record actually saved them.
		var pairs = [
			{
				source: record.netcore0__Destination_Zoho_Identifier,
				dest: record.netcore0__Destination_Netcore_CE_identifier
			},
			{
				source: record.netcore0__Second_SourceIdentifier,
				dest: record.netcore0__Second_DestinaitonIdentifier
			}
		].filter(function (pair, index) {
			return index === 0 || $.trim(pair.source || '') || $.trim(pair.dest || '');
		});

		fillContactsIdentityRow($template, pairs[0]);

		var $previous = $template;
		pairs.slice(1).forEach(function (pair) {
			var $clone = $template.clone()
				.removeAttr('data-contacts-identity-row')
				.attr('data-contacts-identity-clone', 'true');
			fillContactsIdentityRow($clone, pair);
			$previous.after($clone);
			$previous = $clone;
		});
	}

	/** Comma-separated list value; "No" when the sync targets no list at all. */
	function formatContactsListValue(rawValue) {
		var parts = [];

		String(rawValue == null ? '' : rawValue).split(',').forEach(function (part) {
			var trimmed = $.trim(part);
			if (trimmed) {
				parts.push(trimmed);
			}
		});

		return parts.length ? parts.join(', ') : 'No';
	}

	/** Destination data + Field mapping rows of the Contacts-only detail block. */
	function fillContactsSyncDetail($block, record) {
		var action = $.trim(record.netcore0__What_Do_With_Contacts || '').toLowerCase();
		var removeFrom = $.trim(record.netcore0__Remove_Contacts_From || '').toLowerCase();
		var isRemove = action === 'remove';
		var addToList = record.netcore0__Add_To_List === true
			|| String(record.netcore0__Add_To_List).toLowerCase() === 'true';

		$block.find('[data-contacts-detail="contactAction"] .info-value')
			.text(CONTACTS_ACTION_LABELS[action] || '-');

		$block.find('[data-contacts-detail="addToList"]')
			.toggle(!isRemove)
			.find('.info-value').text(addToList ? 'Yes' : 'No');

		$block.find('[data-contacts-detail="removeFrom"]')
			.toggle(isRemove)
			.find('.info-value').text(removeFrom === 'list' ? 'Yes' : 'No');

		$block.find('[data-contacts-detail="lists"] .info-value')
			.text(formatContactsListValue(record.netcore0__List_Contacts_From_Name));

		renderContactsIdentityRows($block, record);

		var mappingRows = parseContactsMappingRows(record);
		renderContactsMappingColumn(
			$block.find('[data-contacts-mapping="source"]'),
			mappingRows,
			['source_field_label', 'source_field'],
			'source_dataType'
		);
		renderContactsMappingColumn(
			$block.find('[data-contacts-mapping="dest"]'),
			mappingRows,
			['destination_field', 'destination_field_label'],
			'destination_dataType'
		);
	}

	/** Label → value, matching the detail panel's .info-label text. */
	function getDetailFieldValue(label, record) {
		switch (label) {
			case 'Connection':
				return (record.netcore0__Connection && record.netcore0__Connection.name) || '-';
			case 'Zoho object':
				return getSourceDisplayLabel(record.netcore0__Source) || '-';
			case 'Netcore entity':
				return record.netcore0__Netcore_Object || '-';
			case 'Sync behaviour':
				return describeTriggerType(record.netcore0__Trigger_Type);
			case 'Filters applied':
				return isFilterOn(record) ? 'Yes' : 'No';
			case 'Event name':
				return record.netcore0__Event_Name || '-';
			case 'Zoho identifier':
				return record.netcore0__Destination_Zoho_Identifier || '-';
			case 'Netcore identifier':
				return record.netcore0__Destination_Netcore_CE_identifier || '-';
			case 'Custom parameters':
				return record.netcore0__Destination_Custom_parameters || '-';
			default:
				// "Filter N" rows are rebuilt by renderFilterDetailRows().
				return null;
		}
	}

	/**
	 * Rebuild the Filter 1..N rows from netcore0__Filter_Data.
	 * The single "Filter 1" row is the template; clones carry
	 * .dt-filter-row so the next render can drop them again.
	 */
	function renderFilterDetailRows($panel, record) {
		var $template = $panel.find('.info-row').filter(function () {
			return $.trim($(this).find('.info-label').text()).indexOf('Filter 1') === 0;
		}).first();

		if (!$template.length) {
			return;
		}

		$panel.find('.info-row.dt-filter-row').remove();

		if (!isFilterOn(record)) {
			$template.hide();
			return;
		}

		var rows = parseFilterRows(record);
		if (!rows.length) {
			$template.show().find('.info-value').text('-');
			return;
		}

		$template.show();
		$template.find('.info-label').text('Filter 1:');
		$template.find('.info-value').text(describeFilterRow(rows[0]));

		var $previous = $template;
		rows.slice(1).forEach(function (row, index) {
			var $clone = $template.clone().addClass('dt-filter-row');
			$clone.find('.info-label').text('Filter ' + (index + 2) + ':');
			$clone.find('.info-value').text(describeFilterRow(row));
			$previous.after($clone);
			$previous = $clone;
		});
	}

	/** Fill the detail panel from one record. */
	function fillSyncDetail(record) {
		var $panel = getListingRoot().find('.listing-lead-sync-detail');
		if (!$panel.length || !record) {
			return;
		}

		$panel.find('.listing-lead-sync-header-left h3').text(record.Name || '');
		applyStatusBadge(
			$panel.find('.listing-lead-sync-header-left'),
			record.netcore0__Data_Transfer_Status
		);

		// Contacts and Event each own a layout block; only one is ever on screen.
		var isContacts = isContactsSyncRecord(record);
		var $contactsBlock = $panel.find('.listing-lead-sync-cont.dt-contacts-detail');
		var $eventBlock = $panel.find('.listing-lead-sync-cont').not('.dt-contacts-detail');
		var $block = isContacts ? $contactsBlock : $eventBlock;

		$contactsBlock.toggle(isContacts);
		$eventBlock.toggle(!isContacts);

		// Filter rows first: it clones/removes .info-row nodes, and the loop
		// below then fills whatever ended up on screen.
		renderFilterDetailRows($block, record);

		$block.find('.info-row').each(function () {
			var $row = $(this);
			// Labels carry a trailing colon in the markup — drop it before matching.
			var label = $.trim($row.find('.info-label').text()).replace(/:$/, '');
			var value = getDetailFieldValue(label, record);

			if (value !== null) {
				$row.find('.info-value').text(value);
			}
		});

		if (isContacts) {
			fillContactsSyncDetail($block, record);
		}
	}

	/** Selected values per dropdown. "All" or "none" both mean no filter. */
	function readFilterSelections($root) {
		var selections = { status: [], source: [], destination: [] };

		FILTER_DROPDOWN_IDS.forEach(function (dropdownId) {
			var meta = FILTER_FIELDS[dropdownId];
			var $items = $root.find('#' + dropdownId).find('.dd-check-item[data-value]');
			var picked = [];

			$items.each(function () {
				var $item = $(this);
				if ($item.hasClass('selected')) {
					picked.push($item.attr('data-value') || '');
				}
			});

			// Whatever is ticked is the filter — including every option, so
			// Select all + APPLY still runs and still shows its chips.
			// Nothing ticked is the only "no filter" case.
			if (picked.length) {
				selections[meta.key] = picked;
			}
		});

		return selections;
	}

	function hasActiveFilters() {
		return FILTER_DROPDOWN_IDS.some(function (dropdownId) {
			return (listingState.filters[FILTER_FIELDS[dropdownId].key] || []).length > 0;
		});
	}

	/**
	 * Status AND Source AND Destination — a record must clear every group.
	 * Inside one group the ticked boxes are ORed, so Draft + Paused keeps both.
	 * A group with nothing ticked is skipped rather than matching nothing.
	 * Compared lowercased, so dropdown "Draft" matches CRM's "DRAFT".
	 */
	function recordMatchesFilters(record) {
		// every() = AND across the three groups
		return FILTER_DROPDOWN_IDS.every(function (dropdownId) {
			var meta = FILTER_FIELDS[dropdownId];
			var wanted = listingState.filters[meta.key] || [];

			if (!wanted.length) {
				return true;
			}

			// Compared as the row shows it, so a ticked "Opportunities" reaches
			// the record saved as "Deals".
			var savedValue = record[meta.field];
			var value = String(
				(meta.toDisplayValue ? meta.toDisplayValue(savedValue) : savedValue) || ''
			).toLowerCase();

			// some() = OR across the ticked values of this group
			return wanted.some(function (option) {
				return String(option).toLowerCase() === value;
			});
		});
	}

	/** Chips + the count badge on the filter button. */
	function renderFilterChips() {
		var $root = getListingRoot();
		// The filter panel's own chips only — never the date one.
		var $info = $root.find('.data-listing-filter-info').not('.custom_date_range');
		var chips = [];

		FILTER_DROPDOWN_IDS.forEach(function (dropdownId) {
			var meta = FILTER_FIELDS[dropdownId];
			(listingState.filters[meta.key] || []).forEach(function (value) {
				chips.push({ dropdownId: dropdownId, label: meta.label, value: value });
			});
		});

		if ($info.length) {
			$info.empty();
			chips.forEach(function (chip) {
				$info.append(
					'<span class="data-listing-filter-item"' +
					' data-filter-dropdown="' + escapeHtml(chip.dropdownId) + '"' +
					' data-filter-value="' + escapeHtml(chip.value) + '">' +
					escapeHtml(chip.label + ': ' + chip.value) +
					' <span class="filter-remove">' +
					'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
					'<path d="M18 6 6 18M6 6l12 12"></path>' +
					'</svg>' +
					'</span>' +
					'</span>'
				);
			});
		}

		var hasDateChip = renderCustomRangeChip();

		// The wrap carries both, so either one keeps it on screen.
		$root.find('.data-listing-filter-wrap').toggle(chips.length > 0 || hasDateChip);

		// Counted on the funnel: the panel's filters, not the Sort by range.
		var $count = $root.find('#filterTrigger .filter-count');
		if ($count.length) {
			$count.text(chips.length).toggle(chips.length > 0);
		}

		return chips.length;
	}

	/** Sort by → Custom range gets its own chip, in its own box. */
	function renderCustomRangeChip() {
		var $dateInfo = getListingRoot().find('.data-listing-filter-info.custom_date_range');
		if (!$dateInfo.length) {
			return false;
		}

		var hasRange = !!(listingState.pickedStart && listingState.pickedEnd);

		$dateInfo.empty().toggle(hasRange);

		if (!hasRange) {
			return false;
		}

		var label = buildRangeLabel(
			parseLogDateKey(listingState.pickedStart),
			parseLogDateKey(listingState.pickedEnd)
		);

		$dateInfo.append(
			'<span class="data-listing-filter-item" data-custom-range-chip="true">' +
			escapeHtml(label) +
			' <span class="filter-remove">' +
			'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">' +
			'<path d="M18 6 6 18M6 6l12 12"></path>' +
			'</svg>' +
			'</span>' +
			'</span>'
		);

		return true;
	}

	/**
	 * Swap the table for the "No data to display." block.
	 * The plain listing has no such block — it keeps the in-table message row.
	 */
	function applyEmptyState(hasRows) {
		var $root = getListingRoot();
		var $empty = $root.find('.data-listing-no-data-found');

		if (!$empty.length) {
			return;
		}

		$root.find('.data-table-card').toggle(hasRows);
		$empty.toggle(!hasRows);
	}

	/**
	 * Build one table row per record.
	 * The first <tr> is reused as the template, so badges,
	 * action icons and tooltip markup stay exactly as designed.
	 */
	function renderListingRows(records) {
		var $tbody = getListingTbody();
		if (!$tbody.length) {
			return;
		}

		// Cache the template row once, before we replace the tbody content.
		if (!listingState.rowTemplate) {
			var templateRow = $tbody.find('tr').first()[0];
			if (!templateRow) {
				return;
			}
			listingState.rowTemplate = templateRow.outerHTML;
		}

		var matching = sortRecords(records)
			.filter(recordMatchesFilters)
			.filter(recordMatchesPickedDate);

		renderFilterChips();
		applyEmptyState(matching.length > 0);

		if (!matching.length) {
			$tbody.html('<tr class="dt-listing-message"><td colspan="5">No data transfers found.</td></tr>');
			return;
		}

		var $rows = $();

		matching.forEach(function (record) {
			var $row = $(listingState.rowTemplate);
			var $name = $row.find('.sync-name');
			var $cells = $row.children('td');
			var name = record.Name || '';

			// The template ships hidden; real rows must not inherit that.
			$row.removeClass('dt-row-template').removeAttr('hidden');

			var tooltip = $name.attr('data-bs-title');
			if (tooltip) {
				$name.attr('data-bs-title', buildTooltipTitle(tooltip, record));
			}

			$name.text(name);
			$cells.eq(1).text(getSourceDisplayLabel(record.netcore0__Source) || '-');
			$cells.eq(2).text(record.netcore0__Netcore_Object || '-');
			applyStatusBadge($row, record.netcore0__Data_Transfer_Status);
			applyRowActions($row, record.netcore0__Data_Transfer_Status, record);
			applyLogsLink($row, record.netcore0__Data_Transfer_Status);

			// Lets the detail panel find this row's record on click.
			$row.attr('data-record-id', record.id || '');

			$rows = $rows.add($row);
		});

		// Kill the old rows' tooltips first — see disposeTooltipsIn().
		disposeTooltipsIn($tbody);
		$tbody.empty().append($rows);
		removeOrphanTooltips();

		// Fresh rows start visible — re-apply whatever is still in the search box.
		filterListingRows(getListingSearchQuery());

		if (typeof window.initBootstrapTooltips === 'function') {
			window.initBootstrapTooltips(getListingRoot()[0]);
		}
		initActionTooltips($tbody);
	}

	/**
	 * Close an action popup and resolve only once it is really gone.
	 * The common loader is a modal too — showing it while this one is still
	 * animating out lets Bootstrap's teardown strip the loader's backdrop.
	 */
	function hideActionPopup(modalId) {
		return new Promise(function (resolve) {
			var element = document.getElementById(modalId);
			var instance = (element && typeof bootstrap !== 'undefined')
				? bootstrap.Modal.getInstance(element)
				: null;

			if (!instance || !element.classList.contains('show')) {
				resolve();
				return;
			}

			// Remember where this dialog sits before it goes — a content-sized
			// Zoho iframe treats position:fixed as the full document, so the
			// listing banners have to be placed on this same slice.
			captureListingAlertAnchor(element);

			$(element).one('hidden.bs.modal', function () {
				resolve();
			});
			instance.hide();
		});
	}

	/**
	 * Row-action toast: the sync's own name in quotes, then what happened.
	 * Falls back to the plain wording when the name cannot be resolved.
	 */
	function buildListingActionMessage(recordId, outcome) {
		var name = getSyncNameById(recordId);

		return (name ? '‘' + name + '’' : 'Data transfer') + ' ' + outcome;
	}

	/**
	 * YES, PAUSE — DT status → Paused, then pause linked Zoho Workflow.
	 * Nothing on screen moves until both succeed (workflow failure rolls DT back).
	 * The repaint rebuilds rows from the template, which swaps Pause → Resume.
	 */
	function confirmPauseTransfer() {
		var recordId = listingState.pendingPauseId;

		return hideActionPopup('pause-popup').then(function () {
			if (!recordId) {
				showListingErrorAlert('Invalid data transfer selected.');
				return;
			}

			showCommonLoader();

			return applyDataTransferStatusWithWorkflow(
				recordId,
				PAUSED_STATUS,
				RUNNING_STATUS,
				false
			).then(function () {
				showListingSuccessAlert(
					buildListingActionMessage(recordId, 'paused successfully')
				);
			}).catch(function (error) {
				console.error('pause data transfer error:', error);
				showPauseResumeErrorAlert(error);
			}).then(function () {
				hideCommonLoader();
			});
		}).then(function () {
			listingState.pendingPauseId = '';
		});
	}

	/**
	 * YES, RESUME — DT status → Running, then activate linked Zoho Workflow.
	 * Same sequencing / rollback rules as Pause; waits for #resume-popup confirm.
	 */
	function confirmResumeTransfer() {
		var recordId = listingState.pendingResumeId;

		return hideActionPopup('resume-popup').then(function () {
			if (!recordId) {
				showListingErrorAlert('Invalid data transfer selected.');
				return;
			}

			showCommonLoader();

			return applyDataTransferStatusWithWorkflow(
				recordId,
				RUNNING_STATUS,
				PAUSED_STATUS,
				true
			).then(function () {
				showListingSuccessAlert(
					buildListingActionMessage(recordId, 'resumed successfully')
				);
			}).catch(function (error) {
				console.error('resume data transfer error:', error);
				showPauseResumeErrorAlert(error);
			}).then(function () {
				hideCommonLoader();
			});
		}).then(function () {
			listingState.pendingResumeId = '';
		});
	}

	/**
	 * YES, DELETE —
	 *  1) getRecord → Workflow_Id + Webhook_Id (response.data[0])
	 *  2) delete workflow + webhook via connectors (halt on failure)
	 *  3) only then delete the Data Transfer record
	 * Avoids orphaned Workflow/Webhook if DT were deleted first.
	 */
	function confirmDeleteTransfer() {
		var recordId = listingState.pendingDeleteId;

		return hideActionPopup('data-list-delete-popup').then(function () {
			if (!recordId) {
				showListingErrorAlert('Invalid data transfer selected.');
				return;
			}

			showCommonLoader();

			return fetchDataTransferRecord(recordId)
				.then(function (record) {
					return deleteLinkedWorkflowAndWebhook(record).then(function () {
						return deleteDataTransferRecord(recordId);
					});
				})
				.then(function () {
					// Built first — removeCachedRecord takes the name with it.
					var message = buildListingActionMessage(recordId, 'removed successfully');

					removeCachedRecord(recordId);
					renderListingRows(listingState.lastRecords);
					showListingSuccessAlert(message);
				})
				.catch(function (error) {
					console.error('delete data transfer error:', error);
					showListingErrorAlert(
						(error && error.message)
						|| 'Could not delete this data transfer.'
					);
				})
				.then(function () {
					hideCommonLoader();
				});
		}).then(function () {
			listingState.pendingDeleteId = '';
		});
	}

	/**
	 * Put the screen back on the table.
	 * showDetail() hides .data-transfer-listing-sec and shows the detail panel;
	 * navigating away leaves that inline style behind, so coming back would
	 * land on the detail panel again and the tab click would look dead.
	 */
	function resetSyncDetailView() {
		var $root = getListingRoot();
		var section = $root.find('.data-transfer-listing-sec')[0];
		var panel = $root.find('.listing-lead-sync-detail')[0];

		if (!section || !panel) {
			return;
		}

		panel.classList.add('lsd-hidden');
		panel.style.display = 'none';
		section.style.display = 'block';
	}

	/** Collapse the search box and drop its query. */
	function resetListingSearch() {
		var $root = getListingRoot();
		var input = $root.find('#searchInput')[0];

		if (input) {
			input.value = '';
		}
		$root.find('#searchBox').removeClass('open');
		$root.find('#searchTrigger').removeClass('hide');
	}

	/** Sort back to the item the markup ships as selected. */
	function resetSortDropdown() {
		var $dd = getListingRoot().find('#shortby-dropdown');
		if (!$dd.length) {
			return;
		}

		// This reset is itself the new committed state — a snapshot left over
		// from an open calendar must not roll it back later.
		discardSortSnapshot();
		// Back to untouched: label reads DEFAULT_SORT_KEY in grey, but no
		// comparator runs, so rows return to CRM's newest-first order.
		listingState.sortKey = '';

		var $items = $dd.find('.dd-simple-item');
		$items.removeClass('selected');
		$items.filter('[data-value="' + DEFAULT_SORT_KEY + '"]').addClass('selected');
		$dd.find('.dd-value').first().text(DEFAULT_SORT_KEY);
		$dd.find('.dd-value-info').first().addClass('is-placeholder');
		$dd.removeClass('open');
		clearPickedDate();
	}

	/**
	 * Back to a clean screen: no filters, every box unticked ("None"), empty
	 * search, default sort, table instead of detail panel. Same end state as
	 * Clear all, so the tab never shows leftover ticks from a previous filter.
	 */
	function resetListingToInitialState() {
		listingState.filters = { status: [], source: [], destination: [] };

		deselectAllFilterOptions(getListingRoot());
		closeFilterPanel();
		resetListingSearch();
		resetSortDropdown();
		resetSyncDetailView();
	}

	/**
	 * Paint the table from the shared records fetch.
	 * Called as render(screenKey) by the screen router, so a non-object first
	 * argument is ignored; pass { forceReload: true } to bypass the cache.
	 */
	function loadAndRenderListing(options) {
		var settings = (options && typeof options === 'object') ? options : {};

		// Arriving from START EXPORT / SAVE can leave a shared popup that
		// Bootstrap still counts as open on top of the listing.
		resyncSharedOverlays();
		resetSyncDetailView();

		return loadDataTransferRecordsOnce(settings)
			.then(function (records) {
				renderListingRows(records);
				return records;
			})
			.catch(function (error) {
				console.error('Failed to render Data Transfer listing:', error);
				return [];
			});
	}

	/**
	 * Repaint whenever the listing screen becomes visible.
	 * The router calls its screen `bind` only once, and its internal
	 * showScreen() is not reachable from here — so watch the root instead of
	 * asking data-transfer.js to call us.
	 */
	function watchListingVisibility() {
		var root = document.querySelector(LISTING_ROOT_SELECTOR);
		if (!root || listingState.visibilityObserver) {
			return;
		}

		function isVisible() {
			return root.classList.contains('active') && root.offsetParent !== null;
		}

		var observer = new MutationObserver(function () {
			var visible = isVisible();
			if (visible === listingState.wasVisible) {
				return;
			}
			listingState.wasVisible = visible;
			if (visible) {
				loadAndRenderListing();
			}
		});

		observer.observe(root, { attributes: true, attributeFilter: ['class', 'style'] });
		listingState.visibilityObserver = observer;

		// bind() runs while the screen is mid-show, so paint once up front.
		listingState.wasVisible = isVisible();
		loadAndRenderListing();
	}

	/** Open the listing screen through the shared Data Transfer router. */
	function openListingScreen(options) {
		var dt = getDataTransferModule();
		options = $.extend({ animate: true }, options || {});

		if (!dt || typeof dt.showScreen !== 'function') {
			return $.Deferred().reject('DataTransferModule is not ready.').promise();
		}

		// Callers land here right after changing something (save, start export),
		// so the cached rows are already out of date.
		invalidateRecordsCache();

		return dt.showScreen(LISTING_SCREEN_KEY, options);
	}

	function hideListingSuccessAlert() {
		var $alert = getListingRoot().find('#dt-listing-success-alert');
		$alert.hide();
		clearListingAlertPin($alert);
	}

	function hideListingErrorAlert() {
		var $alert = getListingRoot().find('#dt-listing-error-alert');
		$alert.hide();
		clearListingAlertPin($alert);
	}

	function getDocumentHeight() {
		return Math.max(
			document.documentElement ? document.documentElement.scrollHeight : 0,
			document.body ? document.body.scrollHeight : 0,
			window.innerHeight || 0
		);
	}

	/**
	 * Height of the window the user can actually see.
	 * A content-sized Zoho iframe reports innerHeight as the full page, so
	 * that value is only trusted when it is shorter than the document.
	 */
	function estimateVisibleViewportHeight(dialogRect) {
		var docHeight = getDocumentHeight();
		var vv = window.visualViewport;
		if (vv && vv.height > 100 && vv.height < docHeight - 80) {
			return vv.height;
		}

		var inner = window.innerHeight || docHeight;
		if (inner > 100 && inner < docHeight - 80) {
			return inner;
		}

		// Tall iframe: the confirm dialog is on the current screen and is
		// treated as centred in a typical CRM widget (~720px).
		return 720;
	}

	function getLiveVisibleViewportBottom() {
		var docHeight = getDocumentHeight();
		var vv = window.visualViewport;
		if (vv && vv.height > 100 && vv.height < docHeight - 80) {
			return vv.offsetTop + vv.height;
		}

		var inner = window.innerHeight || 0;
		var scrollTop = window.pageYOffset
			|| (document.documentElement && document.documentElement.scrollTop)
			|| 0;
		if (inner > 100 && inner < docHeight - 80) {
			return scrollTop + inner;
		}

		return null;
	}

	/**
	 * Record the bottom of the screen the user is looking at, using the
	 * confirm dialog as the centre of that slice. In a content-sized Zoho
	 * iframe, position:fixed bottom:24px is the page foot — not this edge.
	 */
	function captureListingAlertAnchor(modalElement) {
		try {
			var liveBottom = getLiveVisibleViewportBottom();
			if (typeof liveBottom === 'number') {
				listingState.alertViewportBottom = liveBottom;
				return;
			}

			var dialog = modalElement
				&& modalElement.querySelector
				&& modalElement.querySelector('.modal-dialog');
			var rect = (dialog || modalElement).getBoundingClientRect();
			if (!rect) {
				return;
			}

			var visibleHeight = estimateVisibleViewportHeight(rect);
			var center = rect.top + (rect.height / 2);
			listingState.alertViewportBottom = center + (visibleHeight / 2);
		} catch (anchorError) {
			console.error('captureListingAlertAnchor failed:', anchorError);
		}
	}

	/**
	 * Sit the existing listing banner on the bottom edge of the current
	 * screen — 24px above that edge — not the top of the page and not the
	 * document foot.
	 */
	function pinListingAlertToViewport($alert) {
		var el = $alert && $alert[0];
		if (!el) {
			return;
		}

		var visibleBottom = getLiveVisibleViewportBottom();
		if (typeof visibleBottom !== 'number') {
			visibleBottom = listingState.alertViewportBottom;
		}

		if (typeof visibleBottom !== 'number' || isNaN(visibleBottom)) {
			el.style.top = 'auto';
			el.style.bottom = '24px';
			return;
		}

		el.style.bottom = 'auto';
		el.style.top = '0px';

		var alertHeight = el.offsetHeight || 56;
		var top = Math.round(visibleBottom - 24 - alertHeight);
		if (top < 16) {
			top = 16;
		}

		el.style.top = top + 'px';
	}

	function clearListingAlertPin($alert) {
		var el = $alert && $alert[0];
		if (!el) {
			return;
		}
		el.style.removeProperty('top');
		el.style.removeProperty('bottom');
	}

	function showListingSuccessAlert(message) {
		var $root = getListingRoot();
		var $alert = $root.find('#dt-listing-success-alert');
		if (!$alert.length) {
			return;
		}

		hideListingErrorAlert();
		if (listingState.errorAlertHideTimer) {
			clearTimeout(listingState.errorAlertHideTimer);
			listingState.errorAlertHideTimer = null;
		}

		$alert.find('.alert-success-text').text(
			message || 'Data transfer started successfully.'
		);
		$alert.show();
		pinListingAlertToViewport($alert);

		if (listingState.successAlertHideTimer) {
			clearTimeout(listingState.successAlertHideTimer);
		}
		listingState.successAlertHideTimer = setTimeout(function () {
			$alert.hide();
			clearListingAlertPin($alert);
			listingState.successAlertHideTimer = null;
		}, 4000);
	}

	/** Red banner — same viewport pin / dismiss pattern as success. */
	function showListingErrorAlert(message) {
		var $root = getListingRoot();
		var $alert = $root.find('#dt-listing-error-alert');
		if (!$alert.length) {
			return;
		}

		hideListingSuccessAlert();
		if (listingState.successAlertHideTimer) {
			clearTimeout(listingState.successAlertHideTimer);
			listingState.successAlertHideTimer = null;
		}

		$alert.find('.alert-msg-text').text(
			message || 'Failed to update data transfer status'
		);
		$alert.show();
		pinListingAlertToViewport($alert);

		if (listingState.errorAlertHideTimer) {
			clearTimeout(listingState.errorAlertHideTimer);
		}
		listingState.errorAlertHideTimer = setTimeout(function () {
			$alert.hide();
			clearListingAlertPin($alert);
			listingState.errorAlertHideTimer = null;
		}, 5000);
	}

	/** Map Pause/Resume failures to listing error-banner copy. */
	function showPauseResumeErrorAlert(error) {
		var code = error && error.code;
		if (code === 'WORKFLOW_OUT_OF_SYNC' || code === 'WORKFLOW_SYNC_FAILED') {
			showListingErrorAlert('Data transfer status updated, but workflow update failed');
			return;
		}
		showListingErrorAlert('Failed to update data transfer status');
	}

	/** CREATE NEW → open Setup/Create in Insert mode. */
	function openCreateScreen(options) {
		var dt = getDataTransferModule();
		options = $.extend({ animate: true }, options || {});

		if (!dt || typeof dt.showScreen !== 'function') {
			return $.Deferred().reject('DataTransferModule is not ready.').promise();
		}

		// Drop any state left behind by a previous edit/create session.
		if (typeof dt.resetEditor === 'function') {
			dt.resetEditor();
		} else if (typeof dt.clearCurrentRecordId === 'function') {
			dt.clearCurrentRecordId();
		}

		return dt.showScreen('event', options);
	}

	/**
	 * Row Edit → fetch record by id → open event screen in edit mode
	 * (SAVE will updateRecord using that id).
	 */
	function openEditScreen(recordId, options) {
		var dt = getDataTransferModule();
		options = options || {};

		if (!dt || typeof dt.openForEdit !== 'function') {
			return $.Deferred().reject('DataTransferModule.openForEdit is not ready.').promise();
		}

		return dt.openForEdit(recordId).catch(function (error) {
			console.error('openEditScreen error:', error);
			var message = (error && (error.message || error.statusText))
				|| 'Unable to open this data transfer. Please try again.';
			window.alert(message);
			return $.Deferred().reject(error).promise();
		});
	}

	/**
	 * Row Duplicate → fetch parent → open event screen in create mode
	 * with fields copied and name prefixed "Copy:".
	 */
	function openDuplicateScreen(recordId) {
		var dt = getDataTransferModule();

		if (!dt || typeof dt.openForDuplicate !== 'function') {
			return $.Deferred().reject('DataTransferModule.openForDuplicate is not ready.').promise();
		}

		return dt.openForDuplicate(recordId).catch(function (error) {
			console.error('openDuplicateScreen error:', error);
			var message = (error && (error.message || error.statusText))
				|| 'Unable to duplicate this data transfer. Please try again.';
			window.alert(message);
			return $.Deferred().reject(error).promise();
		});
	}

	/**
	 * YES on duplicate confirm → close popup, then open create-mode editor
	 * pre-filled from the pending parent row.
	 */
	function confirmDuplicateTransfer() {
		var recordId = listingState.pendingDuplicateId;

		return hideActionPopup('duplicate-sync-popup').then(function () {
			if (!recordId) {
				window.alert('Invalid data transfer selected.');
				return;
			}

			return openDuplicateScreen(recordId);
		}).then(function () {
			listingState.pendingDuplicateId = '';
		});
	}

	/**
	 * After closing Setup/Edit:
	 * - records exist → go back to listing
	 * - no records → go back to empty landing
	 */
	function openAfterEditorClose(options) {
		var dt = getDataTransferModule();
		options = $.extend({ animate: true }, options || {});

		if (!dt || typeof dt.showScreen !== 'function') {
			return $.Deferred().reject('DataTransferModule is not ready.').promise();
		}

		// A transfer may have just been created, so always ask CRM again.
		return loadDataTransferRecordsOnce({ forceReload: true })
			.then(function (records) {
				return records.length > 0;
			})
			.catch(function (error) {
				// Same rule as the tab open: a failed lookup must not be
				// mistaken for an empty account.
				console.error('openAfterEditorClose error:', error);
				return listingState.lastRecords.length > 0;
			})
			.then(function (hasRecords) {
				return dt.showScreen(hasRecords ? LISTING_SCREEN_KEY : 'landing', options);
			});
	}

	/* ------------------------------------------------------------------ */
	/* Listing UI — search / sort / filter / historic sync / detail      */
	/* Runs only AFTER listing HTML is in the DOM (via bind below).      */
	/* ------------------------------------------------------------------ */

	function closeListingDropdowns(exceptElement) {
		var $root = getListingRoot();
		if (!$root.length) {
			return;
		}

		$root.find('.dd.open').each(function () {
			if (this !== exceptElement) {
				$(this).removeClass('open');
			}
		});
	}

	// All three helpers scope through the active root: both listing partials
	// carry the same element ids, so document.getElementById would always hit
	// whichever screen happens to sit first in the DOM.
	function closeFilterDropdowns() {
		var $root = getListingRoot();
		FILTER_DROPDOWN_IDS.forEach(function (id) {
			$root.find('#' + id).removeClass('open');
		});
	}

	function openFilterPanel() {
		var $root = getListingRoot();
		$root.find('#filterPanel').addClass('open');
		$root.find('#filterBackdrop').addClass('open');
	}

	function closeFilterPanel() {
		var $root = getListingRoot();
		$root.find('#filterPanel').removeClass('open');
		$root.find('#filterBackdrop').removeClass('open');
		closeFilterDropdowns();
	}

	/** Expandable search box in the listing header. */
	function initListingSearchUi($root) {
		var searchTrigger = $root.find('#searchTrigger')[0];
		var searchBox = $root.find('#searchBox')[0];
		var searchInput = $root.find('#searchInput')[0];
		var searchClose = $root.find('#searchClose')[0];

		if (!searchTrigger || !searchBox || !searchInput || !searchClose) {
			return;
		}

		function openSearch() {
			searchTrigger.classList.add('hide');
			searchBox.classList.add('open');
			setTimeout(function () {
				searchInput.focus();
			}, 0);
		}

		function closeSearch() {
			searchBox.classList.remove('open');
			searchTrigger.classList.remove('hide');
			searchInput.value = '';
			filterListingRows('');
		}

		$(searchTrigger).on('click.dtListing', function (event) {
			event.preventDefault();
			openSearch();
		});

		$(searchClose).on('click.dtListing', function (event) {
			event.preventDefault();
			closeSearch();
		});

		// 'input' (not keyup) so paste and clear-by-mouse also filter.
		$(searchInput).on('input.dtListing', function () {
			filterListingRows(this.value);
		});

		$(searchInput).on('keydown.dtListing', function (event) {
			if (event.key === 'Escape') {
				closeSearch();
			}
		});
	}

	/**
	 * Single-select .dd items inside listing (Sort by only).
	 * #historic-sync-size lives outside #data-transfer-listing — see initHistoricSyncPopupUi().
	 */
	function initListingSimpleDropdowns($root) {
		$root.on('click.dtListing', '.dd .dd-trigger', function (event) {
			var $dd = $(this).closest('.dd');
			var ddEl = $dd[0];

			// Multi-select filter dropdowns have their own open/close handler.
			if ($dd.find('.dd-check-item').length) {
				return;
			}

			event.preventDefault();
			event.stopPropagation();

			// Going back to the item list while the Custom range calendar is up
			// dismisses it without an APPLY — otherwise the list would open on
			// top of the calendar and both would sit there at once.
			if ($dd.attr('id') === 'shortby-dropdown') {
				cancelCustomRangeSelection();
			}

			var isOpen = $dd.hasClass('open');
			closeListingDropdowns(ddEl);
			$dd.toggleClass('open', !isOpen);
		});

		$root.on('click.dtListing', '.dd .dd-simple-item', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var $item = $(this);
			var $dd = $item.closest('.dd');
			var label = $item.attr('data-value') || $.trim($item.text());
			var isSortDropdown = $dd.attr('id') === 'shortby-dropdown';
			var isCustomRange = isSortDropdown && label === CUSTOM_RANGE_KEY;

			// Snapshot before the UI moves, so a cancelled Custom range can be undone.
			if (isCustomRange) {
				captureSortSnapshot($dd);
			}

			$dd.find('.dd-simple-item').removeClass('selected');
			$item.addClass('selected');
			// Dropping is-placeholder recolours the label; picking the default
			// item back is still a deliberate choice, so it counts too.
			$dd.find('.dd-value').first().text(label);
			$dd.find('.dd-value-info').first().removeClass('is-placeholder');

			// The calendar is its own panel below the trigger, so the item list
			// closes either way.
			$dd.removeClass('open');

			// Only the Sort by dropdown reorders the table.
			if (!isSortDropdown) {
				return;
			}

			listingState.sortKey = label;

			if (isCustomRange) {
				// APPLY commits the day; nothing changes until then.
				openDatePicker();
				return;
			}

			// A different option is its own commit — the pending Custom range
			// selection is gone for good, so there is nothing to roll back to.
			discardSortSnapshot();
			clearPickedDate();
			renderListingRows(listingState.lastRecords);
		});

		initDatePicker($root);
	}

	/* ------------------------------------------------------------------ */
	/* Sort by → Custom range: inline calendar                            */
	/* ------------------------------------------------------------------ */

	var MONTH_NAMES = [
		'January', 'February', 'March', 'April', 'May', 'June',
		'July', 'August', 'September', 'October', 'November', 'December'
	];

	/** Years offered in the Year dropdown, around the current one. */
	var YEAR_SPAN_BACK = 5;
	// No records exist ahead of today, so the list stops at the current year.
	var YEAR_SPAN_FORWARD = 0;

	function pad2(number) {
		return number < 10 ? '0' + number : String(number);
	}

	function getDatePicker() {
		return getListingRoot().find('#sortDatePicker');
	}

	/** "YYYY-MM-DD" for a calendar cell. */
	function buildDateKey(year, month, day) {
		return year + '-' + pad2(month + 1) + '-' + pad2(day);
	}

	/** Today as "YYYY-MM-DD" — nothing after it can hold a record. */
	function getTodayDateKey() {
		var today = new Date();

		return buildDateKey(today.getFullYear(), today.getMonth(), today.getDate());
	}

	// isDisabled — optional test that greys out and blocks a value.
	function fillSelectPanel($select, values, labels, current, isDisabled) {
		var html = values.map(function (value, index) {
			var classes = 'dp-select-item';
			if (value === current) {
				classes += ' selected';
			}
			if (typeof isDisabled === 'function' && isDisabled(value)) {
				classes += ' is-disabled';
			}

			return '<div class="' + classes + '" data-value="' + value + '">' +
				labels[index] + '</div>';
		}).join('');

		$select.find('.dp-select-panel').html(html);
		$select.find('.dp-select-value').text(labels[values.indexOf(current)] || '');
	}

	/** Months that lie ahead of today in the year a calendar is showing. */
	function isMonthAheadOfToday(monthIndex, shownYear) {
		var today = new Date();

		return shownYear > today.getFullYear()
			|| (shownYear === today.getFullYear() && monthIndex > today.getMonth());
	}

	/** Low / high end of the draft range, whichever order they were picked in. */
	function getDraftRangeBounds() {
		var from = listingState.draftStart;
		var to = listingState.draftEnd;

		if (from && to && from > to) {
			return { from: to, to: from };
		}

		return { from: from, to: to };
	}

	/**
	 * Repaint the calendar: header lists plus the day grid.
	 * Monday-first — JS getDay() is Sunday-based, so shift it by one.
	 */
	function renderDatePicker() {
		var $picker = getDatePicker();
		if (!$picker.length) {
			return;
		}

		var year = listingState.startYear;
		var month = listingState.startMonth;

		var months = MONTH_NAMES.map(function (name, index) {
			return index;
		});
		fillSelectPanel(
			$picker.find('[data-dp-month]'),
			months,
			MONTH_NAMES,
			month,
			function (monthIndex) {
				return isMonthAheadOfToday(monthIndex, year);
			}
		);

		var thisYear = new Date().getFullYear();
		var years = [];
		for (var y = thisYear - YEAR_SPAN_BACK; y <= thisYear + YEAR_SPAN_FORWARD; y += 1) {
			years.push(y);
		}
		fillSelectPanel($picker.find('[data-dp-year]'), years, years.map(String), year);

		var todayKey = getTodayDateKey();
		var bounds = getDraftRangeBounds();
		var showBand = !!(bounds.from && bounds.to);

		var firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7;
		var daysInMonth = new Date(year, month + 1, 0).getDate();
		var cells = [];

		for (var blank = 0; blank < firstWeekday; blank += 1) {
			cells.push('<button type="button" class="dp-day is-empty" tabindex="-1"></button>');
		}

		for (var day = 1; day <= daysInMonth; day += 1) {
			var key = buildDateKey(year, month, day);
			var classes = 'dp-day';
			var isSelected = key === listingState.draftStart || key === listingState.draftEnd;

			// Nothing was recorded ahead of today, so those days stay unpickable.
			var isAhead = key > todayKey;

			if (isAhead) {
				classes += ' is-disabled';
			} else if (isSelected) {
				classes += ' is-selected';
			} else if (showBand && key > bounds.from && key < bounds.to) {
				classes += ' is-in-range';
			}

			cells.push(
				'<button type="button" class="' + classes + '" data-date="' + key + '"' +
				(isAhead ? ' disabled tabindex="-1"' : '') + '>' +
				pad2(day) +
				'</button>'
			);
		}

		$picker.find('[data-dp-grid]').html(cells.join(''));

		// A range needs both ends — one date alone cannot be applied.
		$picker.find('[data-dp-apply]').prop(
			'disabled',
			!(listingState.draftStart && listingState.draftEnd)
		);
	}

	/** Month to open a calendar on: its own picked day, else today. */
	function seedMonthFor(dateKey) {
		var seed = dateKey
			? new Date(+dateKey.slice(0, 4), +dateKey.slice(5, 7) - 1, 1)
			: new Date();

		return { year: seed.getFullYear(), month: seed.getMonth() };
	}

	function openDatePicker() {
		var $picker = getDatePicker();
		if (!$picker.length) {
			return;
		}

		// An applied range reopens exactly as it was — it stays the current
		// selection until another Sort by option replaces it (that path calls
		// clearPickedDate). With nothing applied the start day is today.
		if (listingState.pickedStart) {
			listingState.draftStart = listingState.pickedStart;
			listingState.draftEnd = listingState.pickedEnd;
		} else {
			listingState.draftStart = getTodayDateKey();
			listingState.draftEnd = '';
		}

		// Opens on the month of the start day, so a restored range is on screen.
		var startSeed = seedMonthFor(listingState.draftStart);
		listingState.startYear = startSeed.year;
		listingState.startMonth = startSeed.month;

		$picker.removeAttr('hidden');
		renderDatePicker();
	}

	function closeDatePicker() {
		getDatePicker().attr('hidden', 'hidden').find('.dp-select').removeClass('open');
	}

	/** Forget the picked range and hide the calendars. */
	function clearPickedDate() {
		listingState.pickedStart = '';
		listingState.pickedEnd = '';
		listingState.draftStart = '';
		listingState.draftEnd = '';
		closeDatePicker();
	}

	/**
	 * Custom range is a two-step choice — the date is what decides it — so the
	 * item click alone must not count as a commit. Snapshot what was committed
	 * before it, ready to roll back if no date is applied.
	 *
	 * The label is stored as the selected item's data-value, not the trigger's
	 * text: the markup wraps long labels across lines, so text() would come
	 * back with the line break baked in.
	 */
	function captureSortSnapshot($dd) {
		listingState.sortSnapshot = {
			sortKey: listingState.sortKey,
			pickedStart: listingState.pickedStart,
			pickedEnd: listingState.pickedEnd,
			value: $dd.find('.dd-simple-item.selected').first().attr('data-value') || '',
			placeholder: $dd.find('.dd-value-info').first().hasClass('is-placeholder')
		};
	}

	/** A commit happened (or a fresh choice replaced it) — nothing to roll back to. */
	function discardSortSnapshot() {
		listingState.sortSnapshot = null;
	}

	/**
	 * Roll the Sort by dropdown back to the snapshot: sort key, picked date,
	 * label, tick and the placeholder colour. No re-render — the committed
	 * state never changed, so the table already matches it.
	 */
	function restoreSortSnapshot() {
		var snapshot = listingState.sortSnapshot;
		if (!snapshot) {
			return;
		}

		discardSortSnapshot();

		var $dd = getListingRoot().find('#shortby-dropdown');
		if (!$dd.length) {
			return;
		}

		listingState.sortKey = snapshot.sortKey;
		listingState.pickedStart = snapshot.pickedStart;
		listingState.pickedEnd = snapshot.pickedEnd;
		listingState.draftStart = snapshot.pickedStart;
		listingState.draftEnd = snapshot.pickedEnd;

		var $items = $dd.find('.dd-simple-item');
		$items.removeClass('selected');

		if (snapshot.value) {
			$items.filter('[data-value="' + snapshot.value + '"]').addClass('selected');
			$dd.find('.dd-value').first().text(snapshot.value);
		}

		$dd.find('.dd-value-info').first().toggleClass('is-placeholder', snapshot.placeholder);
	}

	/** Calendar dismissed without APPLY — undo the provisional selection. */
	function cancelCustomRangeSelection() {
		restoreSortSnapshot();
		closeDatePicker();
	}

	function initDatePicker($root) {
		if (listingState.datePickerBound) {
			return;
		}
		listingState.datePickerBound = true;

		// Keep clicks inside the calendar from closing the Sort by dropdown.
		$root.on('click.dtListing', '#sortDatePicker', function (event) {
			event.stopPropagation();
		});

		$root.on('click.dtListing', '#sortDatePicker .dp-select-trigger', function (event) {
			event.preventDefault();
			var $select = $(this).closest('.dp-select');
			var wasOpen = $select.hasClass('open');
			getDatePicker().find('.dp-select').removeClass('open');
			$select.toggleClass('open', !wasOpen);
		});

		$root.on('click.dtListing', '#sortDatePicker .dp-select-item', function (event) {
			event.preventDefault();
			if ($(this).hasClass('is-disabled')) {
				return;
			}

			var $select = $(this).closest('.dp-select');
			var isMonth = $select.is('[data-dp-month]');
			var value = parseInt($(this).attr('data-value'), 10);

			listingState[isMonth ? 'startMonth' : 'startYear'] = value;

			getDatePicker().find('.dp-select').removeClass('open');
			renderDatePicker();
		});

		$root.on('click.dtListing', '#sortDatePicker .dp-day', function (event) {
			event.preventDefault();

			var key = $(this).attr('data-date');
			if (!key) {
				return;
			}

			// One calendar, two clicks: the first opens a range, the second closes
			// it. A third click starts a fresh range from that day.
			if (listingState.draftStart && !listingState.draftEnd) {
				listingState.draftEnd = key;
			} else {
				listingState.draftStart = key;
				listingState.draftEnd = '';
			}

			renderDatePicker();
		});

		$root.on('click.dtListing', '#sortDatePicker [data-dp-apply]', function (event) {
			event.preventDefault();
			if (!listingState.draftStart || !listingState.draftEnd) {
				return;
			}

			// The range is the commit — Custom range is now the real selection.
			discardSortSnapshot();

			// Picked back-to-front (second day earlier than the first) still
			// describes the same range, so store it low-to-high either way.
			var bounds = getDraftRangeBounds();
			listingState.pickedStart = bounds.from;
			listingState.pickedEnd = bounds.to;

			closeDatePicker();
			getListingRoot().find('#shortby-dropdown').removeClass('open');

			runBehindCommonLoader(function () {
				renderListingRows(listingState.lastRecords);
			});
		});

		$root.on('click.dtListing', '#sortDatePicker [data-dp-cancel]', function (event) {
			event.preventDefault();
			cancelCustomRangeSelection();
			getListingRoot().find('#shortby-dropdown').removeClass('open');
		});
	}

	/** Multi-select filter dropdowns (Status / Source / Destination). */
	function initMultiSelectFilter($listingRoot, rootId) {
		var root = $listingRoot.find('#' + rootId)[0];
		if (!root) {
			return;
		}

		var trigger = root.querySelector('.dd-trigger');
		var valueEl = root.querySelector('.dd-value');
		var selectAllItem = root.querySelector('[data-role="select-all"]');
		var panel = root.querySelector('.dd-panel');
		var items = Array.prototype.slice.call(
			root.querySelectorAll('.dd-check-item[data-value]')
		);

		if (!trigger || !valueEl || !selectAllItem) {
			return;
		}

		function refreshValue() {
			var selected = items.filter(function (item) {
				return item.classList.contains('selected');
			});

			if (selected.length === items.length) {
				valueEl.textContent = 'All';
			} else if (selected.length === 0) {
				valueEl.textContent = 'None';
			} else {
				valueEl.textContent = selected
					.map(function (item) {
						return item.getAttribute('data-value') || '';
					})
					.join(', ');
			}

			selectAllItem.classList.toggle('selected', selected.length === items.length);
		}

		$(trigger).on('click.dtListing', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var isOpen = root.classList.contains('open');

			// closeListingDropdowns skips `root`, so an open dropdown has to be
			// closed here — otherwise a second trigger click never shuts it.
			closeListingDropdowns(root);
			root.classList.toggle('open', !isOpen);
		});

		$(selectAllItem).on('click.dtListing', function (event) {
			event.stopPropagation();
			var selectAll = !selectAllItem.classList.contains('selected');
			items.forEach(function (item) {
				item.classList.toggle('selected', selectAll);
			});
			refreshValue();
		});

		items.forEach(function (item) {
			$(item).on('click.dtListing', function (event) {
				event.stopPropagation();
				item.classList.toggle('selected');
				refreshValue();
			});
		});

		if (panel) {
			$(panel).on('click.dtListing', function (event) {
				event.stopPropagation();
			});
		}

		refreshValue();
	}

	function initListingFilterPanel($root) {
		var filterTrigger = $root.find('#filterTrigger')[0];
		var filterClose = $root.find('#filterClose')[0];
		var filterBackdrop = $root.find('#filterBackdrop')[0];
		var filterApply = $root.find('#filterApply')[0];

		if (filterTrigger) {
			$(filterTrigger).on('click.dtListing', function (event) {
				event.preventDefault();
				event.stopPropagation();
				openFilterPanel();
			});
		}

		if (filterClose) {
			$(filterClose).on('click.dtListing', function (event) {
				event.preventDefault();
				closeFilterPanel();
			});
		}

		if (filterBackdrop) {
			$(filterBackdrop).on('click.dtListing', function () {
				closeFilterPanel();
			});
		}

		if (filterApply) {
			$(filterApply).on('click.dtListing', function (event) {
				event.preventDefault();
				listingState.filters = readFilterSelections($root);
				closeFilterPanel();

				// Refetch so the filtered view reflects the latest CRM state.
				// loadAndRenderListing() owns the loader.
				loadAndRenderListing({ forceReload: true });
			});
		}

		// Chip ✕ — drop that one value and re-apply.
		// Bound first so the filter handler below never sees the date chip.
		$root.on('click.dtListing', '[data-custom-range-chip] .filter-remove', function (event) {
			event.preventDefault();
			event.stopPropagation();

			// Same end state as picking another Sort by option.
			resetSortDropdown();
			renderListingRows(listingState.lastRecords);
		});

		$root.on('click.dtListing', '.data-listing-filter-item .filter-remove', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var $chip = $(this).closest('.data-listing-filter-item');
			if ($chip.is('[data-custom-range-chip]')) {
				return;
			}
			var key = FILTER_FIELDS[$chip.attr('data-filter-dropdown')].key;
			var value = $chip.attr('data-filter-value');

			listingState.filters[key] = (listingState.filters[key] || []).filter(function (option) {
				return option !== value;
			});

			if (hasActiveFilters()) {
				syncFilterDropdowns($root);
				renderListingRows(listingState.lastRecords);
			} else {
				// Last chip gone — same end state as Clear all.
				clearListingFilters();
			}
		});

		$root.on('click.dtListing', '.clearall-link', function (event) {
			event.preventDefault();
			// Clear all means the whole table back — the Sort by range goes too.
			resetSortDropdown();
			clearListingFilters();
		});

		FILTER_DROPDOWN_IDS.forEach(function (dropdownId) {
			initMultiSelectFilter($root, dropdownId);
		});
	}

	/** Push listingState.filters back into the checkbox dropdowns. */
	function syncFilterDropdowns($root) {
		FILTER_DROPDOWN_IDS.forEach(function (dropdownId) {
			var meta = FILTER_FIELDS[dropdownId];
			var picked = listingState.filters[meta.key] || [];
			var $dd = $root.find('#' + dropdownId);
			var $items = $dd.find('.dd-check-item[data-value]');

			// Tick exactly what is filtered — nothing more.
			$items.each(function () {
				var $item = $(this);
				var value = $item.attr('data-value') || '';
				$item.toggleClass('selected', picked.indexOf(value) !== -1);
			});

			// Same wording refreshValue() uses: All when every box is ticked,
			// None when none are.
			var allPicked = picked.length > 0 && picked.length === $items.length;
			var label = 'None';
			if (allPicked) {
				label = 'All';
			} else if (picked.length) {
				label = picked.join(', ');
			}

			$dd.find('.dd-value').first().text(label);
			$dd.find('[data-role="select-all"]').toggleClass('selected', allPicked);
		});
	}

	/** Clear all → every box unticked, label reads None. */
	function deselectAllFilterOptions($root) {
		FILTER_DROPDOWN_IDS.forEach(function (dropdownId) {
			var $dd = $root.find('#' + dropdownId);
			if (!$dd.length) {
				return;
			}

			// Covers the Select-all row too, so its tick clears with the rest.
			$dd.find('.dd-check-item').removeClass('selected');
			$dd.find('.dd-value').first().text('None');
			$dd.removeClass('open');
		});
	}

	function clearListingFilters() {
		listingState.filters = { status: [], source: [], destination: [] };
		deselectAllFilterOptions(getListingRoot());
		renderListingRows(listingState.lastRecords);
	}

	/**
	 * Sync name → detail panel (optional markup).
	 * Safe no-op when the detail panel is not in the HTML yet.
	 */
	function initListingDetailPanel($root) {
		var listingSec = $root.find('.data-transfer-listing-sec')[0];
		var detailPanel = $root.find('.listing-lead-sync-detail')[0];

		if (!listingSec || !detailPanel) {
			return;
		}

		// Animation helpers, scoped to listing.
		if (!document.getElementById('dt-listing-detail-style')) {
			var style = document.createElement('style');
			style.id = 'dt-listing-detail-style';
			style.textContent = [
				'.listing-lead-sync-detail {',
				'  transition: clip-path 0.4s ease, opacity 0.4s ease;',
				'  clip-path: inset(0 0 0% 0);',
				'}',
				'.listing-lead-sync-detail.lsd-hidden {',
				'  clip-path: inset(0 0 100% 0);',
				'  opacity: 0;',
				'  pointer-events: none;',
				'}'
			].join('\n');
			document.head.appendChild(style);
		}

		detailPanel.style.display = 'none';
		detailPanel.classList.add('lsd-hidden');

		function showDetail() {
			listingSec.style.display = 'none';
			detailPanel.style.display = 'block';
			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					detailPanel.classList.remove('lsd-hidden');
				});
			});
		}

		function showListing() {
			detailPanel.classList.add('lsd-hidden');
			$(detailPanel).one('transitionend', function () {
				detailPanel.style.display = 'none';
				listingSec.style.display = 'block';
			});
		}

		$root.on('click.dtListing', '.sync-name', function (event) {
			event.preventDefault();

			// The hover tooltip is still open at this point; hiding the listing
			// underneath it would leave the popup floating over the detail panel.
			if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
				var tooltip = bootstrap.Tooltip.getInstance(this);
				if (tooltip) {
					tooltip.hide();
				}
			}

			var record = findRecordById($(this).closest('tr').attr('data-record-id'));
			if (record) {
				fillSyncDetail(record);
			}

			showDetail();

			// Values can only be measured once the panel is on screen and laid out.
			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					refreshContactsMappingTooltips($(detailPanel));
				});
			});
		});

		$root.on('click.dtListing', '.sync-detail-close', function (event) {
			event.preventDefault();
			showListing();
		});
	}

	/** Bind all listing UI once, per listing root. */
	function initListingDesignerUi(rootSelector) {
		var selector = rootSelector || LISTING_ROOT_SELECTOR;
		var $root = $(selector);

		if (!$root.length || listingState.uiBound[selector]) {
			return;
		}
		listingState.uiBound[selector] = true;

		initListingSearchUi($root);
		initListingSimpleDropdowns($root);
		initListingFilterPanel($root);
		initListingDetailPanel($root);
		initLogsPanel();
		initHistoricSyncPopupUi();

		// Close open dropdowns / filter panel when clicking outside listing controls.
		$(document).on('click.dtListingOutside' + hashOf(selector), function (event) {
			var $target = $(event.target);
			if (!$target.closest(selector + ' .dd').length) {
				closeListingDropdowns(null);
			}
			// The calendar sits inside #shortby-dropdown, so a click anywhere
			// outside that whole control dismisses it — and dismissing without
			// APPLY counts as a cancel, same as the CANCEL button.
			if (!$target.closest(selector + ' #shortby-dropdown').length) {
				cancelCustomRangeSelection();
			}
			if (
				!$target.closest(selector + ' #filterPanel').length &&
				!$target.closest(selector + ' #filterTrigger').length
			) {
				// Do not auto-close the whole filter panel on every outside click —
				// backdrop + close button handle that. Only close nested dropdowns.
				closeFilterDropdowns();
			}
		});

		$(document).on('keydown.dtListingEsc' + hashOf(selector), function (event) {
			if (event.key === 'Escape') {
				closeFilterPanel();
				closeListingDropdowns(null);
			}
		});

		// Bootstrap tooltips on sync-name / action icons (same helper as Connections).
		if (typeof window.initBootstrapTooltips === 'function') {
			window.initBootstrapTooltips($root[0]);
		}
	}

	/** Namespace suffix so the two roots get separate document handlers. */
	function hashOf(selector) {
		return selector.replace(/[^a-zA-Z0-9]/g, '');
	}

	function bindListingScreenEvents() {
		if (listingState.bound[LISTING_SCREEN_KEY]) {
			return;
		}
		listingState.bound[LISTING_SCREEN_KEY] = true;

		// CREATE NEW → Setup/Create (Insert mode).
		$('body').on('click', '.dt-listing-create, #dt-listing-create-btn', function (event) {
			event.preventDefault();
			openCreateScreen({ animate: true });
		});

		// Edit → load record by id into the event screen (Update mode).
		$('body').on(
			'click',
			'#data-transfer-listing [data-action="edit"], #data-transfer-listing-filtered [data-action="edit"]',
			function (event) {
				event.preventDefault();
				event.stopPropagation();

				var recordId = $.trim($(this).closest('tr').attr('data-record-id') || '');
				if (!recordId) {
					window.alert('Invalid data transfer selected.');
					return;
				}

				openEditScreen(recordId);
			}
		);

		// Pause icon → remember which row asked; Bootstrap opens #pause-popup
		// on its own via data-bs-target, so nothing else happens yet.
		$('body').on('click', LISTING_ROOT_SELECTOR + ' [data-action="pause"]', function () {
			listingState.pendingPauseId = $.trim($(this).closest('tr').attr('data-record-id') || '');
		});

		// YES, PAUSE → DT Paused + linked workflow disabled.
		$('body').on('click', '#dt-pause-confirm-btn', function (event) {
			event.preventDefault();
			confirmPauseTransfer();
		});

		// Resume icon → remember row id; Bootstrap opens #resume-popup.
		$('body').on('click', LISTING_ROOT_SELECTOR + ' [data-action="resume"]', function () {
			listingState.pendingResumeId = $.trim($(this).closest('tr').attr('data-record-id') || '');
		});

		// YES, RESUME → DT Running + linked workflow activated.
		$('body').on('click', '#dt-resume-confirm-btn', function (event) {
			event.preventDefault();
			confirmResumeTransfer();
		});

		// Delete icon → same idea: hold the row's id, Bootstrap shows the popup.
		// Rows are rebuilt on every render, so the id has to come off the row
		// that was actually clicked, not from a remembered position.
		$('body').on('click', LISTING_ROOT_SELECTOR + ' [data-action="delete"]', function () {
			listingState.pendingDeleteId = $.trim($(this).closest('tr').attr('data-record-id') || '');
		});

		// YES, DELETE → record leaves CRM, then its row leaves the table.
		$('body').on('click', '#dt-delete-confirm-btn', function (event) {
			event.preventDefault();
			confirmDeleteTransfer();
		});

		// Duplicate icon → remember parent row; Bootstrap opens #duplicate-sync-popup.
		$('body').on('click', LISTING_ROOT_SELECTOR + ' [data-action="duplicate"]', function () {
			listingState.pendingDuplicateId = $.trim($(this).closest('tr').attr('data-record-id') || '');
		});

		// YES → create-mode editor pre-filled from the parent (Copy: name).
		$('body').on('click', '#dt-duplicate-confirm-btn', function (event) {
			event.preventDefault();
			confirmDuplicateTransfer();
		});

		// Dismiss listing success / error banners (START EXPORT, Pause, Resume, Delete).
		$('body').on('click', '[data-dt-listing-alert-dismiss="success"]', function (event) {
			event.preventDefault();
			event.stopPropagation();
			hideListingSuccessAlert();
			if (listingState.successAlertHideTimer) {
				clearTimeout(listingState.successAlertHideTimer);
				listingState.successAlertHideTimer = null;
			}
		});

		$('body').on('click', '[data-dt-listing-alert-dismiss="error"]', function (event) {
			event.preventDefault();
			event.stopPropagation();
			hideListingErrorAlert();
			if (listingState.errorAlertHideTimer) {
				clearTimeout(listingState.errorAlertHideTimer);
				listingState.errorAlertHideTimer = null;
			}
		});

		// The tab is a fresh start: drop filters / search / sort.
		// The repaint belongs to DataTransferModule.open() — it decides between
		// listing and create from one settled fetch, and firing a second one
		// here is what let the two responses race.
		$(document).on('click.dtListingTab', '#nav-data-transfer-tab', function () {
			resetListingToInitialState();
		});

		initListingDesignerUi(LISTING_ROOT_SELECTOR);
		watchListingVisibility();
	}

	function registerListingScreen() {
		var dt = getDataTransferModule();
		if (!dt || typeof dt.registerScreen !== 'function') {
			console.error('Cannot register listing screen: DataTransferModule.registerScreen missing.');
			return;
		}

		dt.registerScreen(LISTING_SCREEN_KEY, {
			rootSelector: LISTING_ROOT_SELECTOR,
			url: LISTING_URL,
			bind: bindListingScreenEvents
		});
	}

	/**
	 * Hover hint on the main Data Transfer tab.
	 * The tab lives in widget.html, so the tooltip is created here rather than
	 * through data-bs-* attributes.
	 */
	function initDataTransferTabTooltip() {
		var tab = document.getElementById('nav-data-transfer-tab');
		if (!tab || typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
			return;
		}

		var tooltip = bootstrap.Tooltip.getOrCreateInstance(tab, {
			title: 'Your data is ready to move. Use the ‘Data transfer’ tab to get started.',
			trigger: 'hover',
			placement: 'bottom',
			container: 'body',
			customClass: 'dt-tab-tooltip'
		});

		// The hint only helps before the tab is opened — once it is active the
		// user is already there. show.bs.tooltip is cancelable, so this stops it
		// from ever appearing rather than hiding it after the fact.
		$(tab).on('show.bs.tooltip', function (event) {
			if (tab.classList.contains('active')) {
				event.preventDefault();
			}
		});

		// Clicking the tab makes it active mid-hover; drop the open one.
		$(tab).on('click.dtTabTooltip', function () {
			tooltip.hide();
		});
	}

	// data-transfer.js loads before this file, so registration is safe here.
	registerListingScreen();
	initDataTransferTabTooltip();

	window.DataTransferListing = {
		fetchRecords: fetchDataTransferRecords,
		hasRecords: hasDataTransferRecords,
		invalidateRecordsCache: invalidateRecordsCache,
		open: openListingScreen,
		openCreate: openCreateScreen,
		openEdit: openEditScreen,
		openDuplicate: openDuplicateScreen,
		openAfterEditorClose: openAfterEditorClose,
		initUi: initListingDesignerUi,
		syncOverlays: resyncSharedOverlays,
		render: loadAndRenderListing,
		showSuccessAlert: showListingSuccessAlert,
		hideSuccessAlert: hideListingSuccessAlert,
		showErrorAlert: showListingErrorAlert,
		hideErrorAlert: hideListingErrorAlert,
		showLoader: showCommonLoader,
		hideLoader: hideCommonLoader,
		getLastRecords: function () {
			return listingState.lastRecords.slice();
		}
	};



	/**
	 * Cache a pane's first log row before we ever empty its tbody, then clone
	 * it per log — same idea as the listing table's row template.
	 * key keeps the two panes apart; their columns differ.
	 */
	function getLogsRowTemplate($tbody, key) {
		if (!listingState.logsRowTemplate[key]) {
			var row = $tbody.find('tr').first()[0];
			listingState.logsRowTemplate[key] = row ? row.outerHTML : '';
		}
		return listingState.logsRowTemplate[key];
	}

	/** Listing record for a row id. */
	function getListingRecordById(recordId) {
		return (listingState.lastRecords || []).filter(function (record) {
			return String(record.id) === String(recordId);
		})[0] || null;
	}

	/** Sync name for a listing row id. */
	function getSyncNameById(recordId) {
		var match = getListingRecordById(recordId);

		return $.trim((match && match.Name) || '');
	}

	function formatHistoricSyncTransferName(name) {
		var trimmed = $.trim(name || '');

		return trimmed ? "'" + trimmed + "'" : '-';
	}

	function resolveHistoricSyncRecordId() {
		return $.trim(listingState.pendingHistoricSyncId || listingState.logsRecordId || '');
	}

	function readHistoricSyncBatchSizeFromDom() {
		var dd = document.getElementById('historic-sync-size');
		if (!dd) {
			return '';
		}

		var selected = dd.querySelector('.dd-simple-item.selected');
		if (selected) {
			return $.trim(selected.getAttribute('data-value') || selected.textContent || '');
		}

		var valueEl = dd.querySelector('.dd-value');
		return $.trim((valueEl && valueEl.textContent) || '');
	}

	function getHistoricSyncBatchSize() {
		return $.trim(listingState.historicSyncBatchSize || readHistoricSyncBatchSizeFromDom() || '');
	}

	function resetHistoricSyncBatchSizeDropdown() {
		var dd = document.getElementById('historic-sync-size');
		if (!dd) {
			listingState.historicSyncBatchSize = '';
			return;
		}

		var defaultValue = listingState.historicSyncDefaultBatchSize;
		var valueEl = dd.querySelector('.dd-value');
		var items = Array.prototype.slice.call(dd.querySelectorAll('.dd-simple-item'));
		var selectedItem = null;

		items.forEach(function (item) {
			var itemValue = $.trim(item.getAttribute('data-value') || item.textContent || '');
			var isSelected = !!defaultValue && itemValue === defaultValue;
			item.classList.toggle('selected', isSelected);
			if (isSelected) {
				selectedItem = item;
			}
		});

		if (!selectedItem && items.length) {
			selectedItem = items[0];
			selectedItem.classList.add('selected');
		}

		if (selectedItem && valueEl) {
			valueEl.textContent = $.trim(
				selectedItem.getAttribute('data-value') || selectedItem.textContent || ''
			);
		}

		listingState.historicSyncBatchSize = selectedItem
			? $.trim(selectedItem.getAttribute('data-value') || selectedItem.textContent || '')
			: '';
		dd.classList.remove('open');
	}

	function populateHistoricSyncPopup() {
		var recordId = resolveHistoricSyncRecordId();
		var transferName = getSyncNameById(recordId);

		$('#historic-sync-transfer-name').text(formatHistoricSyncTransferName(transferName));
		resetHistoricSyncBatchSizeDropdown();
	}

	function initHistoricSyncBatchSizeDropdown() {
		var dd = document.getElementById('historic-sync-size');
		if (!dd || dd.getAttribute('data-historic-batch-bound') === 'true') {
			return;
		}

		dd.setAttribute('data-historic-batch-bound', 'true');

		var trigger = dd.querySelector('.dd-trigger');
		var valueEl = dd.querySelector('.dd-value');
		var items = Array.prototype.slice.call(dd.querySelectorAll('.dd-simple-item'));
		if (!trigger || !valueEl || !items.length) {
			return;
		}

		var defaultItem = dd.querySelector('.dd-simple-item.selected') || items[0];
		listingState.historicSyncDefaultBatchSize = $.trim(
			defaultItem.getAttribute('data-value') || defaultItem.textContent || ''
		);
		listingState.historicSyncBatchSize = listingState.historicSyncDefaultBatchSize;

		trigger.addEventListener('click', function (event) {
			event.preventDefault();
			event.stopPropagation();

			var isOpen = dd.classList.contains('open');
			dd.classList.toggle('open', !isOpen);
		});

		items.forEach(function (item) {
			item.addEventListener('click', function (event) {
				event.preventDefault();
				event.stopPropagation();

				items.forEach(function (el) {
					el.classList.remove('selected');
				});
				item.classList.add('selected');
				valueEl.textContent = $.trim(item.getAttribute('data-value') || item.textContent || '');
				dd.classList.remove('open');
				listingState.historicSyncBatchSize = getHistoricSyncBatchSize();
			});
		});

		document.addEventListener('click', function (event) {
			if (!dd.contains(event.target)) {
				dd.classList.remove('open');
			}
		});

		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') {
				dd.classList.remove('open');
			}
		});
	}

	/**
	 * Historic sync confirmation popup — batch-size dropdown + dynamic transfer name.
	 * Modal markup lives outside #data-transfer-listing, so it gets its own init.
	 */
	function initHistoricSyncPopupUi() {
		if (listingState.historicSyncPopupBound) {
			return;
		}

		var popup = document.getElementById('historic-sync-popup');
		if (!popup) {
			return;
		}

		listingState.historicSyncPopupBound = true;
		initHistoricSyncBatchSizeDropdown();

		$(popup).on('show.bs.modal', function (event) {
			var trigger = event.relatedTarget;

			if (trigger) {
				if (trigger.id === 'startSyncBtn') {
					listingState.pendingHistoricSyncId = $.trim(listingState.logsRecordId || '');
				} else if ($(trigger).is('[data-action="historic"]')) {
					listingState.pendingHistoricSyncId = $.trim(
						$(trigger).closest('tr').attr('data-record-id') || ''
					);
				}
			}

			populateHistoricSyncPopup();
		});

		$('body').on('click', '#dt-historic-sync-confirm-btn', function (event) {
			event.preventDefault();
			confirmHistoricSync();
		});
	}

	/**
	 * ZOHO.CRM.FUNCTIONS.execute answers { details: { output: "<json string>" } }.
	 * Returns null when any step of that path is missing or is not JSON, so the
	 * caller decides what to tell the user. Same shape data-transfer.js reads.
	 */
	function parseFunctionOutput(response) {
		if (!response || !response.details || response.details.output == null) {
			return null;
		}

		var output = response.details.output;
		if (typeof output !== 'string') {
			return output;
		}

		try {
			return JSON.parse(output);
		} catch (parseError) {
			console.error('parseFunctionOutput error:', parseError);
			return null;
		}
	}

	/**
	 * Hand the transfer and the chosen batch size to the historic sync function.
	 * Resolves with the parsed output; rejects when the call fails or answers
	 * with something we cannot read.
	 */
	function startBulkContactUpload(recordId, batchSize) {
		if (
			!window.ZOHO
			|| !ZOHO.CRM
			|| !ZOHO.CRM.FUNCTIONS
			|| typeof ZOHO.CRM.FUNCTIONS.execute !== 'function'
		) {
			return Promise.reject(new Error('Zoho function API is unavailable.'));
		}

		var reqData = {
			arguments: JSON.stringify({
				data_transfer_id: recordId,
				batchSize: batchSize
			})
		};

		return Promise.resolve(
			ZOHO.CRM.FUNCTIONS.execute(BULK_CONTACT_UPLOAD_FUNCTION, reqData)
		).then(function (response) {
			var output = parseFunctionOutput(response);
			if (!output) {
				console.error('bulk contact upload — unreadable response:', response);
				throw new Error(HISTORIC_SYNC_FAILED_MESSAGE);
			}
			return output;
		});
	}

	/** Counts are only worth showing when the function actually sent one. */
	function formatHistoricSyncCount(value) {
		var count = Number(value);

		return (!isNaN(count) && count > 0) ? count : null;
	}

	/**
	 * First usable error string from a failed historic-sync batch.
	 *
	 * A batch is treated as failed when its status is Fail / failed / error, or
	 * when it carries an error and no success status. Missing arrays, empty
	 * lists, and batches with no error are skipped rather than assumed.
	 */
	function getHistoricSyncBatchError(output) {
		var batches = output && output.batches;
		if (!Array.isArray(batches) || !batches.length) {
			return '';
		}

		var firstError = '';

		for (var i = 0; i < batches.length; i++) {
			var batch = batches[i];
			if (!batch || typeof batch !== 'object') {
				continue;
			}

			var error = $.trim(String(batch.error || ''));
			if (!error) {
				continue;
			}

			var batchStatus = $.trim(String(batch.status || '')).toLowerCase();
			var isFailed = !batchStatus
				|| batchStatus === 'fail'
				|| batchStatus === 'failed'
				|| batchStatus === 'error';

			if (isFailed) {
				return error;
			}

			if (!firstError) {
				firstError = error;
			}
		}

		return firstError;
	}

	/**
	 * The most useful line the failed / partial payload carries.
	 * Prefer the failed batch's error (e.g. "file Field is required.") over a
	 * generic status banner.
	 */
	function describeHistoricSyncError(output) {
		var batchError = getHistoricSyncBatchError(output);
		if (batchError) {
			return batchError;
		}

		var message = $.trim(String((output && (output.message || output.error)) || ''));
		if (message) {
			return message;
		}

		var batches = output && output.batches;
		if (Array.isArray(batches) && batches.length) {
			return batches.length + ' batch(es) reported an error.';
		}

		return '';
	}

	/** success / partial_success / anything else → one banner on the listing. */
	function reportHistoricSyncOutcome(recordId, output) {
		var status = $.trim(String((output && output.status) || '')).toLowerCase();
		var name = getSyncNameById(recordId);
		var subject = name ? '‘' + name + '’' : 'Historic sync';

		if (status === 'success') {
			var records = formatHistoricSyncCount(output.total_records_sent);
			var batches = formatHistoricSyncCount(output.total_batches);
			var sent = '';

			if (records && batches) {
				sent = ' — ' + records + ' record(s) in ' + batches + ' batch(es)';
			} else if (records) {
				sent = ' — ' + records + ' record(s)';
			}

			//showListingSuccessAlert(subject + ' historic sync started successfully' + sent + '.');
			showListingSuccessAlert(subject + ' historic sync started successfully' + '.');
			return;
		}

		// Partially done is not a failure: say what got through, then why.
		if (status === 'partial_success') {
			var failed = formatHistoricSyncCount(output.failed_batches);
			var total = formatHistoricSyncCount(output.total_batches);
			var detail = describeHistoricSyncError(output);

			showListingErrorAlert(
				subject + ' historic sync completed partially'
				+ ((failed && total) ? ' — ' + failed + ' of ' + total + ' batch(es) failed' : '')
				+ '.'
				+ (detail ? ' ' + detail : '')
			);
			return;
		}

		showListingErrorAlert(describeHistoricSyncError(output) || HISTORIC_SYNC_FAILED_MESSAGE);
	}

	function isHistoricSyncSuccess(output) {
		return $.trim(String((output && output.status) || '')).toLowerCase() === 'success';
	}

	/**
	 * Historic tab after a successful START SYNC — same COQL path the logs
	 * panel already uses (loadLogsPane → runLogsCoql), so new rows show
	 * without closing the popup.
	 */
	function refreshHistoricTransferLogs() {
		if (!listingState.logsRecordId) {
			return Promise.resolve();
		}

		return loadLogsPane('historic').catch(function (refreshError) {
			console.error('refresh historic logs after start sync failed:', refreshError);
		});
	}

	/**
	 * YES, START SYNC — closes the popup, then runs the historic sync behind the
	 * shared loader. Same sequencing as Pause / Resume / Delete: the loader is
	 * dropped in a trailing then(), so no answer can leave it on screen.
	 */
	function confirmHistoricSync() {
		try {
			captureListingAlertAnchor(document.getElementById('historic-sync-popup'));

			var recordId = resolveHistoricSyncRecordId();
			var batchSize = getHistoricSyncBatchSize();

			if (!recordId) {
				showListingErrorAlert('Invalid data transfer selected.');
				return Promise.resolve();
			}

			if (!batchSize) {
				showListingErrorAlert('Select batch size for sync.');
				return Promise.resolve();
			}

			listingState.historicSyncBatchSize = batchSize;

			return hideActionPopup('historic-sync-popup').then(function () {
				showCommonLoader();

				return startBulkContactUpload(recordId, batchSize)
					.then(function (output) {
						reportHistoricSyncOutcome(recordId, output);
						if (isHistoricSyncSuccess(output)) {
							return refreshHistoricTransferLogs();
						}
					})
					.catch(function (error) {
						console.error('historic sync error:', error);
						showListingErrorAlert(
							(error && error.message) || HISTORIC_SYNC_FAILED_MESSAGE
						);
					})
					.then(function () {
						hideCommonLoader();
					});
			}).then(function () {
				listingState.pendingHistoricSyncId = '';
			});
		} catch (historicSyncError) {
			console.error('confirmHistoricSync failed:', historicSyncError);
			hideCommonLoader();
			showListingErrorAlert(HISTORIC_SYNC_FAILED_MESSAGE);
			return Promise.resolve();
		}
	}

	/**
	 * Historic syncs only exist for the Contacts destination — the same field
	 * the listing's "Destination data" column shows.
	 */
	function syncHasHistoric(recordId) {
		return isContactsSyncRecord(getListingRecordById(recordId));
	}

	/**
	 * Show or hide the Historic tab. Hiding it also drops the user back on
	 * Real-time, or they would be left looking at a pane with no way out.
	 */
	function applyHistoricTabVisibility(show) {
		$('.logs-tab[data-tab="historic"]').toggle(!!show);

		if (show || listingState.activeLogsTab !== 'historic') {
			return;
		}

		listingState.activeLogsTab = 'realtime';
		$('.logs-tab').removeClass('active')
			.filter('[data-tab="realtime"]').addClass('active');
		$('#pane-historic').hide();
		$('#pane-realtime').show();
	}

	/** Panel heading: "Transfer logs: <sync name>". */
	function setLogsPanelTitle(syncName) {
		var $title = $('#logsPanelLabel');
		if (!$title.length) {
			return;
		}

		$title.text('Transfer logs: ' + ($.trim(syncName || '') || '-'));
	}

	/** Low / high end of a pair of day keys, whichever order they were picked. */
	function getOrderedRangeBounds(firstKey, secondKey) {
		if (firstKey && secondKey && firstKey > secondKey) {
			return { from: secondKey, to: firstKey };
		}

		return { from: firstKey, to: secondKey };
	}

	// Range picker for one logs pane — its own state, so Real-time and Historic
	// never share a selection. Nothing reaches the pane until APPLY.
	function createLogsRangePicker(paneKey, pickerElement) {
		var $picker = $(pickerElement);
		if (!$picker.length) {
			return null;
		}

		// draft*   — what the user is choosing right now
		// applied* — what this pane is actually filtered by
		var pickerState = {
			draftStart: '',
			draftEnd: '',
			appliedStart: '',
			appliedEnd: '',
			shownYear: 0,
			shownMonth: 0
		};

		/** Repaint the header lists and the day grid, then re-gate APPLY. */
		function render() {
			var year = pickerState.shownYear;
			var month = pickerState.shownMonth;

			var monthValues = MONTH_NAMES.map(function (name, index) {
				return index;
			});
			fillSelectPanel(
				$picker.find('[data-dp-month]'),
				monthValues,
				MONTH_NAMES,
				month,
				function (monthIndex) {
					return isMonthAheadOfToday(monthIndex, year);
				}
			);

			var thisYear = new Date().getFullYear();
			var years = [];
			for (var y = thisYear - YEAR_SPAN_BACK; y <= thisYear + YEAR_SPAN_FORWARD; y += 1) {
				years.push(y);
			}
			fillSelectPanel($picker.find('[data-dp-year]'), years, years.map(String), year);

			var todayKey = getTodayDateKey();
			var bounds = getOrderedRangeBounds(pickerState.draftStart, pickerState.draftEnd);
			var showBand = !!(bounds.from && bounds.to);

			var firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7;
			var daysInMonth = new Date(year, month + 1, 0).getDate();
			var cells = [];

			for (var blank = 0; blank < firstWeekday; blank += 1) {
				cells.push('<button type="button" class="dp-day is-empty" tabindex="-1"></button>');
			}

			for (var day = 1; day <= daysInMonth; day += 1) {
				var key = buildDateKey(year, month, day);
				var classes = 'dp-day';
				var isSelected = key === pickerState.draftStart || key === pickerState.draftEnd;

				// Nothing was logged ahead of today, so those days stay unpickable.
				var isAhead = key > todayKey;

				if (isAhead) {
					classes += ' is-disabled';
				} else if (isSelected) {
					classes += ' is-selected';
				} else if (showBand && key > bounds.from && key < bounds.to) {
					classes += ' is-in-range';
				}

				cells.push(
					'<button type="button" class="' + classes + '" data-date="' + key + '"' +
					(isAhead ? ' disabled tabindex="-1"' : '') + '>' +
					pad2(day) +
					'</button>'
				);
			}

			$picker.find('[data-dp-grid]').html(cells.join(''));

			// A range needs both ends — one day alone cannot be applied.
			$picker.find('[data-dp-apply]').prop(
				'disabled',
				!(pickerState.draftStart && pickerState.draftEnd)
			);
		}

		function open() {
			// An applied range reopens as it was; otherwise today is the start day.
			if (pickerState.appliedStart) {
				pickerState.draftStart = pickerState.appliedStart;
				pickerState.draftEnd = pickerState.appliedEnd;
			} else {
				pickerState.draftStart = getTodayDateKey();
				pickerState.draftEnd = '';
			}

			// Opens on the month of the start day.
			var seed = seedMonthFor(pickerState.draftStart);
			pickerState.shownYear = seed.year;
			pickerState.shownMonth = seed.month;

			$picker.addClass('show');
			render();
		}

		function close() {
			$picker.removeClass('show').find('.dp-select').removeClass('open');
		}

		/** A preset (or the pill's ✕) replaced the range — forget it. */
		function clearApplied() {
			pickerState.appliedStart = '';
			pickerState.appliedEnd = '';
			pickerState.draftStart = '';
			pickerState.draftEnd = '';
		}

		// Clicks inside must not reach the document handler that closes the
		// dropdown, or picking a day would shut the picker.
		$picker.on('click', function (event) {
			event.stopPropagation();
		});

		$picker.on('click', '.dp-select-trigger', function (event) {
			event.preventDefault();

			var $select = $(this).closest('.dp-select');
			var wasOpen = $select.hasClass('open');

			$picker.find('.dp-select').removeClass('open');
			$select.toggleClass('open', !wasOpen);
		});

		$picker.on('click', '.dp-select-item', function (event) {
			event.preventDefault();
			if ($(this).hasClass('is-disabled')) {
				return;
			}

			var $select = $(this).closest('.dp-select');
			var isMonth = $select.is('[data-dp-month]');
			var value = parseInt($(this).attr('data-value'), 10);

			pickerState[isMonth ? 'shownMonth' : 'shownYear'] = value;

			$picker.find('.dp-select').removeClass('open');
			render();
		});

		$picker.on('click', '.dp-day', function (event) {
			event.preventDefault();

			var key = $(this).attr('data-date');
			if (!key) {
				return;
			}

			// One calendar, two clicks: the first opens a range, the second closes
			// it. A third click starts a fresh range from that day.
			if (pickerState.draftStart && !pickerState.draftEnd) {
				pickerState.draftEnd = key;
			} else {
				pickerState.draftStart = key;
				pickerState.draftEnd = '';
			}

			render();
		});

		$picker.on('click', '[data-dp-apply]', function (event) {
			event.preventDefault();
			if (!pickerState.draftStart || !pickerState.draftEnd) {
				return;
			}

			// Picked back-to-front still describes the same range, so store it
			// low-to-high either way.
			var bounds = getOrderedRangeBounds(pickerState.draftStart, pickerState.draftEnd);
			pickerState.appliedStart = bounds.from;
			pickerState.appliedEnd = bounds.to;

			close();

			var fromDate = parseLogDateKey(bounds.from);
			var toDate = parseLogDateKey(bounds.to);

			applyLogsDuration(paneKey, {
				from: bounds.from,
				to: bounds.to,
				label: buildRangeLabel(fromDate, toDate)
			});
		});

		$picker.on('click', '[data-dp-cancel]', function (event) {
			event.preventDefault();
			close();
		});

		return {
			open: open,
			close: close,
			clearApplied: clearApplied
		};
	}

	/** One range picker per pane, filled in when the logs panel is wired up. */
	var logsRangePickers = {};

	/** Every control a pane owns, so one set of code drives both. */
	var LOGS_PANE_UI = {
		realtime: {
			paneId: 'pane-realtime',
			durationDdId: 'logs-duration-dropdown',
			perPageDdId: 'logs-perpage-dropdown',
			pillId: 'realtimeDurationPill',
			pillTextId: 'realtimeDurationText',
			extraShowId: 'realtimeInfoBanner',
			columns: 3
		},
		historic: {
			paneId: 'pane-historic',
			durationDdId: 'logs-duration-historic-dropdown',
			perPageDdId: 'logs-perpage-historic-dropdown',
			pillId: 'historicDurationPill',
			pillTextId: 'historicDurationText',
			extraShowId: 'historicSummary',
			columns: 4
		}
	};

	/** Back to "everything, page one" — used when a new sync is opened. */
	function resetLogsPanes() {
		Object.keys(LOGS_PANE_UI).forEach(function (key) {
			listingState.logsPanes[key] = makeLogsPane();
			clearLogsDuration(key, { silent: true });
		});
	}

	/** Show a chosen duration on the pane's dropdown + pill, then repaint. */
	function applyLogsDuration(key, range) {
		var ui = LOGS_PANE_UI[key];
		var pane = getLogsPane(key);
		if (!ui || !pane || !range) {
			return;
		}

		pane.from = range.from;
		pane.to = range.to;
		pane.page = 1;

		var dd = document.getElementById(ui.durationDdId);
		var value = dd && dd.querySelector('.dd-value');
		if (value) {
			value.textContent = range.label;
			value.classList.add('set');
		}

		$('#' + ui.pillTextId).text(range.label);
		$('#' + ui.pillId).addClass('show');
		$('#' + ui.extraShowId).addClass('show');

		// The window is part of the query, so CRM has to be asked again.
		loadLogsPane(key);
	}

	/** Pill removed → no date filter, on this pane only. */
	function clearLogsDuration(key, options) {
		var ui = LOGS_PANE_UI[key];
		var pane = getLogsPane(key);
		if (!ui || !pane) {
			return;
		}

		pane.from = '';
		pane.to = '';
		pane.page = 1;

		var dd = document.getElementById(ui.durationDdId);
		if (dd) {
			var value = dd.querySelector('.dd-value');
			if (value) {
				value.textContent = 'Select duration';
				value.classList.remove('set');
			}
			dd.querySelectorAll('.dd-simple-item').forEach(function (item) {
				item.classList.remove('selected');
			});
		}

		$('#' + ui.pillId).removeClass('show');
		$('#' + ui.extraShowId).removeClass('show');

		// The picker has to forget it too, or reopening Custom range would
		// restore a range that is no longer applied — including on the next
		// sync, since resetLogsPanes comes through here.
		if (logsRangePickers[key]) {
			logsRangePickers[key].clearApplied();
		}

		if (!(options && options.silent)) {
			loadLogsPane(key);
		}
	}

	/** How many numbered buttons the design shows at once. */
	var LOGS_PAGE_BUTTONS = 5;

	/**
	 * Rebuild a pane's numbered page buttons around the current page.
	 * The nav's first two and last two buttons are the first/prev and next/last
	 * arrows; everything between them is ours to replace. Classes stay exactly
	 * as the designer wrote them (btn / active-page) so nothing looks different.
	 */
	function renderLogsPagination(paneId, key, totalPages, page) {
		var nav = document.querySelector('#' + paneId + ' .pagination-nav');
		if (!nav) {
			return;
		}

		var buttons = Array.prototype.slice.call(nav.querySelectorAll('button'));
		if (buttons.length < 4) {
			return;
		}

		var lead = buttons.slice(0, 2);
		var trail = buttons.slice(-2);

		if (nav.getAttribute('data-logs-nav-bound') !== 'true') {
			nav.setAttribute('data-logs-nav-bound', 'true');
			lead[0].setAttribute('data-logs-nav', 'first');
			lead[1].setAttribute('data-logs-nav', 'prev');
			trail[0].setAttribute('data-logs-nav', 'next');
			trail[1].setAttribute('data-logs-nav', 'last');

			nav.addEventListener('click', function (event) {
				var button = event.target.closest('button');
				if (!button) {
					return;
				}

				var pane = getLogsPane(key);
				var step = button.getAttribute('data-logs-nav');
				var target = button.getAttribute('data-logs-page');

				if (target) {
					pane.page = parseInt(target, 10);
				} else if (step === 'first') {
					pane.page = 1;
				} else if (step === 'prev') {
					pane.page -= 1;
				} else if (step === 'next') {
					pane.page += 1;
				} else if (step === 'last') {
					pane.page = Number.MAX_SAFE_INTEGER;
				} else {
					return;
				}

				// loadLogsPane clamps, so an out-of-range page fixes itself.
				loadLogsPane(key);
			});
		}

		buttons.slice(2, -2).forEach(function (button) {
			button.remove();
		});

		// Slide a fixed-size window so the current page stays inside it.
		var start = Math.max(1, Math.min(
			page - Math.floor(LOGS_PAGE_BUTTONS / 2),
			totalPages - LOGS_PAGE_BUTTONS + 1
		));
		var end = Math.min(totalPages, start + LOGS_PAGE_BUTTONS - 1);

		for (var number = start; number <= end; number += 1) {
			var button = document.createElement('button');
			button.type = 'button';
			button.className = 'btn' + (number === page ? ' active-page' : '');
			button.textContent = String(number).padStart(2, '0');
			button.setAttribute('data-logs-page', String(number));
			nav.insertBefore(button, trail[0]);
		}
	}

	/**
	 * The green banner sits outside both panes, so it follows whichever tab is
	 * open rather than belonging to one of them.
	 */
	function updateLogsSuccessBanner() {
		var key = listingState.activeLogsTab || 'realtime';
		var pane = getLogsPane(key);
		if (!pane) {
			return;
		}

		// Every log the sync produced, passed and failed alike.
		$('#successBannerText').text(
			'Unique records exported: ' + formatLogCount(pane.total)
		);

		// Always on. On an empty sync this is the only strip left above the
		// illustration — the info banner and the summary still go with it.
		$('#successBanner').show();
	}

	/**
	 * Wrapper the empty-state classes go on. Historic keeps the START SYNC
	 * pitch outside #historicContent, so only the content half is swapped.
	 */
	function getLogsEmptyScope(key) {
		return key === 'historic'
			? $('#historicContent')
			: $('#' + LOGS_PANE_UI[key].paneId);
	}

	/**
	 * Swap a pane between its table and the illustration.
	 *
	 * isEmpty  — nothing to list right now: banner, summary, table and footer
	 *            give way to the illustration.
	 * isBlank  — the sync has no logs at all, so the duration control and pill
	 *            go too; there is no filter to undo. When a filter is what
	 *            emptied the list they stay, or the user would be stuck.
	 */
	function applyLogsEmptyState(key, isEmpty, isBlank) {
		getLogsEmptyScope(key)
			.toggleClass('is-logs-empty', !!isEmpty)
			.toggleClass('is-logs-blank', !!(isEmpty && isBlank));
	}

	/** Put a pane's table into a single full-width message row. */
	function showLogsMessage(key, message) {
		// A message needs the table visible — an empty state left over from the
		// previous sync would hide it.
		applyLogsEmptyState(key, false, false);

		var config = LOGS_PANE_UI[key];
		var $tbody = $('#' + config.paneId + ' .logs-table tbody').first();

		if ($tbody.length) {
			$tbody.html(
				'<tr class="logs-empty-row"><td colspan="' + config.columns + '">'
				+ message
				+ '</td></tr>'
			);
		}
	}

	/** Paint one pane's rows for the page it is on. */
	function paintLogsRows(key, rows) {
		var config = LOGS_PANE_UI[key];
		var $tbody = $('#' + config.paneId + ' .logs-table tbody').first();
		if (!$tbody.length) {
			return;
		}

		var template = getLogsRowTemplate($tbody, key);

		if (!rows.length) {
			// The illustration is the empty state now — a "No logs" row here
			// would also undo it, since showLogsMessage clears the classes.
			$tbody.empty();
			return;
		}

		var $rows = $();

		rows.forEach(function (log) {
			var $row = $(template);
			var $cells = $row.children('td');

			if (key === 'historic') {
				$cells.eq(0).text(formatLogTimestamp(log.netcore0__Start_Time));
				// Still running → the field is empty, and the design says NA.
				$cells.eq(1).text(
					log.netcore0__Completed_On
						? formatLogTimestamp(log.netcore0__Completed_On)
						: 'NA'
				);
				$cells.eq(2).text(log.netcore0__Log_Status || '-');
				$cells.eq(3).text(getLogRecordId(log) || '-');
			} else {
				$cells.eq(0).text(formatLogTimestamp(log.Created_Time));
				$cells.eq(1).text(getLogRecordId(log) || '-');
				$cells.eq(2).text(log.netcore0__Error_Message || '-');
			}

			$rows = $rows.add($row);
		});

		$tbody.empty().append($rows);
	}

	/**
	 * Repaint one pane from the logs it already holds.
	 *
	 * Real-time lists failures only — that is what its Error message column and
	 * the "Failed syncs" heading describe. Historic lists everything, because
	 * its Status column is what tells success from failure.
	 *
	 * Counts describe the whole filtered window, not just the visible page,
	 * so they do not jump around as the user pages through.
	 */
	function renderLogsPane(key) {
		var pane = getLogsPane(key);
		var config = LOGS_PANE_UI[key];
		if (!pane || !config) {
			return;
		}

		if (key === 'historic') {
			$('#historicTotalSyncs').text(formatLogCount(pane.total));
			$('#historicFailedSyncs').text(formatLogCount(pane.failed));

			// The pitch keys off every historic log, not the filtered set —
			// picking a quiet day should leave the table on screen, not send
			// the user back to START SYNC.
			$('#historicEmpty').toggle(!pane.anyLogs);
			$('#historicContent').toggle(!!pane.anyLogs);
		} else {
			$('#realtimeInfoText').text(
				'Total records exports: ' + formatLogCount(pane.total)
				+ ' | Failures: ' + formatLogCount(pane.failed)
			);
			// Record ID is the log's own id, so every failure is its own sync.
			$('#realtimeFailedSyncs').text(formatLogCount(pane.failed));
		}

		updateLogsSuccessBanner();

		applyLogsEmptyState(key, !pane.listedTotal, !pane.anyLogs);
		renderLogsPagination(config.paneId, key, pane.totalPages, pane.page);
		paintLogsRows(key, pane.rows);
	}

	/**
	 * View link → load this sync's logs and paint both panes.
	 * One fetch feeds both; netcore0__Log_Type decides which pane a log lands
	 * in, and an empty type lands in neither.
	 */
	function loadTransferLogs(recordId) {
		var id = $.trim(recordId || '');

		listingState.logsRecordId = id;
		setLogsPanelTitle(getSyncNameById(id));

		// Decided before the panes are painted so the tab never flickers in.
		var hasHistoric = syncHasHistoric(id);
		applyHistoricTabVisibility(hasHistoric);

		// Cache each pane's template row before anything empties the tbody.
		Object.keys(LOGS_PANE_UI).forEach(function (key) {
			var $tbody = $('#' + LOGS_PANE_UI[key].paneId + ' .logs-table tbody').first();
			if ($tbody.length) {
				getLogsRowTemplate($tbody, key);
			}
		});

		resetLogsPanes();

		// Paint the now-empty panes straight away. The panel is already on
		// screen while the fetch runs, and without this the markup's sample
		// row and counts ("6,102 | 971") sit there until the logs land —
		// which is why the empty state only showed on a second open.
		renderLogsPane('realtime');
		if (hasHistoric) {
			renderLogsPane('historic');
		}

		if (!id) {
			return Promise.resolve();
		}

		// Loader covers the empty panes until the first page lands.
		var doneLoading = beginCommonLoader();

		// No Historic tab means no Historic queries — three COQL calls saved.
		var fetches = [loadLogsPane('realtime')];
		if (hasHistoric) {
			fetches.push(loadLogsPane('historic'));
		}

		return Promise.all(fetches).then(function () {
			if (listingState.logsRecordId !== id) {
				return;
			}
		}).catch(function (error) {
			console.error('load transfer logs error:', error);
			showLogsMessage('realtime', 'Could not load logs.');
			showLogsMessage('historic', 'Could not load logs.');
		}).then(doneLoading, doneLoading);
	}

	/**
	 * Logs panel (View link).
	 * Called from initListingDesignerUi, i.e. after the partial is in the DOM —
	 * running at script time would find every element null.
	 */
	function initLogsPanel() {
		/* ---------- open / close logs panel ---------- */
		const panel = document.getElementById('logsPanel');
		const backdrop = document.getElementById('logsBackdrop');
		const closeBtn = document.getElementById('logsClose');

		if (!panel || !backdrop || listingState.logsPanelBound) {
			return;
		}
		listingState.logsPanelBound = true;

		function openPanel(e) {
			if (e) e.preventDefault();
			panel.classList.add('open');
			backdrop.classList.add('open');

			// #logsPanel sits OUTSIDE #data-transfer-listing, so the root-level
			// init never reaches it and the browser was showing its own native
			// tooltip instead of the themed one. Same helper as everywhere else.
			if (typeof window.initBootstrapTooltips === 'function') {
				window.initBootstrapTooltips(panel);
			}
		}
		function closePanel() {
			panel.classList.remove('open');
			backdrop.classList.remove('open');
		}

		// Delegated: table rows are rebuilt on every render, so a handler bound
		// straight to a View link would die with the row it was attached to.
		getListingRoot().on('click.dtListingLogs', '.view-link', function (event) {
			openPanel(event);
			loadTransferLogs($.trim($(this).closest('tr').attr('data-record-id') || ''));
		});

		if (closeBtn) {
			closeBtn.addEventListener('click', closePanel);
		}
		backdrop.addEventListener('click', closePanel);
		document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); });

		/* ---------- tabs ---------- */
		const tabButtons = Array.from(document.querySelectorAll('.logs-tab'));
		const panes = { realtime: document.getElementById('pane-realtime'), historic: document.getElementById('pane-historic') };

		tabButtons.forEach(btn => {
			btn.addEventListener('click', () => {
				tabButtons.forEach(b => b.classList.remove('active'));
				btn.classList.add('active');
				Object.keys(panes).forEach(key => {
					panes[key].style.display = (key === btn.dataset.tab) ? 'block' : 'none';
				});

				// The green banner lives outside both panes, so it has to be
				// told which one the user is now looking at.
				listingState.activeLogsTab = btn.dataset.tab;
				updateLogsSuccessBanner();
			});
		});

		/* ---------- generic simple-list dd (per page) ---------- */
		function initSimpleDD(rootId) {
			const dd = document.getElementById(rootId);
			const trigger = dd.querySelector('.dd-trigger');
			const valueEl = dd.querySelector('.dd-value');
			const items = Array.from(dd.querySelectorAll('.dd-simple-item'));

			trigger.addEventListener('click', (e) => {
				e.stopPropagation();
				const isOpen = dd.classList.contains('open');
				document.querySelectorAll('.dd').forEach(d => d.classList.remove('open'));
				if (!isOpen) dd.classList.add('open');
			});

			items.forEach(item => {
				item.addEventListener('click', () => {
					items.forEach(i => i.classList.remove('selected'));
					item.classList.add('selected');
					valueEl.textContent = item.dataset.value;
					valueEl.classList.add('set');
					dd.classList.remove('open');
				});
			});

			document.addEventListener('click', (e) => {
				if (!dd.contains(e.target)) dd.classList.remove('open');
			});
			document.addEventListener('keydown', (e) => {
				if (e.key === 'Escape') dd.classList.remove('open');
			});
		}

		initSimpleDD('logs-perpage-dropdown');
		initSimpleDD('logs-perpage-historic-dropdown');

		// Per page: initSimpleDD only moves the label, so wire the size here.
		Object.keys(LOGS_PANE_UI).forEach(function (key) {
			var dd = document.getElementById(LOGS_PANE_UI[key].perPageDdId);
			if (!dd) {
				return;
			}

			dd.querySelectorAll('.dd-simple-item').forEach(function (item) {
				item.addEventListener('click', function () {
					var pane = getLogsPane(key);
					pane.perPage = parsePerPage(item.dataset.value);
					// A smaller page size can leave the old page out of range.
					pane.page = 1;
					loadLogsPane(key);
				});
			});

			// Start from whatever the markup marks as selected.
			var selected = dd.querySelector('.dd-simple-item.selected');
			if (selected) {
				getLogsPane(key).perPage = parsePerPage(selected.dataset.value);
			}
		});
		// Both duration dropdowns open and label themselves the same way; the
		// Custom range behaviour is layered on below.
		initSimpleDD('logs-duration-dropdown');
		initSimpleDD('logs-duration-historic-dropdown');

		/* ---------- duration dropdowns + Custom range ---------- */

		/**
		 * Wire one pane's duration dropdown: presets apply straight away,
		 * Custom range swaps the list for that pane's own range picker.
		 */
		function initLogsDurationDropdown(paneKey, dropdownId, pickerId) {
			var dropdown = document.getElementById(dropdownId);
			var pickerElement = document.getElementById(pickerId);
			if (!dropdown || !pickerElement) {
				return;
			}

			var listPanel = dropdown.querySelector('.dd-panel');
			var picker = createLogsRangePicker(paneKey, pickerElement);
			logsRangePickers[paneKey] = picker;

			function closeDurationUI() {
				dropdown.classList.remove('open');
				listPanel.style.display = '';
				if (picker) {
					picker.close();
				}
			}

			// initSimpleDD has already toggled .open by the time this runs. Either
			// way the preset list comes back — the calendar only ever opens from
			// the Custom range item.
			var trigger = dropdown.querySelector('.dd-trigger');
			if (trigger) {
				trigger.addEventListener('click', function () {
					listPanel.style.display = '';
					if (picker) {
						picker.close();
					}
				});
			}

			dropdown.querySelectorAll('.dd-simple-item').forEach(function (item) {
				item.addEventListener('click', function () {
					if (item.dataset.value === 'Custom range') {
						// The picker takes the dropdown's place — both at once
						// would overlap inside the panel.
						listPanel.style.display = 'none';
						dropdown.classList.add('open');
						if (picker) {
							picker.open();
						}
						return;
					}

					// A preset replaces whatever range was applied.
					if (picker) {
						picker.clearApplied();
					}
					closeDurationUI();
					applyLogsDuration(paneKey, buildPresetRange(item.dataset.value));
				});
			});

			document.addEventListener('click', function (event) {
				if (!dropdown.contains(event.target)) {
					closeDurationUI();
				}
			});
			document.addEventListener('keydown', function (event) {
				if (event.key === 'Escape') {
					closeDurationUI();
				}
			});
		}

		initLogsDurationDropdown('realtime', 'logs-duration-dropdown', 'calendarPopover');
		initLogsDurationDropdown('historic', 'logs-duration-historic-dropdown', 'historic-calendarPopover');

		/* ---------- clear duration pills ---------- */
		// Each pill clears only its own pane now.
		document.querySelectorAll('[data-clear]').forEach(btn => {
			btn.addEventListener('click', () => {
				clearLogsDuration(btn.dataset.clear === 'historic' ? 'historic' : 'realtime');
			});
		});

	}

});

