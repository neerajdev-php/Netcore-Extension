jQuery(document).ready(function($) {

	ZOHO.embeddedApp.on("PageLoad", function(data) {

		var CONNECTIONS_ENTITY = "netcore0__Connections";
		var MAX_CONNECTIONS = 5;

		/**
		 * Persist the main nav tab across reloads.
		 * No URL/hash tab routing exists in this app — use localStorage.
		 */
		var MAIN_TAB_STORAGE_KEY = 'netcore0_active_main_tab';
		var MAIN_TAB = {
			CONNECTIONS: 'connections',
			DATA_TRANSFER: 'data-transfer'
		};

		function getSavedMainTab() {
			try {
				return String(window.localStorage.getItem(MAIN_TAB_STORAGE_KEY) || '');
			} catch (error) {
				return '';
			}
		}

		function saveActiveMainTab(tabId) {
			var id = String(tabId || '');
			// Only Connections / Data Transfer are switchable tabs.
			if (id !== MAIN_TAB.CONNECTIONS && id !== MAIN_TAB.DATA_TRANSFER) {
				return;
			}

			try {
				window.localStorage.setItem(MAIN_TAB_STORAGE_KEY, id);
			} catch (error) {
				// Private mode / quota — persistence is best-effort.
			}
		}

		/** Wait briefly for DataTransferModule if scripts are still loading. */
		function whenDataTransferModuleReady(maxWaitMs) {
			var limit = typeof maxWaitMs === 'number' ? maxWaitMs : 2000;

			if (window.DataTransferModule && typeof window.DataTransferModule.open === 'function') {
				return Promise.resolve(window.DataTransferModule);
			}

			return new Promise(function (resolve, reject) {
				var started = Date.now();
				var timer = setInterval(function () {
					if (window.DataTransferModule && typeof window.DataTransferModule.open === 'function') {
						clearInterval(timer);
						resolve(window.DataTransferModule);
						return;
					}
					if (Date.now() - started >= limit) {
						clearInterval(timer);
						reject({ message: 'DataTransferModule is not ready.' });
					}
				}, 50);
			});
		}

		function getMainSections() {
			return {
				$netcore: $('#nav-netcore'),
				$connections: $('#nav-connections'),
				$connectionsList: $('#nav-connections-list'),
				$viewEdit: $('#connections-view-edit'),
				$dataTransfer: $('#data-transfer'),
				$dataTransferSetup: $('#data-transfer-setup'),
				$dataTransferListing: $('#data-transfer-listing')
			};
		}

		function hideAllMainSections() {
			var sections = getMainSections();
			sections.$netcore.removeClass('active').hide();
			sections.$connections.removeClass('active').hide();
			sections.$connectionsList.removeClass('active').hide();
			sections.$viewEdit.removeClass('active').hide();
			sections.$dataTransfer.removeClass('active').hide();
			sections.$dataTransferSetup.removeClass('active').hide();
			sections.$dataTransferListing.removeClass('active').hide();
			$('#section-data-transfer').hide();
		}

		function showListErrorMessage(message) {
			var $alert = $('#nav-connections-list .alert-error-msg');
			if (!$alert.length) {
				return;
			}

			$alert.find('.alert-error-text').text(message || 'Unable to load connection details.');
			$alert.show();
			setTimeout(function() {
				$alert.hide();
			}, 5000);
		}

		function hideListErrorMessage() {
			$('#nav-connections-list .alert-error-msg').hide();
		}

		function getApiErrorMessage(error, fallbackMessage) {
			if (!error) {
				return fallbackMessage;
			}

			if (typeof error === 'string') {
				return error;
			}

			if (error.message) {
				return error.message;
			}

			if (error.details && error.details.message) {
				return error.details.message;
			}

			return fallbackMessage;
		}

		/*function to set initial widget section on load */
		function initializeWidgetView() {
			hideAllMainSections();
			showCommonLoaderPopup();

			return ZOHO.CRM.API.getAllRecords({
				Entity: CONNECTIONS_ENTITY,
				// Newest first, so a freshly created connection heads the list.
				sort_order: "desc",
				per_page: 200,
				page: 1
			}).then(function(response) {
				var records = response.data || [];
				var hasConnections = records.length > 0;

				syncDataTransferTabVisibility(records);

				var savedTab = getSavedMainTab();
				// Legacy: "netcore" was a tab before; treat as Connections.
				if (savedTab === 'netcore') {
					savedTab = MAIN_TAB.CONNECTIONS;
				}

				// Restore Data Transfer only when the tab is still allowed.
				if (savedTab === MAIN_TAB.DATA_TRANSFER) {
					if (hasConnections) {
						return whenDataTransferModuleReady()
							.then(function (dt) {
								saveActiveMainTab(MAIN_TAB.DATA_TRANSFER);
								return dt.open({ animate: false });
							})
							.catch(function (error) {
								console.error('Restore Data Transfer tab failed:', error);
								saveActiveMainTab(MAIN_TAB.CONNECTIONS);
								return showConnectionsListTab({
									records: records,
									animate: false,
									showSuccessAlert: false
								});
							});
					}

					// DT tab hidden with no connections — fall back to Connections.
					saveActiveMainTab(MAIN_TAB.CONNECTIONS);
					return showConnectionsListTab({
						records: records,
						animate: false,
						showSuccessAlert: false
					});
				}

				if (savedTab === MAIN_TAB.CONNECTIONS) {
					saveActiveMainTab(MAIN_TAB.CONNECTIONS);
					if (hasConnections) {
						return showConnectionsListTab({
							records: records,
							animate: false,
							showSuccessAlert: false
						});
					}
					// No connections yet — show the connect landing (label stays non-tab).
					showNetcoreCESection({ animate: false });
					return;
				}

				// First visit / no saved tab — existing default.
				if (hasConnections) {
					saveActiveMainTab(MAIN_TAB.CONNECTIONS);
					return showConnectionsListTab({
						records: records,
						animate: false,
						showSuccessAlert: false
					});
				}

				saveActiveMainTab(MAIN_TAB.CONNECTIONS);
				showNetcoreCESection({ animate: false });
			}).catch(function(error) {
				console.error('initializeWidgetView error:', error);
				syncDataTransferTabVisibility([]);
				saveActiveMainTab(MAIN_TAB.CONNECTIONS);
				showNetcoreCESection({ animate: false });
			}).then(function() {
				document.body.classList.remove('widget-loading');
				hideCommonLoaderPopup();
			}, function() {
				document.body.classList.remove('widget-loading');
				hideCommonLoaderPopup();
			});
		}

        //--------function to show common loader popup --------------------
		var commonLoaderModal = null;
		var commonLoaderRetryHide = null;

		function showCommonLoaderPopup() {
			var loaderElement = document.getElementById('common-loader-popup');
			if (!loaderElement) {
				return;
			}

			// A retry left over from the previous hide belongs to that hide — it
			// must not close the loader this caller is opening.
			if (commonLoaderRetryHide) {
				$(loaderElement).off('shown.bs.modal', commonLoaderRetryHide);
				commonLoaderRetryHide = null;
			}

			commonLoaderModal = bootstrap.Modal.getOrCreateInstance(loaderElement, {
				backdrop: 'static',
				keyboard: false
			});
			commonLoaderModal.show();
		}

		function hideCommonLoaderPopup() {
			var loaderElement = document.getElementById('common-loader-popup');
			if (!loaderElement) {
				return;
			}

			// The live instance wins: a stale cached one may have been disposed
			// by the Data Transfer overlay repair.
			var modalInstance = bootstrap.Modal.getInstance(loaderElement) || commonLoaderModal;
			if (modalInstance) {
				modalInstance.hide();

				// Bootstrap drops hide() while the show transition is still
				// running. Forcing the DOM closed below then leaves the instance
				// counted as open with its focus trap still on the document —
				// two live traps fight over focusin and blow the call stack.
				// Hide again for real once the show has settled.
				if (modalInstance._isTransitioning) {
					commonLoaderRetryHide = function () {
						commonLoaderRetryHide = null;
						modalInstance.hide();
						clearCommonLoaderPopupDom(loaderElement);
					};
					$(loaderElement).one('shown.bs.modal', commonLoaderRetryHide);
				}
			}

			clearCommonLoaderPopupDom(loaderElement);
		}

		/** Force cleanup if Bootstrap hide animation races with a fast API response */
		function clearCommonLoaderPopupDom(loaderElement) {
			loaderElement.classList.remove('show');
			loaderElement.style.display = 'none';
			loaderElement.setAttribute('aria-hidden', 'true');
			loaderElement.removeAttribute('aria-modal');
			document.body.classList.remove('modal-open');
			document.body.style.removeProperty('overflow');
			document.body.style.removeProperty('padding-right');
			document.querySelectorAll('.modal-backdrop').forEach(function(backdrop) {
				backdrop.remove();
			});
		}

		function showConnectionActivatePopup() {
			var activateElement = document.getElementById('connection-activate');
			if (!activateElement) {
				return null;
			}

			var modalInstance = bootstrap.Modal.getOrCreateInstance(activateElement, {
				backdrop: 'static',
				keyboard: false
			});
			modalInstance.show();
			return modalInstance;
		}

		function hideConnectionActivatePopup() {
			var activateElement = document.getElementById('connection-activate');
			if (!activateElement) {
				return;
			}

			var modalInstance = bootstrap.Modal.getInstance(activateElement);
			if (modalInstance) {
				modalInstance.hide();
			}

			// Force cleanup so gateway/success UI is never blocked by a stuck activate loader
			activateElement.classList.remove('show');
			activateElement.style.display = 'none';
			activateElement.setAttribute('aria-hidden', 'true');
			activateElement.removeAttribute('aria-modal');
			document.body.classList.remove('modal-open');
			document.body.style.removeProperty('overflow');
			document.body.style.removeProperty('padding-right');
			document.querySelectorAll('.modal-backdrop').forEach(function(backdrop) {
				backdrop.remove();
			});
		}

		/*function to show Netcore CE landing section */
		function showNetcoreCESection(options) {
			var settings = $.extend({
				animate: false
			}, options);

			var sections = getMainSections();

			function activateNetcoreSection() {
				hideAllMainSections();
				sections.$netcore.addClass('active').show();
				// Netcore CE is a static brand label — keep Connections as the active tab chrome.
				$('.main-tabs .nav-link').removeClass('active');
				$('#nav-connections-tab').addClass('active');
				saveActiveMainTab(MAIN_TAB.CONNECTIONS);
				$('.alert-success-msg').hide();
				hideListErrorMessage();
			}

			if (!settings.animate) {
				activateNetcoreSection();
				return;
			}

			var $activeSection = $('.tab-pane-netcore-ce.active, .tab-netcore-connection.active, .tab-data-transfer.active').first();

			if (!$activeSection.length || $activeSection.is(sections.$netcore)) {
				activateNetcoreSection();
				return;
			}

			$activeSection.slideDown(400, function() {
				activateNetcoreSection();
			});
		}

		/*function to open connections list tab */
		function showConnectionsListTab(options) {
			var settings = $.extend({
				records: null,
				animate: true,
				showSuccessAlert: false,
				successMessage: 'Connector added successfully'
			}, options);

			var recordsPromise = settings.records
				? Promise.resolve({ data: settings.records })
				: ZOHO.CRM.API.getAllRecords({
					Entity: CONNECTIONS_ENTITY,
					// Newest first, so a freshly created connection heads the list.
					sort_order: "desc",
					per_page: 200,
					page: 1
				});

			return recordsPromise.then(function(response) {
				var records = response.data || [];
				renderConnectionsList(records);

				var sections = getMainSections();

				function activateConnectionsListSection() {
					hideAllMainSections();
					sections.$connectionsList.addClass('active').show();
					$('.main-tabs .nav-link').removeClass('active');
					$('#nav-connections-tab').addClass('active');
					saveActiveMainTab(MAIN_TAB.CONNECTIONS);

					if (settings.showSuccessAlert) {
						$('#nav-connections-list .alert-success-text').text(settings.successMessage);
						$('.alert-success-msg').show();
						setTimeout(function() {
							$('.alert-success-msg').hide();
						}, 4000);
					} else {
						$('.alert-success-msg').hide();
					}
				}

				if (!settings.animate) {
					activateConnectionsListSection();
					return;
				}

				var $activeSection = $('.tab-pane-netcore-ce.active, .tab-netcore-connection.active, .tab-data-transfer.active').first();

				if (!$activeSection.length || $activeSection.is(sections.$connectionsList)) {
					activateConnectionsListSection();
					return;
				}

				$activeSection.slideDown(400, function() {
					$activeSection.removeClass('active');
					hideAllMainSections();
					sections.$connectionsList.addClass('active').slideDown(400);
					$('.main-tabs .nav-link').removeClass('active');
					$('#nav-connections-tab').addClass('active');
					saveActiveMainTab(MAIN_TAB.CONNECTIONS);

					if (settings.showSuccessAlert) {
						$('#nav-connections-list .alert-success-text').text(settings.successMessage);
						$('.alert-success-msg').show();
						setTimeout(function() {
							$('.alert-success-msg').hide();
						}, 4000);
					} else {
						$('.alert-success-msg').hide();
					}
				});
			});
		}

		function buildFullConnectionId(record) {
			var source = record.netcore0__Source || '';
			var connectionId = record.netcore0__Netcore_connection_ID || '';
			var clientId = record.netcore0__Client_ID || '';

			if (source && connectionId && clientId) {
				return source + '-' + connectionId + '-' + clientId;
			}

			return connectionId || '';
		}

		function fetchConnectionRecord(recordId) {

			return ZOHO.CRM.API.getRecord({
				Entity: CONNECTIONS_ENTITY,
				RecordID: recordId
			}).then(function(response) {
				var record = response && response.data && response.data[0];
				if (!record) {
					return Promise.reject({
						message: 'Connection record not found.'
					});
				}

			

				return record;
			});
		}

		function hideActiveModals(modalIds) {
			modalIds.forEach(function(modalId) {
				var modalElement = document.getElementById(modalId);
				if (!modalElement) {
					return;
				}

				var modalInstance = bootstrap.Modal.getInstance(modalElement);
				if (modalInstance) {
					modalInstance.hide();
				}
			});

			document.body.classList.remove('modal-open');
			document.body.style.removeProperty('overflow');
			document.body.style.removeProperty('padding-right');
			document.querySelectorAll('.modal-backdrop').forEach(function(backdrop) {
				backdrop.remove();
			});
		}

		function resetConnectionViewEditForm() {
			$('#view-connection-title, #view-connectionId, #view-apiKey, #view-endPoint').val('');
			$('#connections-view-edit .form-control').removeClass('input-error');
			$('#connections-view-edit .error-message').hide().text('');
			$('#connections-view-edit .view-alert-error-msg, #connections-view-edit .view-alert-msg').hide();
			$('#connections-view-edit').removeData('record-id').removeData('original-record').removeData('edit-baseline');
			if (typeof window.clearConnectionNameErrorTooltip === 'function') {
				window.clearConnectionNameErrorTooltip($('#view-connection-title'));
			}
			setConnectionViewMode('view');
		}

		function resetWidgetConnectionState() {
			if (typeof window.resetConnectionForm === 'function') {
				window.resetConnectionForm();
			}

			resetConnectionViewEditForm();
			$('#nav-connections').removeData('create-baseline');
			$('#connections-cards-list').empty();
			hideListErrorMessage();
			$('.alert-success-msg').hide();

			delete window.__gatewayPayloadJson;
			delete window.__gatewayResponseJson;

			document.querySelectorAll('.dots-menu.show').forEach(function(menu) {
				menu.classList.remove('show');
			});

			hideActiveModals([
				'connection-close',
				'connection-activate',
				'gatewayResponseModal',
				'connection-successfully',
				'connection-deactivate',
				'connection-deactivate-confirm'
			]);
		}

		function handleDiscardAndExit() {
			hideActiveModals(['connection-close']);
			resetWidgetConnectionState();
			initializeWidgetView();
		}

		function bindDiscardExitEvents() {
			$('body').on('click', '#connection-discard-exit-btn', function(event) {
				event.preventDefault();
				handleDiscardAndExit();
			});

			$('body').on('click', '#create-close-btn', handleCreateCloseClick);
		}

		function getConnectionCreateFormSnapshot() {
			return {
				title: $.trim($('#netcore-connection-title').val() || ''),
				connectionId: $.trim($('#connectionId').val() || ''),
				apiKey: $.trim($('#apiKey').val() || ''),
				endPoint: $.trim($('#endPoint').val() || '')
			};
		}

		function setConnectionCreateFormBaseline() {
			$('#nav-connections').data('create-baseline', getConnectionCreateFormSnapshot());
		}

		function hasConnectionCreateFormChanges() {
			var baseline = $('#nav-connections').data('create-baseline');
			if (!baseline) {
				return false;
			}

			var current = getConnectionCreateFormSnapshot();
			return current.title !== baseline.title
				|| current.connectionId !== baseline.connectionId
				|| current.apiKey !== baseline.apiKey
				|| current.endPoint !== baseline.endPoint;
		}

		function isCreateConnectionScreenActive() {
			var $createSection = $('#nav-connections');
			return $createSection.hasClass('active') && $createSection.is(':visible');
		}

		function handleCreateCloseClick(event) {
			event.preventDefault();
			event.stopPropagation();

			if (!isCreateConnectionScreenActive()) {
				return;
			}

			if (hasConnectionCreateFormChanges()) {
				var closeModalElement = document.getElementById('connection-close');
				if (closeModalElement) {
					bootstrap.Modal.getOrCreateInstance(closeModalElement).show();
				}
				return;
			}

			handleDiscardAndExit();
		}

		function setConnectionViewMode(mode) {
			var $section = $('#connections-view-edit');
			var isEdit = mode === 'edit';
			var $editableFields = $('#view-connection-title, #view-connectionId, #view-apiKey, #view-endPoint');

			$section.attr('data-mode', isEdit ? 'edit' : 'view');
			$section.toggleClass('is-edit-mode', isEdit);

			if (isEdit) {
				$editableFields.prop('disabled', false).prop('readonly', false);
				$section.data('edit-baseline', getConnectionViewFormSnapshot());
			} else {
				$editableFields.prop('disabled', true).prop('readonly', true);
				$section.removeData('edit-baseline');
			}

			$('#view-only-banner').toggleClass('d-none', isEdit);
			$('#view-edit-btn').toggleClass('d-none', isEdit);
			$('#view-update-btn').toggleClass('d-none', !isEdit);
		}

		function getConnectionViewFormSnapshot() {
			return {
				title: $.trim($('#view-connection-title').val() || ''),
				connectionId: $.trim($('#view-connectionId').val() || ''),
				apiKey: $.trim($('#view-apiKey').val() || ''),
				endPoint: $.trim($('#view-endPoint').val() || '')
			};
		}

		function hasConnectionViewFormChanges() {
			var baseline = $('#connections-view-edit').data('edit-baseline');
			if (!baseline) {
				return false;
			}

			var current = getConnectionViewFormSnapshot();
			return current.title !== baseline.title
				|| current.connectionId !== baseline.connectionId
				|| current.apiKey !== baseline.apiKey
				|| current.endPoint !== baseline.endPoint;
		}

		function isConnectionViewEditMode() {
			var $section = $('#connections-view-edit');
			return $section.hasClass('is-edit-mode') || $section.attr('data-mode') === 'edit';
		}

		function exitConnectionViewEditWithoutConfirm() {
			setConnectionViewMode('view');
			showConnectionsListTab({ animate: true, showSuccessAlert: false });
		}

		function handleViewCloseClick(event) {
			event.preventDefault();
			event.stopPropagation();

			if (isConnectionViewEditMode() && hasConnectionViewFormChanges()) {
				var closeModalElement = document.getElementById('connection-close');
				if (closeModalElement) {
					bootstrap.Modal.getOrCreateInstance(closeModalElement).show();
				}
				return;
			}

			exitConnectionViewEditWithoutConfirm();
		}

		function populateConnectionViewForm(record) {
			$('#view-connection-title').val(record.Name || '');
			$('#view-connectionId').val(buildFullConnectionId(record));
			$('#view-apiKey').val(record.netcore0__Netcore_API_key || '');
			$('#view-endPoint').val(record.netcore0__Netcore_end_point || '');
			$('#connections-view-edit .view-alert-error-msg').hide();
			$('#connections-view-edit').data('record-id', record.id || '');
			setConnectionViewMode('view');
		}

		function showConnectionViewEditSection(options) {
			var settings = $.extend({
				animate: true
			}, options);

			var sections = getMainSections();

			function activateViewEditSection() {
				hideAllMainSections();
				sections.$viewEdit.addClass('active').show();
				$('.main-tabs .nav-link').removeClass('active');
				$('#nav-connections-tab').addClass('active');
				saveActiveMainTab(MAIN_TAB.CONNECTIONS);
				hideListErrorMessage();
			}

			if (!settings.animate) {
				activateViewEditSection();
				return;
			}

			var $activeSection = $('.tab-pane-netcore-ce.active, .tab-netcore-connection.active, .tab-data-transfer.active').first();

			if (!$activeSection.length || $activeSection.is(sections.$viewEdit)) {
				activateViewEditSection();
				return;
			}

			$activeSection.slideDown(400, function() {
				$activeSection.removeClass('active');
				hideAllMainSections();
				sections.$viewEdit.addClass('active').slideDown(400);
				$('.main-tabs .nav-link').removeClass('active');
				$('#nav-connections-tab').addClass('active');
				saveActiveMainTab(MAIN_TAB.CONNECTIONS);
			});
		}

		function handleViewConnection(recordId) {
			if (!recordId) {
				showListErrorMessage('Invalid connection selected.');
				return;
			}

			document.querySelectorAll('.dots-menu.show').forEach(function(menu) {
				menu.classList.remove('show');
			});

			showCommonLoaderPopup();

			fetchConnectionRecord(recordId).then(function(record) {
				populateConnectionViewForm(record);
				showConnectionViewEditSection({ animate: true });
			}).catch(function(error) {
				console.error('handleViewConnection error:', error);
				showListErrorMessage(
					getApiErrorMessage(error, 'Unable to load connection details. Please try again.')
				);
			}).then(function() {
				hideCommonLoaderPopup();
			}, function() {
				hideCommonLoaderPopup();
			});
		}

		/* ------------------------------------------------------------------ */
		/* Remove connection → syncs that go with it                          */
		/* ------------------------------------------------------------------ */

		var DATA_TRANSFER_ENTITY = 'netcore0__Data_Transfer';

		// A dropped request should not leave a sync behind, so retry each delete.
		var SYNC_DELETE_ATTEMPTS = 3;

		/** CRM timestamp → "Dec 06, 2025 06:14 PM". */
		function formatImpactDate(value) {
			if (!value) {
				return '-';
			}

			// Read the wall-clock parts straight off the string; letting
			// new Date(iso) parse the offset would shift the day for the viewer.
			var parts = String(value).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
			var date = parts
				? new Date(+parts[1], +parts[2] - 1, +parts[3], +parts[4], +parts[5])
				: new Date(value);

			if (isNaN(date.getTime())) {
				return '-';
			}

			return date.toLocaleDateString('en-US', {
				month: 'short',
				day: '2-digit',
				year: 'numeric'
			}) + ' ' + date.toLocaleTimeString('en-US', {
				hour: '2-digit',
				minute: '2-digit',
				hour12: true
			});
		}

		/** Data Transfer records whose connection lookup points at this id. */
		function fetchSyncsForConnection(recordId) {
			if (!window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API ||
				typeof ZOHO.CRM.API.getAllRecords !== 'function') {
				return Promise.resolve([]);
			}

			return Promise.resolve(
				ZOHO.CRM.API.getAllRecords({
					Entity: DATA_TRANSFER_ENTITY,
					sort_order: 'desc',
					per_page: 200,
					page: 1
				})
			).then(function(response) {
				var records = (response && response.data) || [];
				var wanted = String(recordId);

				return records.filter(function(record) {
					var connection = record.netcore0__Connection;
					return connection && String(connection.id) === wanted;
				});
			}).catch(function(error) {
				console.error('Could not load syncs for connection', recordId, error);
				return [];
			});
		}

		function buildImpactRowHtml(record) {
			var status = $.trim(record.netcore0__Data_Transfer_Status || '');
			// Same class shape as the listing table — status-draft / status-paused /
			// status-stopped colour the badge, anything else keeps the green base.
			var badgeClass = 'status-badge' + (status ? ' status-' + status.toLowerCase() : '');

			return '<div class="row impact-row align-items-center g-0" data-sync-id="' +
					escapeHtml(record.id || '') + '">' +
					'<div class="col-8">' +
						'<div class="d-flex align-items-center">' +
							'<div class="me-4 sync-icon">' +
								'<img src="assests/images/symbols_sync.svg" alt="symbols_sync">' +
							'</div>' +
							'<div>' +
								'<div class="sync-name">' + escapeHtml(record.Name || '-') + '</div>' +
								'<div class="sync-meta">' +
									'<span>ID - ' + escapeHtml(record.id || '-') + '</span>' +
									'<span class="divider"></span>' +
									'<span class="' + escapeHtml(badgeClass) + '">' + escapeHtml(status.toUpperCase()) + '</span>' +
								'</div>' +
							'</div>' +
						'</div>' +
					'</div>' +
					'<div class="col-4">' +
						'<div class="modified-date">' + escapeHtml(formatImpactDate(record.Modified_Time)) + '</div>' +
					'</div>' +
					'</div>';
		}

		/**
		 * Paint the impact list. The warning line above it stays either way;
		 * only the table is hidden when no sync uses this connection.
		 */
		function renderConnectionImpact(records) {
			var $card = $('#remove-connection-impact');
			var $body = $('#remove-connection-impact-body');

			if (!$body.length) {
				return;
			}

			$body.html(records.map(buildImpactRowHtml).join(''));
			$card.prop('hidden', records.length === 0);

			// The final confirm reads these back to know what to delete.
			$('#connection-deactivate').data('impact-records', records);
		}

		/** Delete one sync, retrying a few times before giving up. */
		function deleteSyncRecord(recordId, attemptsLeft) {
			return Promise.resolve(
				ZOHO.CRM.API.deleteRecord({
					Entity: DATA_TRANSFER_ENTITY,
					RecordID: recordId
				})
			).then(function(response) {
				var result = response && response.data && response.data[0];
				var failed = result && (
					String(result.code || '').toUpperCase() === 'ERROR' ||
					String(result.status || '').toLowerCase() === 'error'
				);

				// A soft error in the payload still means the record is there.
				if (failed) {
					throw new Error(getApiErrorMessage(result, 'Delete failed.'));
				}

				return true;
			}).catch(function(error) {
				if (attemptsLeft > 1) {
					return deleteSyncRecord(recordId, attemptsLeft - 1);
				}

				console.error('Could not delete sync', recordId, error);
				return false;
			});
		}

		/** Delete every sync listed in the popup. Resolves once all are done. */
		function deleteSyncsForConnection() {
			var ids = ($('#connection-deactivate').data('impact-records') || [])
				.map(function(record) {
					return record.id;
				})
				.filter(Boolean);

			if (!ids.length || !window.ZOHO || !ZOHO.CRM || !ZOHO.CRM.API ||
				typeof ZOHO.CRM.API.deleteRecord !== 'function') {
				return Promise.resolve();
			}

			return Promise.all(ids.map(function(id) {
				return deleteSyncRecord(id, SYNC_DELETE_ATTEMPTS);
			}));
		}

		function openRemoveConnectionModal(recordId, connectionName) {
			if (!recordId) {
				showListErrorMessage('Invalid connection selected.');
				return;
			}

			document.querySelectorAll('.dots-menu.show').forEach(function(menu) {
				menu.classList.remove('show');
			});

			var modalElement = document.getElementById('connection-deactivate');
			var confirmModalElement = document.getElementById('connection-deactivate-confirm');

			if (!modalElement || !confirmModalElement) {
				showListErrorMessage('Remove confirmation dialog is unavailable.');
				return;
			}

			var name = connectionName || 'this connection';

			$('#connection-deactivate')
				.data('record-id', recordId)
				.data('connection-name', name)
				.removeData('impact-records');

			$('#remove-connection-name').text(name);
			$('#remove-connection-confirm-name').text(name);

			// Single reset point for the step2 note: it only ever gets hidden
			// below, so restoring it here keeps a previous zero-sync removal
			// from leaving it hidden for the next one.
			$('#remove-connection-permanent-note').show();

			// Start empty
			renderConnectionImpact([]);

			hideActiveModals([
				'connection-deactivate',
				'connection-deactivate-confirm'
			]);

			showCommonLoaderPopup();

			fetchSyncsForConnection(recordId).then(function(records) {

				// Ignore stale response
				if ($('#connection-deactivate').data('record-id') !== recordId) {
					return;
				}

				if (records.length > 0) {

					// Syncs to warn about: step1 lists them, Continue leads to step2.
					$('#connection-deactivate-confirm').data('skip-step1', false);

					renderConnectionImpact(records);

					hideLoaderThenShowModal(modalElement);

					return;
				}

				// No sync uses this connection, so step1 would list nothing —
				// go straight to the final confirm. The flag tells CANCEL to
				// close instead of falling back to a step1 that never opened.
				$('#connection-deactivate-confirm').data('skip-step1', true);

				// Nothing is associated, so the permanent-delete warning does not apply.
				$('#remove-connection-permanent-note').hide();

				hideLoaderThenShowModal(confirmModalElement);

			}).catch(function() {
				hideCommonLoaderPopup();
			});
		}

		/**
		 * Hand a modal over from the shared loader without deleting the new
		 * modal's backdrop. The API can resolve while the loader is still in its
		 * show transition, so wait for Bootstrap to finish hiding it first.
		 */
		function hideLoaderThen(callback) {
			var loaderElement = document.getElementById('common-loader-popup');
			var loaderInstance = loaderElement
				? bootstrap.Modal.getInstance(loaderElement)
				: null;

			if (!loaderElement || !loaderInstance || !loaderElement.classList.contains('show')) {
				callback();
				return;
			}

			$(loaderElement).one('hidden.bs.modal', callback);

			if (loaderInstance._isTransitioning) {
				$(loaderElement).one('shown.bs.modal', function() {
					loaderInstance.hide();
				});
			} else {
				loaderInstance.hide();
			}
		}

		function hideLoaderThenShowModal(modalElement) {
			hideLoaderThen(function() {
				bootstrap.Modal.getOrCreateInstance(modalElement).show();
			});
		}

		function openRemoveConnectionConfirmModal() {
			var recordId = $('#connection-deactivate').data('record-id');
			if (!recordId) {
				hideActiveModals(['connection-deactivate', 'connection-deactivate-confirm']);
				showListErrorMessage('Invalid connection selected.');
				return;
			}

			var name = $('#connection-deactivate').data('connection-name') || 'this connection';
			$('#remove-connection-confirm-name').text(name);

			var step1 = document.getElementById('connection-deactivate');
			var step2 = document.getElementById('connection-deactivate-confirm');
			if (!step2) {
				showListErrorMessage('Remove confirmation dialog is unavailable.');
				return;
			}

			// Reached via step1's Continue button — a step1 to go back to exists.
			$('#connection-deactivate-confirm').data('skip-step1', false);

			var step1Instance = step1 ? bootstrap.Modal.getInstance(step1) : null;
			if (step1Instance) {
				$(step1).one('hidden.bs.modal', function() {
					bootstrap.Modal.getOrCreateInstance(step2).show();
				});
				step1Instance.hide();
				return;
			}

			bootstrap.Modal.getOrCreateInstance(step2).show();
		}

		function returnToRemoveConnectionStep1() {
			var step2 = document.getElementById('connection-deactivate-confirm');

			// Zero syncs: step2 was opened directly, so there is no step1 behind
			// it — CANCEL just closes.
			if ($('#connection-deactivate-confirm').data('skip-step1') === true) {

				if (step2) {
					var modalInstance = bootstrap.Modal.getInstance(step2);

					if (modalInstance) {
						modalInstance.hide();
					} else {
						bootstrap.Modal
							.getOrCreateInstance(step2)
							.hide();
					}
				}

				return;
			}

			// Syncs were listed: CANCEL walks back to step1.
			var step1 = document.getElementById('connection-deactivate');

			if (!step1) {
				return;
			}

			var step2Instance = step2
				? bootstrap.Modal.getInstance(step2)
				: null;


			if (step2Instance) {

				$(step2).one('hidden.bs.modal', function() {
					bootstrap.Modal
						.getOrCreateInstance(step1)
						.show();
				});

				step2Instance.hide();

				return;
			}


			bootstrap.Modal
				.getOrCreateInstance(step1)
				.show();
		}

		function deleteConnectionRecord(recordId) {
			return ZOHO.CRM.API.deleteRecord({
				Entity: CONNECTIONS_ENTITY,
				RecordID: recordId
			}).then(function(response) {
				var result = response && response.data && response.data[0];
				var hasError = result && (
					String(result.code || '').toUpperCase() === 'ERROR' ||
					String(result.status || '').toLowerCase() === 'error'
				);

				if (hasError) {
					return Promise.reject(result);
				}

				return response;
			});
		}

		function handleConfirmRemoveConnection() {
			var recordId = $('#connection-deactivate').data('record-id');
			var connectionName = $('#connection-deactivate').data('connection-name')
				|| $.trim($('#remove-connection-name').text())
				|| 'Connection';

			if (!recordId) {
				hideActiveModals(['connection-deactivate', 'connection-deactivate-confirm']);
				showListErrorMessage('Invalid connection selected.');
				return;
			}

			hideActiveModals(['connection-deactivate', 'connection-deactivate-confirm']);
			showCommonLoaderPopup();

			// Dependent syncs go first — deleting the connection while they are
			// still around would leave them pointing at a record that is gone.
			deleteSyncsForConnection().then(function() {
				return deleteConnectionRecord(recordId);
			}).then(function() {
				$('#connection-deactivate')
					.removeData('record-id')
					.removeData('connection-name')
					.removeData('impact-records');
				return ZOHO.CRM.API.getAllRecords({
					Entity: CONNECTIONS_ENTITY,
					// Newest first, so a freshly created connection heads the list.
					sort_order: 'desc',
					per_page: 200,
					page: 1
				});
			}).then(function(response) {
				var records = (response && response.data) || [];

				syncDataTransferTabVisibility(records);

				if (records.length > 0) {
					return showConnectionsListTab({
						records: records,
						animate: false,
						showSuccessAlert: true,
						successMessage: 'Connection removed successfully.'
					});
				}

				renderConnectionsList([]);
				showNetcoreCESection({ animate: false });
			}).catch(function(error) {
				console.error('handleConfirmRemoveConnection error:', error);
				showGatewayResponseModal(
					{
						action: 'remove_connection',
						connectionname: connectionName,
						record_id: recordId
					},
					sanitizeResponseForDisplay(error) || {
						status: 'failed',
						message: getApiErrorMessage(error, 'Unable to remove connection. Please try again.')
					}
				);
			}).then(function() {
				hideCommonLoaderPopup();
			}, function() {
				hideCommonLoaderPopup();
			});
		}

		function bindViewConnectionEvents() {
			$('#connections-cards-list').on('click', '.view-connection-btn', function(event) {
				event.preventDefault();
				event.stopPropagation();
				handleViewConnection($(this).data('record-id'));
			});

			$('#connections-cards-list').on('click', '.remove-connection-btn', function(event) {
				event.preventDefault();
				event.stopPropagation();
				openRemoveConnectionModal(
					$(this).data('record-id'),
					$(this).attr('data-connection-name')
				);
			});

			$('#remove-connection-continue-btn').on('click', function(event) {
				event.preventDefault();
				openRemoveConnectionConfirmModal();
			});

			$('#remove-connection-back-btn').on('click', function(event) {
				event.preventDefault();
				returnToRemoveConnectionStep1();
			});

			$('#confirm-remove-connection-btn').on('click', function(event) {
				event.preventDefault();
				handleConfirmRemoveConnection();
			});

			$('#view-edit-btn').on('click', function() {
				setConnectionViewMode('edit');
			});

			$('#view-close-btn').on('click', handleViewCloseClick);
		}

		// function to handle the submitted connection details --------------------------
		function fetchAllConnectionRecords() {
			return ZOHO.CRM.API.getAllRecords({
				Entity: CONNECTIONS_ENTITY,
				// Newest first, so a freshly created connection heads the list.
				sort_order: 'desc',
				per_page: 200,
				page: 1
			}).then(function(response) {
				return (response && response.data) || [];
			});
		}

		/**
		 * Show/hide the "Data Transfer" main nav tab.
		 * Visible only when at least one Connection record exists.
		 */
		function setDataTransferNavVisible(isVisible) {
			var $tab = $('#nav-data-transfer-tab');
			if (!$tab.length) {
				return;
			}

			if (isVisible) {
				$tab
					.removeClass('is-nav-hidden')
					.removeAttr('hidden')
					.attr('aria-hidden', 'false');
			} else {
				$tab
					.addClass('is-nav-hidden')
					.attr('hidden', true)
					.attr('aria-hidden', 'true')
					.removeClass('active');
			}
		}

		/**
		 * Sync Data Transfer tab visibility from Connection records.
		 * Reuses fetchAllConnectionRecords() (same getAllRecords call as
		 * Connections list / Data Transfer Setup Connection dropdown).
		 *
		 * @param {Array} [optionalRecords] - skip fetch when already loaded
		 * @returns {Promise<boolean>} true when tab is visible
		 */
		function syncDataTransferTabVisibility(optionalRecords) {
			function apply(records) {
				var hasConnections = Array.isArray(records) && records.length > 0;
				setDataTransferNavVisible(hasConnections);

				if (
					window.DataTransferModule
					&& typeof window.DataTransferModule.invalidateConnectionsCache === 'function'
				) {
					window.DataTransferModule.invalidateConnectionsCache();
				}

				return hasConnections;
			}

			if (Array.isArray(optionalRecords)) {
				return Promise.resolve(apply(optionalRecords));
			}

			return fetchAllConnectionRecords()
				.then(apply)
				.catch(function(error) {
					console.error('syncDataTransferTabVisibility error:', error);
					setDataTransferNavVisible(false);
					return false;
				});
		}

		/**
		 * Block Data Transfer access when no Connections exist:
		 * hide the tab, open Connections, show guidance message.
		 */
		function redirectToConnectionsRequireConnection(message) {
			setDataTransferNavVisible(false);
			showCommonLoaderPopup();

			return fetchAllConnectionRecords()
				.then(function(records) {
					var hasConnections = (records || []).length > 0;
					setDataTransferNavVisible(hasConnections);

					return showConnectionsListTab({
						records: records || [],
						animate: true,
						showSuccessAlert: false
					}).then(function() {
						if (!hasConnections) {
							showListErrorMessage(
								message || 'Please create a Connection first.'
							);
						}
					});
				})
				.catch(function(error) {
					console.error('redirectToConnectionsRequireConnection error:', error);
					showNetcoreCESection({ animate: true });
					showListErrorMessage(
						message || 'Please create a Connection first.'
					);
				})
				.then(function() {
					hideCommonLoaderPopup();
				}, function() {
					hideCommonLoaderPopup();
				});
		}

		function updateCreateConnectionTitlePlaceholder() {
			return fetchAllConnectionRecords().then(function(records) {
				var nextNumber = (records.length || 0) + 1;
				var nextName = 'Netcore connection_' + nextNumber;
				$('#netcore-connection-title').val(nextName);
				setConnectionCreateFormBaseline();
			}).catch(function(error) {
				console.error('updateCreateConnectionTitlePlaceholder error:', error);
				$('#netcore-connection-title').val('Netcore connection_1');
				setConnectionCreateFormBaseline();
			});
		}

		function hasDuplicateConnectionName(records, connectionName, excludeRecordId) {
			var normalizedName = String(connectionName || '').trim().toLowerCase();
			if (!normalizedName) {
				return false;
			}

			return (records || []).some(function(record) {
				if (excludeRecordId && String(record.id) === String(excludeRecordId)) {
					return false;
				}

				return String(record.Name || '').trim().toLowerCase() === normalizedName;
			});
		}

		function showDuplicateConnectionNameError(connectionDetails) {
			var isUpdate = connectionDetails.mode === 'update';
			var $title = $(isUpdate ? '#view-connection-title' : '#netcore-connection-title');
			var $error = $title.closest('.title-connections').find('.error-message');
			var $alert = $(isUpdate ? '#connections-view-edit .view-alert-msg' : '#nav-connections .alert-msg');
			var duplicateMessage = 'A connection with this name already exists. Please use a unique name.';

			$title.addClass('input-error');
			// Duplicate-name message is shown via tooltip on hover, not inline under the field.
			$error.hide().text('');

			// Set alert text first so the banner is correct even if tooltip init fails.
			$alert.find('.alert-msg-text').text(duplicateMessage);

			if (typeof window.setConnectionNameErrorTooltip === 'function') {
				window.setConnectionNameErrorTooltip($title, duplicateMessage);
			}

			if ($alert.length) {
				var existingTimer = $alert.data('alert-hide-timer');
				if (existingTimer) {
					clearTimeout(existingTimer);
				}

				$alert.show();
				$('html, body').animate({
					scrollTop: $alert.offset().top - 20
				}, 300);

				var hideTimer = setTimeout(function() {
					$alert.hide();
					$alert.removeData('alert-hide-timer');
				}, 2000);
				$alert.data('alert-hide-timer', hideTimer);
			}
		}

		function showMaxConnectionsLimitError() {
			var $alert = $('#nav-connections .alert-msg');
			var $alertText = $alert.find('.alert-msg-text');

			if ($alertText.length) {
				$alertText.text(
					'Maximum connection limit reached. You can create up to ' + MAX_CONNECTIONS + ' connections only.'
				);
			}

			if ($alert.length) {
				$alert.show();
				$('html, body').animate({
					scrollTop: $alert.offset().top - 20
				}, 300);
			}
		}

		function proceedWithConnectionActivation(connectionDetails) {
			showConnectionActivatePopup();

			var func_name = 'netcore0__connection_from_zoho_to_netcore';
			var req_data = {
				arguments: JSON.stringify({
					connection_id: connectionDetails.connectionId,
					api_key: connectionDetails.apiKey,
					endpoint: connectionDetails.endPoint,
					source: connectionDetails.source
				})
			};


			ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
				.then(function(data) {
					handleFunctionExecuteResponse(data, connectionDetails);
				})
				.catch(function(err) {
					console.error('Function execute error:', err);
					hideConnectionActivatePopup();
					showGatewayResponseModal(buildGatewayPayload(connectionDetails), err);
				});
		}

		/** Strip trailing slashes from the Netcore endpoint before any Zoho API call. */
		function normalizeNetcoreEndPoint(url) {
			return $.trim(String(url || '')).replace(/\/+$/, '');
		}

		function handleSubmittedConnectionDetails(connectionDetails, options) {
			options = options || {};
			connectionDetails = connectionDetails || {};
			connectionDetails.endPoint = normalizeNetcoreEndPoint(connectionDetails.endPoint);

			if (connectionDetails.mode === 'update' && !connectionDetails.recordId) {
				$('#connections-view-edit .view-alert-error-text').text('Invalid connection record. Please reopen the connection and try again.');
				$('#connections-view-edit .view-alert-error-msg').show();
				return;
			}

			var fieldsValid = options.fieldsValid !== false;
			var titleValue = String(connectionDetails.connectionTitle || '').trim();

			// No name entered: skip uniqueness check and show field validation alert.
			if (!titleValue) {
				if (!fieldsValid && typeof options.onFieldsInvalid === 'function') {
					options.onFieldsInvalid();
				}
				return;
			}

			showCommonLoaderPopup();

			fetchAllConnectionRecords().then(function(records) {
				var isCreate = connectionDetails.mode !== 'update';
				var excludeRecordId = connectionDetails.mode === 'update'
					? connectionDetails.recordId
					: null;

				if (isCreate && records.length >= MAX_CONNECTIONS) {
					hideCommonLoaderPopup();
					showMaxConnectionsLimitError();
					return;
				}

				// Duplicate name takes priority over the generic "fill all details" alert.
				if (hasDuplicateConnectionName(records, connectionDetails.connectionTitle, excludeRecordId)) {
					hideCommonLoaderPopup();
					showDuplicateConnectionNameError(connectionDetails);
					return;
				}

				if (!fieldsValid) {
					hideCommonLoaderPopup();
					if (typeof options.onFieldsInvalid === 'function') {
						options.onFieldsInvalid();
					}
					return;
				}

				hideLoaderThen(function() {
					proceedWithConnectionActivation(connectionDetails);
				});
			}).catch(function(error) {
				console.error('Connection name uniqueness check failed:', error);
				hideCommonLoaderPopup();
				showGatewayResponseModal(
					buildGatewayPayload(connectionDetails),
					sanitizeResponseForDisplay(error) || {
						status: 'failed',
						message: getApiErrorMessage(error, 'Unable to validate connection name. Please try again.')
					}
				);
			});
		}

		function buildConnectionRecordData(connectionDetails, netcoreClientId) {
			var clientId = netcoreClientId || connectionDetails.clientId || '';

			return {
				Name: connectionDetails.connectionTitle,
				netcore0__Client_ID: String(clientId),
				netcore0__Netcore_connection_ID: connectionDetails.connectionId,
				netcore0__Netcore_API_key: connectionDetails.apiKey,
				netcore0__Netcore_end_point: connectionDetails.endPoint,
				netcore0__Source: connectionDetails.source,
				netcore0__Status:'Active'
			};
		}

		function saveConnectionRecord(recordData, connectionDetails) {
			if (connectionDetails.mode === 'update' && connectionDetails.recordId) {
				recordData.id = connectionDetails.recordId;
				return ZOHO.CRM.API.updateRecord({
					Entity: CONNECTIONS_ENTITY,
					APIData: recordData
				});
			}

			return ZOHO.CRM.API.insertRecord({
				Entity: CONNECTIONS_ENTITY,
				APIData: recordData
			});
		}

		/*function to escape html characters */
		function escapeHtml(text) {
			return String(text)
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;');
		}

		/*function to highlight a single pretty-printed JSON line */
		function highlightJsonLine(line) {
			var result = '';
			var i = 0;
			var len = line.length;

			while (i < len) {
				var ch = line.charAt(i);

				if (/\s/.test(ch)) {
					result += ch;
					i += 1;
					continue;
				}

				if (ch === '"') {
					var end = i + 1;
					var escaped = false;

					while (end < len) {
						if (escaped) {
							escaped = false;
						} else if (line.charAt(end) === '\\') {
							escaped = true;
						} else if (line.charAt(end) === '"') {
							break;
						}
						end += 1;
					}

					var strToken = line.slice(i, end + 1);
					var isKey = /^\s*:/.test(line.slice(end + 1));
					var stringClass = isKey ? 'tok-key' : 'tok-string';
					result += '<span class="' + stringClass + '">' + escapeHtml(strToken) + '</span>';
					i = end + 1;
					continue;
				}

				if (ch === '-' || (ch >= '0' && ch <= '9')) {
					var numMatch = line.slice(i).match(/^-?\d+(\.\d+)?([eE][+-]?\d+)?/);
					if (numMatch) {
						result += '<span class="tok-num">' + escapeHtml(numMatch[0]) + '</span>';
						i += numMatch[0].length;
						continue;
					}
				}

				if (line.slice(i, i + 4) === 'true') {
					result += '<span class="tok-bool">true</span>';
					i += 4;
					continue;
				}

				if (line.slice(i, i + 5) === 'false') {
					result += '<span class="tok-bool">false</span>';
					i += 5;
					continue;
				}

				if (line.slice(i, i + 4) === 'null') {
					result += '<span class="tok-null">null</span>';
					i += 4;
					continue;
				}

				if (ch === '{' || ch === '}' || ch === '[' || ch === ']') {
					result += '<span class="tok-brace">' + escapeHtml(ch) + '</span>';
					i += 1;
					continue;
				}

				if (ch === ':' || ch === ',') {
					result += '<span class="tok-punct">' + escapeHtml(ch) + '</span>';
					i += 1;
					continue;
				}

				result += escapeHtml(ch);
				i += 1;
			}

			return result;
		}

		/*function to populate the code panel */
		function populateCodePanel(containerId, data) {
			var container = document.getElementById(containerId);
			if (!container) {
				return '';
			}

			var jsonStr = JSON.stringify(data, null, 2);
			var lines = jsonStr.split('\n');

			container.innerHTML = lines.map(function(line, index) {
				return (
					'<div class="code-line">' +
					'<span class="line-no">' + (index + 1) + '</span>' +
					'<span class="line-content">' + highlightJsonLine(line) + '</span>' +
					'</div>'
				);
			}).join('');

			return jsonStr;
		}

		/*function to sanitize the response for display */
		function sanitizeResponseForDisplay(response) {
			if (!response || typeof response !== 'object') {
				return response;
			}

			var sanitized = Object.assign({}, response);
			delete sanitized.$responseHeaders;
			return sanitized;
		}

		/*function to build payload for gateway modal — mirrors the request sent to FUNCTIONS.execute */
		function buildGatewayPayload(connectionDetails) {
			var payload = {
				connectionname: connectionDetails.connectionTitle || '',
				connection_id: connectionDetails.connectionId || '',
				api_key: connectionDetails.apiKey || '',
				endpoint: connectionDetails.endPoint || '',
				source: connectionDetails.source || ''
			};

			if (connectionDetails.mode === 'update' && connectionDetails.recordId) {
				payload.record_id = connectionDetails.recordId;
			}

			if (connectionDetails.clientId) {
				payload.client_id = connectionDetails.clientId;
			}

			return payload;
		}

		/*function to check if output string is HTML */
		function isHtmlString(str) {
			if (typeof str !== 'string') {
				return false;
			}

			var trimmed = str.trim();
			return /^<!DOCTYPE/i.test(trimmed) || /^<html/i.test(trimmed) || /<html[\s>]/i.test(trimmed);
		}

		/*function to extract readable message from HTML output */
		function parseHtmlOutput(html) {
			try {
				var doc = new DOMParser().parseFromString(html, 'text/html');
				var titleEl = doc.querySelector('title');
				var h1El = doc.querySelector('h1');
				var h2El = doc.querySelector('h2');
				var title = titleEl ? titleEl.textContent.trim() : '';
				var heading = h1El ? h1El.textContent.trim() : '';
				var description = h2El ? h2El.textContent.trim() : '';

				return {
					status: 'failed',
					message: heading || title || 'Request failed',
					description: description || 'The server returned an HTML error page instead of a valid JSON response.'
				};
			} catch (error) {
				return {
					status: 'failed',
					message: 'Invalid response received from gateway',
					description: 'The server returned an HTML error page instead of a valid JSON response.'
				};
			}
		}

		/*function to parse function output from Zoho response */
		function parseFunctionOutput(data) {
			if (!data || !data.details || data.details.output == null) {
				return null;
			}

			var output = data.details.output;

			if (typeof output !== 'string') {
				return output;
			}

			if (isHtmlString(output)) {
				return parseHtmlOutput(output);
			}

			try {
				return JSON.parse(output);
			} catch (error) {
				return {
					status: 'failed',
					message: output
				};
			}
		}

		/*function to check if function output indicates failure */
		function isFunctionOutputFailed(output) {
			if (!output) {
				return false;
			}

			if (output.status == null) {
				return false;
			}

			var status = String(output.status).toLowerCase();
			return status === 'failed' || status === 'error';
		}

		/*function to check if function output indicates success */
		function isFunctionOutputSuccess(output) {
			if (!output || output.status == null) {
				return false;
			}

			return String(output.status).toLowerCase() === 'success';
		}

		/*function to get client_id from function output */
		function getNetcoreClientId(output) {
			if (
				!output ||
				!output.data ||
				!output.data.connector_parameters ||
				output.data.connector_parameters.client_id == null
			) {
				return null;
			}

			return output.data.connector_parameters.client_id;
		}

		/*function to format added on date */
		function formatAddedOnDate(date) {
			return date.toLocaleDateString('en-GB', {
				day: 'numeric',
				month: 'short',
				year: 'numeric'
			});
		}

		/*function to format created time from CRM record */
		function formatCreatedTime(createdTime) {
			if (!createdTime) {
				return '-';
			}

			return formatAddedOnDate(new Date(createdTime));
		}

		/*function to build a single connection card */
		function buildConnectionCardHtml(record) {
			var connectionName = escapeHtml(record.Name || '-');
			var addedOn = formatCreatedTime(record.Created_Time);
			var status = record.netcore0__Status || '';
			var statusIcon = status === 'Active' ? '<div class="status-ping" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Activated"></div>' : '<div class="status-ping inactive-status" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Deactivated"></div>';
			return (
				'<div class="conn-card" data-record-id="' + escapeHtml(record.id || '') + '">' +
					'<div class="conn-top">' +
						'<div class="conn-icon">' +
							'<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_2080_7853)"><path d="M12.8193 0.443217L11.4559 3.94555L12.7808 6.76399L14.2251 3.12751H17.376V15.531C17.3753 16.0044 17.1912 16.4581 16.8641 16.7927C16.5369 17.1273 16.0934 17.3154 15.6309 17.3157C15.2621 17.3157 14.6261 17.1053 14.3742 16.5924L12.4467 12.2523L12.4338 12.2733L9.25212 5.14105L9.2624 5.1279L7.92727 2.13323C7.17425 0.578681 5.63351 0 4.36906 0C3.21031 0 2.09902 0.471116 1.27967 1.30971C0.46031 2.1483 0 3.28568 0 4.47162L0.0436906 19.5542H6.65896L8.36931 15.7664L7.04703 12.9467L5.24801 16.8699H2.62272V4.47162C2.62272 3.99759 2.80671 3.54298 3.13421 3.20779C3.46171 2.8726 3.9059 2.68429 4.36906 2.68429C4.60164 2.68429 5.38679 2.73821 5.67463 3.51812L7.15497 6.84816L7.64456 7.95949L10.8134 15.0904C11.366 16.3096 11.9802 17.6577 12.2501 18.2377C12.7988 19.4121 14.2264 20 15.6309 20C16.2047 20 16.7728 19.8843 17.3029 19.6596C17.833 19.4349 18.3146 19.1055 18.7203 18.6903C19.126 18.2751 19.4479 17.7821 19.6674 17.2396C19.887 16.6971 20 16.1156 20 15.5284V0.443217H12.8193Z" fill="#FC5E02"/></g><defs><clipPath id="clip0_2080_7853"><rect width="20" height="20" fill="white"/></clipPath></defs></svg>' +
						'</div>' +
						'<div class="conn-name">' +
							'<h3>Netcore</h3>' +
							'<p>Transfer data from Zoho to Netcore CE</p>' +
						'</div>' +
						'<div class="conn-status">' +
							statusIcon +
							'<button class="btn-dots" type="button" onclick="toggleMenu(event)">' +
								'<svg width="5" height="20" viewBox="0 0 5 20" fill="none" xmlns="http://www.w3.org/2000/svg">' +
									'<path d="M2.5 15C3.88071 15 5 16.1193 5 17.5C5 18.8807 3.88071 20 2.5 20C1.11929 20 0 18.8807 0 17.5C0 16.1193 1.11929 15 2.5 15ZM2.5 7.5C3.88071 7.5 5 8.61929 5 10C5 11.3807 3.88071 12.5 2.5 12.5C1.11929 12.5 0 11.3807 0 10C0 8.61929 1.11929 7.5 2.5 7.5ZM2.5 0C3.88071 0 5 1.11929 5 2.5C5 3.88071 3.88071 5 2.5 5C1.11929 5 0 3.88071 0 2.5C0 1.11929 1.11929 0 2.5 0Z" fill="currentColor"/>' +
								'</svg>' +
							'</button>' +
							'<div class="dots-menu">' +
								'<div class="menu-item view-connection-btn" role="button" tabindex="0" data-record-id="' + escapeHtml(record.id || '') + '">View' +
									'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>' +
								'</div>' +
								'<div class="menu-item remove-connection-btn" role="button" tabindex="0" data-record-id="' + escapeHtml(record.id || '') + '" data-connection-name="' + connectionName + '">Remove' +
									'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>' +
								'</div>' +
							'</div>' +
						'</div>' +
					'</div>' +
					'<div class="conn-meta">' +
						'<div class="row-line"><span class="label">Connection name</span> : <b>' + connectionName + '</b></div>' +
						'<div class="row-line"><span class="label">Added on</span> : <b>' + addedOn + '</b></div>' +
					'</div>' +
				'</div>'
			);
		}

		/*function to render connections list cards */
		function renderConnectionsList(records) {
			var container = document.getElementById('connections-cards-list');
			var addNewBtn = document.getElementById('add-new-connection-btn');
			var connectionCount = records && records.length ? records.length : 0;

			if (!container) {
				return;
			}

			if (!connectionCount) {
				container.innerHTML = '';
			} else {
				container.innerHTML = records.map(buildConnectionCardHtml).join('');
			}

			if (addNewBtn) {
				addNewBtn.style.display = connectionCount >= MAX_CONNECTIONS ? 'none' : '';
			}

			// Cards are injected after page load — re-init Bootstrap tooltips in this list.
			if (typeof window.initBootstrapTooltips === 'function') {
				window.initBootstrapTooltips(container);
			}
		}

		function bindMainTabNavigation() {
			$('#nav-connections-tab').on('click', function(event) {
				event.preventDefault();
				showCommonLoaderPopup();

				ZOHO.CRM.API.getAllRecords({
					Entity: CONNECTIONS_ENTITY,
					// Newest first, so a freshly created connection heads the list.
					sort_order: 'desc',
					per_page: 200,
					page: 1
				}).then(function(response) {
					var records = (response && response.data) || [];

					syncDataTransferTabVisibility(records);

					if (records.length > 0) {
						return showConnectionsListTab({
							records: records,
							animate: true,
							showSuccessAlert: false
						});
					}

					return showConnectionsListTab({
						records: [],
						animate: true,
						showSuccessAlert: false
					});
				}).catch(function(error) {
					console.error('Connections tab navigation error:', error);
					syncDataTransferTabVisibility([]);
					showNetcoreCESection({ animate: true });
				}).then(function() {
					hideCommonLoaderPopup();
				}, function() {
					hideCommonLoaderPopup();
				});
			});
		}

		initializeWidgetView();
		bindViewConnectionEvents();
		bindDiscardExitEvents();
		bindMainTabNavigation();
		window.handleViewConnection = handleViewConnection;
		window.handleDiscardAndExit = handleDiscardAndExit;
		window.updateCreateConnectionTitlePlaceholder = updateCreateConnectionTitlePlaceholder;
		window.hideAllMainWidgetSections = hideAllMainSections;
		window.showNetcoreCESection = showNetcoreCESection;
		window.showConnectionsListTab = showConnectionsListTab;
		window.setConnectionCreateFormBaseline = setConnectionCreateFormBaseline;
		window.fetchAllConnectionRecords = fetchAllConnectionRecords;
		window.syncDataTransferTabVisibility = syncDataTransferTabVisibility;
		window.setDataTransferNavVisible = setDataTransferNavVisible;
		window.redirectToConnectionsRequireConnection = redirectToConnectionsRequireConnection;
		window.saveActiveMainTab = saveActiveMainTab;
		window.getSavedMainTab = getSavedMainTab;

		/*function to handle function execute response */
		function handleFunctionExecuteResponse(data, connectionDetails) {
			var gatewayPayload = buildGatewayPayload(connectionDetails);

			// Always dismiss activate loader before handling success or failure
			hideConnectionActivatePopup();

			if (!data || data.code !== 'success') {
				console.error('Function failed:', data && data.message, data);
				showGatewayResponseModal(gatewayPayload, data);
				return;
			}

			var output = parseFunctionOutput(data);

			if (isFunctionOutputFailed(output)) {
				console.error('Gateway connection failed:', output);
				showGatewayResponseModal(gatewayPayload, output);
				return;
			}

			if (!isFunctionOutputSuccess(output)) {
				console.error('Unexpected gateway response:', output);
				showGatewayResponseModal(gatewayPayload, output || {
					status: 'failed',
					message: 'Unexpected response received from gateway'
				});
				return;
			}

			var netcoreClientId = getNetcoreClientId(output);

			if (!netcoreClientId) {
				console.error('Client ID missing in gateway response:', output);
				showGatewayResponseModal(gatewayPayload, {
					status: 'failed',
					message: 'Client ID not found in response',
					description: 'Verified response did not include client_id.'
				});
				return;
			}


			var recordData = buildConnectionRecordData(connectionDetails, netcoreClientId);
			var isUpdate = connectionDetails.mode === 'update';

			saveConnectionRecord(recordData, connectionDetails).then(function(saveResponse) {


				// First (or any) successful Connection → Data Transfer tab becomes visible immediately.
				setDataTransferNavVisible(true);
				if (
					window.DataTransferModule
					&& typeof window.DataTransferModule.invalidateConnectionsCache === 'function'
				) {
					window.DataTransferModule.invalidateConnectionsCache();
				}

				var listOptions = {
					animate: true,
					showSuccessAlert: true,
					successMessage: isUpdate
						? 'Connection updated successfully.'
						: 'Connector added successfully.'
				};

				var afterSavePromise = isUpdate
					? showConnectionsListTab(listOptions)
					: showConnectionSuccessPopup().then(function() {
						return showConnectionsListTab(listOptions);
					});

				return afterSavePromise.catch(function(error) {
					console.error('load connections list error:', error);
				});
			}).catch(function(error) {
				console.error(isUpdate ? 'updateRecord error:' : 'insertRecord error:', error);
				showGatewayResponseModal(gatewayPayload, error);
			});
		}

		/*function to show the connection success popup */
		function showConnectionSuccessPopup() {
			return new Promise(function(resolve) {
				var connectionSuccessPopup = document.getElementById('connection-successfully');
				if (!connectionSuccessPopup) {
					resolve();
					return;
				}

				var connectionSuccessPopupModal = bootstrap.Modal.getOrCreateInstance(connectionSuccessPopup, {
					backdrop: 'static',
					keyboard: false
				});
				var settled = false;

				function finish() {
					if (settled) {
						return;
					}
					settled = true;
					resolve();
				}

				$(connectionSuccessPopup).one('hidden.bs.modal', finish);
				connectionSuccessPopupModal.show();

				// Let the success GIF play briefly, then continue to the list.
				setTimeout(function() {
					connectionSuccessPopupModal.hide();
					// Fallback if hidden event does not fire.
					setTimeout(finish, 400);
				}, 3500);
			});
		}

		/*function to show the gateway response modal */
		function showGatewayResponseModal(payload, response) {
			// Safety net: never leave activate loader open behind gateway dialog
			hideConnectionActivatePopup();

			var modalElement = document.getElementById('gatewayResponseModal');
			if (!modalElement) {
				console.error('gatewayResponseModal element not found');
				return;
			}

			var displayResponse = sanitizeResponseForDisplay(response);

			window.__gatewayPayloadJson = populateCodePanel('gatewayPayloadLines', payload);
			window.__gatewayResponseJson = populateCodePanel('gatewayResponseLines', displayResponse);

			if (typeof window.switchTab === 'function') {
				window.switchTab('response');
			}

			var connectionErrorModal = bootstrap.Modal.getOrCreateInstance(modalElement);
			connectionErrorModal.show();
		}


		//--------function to process connection details --------------------
		 window.processConnectionDetails = handleSubmittedConnectionDetails;
        //----------------------------------------------------------------- */
	  
	});
	ZOHO.embeddedApp.init();

});
