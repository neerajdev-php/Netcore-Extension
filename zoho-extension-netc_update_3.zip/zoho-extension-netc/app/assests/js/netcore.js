jQuery(document).ready(function ($) {

    /**
     * Host element that owns the "Rename" Bootstrap tooltip.
     * - Connections: wrapper .title-connections[data-connection-name-tooltip]
     * - Data Transfer title: wrapper .datatrsf-title[data-rename-tooltip]
     *   (tooltip lives on the wrapper — never on the input — to avoid a second tip)
     */
    function getRenameTooltipHost($input) {
        var $el = $($input);
        var $container = $el.closest('[data-connection-name-tooltip]');
        if ($container.length) {
            return $container;
        }
        var $renameHost = $el.closest('[data-rename-tooltip]');
        if ($renameHost.length) {
            return $renameHost;
        }
        if ($el.is('[data-rename-tooltip]')) {
            return $el;
        }
        return $();
    }

    // Older name kept so existing connection helpers keep working.
    function getConnectionNameTooltipContainer($input) {
        return getRenameTooltipHost($input);
    }

    function safeHideConnectionNameTooltip(tip) {
        if (!tip) {
            return;
        }
        try {
            tip.hide();
        } catch (error) {
            // Bootstrap can throw if hide runs during dispose/animation.
        }
    }

    /**
     * Block tooltip from opening while the user is typing in the name field.
     * Bound once per host (avoids dispose/disable races).
     */
    function ensureConnectionNameTooltipTypingGuard($container) {
        if (!$container.length || $container.data('tooltip-typing-guard')) {
            return;
        }

        $container.data('tooltip-typing-guard', true);
        $container.on('show.bs.tooltip.connectionName', function (event) {
            if ($container.attr('data-tooltip-typing') === 'true') {
                event.preventDefault();
            }
        });
    }

    /**
     * Hide the Rename/error tooltip on focus/typing,
     * and keep it off until the user leaves the field (blur).
     */
    function hideConnectionNameTooltipWhileTyping($input) {
        var $container = getRenameTooltipHost($input);
        if (!$container.length) {
            return;
        }

        $container.attr('data-tooltip-typing', 'true');
        ensureConnectionNameTooltipTypingGuard($container);

        if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
            return;
        }

        safeHideConnectionNameTooltip(bootstrap.Tooltip.getInstance($container[0]));
    }

    /** After editing ends, allow hover tooltips again. */
    function restoreConnectionNameTooltipAfterTyping($input) {
        var $container = getRenameTooltipHost($input);
        if (!$container.length) {
            return;
        }

        $container.removeAttr('data-tooltip-typing');
    }

    function initializeConnectionNameTooltip($container, message, isError) {
        if (!$container.length) {
            return;
        }

        var helpText = $container.attr('data-help-text') || 'Rename';
        var tooltipText = message || helpText;
        var element = $container[0];
        var isTyping = $container.attr('data-tooltip-typing') === 'true';

        // Keep Bootstrap's copy of the title only. Leaving a live `title` attribute
        // causes a second (native browser) tooltip next to the Bootstrap one.
        $container
            .attr('data-bs-original-title', tooltipText)
            .attr('data-bs-trigger', 'hover')
            .removeAttr('title')
            .toggleClass('has-name-error', !!isError);

        if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
            return;
        }

        ensureConnectionNameTooltipTypingGuard($container);

        // Prefer updating the existing instance — dispose+recreate while hovering
        // causes Bootstrap "_isWithActiveTrigger" console errors.
        var tooltip = bootstrap.Tooltip.getInstance(element);
        if (!tooltip) {
            tooltip = bootstrap.Tooltip.getOrCreateInstance(element, {
                trigger: 'hover',
                placement: 'bottom',
                container: 'body',
                title: tooltipText
            });
        } else if (tooltip._config) {
            tooltip._config.title = tooltipText;
        }

        // Bootstrap 5: push text into the live tip if it is already open.
        if (typeof tooltip.setContent === 'function') {
            try {
                tooltip.setContent({ '.tooltip-inner': tooltipText });
            } catch (setContentError) {
                // Older / partial Bootstrap builds — _config.title is enough.
            }
        }

        if (isTyping) {
            safeHideConnectionNameTooltip(tooltip);
            return;
        }

        // Only refresh if hovering and the user is not editing.
        var isHostInputFocused = $container.is('input:focus, textarea:focus');
        var hasNestedFocusedInput = $container.find('input:focus, textarea:focus').length > 0;
        if ($container.is(':hover') && !isHostInputFocused && !hasNestedFocusedInput) {
            try {
                tooltip.show();
            } catch (error) {
                // Ignore Bootstrap internal race conditions.
            }
        }
    }

    function clearConnectionNameErrorTooltip($input) {
        initializeConnectionNameTooltip(
            getRenameTooltipHost($input),
            '',
            false
        );
    }

    function setConnectionNameErrorTooltip($input, message) {
        if (!message) {
            clearConnectionNameErrorTooltip($input);
            return;
        }

        initializeConnectionNameTooltip(
            getRenameTooltipHost($input),
            message,
            true
        );
    }

    /**
     * Reusable: hover-only Rename tooltip that hides on focus/typing.
     * Used by Connections name fields and Data Transfer transferName.
     */
    function bindRenameTooltipHideOnEdit($input) {
        var $field = $($input);
        if (!$field.length || $field.data('rename-tooltip-edit-bound')) {
            return;
        }

        var $host = getRenameTooltipHost($field);
        if (!$host.length) {
            return;
        }

        $field.data('rename-tooltip-edit-bound', true);

        // Ensure a single hover-only Bootstrap instance on the host.
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            ensureConnectionNameTooltipTypingGuard($host);
            $host.attr('data-bs-trigger', 'hover');
            var existing = bootstrap.Tooltip.getInstance($host[0]);
            if (!existing) {
                bootstrap.Tooltip.getOrCreateInstance($host[0], {
                    trigger: 'hover',
                    placement: $host.attr('data-bs-placement') || 'bottom',
                    container: 'body'
                });
            } else if (existing._config) {
                existing._config.trigger = 'hover';
            }
        }

        $field.on('focus.renameTooltip keydown.renameTooltip input.renameTooltip', function () {
            hideConnectionNameTooltipWhileTyping(this);
        });
        $field.on('blur.renameTooltip', function () {
            restoreConnectionNameTooltipAfterTyping(this);
        });
    }

    window.clearConnectionNameErrorTooltip = clearConnectionNameErrorTooltip;
    window.setConnectionNameErrorTooltip = setConnectionNameErrorTooltip;
    window.bindRenameTooltipHideOnEdit = bindRenameTooltipHideOnEdit;

    function resetConnectionForm() {
        $('#netcore-connection-title, #connectionId, #apiKey, #endPoint').val('');
        $('#netcore-connection-title, .connections-form .form-control').removeClass('input-error');
        $('.title-connections .error-message, .connections-form .error-message').hide().text('');
        $('.alert-msg, .alert-success-msg').hide();
        clearConnectionNameErrorTooltip($('#netcore-connection-title'));

        if (typeof window.setConnectionCreateFormBaseline === 'function') {
            window.setConnectionCreateFormBaseline();
        }
    }

    function openConnectionsFormSection(options) {
        const settings = $.extend({ resetForm: false }, options);
        const $netcore = $('#nav-netcore');
        const $connections = $('#nav-connections');
        const $connectionsList = $('#nav-connections-list');
        const $viewEdit = $('#connections-view-edit');
        const $activeSection = $('.tab-pane-netcore-ce.active, .tab-netcore-connection.active, .tab-data-transfer.active').first();

        function refreshCreateConnectionTitle() {
            if (typeof window.updateCreateConnectionTitlePlaceholder === 'function') {
                window.updateCreateConnectionTitlePlaceholder();
            }
        }

        function showConnectionsForm() {
            $netcore.removeClass('active').hide();
            $connectionsList.removeClass('active').hide();
            $viewEdit.removeClass('active').hide();
            $('#data-transfer').removeClass('active').hide();
            $('#data-transfer-setup').removeClass('active').hide();
            $('#section-data-transfer').hide();
            $connections.addClass('active').slideDown(400);
            $('.main-tabs .nav-link').removeClass('active');
            $('#nav-connections-tab').addClass('active');
            if (typeof window.saveActiveMainTab === 'function') {
                window.saveActiveMainTab('connections');
            }

            if (settings.resetForm) {
                resetConnectionForm();
            }

            refreshCreateConnectionTitle();
        }

        if ($activeSection.is($connections)) {
            if (settings.resetForm) {
                resetConnectionForm();
            }
            refreshCreateConnectionTitle();
            return;
        }

        $activeSection.slideDown(400, function () {
            $activeSection.removeClass('active');
            showConnectionsForm();
        });
    }

    window.openConnectionsFormSection = openConnectionsFormSection;
    window.resetConnectionForm = resetConnectionForm;

    $('#connect-btn').on('click', function () {
        openConnectionsFormSection({ resetForm: true });
    });

    $('#add-new-connection-btn').on('click', function () {
        openConnectionsFormSection({ resetForm: true });
    });

    function isValidEndPoint(value) {
        return value.toLowerCase().indexOf('netcoreapi') !== -1;
    }

    function parseConnectionIdValue(value) {
        const parts = $.trim(value).split('-');

        return {
            source: parts[0] || '',
            connectionId: parts[1] || '',
            clientId: parts[2] || ''
        };
    }

    function isValidConnectionIdFormat(value) {
        const parts = $.trim(value).split('-');

        return parts.length === 3 &&
            $.trim(parts[0]) !== '' &&
            $.trim(parts[1]) !== '' &&
            $.trim(parts[2]) !== '';
    }

    function getConnectionFormConfig(mode) {
        if (mode === 'update') {
            return {
                mode: 'update',
                titleSelector: '#view-connection-title',
                connectionIdSelector: '#view-connectionId',
                apiKeySelector: '#view-apiKey',
                endPointSelector: '#view-endPoint',
                formSelector: '#connections-view-edit .connections-view-form',
                alertSelector: '#connections-view-edit .view-alert-msg',
                recordId: $('#connections-view-edit').data('record-id') || ''
            };
        }

        return {
            mode: 'create',
            titleSelector: '#netcore-connection-title',
            connectionIdSelector: '#connectionId',
            apiKeySelector: '#apiKey',
            endPointSelector: '#endPoint',
            formSelector: '#nav-connections .connections-form',
            alertSelector: '#nav-connections .alert-msg'
        };
    }

    function getConnectionFormAlertMessage(mode) {
        return mode === 'update'
            ? 'Fill all the necessary details to update the connection.'
            : 'Fill all the necessary details to activate the connection.';
    }

    function showConnectionFormValidationAlert(config, message) {
        var $alert = $(config.alertSelector);
        var alertMessage = message || getConnectionFormAlertMessage(config.mode);

        $alert.find('.alert-msg-text').text(alertMessage);
        $alert.show();

        if ($alert.length) {
            $('html, body').animate({
                scrollTop: $alert.offset().top - 20
            }, 300);
        }

        var existingTimer = $alert.data('alert-hide-timer');
        if (existingTimer) {
            clearTimeout(existingTimer);
        }

        var hideTimer = setTimeout(function () {
            $alert.hide();
            $alert.removeData('alert-hide-timer');
        }, 2000);
        $alert.data('alert-hide-timer', hideTimer);
    }

    window.showConnectionFormValidationAlert = showConnectionFormValidationAlert;
    window.getConnectionFormAlertMessage = getConnectionFormAlertMessage;

    function validateAndGetConnectionDetails(config, options) {
        options = options || {};
        const $title = $(config.titleSelector);
        const titleValue = $.trim($title.val());
        const $titleError = $title.closest('.title-connections').find('.error-message');
        let isValid = true;

        if (titleValue === '') {
            $title.addClass('input-error');
            $titleError.hide().text('');
            if (typeof window.setConnectionNameErrorTooltip === 'function') {
                window.setConnectionNameErrorTooltip($title, 'Connection name is required.');
            }
            isValid = false;
        }
        else if (titleValue.length > 50) {
            $title.addClass('input-error');
            $titleError.hide().text('');
            setConnectionNameErrorTooltip($title, 'Connection name must be less than 50 characters.');
            isValid = false;
        } else {
            $title.removeClass('input-error');
            clearConnectionNameErrorTooltip($title);
            $titleError.hide().text('');
        }

        const fieldRules = [
            {
                selector: config.connectionIdSelector,
                requiredMessage: 'Netcore connection ID is required.',
                invalidMessage: 'Please enter connection ID in format source-connectionId-clientId.',
                validate: isValidConnectionIdFormat
            },
            {
                selector: config.apiKeySelector,
                requiredMessage: 'Netcore API key is required.'
            },
            {
                selector: config.endPointSelector,
                requiredMessage: 'Netcore end point is required.',
                invalidMessage: 'Please put a valid url',
                validate: isValidEndPoint
            }
        ];

        fieldRules.forEach(function (rule) {
            const $input = $(rule.selector);
            const value = $.trim($input.val());
            const $error = $input.closest('.field-group').find('.error-message');

            if (value === '') {
                $input.addClass('input-error');
                $error.text(rule.requiredMessage).show();
                isValid = false;
            } else if (rule.validate && !rule.validate(value)) {
                $input.addClass('input-error');
                $error.text(rule.invalidMessage).show();
                isValid = false;
            } else {
                $input.removeClass('input-error');
                $error.hide().text('');
            }
        });

        const parsedConnectionId = parseConnectionIdValue($(config.connectionIdSelector).val());
        const connectionDetails = {
            mode: config.mode,
            connectionTitle: titleValue,
            connectionId: parsedConnectionId.connectionId,
            apiKey: $.trim($(config.apiKeySelector).val()),
            endPoint: $.trim($(config.endPointSelector).val()),
            source: parsedConnectionId.source || 'web',
            clientId: parsedConnectionId.clientId || ''
        };

        if (config.mode === 'update') {
            connectionDetails.recordId = config.recordId;
        }

        if (!isValid) {
            // Alert may be deferred so duplicate-name checks can take priority.
            if (!options.deferAlert) {
                showConnectionFormValidationAlert(config);
            }

            return {
                isValid: false,
                connectionDetails: connectionDetails
            };
        }

        $(config.alertSelector).hide();

        return {
            isValid: true,
            connectionDetails: connectionDetails
        };
    }

    function submitConnectionForm(mode) {
        const config = getConnectionFormConfig(mode);
        // Defer the banner so a duplicate name can outrank the generic fill-all message.
        const result = validateAndGetConnectionDetails(config, { deferAlert: true });

        if (typeof window.processConnectionDetails === 'function') {
            window.processConnectionDetails(result.connectionDetails, {
                fieldsValid: result.isValid,
                onFieldsInvalid: function () {
                    showConnectionFormValidationAlert(config);
                }
            });
            return result.isValid;
        }

        console.error('processConnectionDetails is not available in connections.js');
        if (!result.isValid) {
            showConnectionFormValidationAlert(config);
        }
        return result.isValid;
    }

    window.connectionFormHelpers = {
        isValidEndPoint: isValidEndPoint,
        parseConnectionIdValue: parseConnectionIdValue,
        isValidConnectionIdFormat: isValidConnectionIdFormat,
        validateAndGetConnectionDetails: validateAndGetConnectionDetails
    };

    $('body').on('click', '.btn-activate', function (e) {
        e.preventDefault();
        submitConnectionForm('create');
    });

    $('body').on('click', '#view-update-btn', function (e) {
        e.preventDefault();
        if ($('#connections-view-edit').attr('data-mode') !== 'edit') {
            return;
        }
        submitConnectionForm('update');
    });

    function hasInvalidConnectionFields(config) {
        const titleValue = $.trim($(config.titleSelector).val());
        if (titleValue === '') {
            return true;
        }

        const fieldChecks = [
            {
                selector: config.connectionIdSelector,
                validate: isValidConnectionIdFormat
            },
            {
                selector: config.apiKeySelector
            },
            {
                selector: config.endPointSelector,
                validate: isValidEndPoint
            }
        ];

        for (var i = 0; i < fieldChecks.length; i++) {
            var field = fieldChecks[i];
            var value = $.trim($(field.selector).val());

            if (value === '') {
                return true;
            }

            if (field.validate && !field.validate(value)) {
                return true;
            }
        }

        return false;
    }

    // Hide Rename tooltip on focus/typing; clear field errors — create form
    $('#netcore-connection-title').on('focus keydown input', function () {
        hideConnectionNameTooltipWhileTyping($(this));
    });

    $('#netcore-connection-title').on('input', function () {
        const config = getConnectionFormConfig('create');
        const value = $.trim($(this).val());
        const $error = $(this).closest('.title-connections').find('.error-message');

        if (value !== '') {
            $(this).removeClass('input-error');
            $error.hide().text('');
            clearConnectionNameErrorTooltip($(this));
        }

        if (!hasInvalidConnectionFields(config)) {
            $(config.alertSelector).hide();
        }
    });

    $('#netcore-connection-title').on('blur', function () {
        restoreConnectionNameTooltipAfterTyping($(this));
    });

    $('#nav-connections .connections-form .form-control').on('input', function () {
        const config = getConnectionFormConfig('create');
        handleConnectionFieldInput($(this), config);
    });

    // Hide Rename tooltip on focus/typing; clear field errors — view/edit form
    $('#view-connection-title').on('focus keydown input', function () {
        hideConnectionNameTooltipWhileTyping($(this));
    });

    $('#view-connection-title').on('input', function () {
        const config = getConnectionFormConfig('update');
        const value = $.trim($(this).val());
        const $error = $(this).closest('.title-connections').find('.error-message');

        if (value !== '') {
            $(this).removeClass('input-error');
            $error.hide().text('');
            clearConnectionNameErrorTooltip($(this));
        }

        if (!hasInvalidConnectionFields(config)) {
            $(config.alertSelector).hide();
        }
    });

    $('#view-connection-title').on('blur', function () {
        restoreConnectionNameTooltipAfterTyping($(this));
    });

    $('#connections-view-edit .connections-view-form .form-control').on('input', function () {
        const config = getConnectionFormConfig('update');
        handleConnectionFieldInput($(this), config);
    });

    function handleConnectionFieldInput($input, config) {
        const value = $.trim($input.val());
        const $error = $input.closest('.field-group').find('.error-message');
        const fieldId = $input.attr('id');

        if (fieldId === config.endPointSelector.replace('#', '')) {
            if (value === '') {
                $input.removeClass('input-error');
                $error.hide().text('');
            } else if (!isValidEndPoint(value)) {
                $input.addClass('input-error');
                $error.text('Please put a valid url').show();
            } else {
                $input.removeClass('input-error');
                $error.hide().text('');
            }
        } else if (fieldId === config.connectionIdSelector.replace('#', '')) {
            if (value === '') {
                $input.removeClass('input-error');
                $error.hide().text('');
            } else if (!isValidConnectionIdFormat(value)) {
                $input.addClass('input-error');
                $error.text('Please enter connection ID in format source-connectionId-clientId.').show();
            } else {
                $input.removeClass('input-error');
                $error.hide().text('');
            }
        } else if (value !== '') {
            $input.removeClass('input-error');
            $error.hide().text('');
        }
        if (!hasInvalidConnectionFields(config)) {
            $(config.alertSelector).hide();
        }
    }
    // Global function for inline onclick
    window.switchTab = function (tab) {
        const payloadBtn = document.getElementById('payloadTabBtn');
        const responseBtn = document.getElementById('responseTabBtn');
        const payloadContent = document.getElementById('payloadTabContent');
        const responseContent = document.getElementById('responseTabContent');
        if (tab === 'payload') {
            payloadBtn.classList.add('active');
            responseBtn.classList.remove('active');
            payloadContent.style.display = 'block';
            responseContent.style.display = 'none';
        } else {
            responseBtn.classList.add('active');
            payloadBtn.classList.remove('active');
            responseContent.style.display = 'block';
            payloadContent.style.display = 'none';
        }
    };

    window.copyResponse = function () {
        var responseContent = document.getElementById('responseTabContent');
        var isResponseTab = responseContent && responseContent.style.display !== 'none';
        var jsonText = isResponseTab
            ? (window.__gatewayResponseJson || '')
            : (window.__gatewayPayloadJson || '');

        if (!jsonText) {
            return;
        }

        navigator.clipboard.writeText(jsonText).then(function () {
            var toastId = isResponseTab ? 'copiedToast' : 'copiedToastPayload';
            var toast = document.getElementById(toastId);

            if (toast) {
                toast.classList.add('show');

                setTimeout(function () {
                    toast.classList.remove('show');
                }, 1500);
            }
        }).catch(function (err) {
            console.error('Copy failed:', err);
        });
    };



    window.toggleMenu = function (e) {
        e.stopPropagation();

        var menu = e.currentTarget.parentElement.querySelector('.dots-menu');

        if (menu) {
            document.querySelectorAll('.dots-menu.show').forEach(function (openMenu) {
                if (openMenu !== menu) {
                    openMenu.classList.remove('show');
                }
            });
            menu.classList.toggle('show');
        }
    };

    document.addEventListener('click', function () {
        document.querySelectorAll('.dots-menu.show').forEach(function (menu) {
            menu.classList.remove('show');
        });
    });

    window.showToast = function () {
        var toast = document.getElementById('successToast');

        if (toast) {
            toast.classList.add('show');

            setTimeout(function () {
                toast.classList.remove('show');
            }, 2800);
        }
    };

    window.initBootstrapTooltips = function (root) {
        if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) {
            return;
        }

        var $scope = root ? $(root) : $(document);
        var $targets = root
            ? $scope.find('[data-bs-toggle="tooltip"]').addBack('[data-bs-toggle="tooltip"]')
            : $scope.find('[data-bs-toggle="tooltip"]');

        $targets.each(function () {
            var $el = $(this);
            var isHoverOnlyRename = $el.is('[data-connection-name-tooltip], [data-rename-tooltip]');
            var existing = bootstrap.Tooltip.getInstance(this);

            // Rename tooltips: never dispose/recreate here (causes Bootstrap races while typing).
            if (isHoverOnlyRename) {
                if (!existing) {
                    bootstrap.Tooltip.getOrCreateInstance(this, {
                        trigger: 'hover',
                        placement: $el.attr('data-bs-placement') || 'bottom',
                        container: 'body'
                    });
                }
                return;
            }

            if (existing) {
                existing.dispose();
            }
            if ($el.is('.sync-name')) {
                bootstrap.Tooltip.getOrCreateInstance(this, {
                    trigger: 'hover',
                    placement: 'right',
                    container: 'body',
                    boundary: 'viewport',
                    // An omitted fallback list uses Bootstrap's default sides.
                    // Keep Sync Name details on the right instead.
                    fallbackPlacements: []
                });
            } 
            else {
                bootstrap.Tooltip.getOrCreateInstance(this);
            }
        });
    };

    $(function () {
        window.initBootstrapTooltips();
    });

});
